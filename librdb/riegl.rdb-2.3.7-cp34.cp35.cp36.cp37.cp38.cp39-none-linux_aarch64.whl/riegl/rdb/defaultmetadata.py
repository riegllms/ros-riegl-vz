#
#*******************************************************************************
#
#  Copyright 2020 RIEGL Laser Measurement Systems
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
#  SPDX-License-Identifier: Apache-2.0
#
#*******************************************************************************
#
"""
*******************************************************************************
*
* \author  RIEGL LMS GmbH, Austria
* \brief   Description of RIEGL RDB 2 database meta data items.
* \version 2015-10-27/AW: Initial version
* \version 2015-11-25/AW: Item "Geo Tag" added
* \version 2016-10-27/AW: Item "Voxel Information" added
* \version 2016-11-17/AW: Item "Voxel Information" updated
* \version 2016-12-12/AW: Item "Range Statistics" added
* \version 2017-03-08/AW: Item "Plane Patch Statistics" added
* \version 2017-04-05/AW: Items "Atmosphere" and "Geometric Scale Factor" added
* \version 2017-08-22/AW: Items for waveform sample block and value files added
* \version 2017-10-24/AW: Item "Gaussian Decomposition" added
* \version 2017-11-13/AW: Item "riegl.scan_pattern" updated
* \version 2017-11-21/AW: Item "riegl.trajectory_info" added
* \version 2018-01-11/AW: Item "riegl.beam_geometry" added
* \version 2018-01-15/AW: Item "riegl.reflectance_calculation" added
* \version 2018-01-15/AW: Item "riegl.near_range_correction" added
* \version 2018-01-15/AW: Item "riegl.device_geometry" added
* \version 2018-02-13/AW: Item "riegl.notch_filter" added
* \version 2018-03-08/AW: Item "riegl.window_echo_correction" added
* \version 2018-03-15/AW: Item "riegl.pulse_position_modulation" added
* \version 2018-05-24/AW: Item "riegl.pixel_info" added
* \version 2018-06-08/AW: Item "riegl.shot_info" added
* \version 2018-06-08/AW: Item "riegl.echo_info" added
* \version 2018-06-14/AW: Item "riegl.mta_settings" added
* \version 2018-06-14/AW: Item "riegl.receiver_internals" added
* \version 2018-06-14/AW: Item "riegl.device_output_limits" added
* \version 2018-06-26/AW: Schema: replace "number" with "integer" if applicable
* \version 2018-07-09/AW: Item "riegl.pose_estimation" added
* \version 2018-07-09/AW: Item "riegl.pose_sensors" added
* \version 2018-09-20/AW: Item "riegl.pointcloud_info" added
* \version 2018-11-08/AW: Item "riegl.scan_pattern" updated
* \version 2018-11-13/AW: Item "riegl.receiver_internals" updated
* \version 2019-03-06/AW: Item "riegl.receiver_internals" updated
* \version 2019-03-21/AW: Item "riegl.device_geometry" updated
* \version 2019-04-15/AW: Item "riegl.point_attribute_groups" added
* \version 2019-04-30/AW: Item "riegl.waveform_settings" added
* \version 2019-10-03/AW: Item "riegl.angular_notch_filter" added
* \version 2019-10-03/AW: Item "riegl.noise_estimates" added
* \version 2019-10-25/AW: Item "riegl.window_analysis" added
* \version 2019-11-06/AW: Item "riegl.georeferencing_parameters" added
* \version 2019-11-27/AW: Item "riegl.plane_patch_matching" added
* \version 2019-12-13/AW: Items for tie-/control objects added
* \version 2019-12-19/AW: Items for tie-/control objects added
* \version 2020-02-04/AW: Item "riegl.detection_probability" added
* \version 2020-02-04/AW: Item "riegl.licenses" added
* \version 2020-04-27/AW: Item "riegl.waveform_info" updated (schema+example)
* \version 2020-09-03/AW: Item "riegl.reflectance_correction" added
* \version 2020-09-10/AW: Item "riegl.device_geometry_passive_channel" added
* \version 2020-09-25/AW: Item "riegl.georeferencing_parameters" updated
* \version 2020-09-25/AW: Item "riegl.trajectory_info" updated
* \version 2020-09-29/AW: Item "riegl.temperature_calculation" added
* \version 2020-10-23/AW: Item "riegl.exponential_decomposition" added (#3709)
* \version 2020-11-30/AW: Item "riegl.notch_filter" updated (schema)
* \version 2020-12-02/AW: Item "riegl.georeferencing_parameters" updated (schema)
* \version 2021-02-02/AW: Item "riegl.plane_slope_class_info" added (rdbplanes/#7)
* \version 2021-02-16/AW: Item "riegl.device_output_limits" updated (schema, #3811)
* \version 2021-03-03/AW: Item "riegl.exponential_decomposition" updated (schema, #3822)
* \version 2021-03-03/AW: Item "riegl.waveform_averaging_settings" added (#3821)
* \version 2021-04-01/AW: Item "riegl.voxel_info" updated (schema, #3854)
* \version 2021-04-16/AW: Item "riegl.voxel_info" updated (schema, #3866)
* \version 2021-09-30/AW: Item "riegl.waveform_info" updated (schema+example, #4016)
* \version 2021-10-04/AW: Improved spelling of the descriptions of some items
*
*******************************************************************************
"""

# Angular notch filter parameters for window glass echoes
RDB_RIEGL_ANGULAR_NOTCH_FILTER             = "riegl.angular_notch_filter"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_TITLE       = "Angular Notch Filter"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_DESCRIPTION = "Angular notch filter parameters for window glass echoes"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_STATUS      = "optional"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_SCHEMA = (
"{\"properties\":{\"range_mean\":{\"type\":\"array\",\"description\":\"Mean range "
"[m]\",\"items\":{\"type\":\"number\"}},\"amplitude_mean\":{\"type\":\"array\",\"desc"
"ription\":\"Mean amplitude [dB]\",\"items\":{\"type\":\"number\"}},\"angle\":{\"ty"
"pe\":\"array\",\"description\":\"Angle "
"[deg]\",\"items\":{\"type\":\"number\"}}},\"description\":\"Angular notch filter"
" parameters for window glass echoes\",\"required\":[\"angle\",\"range_mean\","
"\"amplitude_mean\"],\"type\":\"object\",\"$schema\":\"http://json-schema.org/dr"
"aft-04/schema#\",\"title\":\"Angular Notch Filter\"}"
)
RDB_RIEGL_ANGULAR_NOTCH_FILTER_EXAMPLE = (
"{\"range_mean\":[0.094,0.094,0.09075,0.08675,0.0815,0.0775,0.074,0.071,0"
".068,0.0675,0.06475],\"amplitude_mean\":[3.780913,3.780913,3.480913,3.12"
"0913,2.850913,2.720913,2.680913,2.610913,2.530913,2.570913,2.570913],\""
"angle\":[14.0,15.0,16.0,17.0,18.0,19.0,20.0,21.0,22.0,23.0,24.0]}"
)

# Atmospheric parameters
RDB_RIEGL_ATMOSPHERE             = "riegl.atmosphere"
RDB_RIEGL_ATMOSPHERE_TITLE       = "Atmosphere"
RDB_RIEGL_ATMOSPHERE_DESCRIPTION = "Atmospheric parameters"
RDB_RIEGL_ATMOSPHERE_STATUS      = "optional"
RDB_RIEGL_ATMOSPHERE_SCHEMA = (
"{\"properties\":{\"attenuation\":{\"type\":\"number\",\"description\":\"Atmospher"
"ic attenuation "
"[1/km]\"},\"rel_humidity\":{\"type\":\"number\",\"description\":\"Relative "
"humidity along measurement path "
"[%]\"},\"group_velocity\":{\"type\":\"number\",\"description\":\"Group velocity "
"of laser beam "
"[m/s]\"},\"pressure_sl\":{\"type\":\"number\",\"description\":\"Atmospheric "
"pressure at sea level "
"[mbar]\"},\"wavelength\":{\"type\":\"number\",\"description\":\"Laser wavelength"
" [nm]\"},\"amsl\":{\"type\":\"number\",\"description\":\"Height above mean sea "
"level (AMSL) [m]\"},\"pressure\":{\"type\":\"number\",\"description\":\"Pressure"
" along measurment path "
"[mbar]\"},\"temperature\":{\"type\":\"number\",\"description\":\"Temperature "
"along measurement path [\\u00b0C]\"}},\"description\":\"Atmospheric paramet"
"ers\",\"required\":[\"temperature\",\"pressure\",\"rel_humidity\",\"pressure_sl\""
",\"amsl\",\"group_velocity\",\"attenuation\",\"wavelength\"],\"type\":\"object\",\""
"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Atmospheri"
"c Parameters\"}"
)
RDB_RIEGL_ATMOSPHERE_EXAMPLE = (
"{\"attenuation\":0.028125,\"rel_humidity\":63,\"group_velocity\":299711000.0"
",\"pressure_sl\":970,\"wavelength\":1550,\"amsl\":0,\"pressure\":970,\"temperat"
"ure\":7}"
)

# Laser beam geometry details
RDB_RIEGL_BEAM_GEOMETRY             = "riegl.beam_geometry"
RDB_RIEGL_BEAM_GEOMETRY_TITLE       = "Beam Geometry"
RDB_RIEGL_BEAM_GEOMETRY_DESCRIPTION = "Laser beam geometry details"
RDB_RIEGL_BEAM_GEOMETRY_STATUS      = "optional"
RDB_RIEGL_BEAM_GEOMETRY_SCHEMA = (
"{\"properties\":{\"beam_exit_diameter\":{\"type\":\"number\",\"description\":\"Be"
"am width at exit aperture [m]\",\"exclusiveMinimum\":false,\"minimum\":0},\""
"beam_divergence\":{\"type\":\"number\",\"description\":\"Beam divergence in "
"far field "
"[rad]\",\"exclusiveMinimum\":false,\"minimum\":0}},\"description\":\"Laser "
"beam geometry details\",\"required\":[\"beam_exit_diameter\",\"beam_divergen"
"ce\"],\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema"
"#\",\"title\":\"Beam Geometry\"}"
)
RDB_RIEGL_BEAM_GEOMETRY_EXAMPLE = (
"{\"beam_exit_diameter\":0.0072,\"beam_divergence\":0.0003}"
)

# List of control object type definitions
RDB_RIEGL_CONTROL_OBJECT_CATALOG             = "riegl.control_object_catalog"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_TITLE       = "Control Object Catalog"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_DESCRIPTION = "List of control object type definitions"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_STATUS      = "optional"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_SCHEMA = (
"{\"properties\":{\"types\":{\"type\":\"array\",\"uniqueItems\":true,\"items\":{\"ty"
"pe\":\"object\",\"oneOf\":[{\"$ref\":\"#/definitions/rectangle\"},{\"$ref\":\"#/de"
"finitions/checkerboard2x2\"},{\"$ref\":\"#/definitions/chevron\"},{\"$ref\":\""
"#/definitions/circular_disk\"},{\"$ref\":\"#/definitions/cylinder\"},{\"$ref"
"\":\"#/definitions/sphere\"},{\"$ref\":\"#/definitions/round_corner_cube_pri"
"sm\"}]}}},\"description\":\"List of control object type definitions\",\"requ"
"ired\":[\"types\"],\"type\":\"object\",\"$schema\":\"http://json-schema.org/draf"
"t-04/schema#\",\"title\":\"Control Object Catalog\",\"definitions\":{\"cylinde"
"r\":{\"type\":\"object\",\"description\":\"cylinder\",\"allOf\":[{\"$ref\":\"#/defin"
"itions/common\"},{\"type\":\"object\",\"properties\":{\"shape\":{\"type\":\"string"
"\",\"description\":\"shape identifier\",\"enum\":[\"cylinder\"]},\"diameter\":{\"t"
"ype\":\"number\",\"description\":\"diameter in meters\",\"exclusiveMinimum\":tr"
"ue,\"minimum\":0},\"height\":{\"type\":\"number\",\"description\":\"height in "
"meters\",\"exclusiveMinimum\":true,\"minimum\":0}},\"description\":\"cylinder "
"specific properties\",\"required\":[\"shape\",\"diameter\",\"height\"]}]},\"roun"
"d_corner_cube_prism\":{\"type\":\"object\",\"description\":\"round corner cube"
" prism\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"type\":\"object\",\"pro"
"perties\":{\"shape\":{\"type\":\"string\",\"description\":\"shape identifier\",\"e"
"num\":[\"round_corner_cube_prism\"]},\"diameter\":{\"type\":\"number\",\"descrip"
"tion\":\"diameter in meters\",\"exclusiveMinimum\":true,\"minimum\":0},\"offse"
"t\":{\"type\":\"number\",\"description\":\"offset in meters, e.g. reflector "
"constant (optional)\"}},\"description\":\"round corner cube prism specific"
" properties\",\"required\":[\"shape\",\"diameter\"]}]},\"common\":{\"type\":\"obje"
"ct\",\"properties\":{\"name\":{\"type\":\"string\",\"description\":\"unique type i"
"dentifier\",\"minLength\":3},\"shape\":{\"type\":\"string\",\"description\":\"shap"
"e identifier\",\"enum\":[\"rectangle\",\"checkerboard2x2\",\"chevron\",\"circula"
"r_disk\",\"cylinder\",\"sphere\",\"round_corner_cube_prism\"]},\"description\":"
"{\"type\":\"string\",\"description\":\"string describing the "
"object\"},\"surface_type\":{\"type\":\"string\",\"description\":\"surface "
"material type\",\"enum\":[\"retro_reflective_foil\",\"diffuse\"]}},\"descripti"
"on\":\"common object properties\",\"required\":[\"name\",\"shape\"]},\"chevron\":"
"{\"type\":\"object\",\"description\":\"chevron\",\"allOf\":[{\"$ref\":\"#/definitio"
"ns/common\"},{\"type\":\"object\",\"properties\":{\"shape\":{\"type\":\"string\",\"d"
"escription\":\"shape identifier\",\"enum\":[\"chevron\"]},\"thickness\":{\"type\""
":\"number\",\"description\":\"thickness in meters\",\"exclusiveMinimum\":true,"
"\"minimum\":0},\"outside_edge_length\":{\"type\":\"number\",\"description\":\"len"
"gth of the two outer edges in "
"meters\",\"exclusiveMinimum\":true,\"minimum\":0}},\"description\":\"chevron "
"specific properties\",\"required\":[\"shape\",\"outside_edge_length\",\"thickn"
"ess\"]}]},\"sphere\":{\"type\":\"object\",\"description\":\"sphere\",\"allOf\":[{\"$"
"ref\":\"#/definitions/common\"},{\"type\":\"object\",\"properties\":{\"shape\":{\""
"type\":\"string\",\"description\":\"shape identifier\",\"enum\":[\"sphere\"]},\"di"
"ameter\":{\"type\":\"number\",\"description\":\"diameter in "
"meters\",\"exclusiveMinimum\":true,\"minimum\":0}},\"description\":\"sphere "
"specific properties\",\"required\":[\"shape\",\"diameter\"]}]},\"checkerboard2"
"x2\":{\"type\":\"object\",\"description\":\"checkerboard 2 by 2\",\"allOf\":[{\"$r"
"ef\":\"#/definitions/common\"},{\"type\":\"object\",\"properties\":{\"shape\":{\"t"
"ype\":\"string\",\"description\":\"shape identifier\",\"enum\":[\"checkerboard2x"
"2\"]},\"square_length\":{\"type\":\"number\",\"description\":\"length of a "
"square of the checkerboard in meters\",\"exclusiveMinimum\":true,\"minimum"
"\":0}},\"description\":\"checkerboard specific properties\",\"required\":[\"sh"
"ape\",\"square_length\"]}]},\"circular_disk\":{\"type\":\"object\",\"description"
"\":\"circular disk\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"type\":\"ob"
"ject\",\"properties\":{\"shape\":{\"type\":\"string\",\"description\":\"shape iden"
"tifier\",\"enum\":[\"circular_disk\"]},\"diameter\":{\"type\":\"number\",\"descrip"
"tion\":\"diameter in meters\",\"exclusiveMinimum\":true,\"minimum\":0},\"offse"
"t\":{\"type\":\"number\",\"description\":\"offset in meters, e.g. reflector "
"constant (optional)\"}},\"description\":\"circular disk specific propertie"
"s\",\"required\":[\"shape\",\"diameter\"]}]},\"rectangle\":{\"type\":\"object\",\"de"
"scription\":\"rectangle\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"type"
"\":\"object\",\"properties\":{\"shape\":{\"type\":\"string\",\"enum\":[\"rectangle\"]"
"},\"width\":{\"type\":\"number\",\"description\":\"width in meters\",\"exclusiveM"
"inimum\":true,\"minimum\":0},\"length\":{\"type\":\"number\",\"description\":\"len"
"gth in "
"meters\",\"exclusiveMinimum\":true,\"minimum\":0}},\"description\":\"rectangle"
" specific properties\",\"required\":[\"shape\",\"length\",\"width\"]}]}}}"
)
RDB_RIEGL_CONTROL_OBJECT_CATALOG_EXAMPLE = (
"{\"types\":[{\"name\":\"Rectangle "
"60x30\",\"shape\":\"rectangle\",\"description\":\"Rectangle (60cm x "
"30cm)\",\"width\":0.3,\"length\":0.6},{\"name\":\"Rectangle "
"80x40\",\"shape\":\"rectangle\",\"description\":\"Rectangle (80cm x "
"40cm)\",\"width\":0.4,\"length\":0.8},{\"name\":\"Checkerboard2x2 "
"30\",\"shape\":\"checkerboard2x2\",\"description\":\"Checkerboard (square "
"length: 30cm)\",\"square_length\":0.3},{\"name\":\"Checkerboard2x2 "
"50\",\"shape\":\"checkerboard2x2\",\"description\":\"Checkerboard (square "
"length: 50cm)\",\"square_length\":0.5},{\"name\":\"Chevron "
"24''/4''\",\"shape\":\"chevron\",\"description\":\"Chevron (a=24''; b=4'')\",\"t"
"hickness\":0.1016,\"outside_edge_length\":0.6096},{\"name\":\"Circular Disk "
"50\",\"shape\":\"circular_disk\",\"description\":\" Circular Disk (diameter: "
"50cm)\",\"surface_type\":\"diffuse\",\"diameter\":0.5},{\"name\":\"RIEGL flat "
"reflector 50 mm\",\"diameter\":0.05,\"description\":\"flat circular "
"reflector from retro-reflective foil\",\"offset\":0.0,\"shape\":\"circular_d"
"isk\",\"surface_type\":\"retro_reflective_foil\"},{\"name\":\"RIEGL flat "
"reflector 100 mm\",\"diameter\":0.1,\"description\":\"flat circular "
"reflector from retro-reflective foil\",\"offset\":0.0,\"shape\":\"circular_d"
"isk\",\"surface_type\":\"retro_reflective_foil\"},{\"name\":\"RIEGL flat "
"reflector 150 mm\",\"diameter\":0.15,\"description\":\"flat circular "
"reflector from retro-reflective foil\",\"offset\":0.0,\"shape\":\"circular_d"
"isk\",\"surface_type\":\"retro_reflective_foil\"},{\"name\":\"RIEGL "
"cylindrical reflector 50 "
"mm\",\"diameter\":0.05,\"description\":\"cylindrical reflector from "
"retro-reflective foil\",\"surface_type\":\"retro_reflective_foil\",\"shape\":"
"\"cylinder\",\"height\":0.05},{\"name\":\"RIEGL cylindrical reflector 100 "
"mm\",\"diameter\":0.1,\"description\":\"cylindrical reflector from "
"retro-reflective foil\",\"surface_type\":\"retro_reflective_foil\",\"shape\":"
"\"cylinder\",\"height\":0.1},{\"name\":\"Sphere 200 "
"mm\",\"shape\":\"sphere\",\"description\":\"Sphere (diameter: 200 "
"mm)\",\"diameter\":0.2},{\"name\":\"Corner Cube Prism 50 "
"mm\",\"shape\":\"round_corner_cube_prism\",\"description\":\"round corner cube"
" prism\",\"offset\":0.0,\"diameter\":0.05}],\"comments\":[\"This file contains"
" a list of control object types (aka. 'catalog').\",\"Each type is "
"described by an object,\",\"which must contain at least the following "
"parameters:\",\"  - name: unique identifier of the type\",\"  - shape: one"
" of the following supported shapes:\",\"      - rectangle\",\"      - "
"checkerboard2x2\",\"      - chevron\",\"      - circular_disk\",\"      - "
"cylinder\",\"      - sphere\",\"      - "
"round_corner_cube_prism\",\"Depending on 'shape', the following "
"parameters must/may be specified:\",\"  - rectangle:\",\"      - length: "
"length in meters\",\"      - width: width in meters\",\"  - "
"checkerboard2x2:\",\"      - square_length: length of a square of the "
"checkerboard in meters\",\"  - circular_disk:\",\"      - diameter: "
"diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
"constant (optional)\",\"  - chevron:\",\"      - outside_edge_length: "
"length of the two outer edges in meters\",\"      - thickness: thickness"
" in meters\",\"  - cylinder:\",\"      - diameter: diameter in meters\",\""
"      - height:  height in meters\",\"  - sphere:\",\"      - diameter: "
"diameter in meters\",\"  - round_corner_cube_prism:\",\"      - diameter: "
"diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
"constant (optional)\",\"Optional parameters:\",\"    - description: string"
" describing the object\",\"    - surface_type: surface material type "
"(either 'retro_reflective_foil' or 'diffuse')\"]}"
)

# Details about the control object reference file
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE             = "riegl.control_object_reference_file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_TITLE       = "Control Object Reference file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_DESCRIPTION = "Details about the control object reference file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_STATUS      = "optional"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_SCHEMA = (
"{\"type\":\"object\",\"properties\":{\"reference_file\":{\"type\":\"object\",\"prop"
"erties\":{\"file_path\":{\"type\":\"string\",\"description\":\"Path of the "
"control object file relative to referring "
"file\"},\"file_uuid\":{\"type\":\"string\",\"description\":\"Control object "
"file's Universally Unique Identifier (RFC "
"4122)\"}},\"description\":\"Reference to a control object file\",\"required\""
":[\"file_uuid\",\"file_path\"]}},\"$schema\":\"http://json-schema.org/draft-0"
"4/schema#\",\"title\":\"Control Object Reference "
"file\",\"description\":\"Details about the control object reference file\"}"
)
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_EXAMPLE = (
"{\"reference_file\":{\"file_path\":\"../../../10_CONTROL_OBJECTS/ControlPoi"
"nts.cpx\",\"file_uuid\":\"810f5d57-eccf-49ed-b07a-0cdd109b4213\"}}"
)

# Detection probability as a function of amplitude
RDB_RIEGL_DETECTION_PROBABILITY             = "riegl.detection_probability"
RDB_RIEGL_DETECTION_PROBABILITY_TITLE       = "Detection Probability"
RDB_RIEGL_DETECTION_PROBABILITY_DESCRIPTION = "Detection probability as a function of amplitude"
RDB_RIEGL_DETECTION_PROBABILITY_STATUS      = "optional"
RDB_RIEGL_DETECTION_PROBABILITY_SCHEMA = (
"{\"properties\":{\"detection_probability\":{\"type\":\"array\",\"description\":\""
"Detection probability [0..1]\",\"items\":{\"type\":\"number\"}},\"amplitude\":{"
"\"type\":\"array\",\"description\":\"Amplitude "
"[dB]\",\"items\":{\"type\":\"number\"}}},\"description\":\"Detection probability"
" as a function of amplitude\",\"required\":[\"amplitude\",\"detection_probab"
"ility\"],\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/sch"
"ema#\",\"title\":\"Detection Probability\"}"
)
RDB_RIEGL_DETECTION_PROBABILITY_EXAMPLE = (
"{\"detection_probability\":[0.0,0.5,0.8,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0]"
",\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0]}"
)

# Details about the device used to acquire the point cloud
RDB_RIEGL_DEVICE             = "riegl.device"
RDB_RIEGL_DEVICE_TITLE       = "Device Information"
RDB_RIEGL_DEVICE_DESCRIPTION = "Details about the device used to acquire the point cloud"
RDB_RIEGL_DEVICE_STATUS      = "optional"
RDB_RIEGL_DEVICE_SCHEMA = (
"{\"properties\":{\"device_name\":{\"type\":\"string\",\"description\":\"Optional "
"device name (e.g. 'Scanner 1' for multi-scanner "
"systems)\"},\"channel_text\":{\"type\":\"string\",\"description\":\"Optional "
"channel description (e.g. 'Green Channel' for multi-channel "
"devices)\"},\"channel_number\":{\"type\":\"integer\",\"description\":\"Laser "
"channel number (not defined or 0: single channel device)\",\"exclusiveMi"
"nimum\":false,\"minimum\":0},\"device_build\":{\"type\":\"string\",\"description"
"\":\"Device build "
"variant\"},\"serial_number\":{\"type\":\"string\",\"description\":\"Device "
"serial number (e.g. "
"S2221234)\"},\"device_type\":{\"type\":\"string\",\"description\":\"Device type "
"identifier (e.g. VZ-400i)\"}},\"description\":\"Details about the device "
"used to acquire the point cloud\",\"required\":[\"device_type\",\"serial_num"
"ber\"],\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schem"
"a#\",\"title\":\"Device Information\"}"
)
RDB_RIEGL_DEVICE_EXAMPLE = (
"{\"device_name\":\"Scanner 1\",\"channel_text\":\"\",\"channel_number\":0,\"devic"
"e_build\":\"\",\"serial_number\":\"S2221234\",\"device_type\":\"VZ-400i\"}"
)

# Scanner device geometry details
RDB_RIEGL_DEVICE_GEOMETRY             = "riegl.device_geometry"
RDB_RIEGL_DEVICE_GEOMETRY_TITLE       = "Device Geometry"
RDB_RIEGL_DEVICE_GEOMETRY_DESCRIPTION = "Scanner device geometry details"
RDB_RIEGL_DEVICE_GEOMETRY_STATUS      = "optional"
RDB_RIEGL_DEVICE_GEOMETRY_SCHEMA = (
"{\"properties\":{\"amu\":{\"type\":\"object\",\"properties\":{\"frameCC\":{\"type\":"
"\"number\",\"description\":\"Frame Circle Count (number of LSBs per full "
"rotation about frame axis)\",\"exclusiveMinimum\":false,\"minimum\":0},\"lin"
"eCC\":{\"type\":\"number\",\"description\":\"Line Circle Count (number of LSBs"
" per full rotation about line "
"axis)\",\"exclusiveMinimum\":false,\"minimum\":0}},\"description\":\"Angle "
"Measurement Unit\"},\"primary\":{\"type\":\"object\",\"properties\":{\"content\":"
"{\"type\":\"array\",\"description\":\"Internal calibration values\",\"items\":{\""
"type\":\"number\"}},\"ID\":{\"type\":\"array\",\"description\":\"Structure identif"
"ier\",\"items\":{\"type\":\"integer\"},\"maxItems\":2,\"minItems\":2}},\"descripti"
"on\":\"Primary device geometry structure (mandatory)\",\"required\":[\"ID\",\""
"content\"]},\"secondary\":{\"type\":\"object\",\"properties\":{\"content\":{\"type"
"\":\"array\",\"description\":\"Internal calibration values\",\"items\":{\"type\":"
"\"number\"}},\"ID\":{\"type\":\"array\",\"description\":\"Structure identifier\",\""
"items\":{\"type\":\"integer\"},\"maxItems\":2,\"minItems\":2}},\"description\":\"A"
"dditional device geometry structure "
"(optional)\",\"required\":[\"ID\",\"content\"]}},\"description\":\"Scanner "
"device geometry details\",\"required\":[\"primary\"],\"type\":\"object\",\"$sche"
"ma\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Device "
"Geometry\"}"
)
RDB_RIEGL_DEVICE_GEOMETRY_EXAMPLE = (
"{\"amu\":{\"frameCC\":124000,\"lineCC\":124000},\"primary\":{\"content\":[0],\"ID"
"\":[4,0]},\"secondary\":{\"content\":[0],\"ID\":[91,0]}}"
)

# Scanner passive channel device geometry details
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL             = "riegl.device_geometry_passive_channel"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_TITLE       = "Device Geometry Passive Channel"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_DESCRIPTION = "Scanner passive channel device geometry details"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_STATUS      = "optional"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_SCHEMA = (
"{\"properties\":{\"primary\":{\"type\":\"object\",\"properties\":{\"content\":{\"ty"
"pe\":\"array\",\"description\":\"Internal calibration values\",\"items\":{\"type"
"\":\"number\"}},\"ID\":{\"type\":\"array\",\"description\":\"Structure identifier\""
",\"items\":{\"type\":\"integer\"},\"maxItems\":2,\"minItems\":2}},\"description\":"
"\"Primary device geometry structure "
"(mandatory)\",\"required\":[\"ID\",\"content\"]}},\"description\":\"Scanner "
"passive channel device geometry details\",\"required\":[\"primary\"],\"type\""
":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":"
"\"Device Geometry Passive Channel\"}"
)
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_EXAMPLE = (
"{\"primary\":{\"content\":[0],\"ID\":[143,0]}}"
)

# Limits of the measured values output by the device
RDB_RIEGL_DEVICE_OUTPUT_LIMITS             = "riegl.device_output_limits"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_TITLE       = "Device Output Limits"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_DESCRIPTION = "Limits of the measured values output by the device"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_STATUS      = "optional"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_SCHEMA = (
"{\"type\":\"object\",\"properties\":{\"echo_count_maximum\":{\"type\":\"number\",\""
"description\":\"Maximum number of echoes a laser shot can "
"have.\"},\"deviation_minimum\":{\"type\":\"number\",\"description\":\"Minimum "
"possible pulse shape deviation.\"},\"background_radiation_minimum\":{\"typ"
"e\":\"number\",\"description\":\"Minimum possible background "
"radiation.\"},\"range_maximum\":{\"type\":\"number\",\"description\":\"Maximum "
"possible range in meters.\"},\"reflectance_minimum\":{\"type\":\"number\",\"de"
"scription\":\"Minimum possible reflectance in "
"dB.\"},\"amplitude_maximum\":{\"type\":\"number\",\"description\":\"Maximum "
"possible amplitude in "
"dB.\"},\"reflectance_maximum\":{\"type\":\"number\",\"description\":\"Maximum "
"possible reflectance in dB.\"},\"background_radiation_maximum\":{\"type\":\""
"number\",\"description\":\"Maximum possible background "
"radiation.\"},\"range_minimum\":{\"type\":\"number\",\"description\":\"Minimum "
"possible range in "
"meters.\"},\"deviation_maximum\":{\"type\":\"number\",\"description\":\"Maximum "
"possible pulse shape deviation.\"},\"mta_zone_count_maximum\":{\"type\":\"nu"
"mber\",\"description\":\"Maximum number of MTA "
"zones.\"},\"amplitude_minimum\":{\"type\":\"number\",\"description\":\"Minimum "
"possible amplitude in dB.\"}},\"$schema\":\"http://json-schema.org/draft-0"
"4/schema#\",\"title\":\"Device Output Limits\",\"description\":\"Limits of the"
" measured values output by the device. The limits depend on the device"
" type, measurement program and/or scan pattern.\"}"
)
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_EXAMPLE = (
"{\"reflectance_maximum\":100.0,\"deviation_minimum\":-1,\"range_minimum\":2."
"9,\"background_radiation_minimum\":0,\"range_maximum\":10000.0,\"deviation_"
"maximum\":32767,\"reflectance_minimum\":-100.0,\"amplitude_minimum\":0.0,\"b"
"ackground_radiation_maximum\":0,\"mta_zone_count_maximum\":7,\"amplitude_m"
"aximum\":100.0}"
)

# Details about echo files
RDB_RIEGL_ECHO_INFO             = "riegl.echo_info"
RDB_RIEGL_ECHO_INFO_TITLE       = "Echo Information"
RDB_RIEGL_ECHO_INFO_DESCRIPTION = "Details about echo files"
RDB_RIEGL_ECHO_INFO_STATUS      = "optional"
RDB_RIEGL_ECHO_INFO_SCHEMA = (
"{\"properties\":{\"echo_file\":{\"type\":\"object\",\"properties\":{\"file_extens"
"ion\":{\"type\":\"string\",\"description\":\"Echo file extension, without the "
"leading dot\"},\"file_uuid\":{\"type\":\"string\",\"description\":\"File's "
"Universally Unique Identifier (RFC "
"4122)\"}},\"required\":[\"file_extension\"]}},\"description\":\"Details about "
"echo files\",\"required\":[\"echo_file\"],\"type\":\"object\",\"$schema\":\"http:/"
"/json-schema.org/draft-04/schema#\",\"title\":\"Echo Information\"}"
)
RDB_RIEGL_ECHO_INFO_EXAMPLE = (
"{\"echo_file\":{\"file_extension\":\"owp\",\"file_uuid\":\"26a03615-67c0-4bea-8"
"fe8-c577378fe661\"}}"
)

# Details for exponential decomposition of full waveform data
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION             = "riegl.exponential_decomposition"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_TITLE       = "Exponential Decomposition"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_DESCRIPTION = "Details for exponential decomposition of full waveform data"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_STATUS      = "optional"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_SCHEMA = (
"{\"description\":\"Details for exponential decomposition of full waveform"
" data\",\"type\":\"object\",\"additionalProperties\":false,\"$schema\":\"http://"
"json-schema.org/draft-04/schema#\",\"patternProperties\":{\"^[0-9]+$\":{\"de"
"scription\":\"one field per channel, field name is channel "
"index\",\"$ref\":\"#/definitions/channel\"}},\"title\":\"Exponential Decomposi"
"tion\",\"definitions\":{\"channel\":{\"type\":\"object\",\"properties\":{\"scale\":"
"{\"type\":\"number\",\"description\":\"amplitude calibration\"},\"parameter\":{\""
"type\":\"object\",\"properties\":{\"gamma\":{\"type\":\"array\",\"description\":\"de"
"cay in 1/second\",\"items\":{\"type\":\"number\"}},\"omega\":{\"type\":\"array\",\"d"
"escription\":\"angular frequency in "
"Hz\",\"items\":{\"type\":\"number\"}},\"A\":{\"type\":\"array\",\"description\":\"real"
" part of amplitude factor in units of full-scale\",\"items\":{\"type\":\"num"
"ber\"}},\"B\":{\"type\":\"array\",\"description\":\"imaginary part of amplitude "
"factor in units of "
"full-scale\",\"items\":{\"type\":\"number\"}}},\"description\":\"parameters of "
"the syswave exponential sum\",\"required\":[\"A\",\"B\",\"gamma\",\"omega\"]},\"de"
"lay\":{\"type\":\"number\",\"description\":\"delay calibration in "
"seconds\"},\"a_lin\":{\"description\":\"relative linear amplitude range [0.."
"1]\",\"exclusiveMaximum\":false,\"exclusiveMinimum\":false,\"type\":\"number\","
"\"maximum\":1,\"minimum\":0}},\"required\":[\"delay\",\"scale\",\"parameter\"]}}}"
)
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_EXAMPLE = (
"{\"1\":{\"scale\":1.0,\"parameter\":{\"gamma\":[-1094726528.0,-769562752.0,-84"
"8000064.0],\"omega\":[352020896.0,3647927552.0,-1977987072.0],\"A\":[0.9,0"
".3,-1.3],\"B\":[-3.9,0.0,-0.3]},\"delay\":3.5e-09,\"a_lin\":0.9},\"0\":{\"scale"
"\":1.0,\"parameter\":{\"gamma\":[-1094726528.0,-769562752.0,-848000064.0],\""
"omega\":[352020896.0,3647927552.0,-1977987072.0],\"A\":[0.977245092391967"
"8,0.3354335129261017,-1.312678575515747],\"B\":[-3.9813032150268555,0.08"
"622030913829803,-0.3152860999107361]},\"delay\":3.783458418887631e-09,\"a"
"_lin\":0.27}}"
)

# Details for Gaussian decomposition of full waveform data
RDB_RIEGL_GAUSSIAN_DECOMPOSITION             = "riegl.gaussian_decomposition"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_TITLE       = "Gaussian Decomposition"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_DESCRIPTION = "Details for Gaussian decomposition of full waveform data"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_STATUS      = "optional"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_SCHEMA = (
"{\"properties\":{\"range_offset_sec_high_power\":{\"type\":\"array\",\"items\":{"
"\"type\":\"number\"}},\"range_offset_sec_low_power\":{\"type\":\"array\",\"items\""
":{\"type\":\"number\"}},\"amplitude_lsb_low_power\":{\"type\":\"array\",\"items\":"
"{\"type\":\"number\"}},\"amplitude_db\":{\"type\":\"array\",\"items\":{\"type\":\"num"
"ber\"}},\"amplitude_lsb_high_power\":{\"type\":\"array\",\"items\":{\"type\":\"num"
"ber\"}}},\"description\":\"riegl.gaussian_decomposition contains "
"information relevant for extracting calibrated amplitudes and "
"calibrated ranges from a Gaussian decomposition of full waveform data."
" This information is contained in a table with five columns. Two "
"columns are to be used as input: amplitude_lsb_low_power and "
"amplitude_lsb_high_power. The other three columns provide the outputs."
" Amplitude_db gives the calibrated amplitude in the optical regime in "
"decibels. The range offset columns provide additive range offsets, "
"given in units of seconds, for each channel.\",\"required\":[\"amplitude_l"
"sb_low_power\",\"amplitude_lsb_high_power\",\"amplitude_db\",\"range_offset_"
"sec_low_power\",\"range_offset_sec_high_power\"],\"type\":\"object\",\"$schema"
"\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Gaussian "
"Decomposition\"}"
)
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_EXAMPLE = (
"{\"range_offset_sec_high_power\":[],\"range_offset_sec_low_power\":[],\"amp"
"litude_lsb_low_power\":[],\"amplitude_db\":[],\"amplitude_lsb_high_power\":"
"[]}"
)

# Point cloud georeferencing information
RDB_RIEGL_GEO_TAG             = "riegl.geo_tag"
RDB_RIEGL_GEO_TAG_TITLE       = "Geo Tag"
RDB_RIEGL_GEO_TAG_DESCRIPTION = "Point cloud georeferencing information"
RDB_RIEGL_GEO_TAG_STATUS      = "optional"
RDB_RIEGL_GEO_TAG_SCHEMA = (
"{\"type\":\"object\",\"properties\":{\"pose\":{\"type\":\"array\",\"description\":\"C"
"oordinate Transformation Matrix to transform from File Coordinate "
"System to Global Coordinate Reference System. 4x4 matrix stored as two"
" dimensional array, row major order.\",\"items\":{\"type\":\"array\",\"descrip"
"tion\":\"rows\",\"items\":{\"type\":\"number\",\"description\":\"columns\"},\"maxIte"
"ms\":4,\"minItems\":4},\"maxItems\":4,\"minItems\":4},\"crs\":{\"type\":\"object\","
"\"properties\":{\"name\":{\"type\":\"string\",\"description\":\"Coordinate "
"reference system name\"},\"epsg\":{\"type\":\"integer\",\"description\":\"EPSG "
"code\",\"minimum\":0},\"wkt\":{\"type\":\"string\",\"description\":\"\\\"Well-Known "
"Text\\\" string, OGC WKT dialect (see http://www.opengeospatial.org/stan"
"dards/wkt-crs)\"}},\"description\":\"Global Coordinate Reference System. "
"Please note that only 3D Cartesian Coordinate Systems are allowed.\"}},"
"\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Geo "
"Tag\",\"description\":\"Point cloud georeferencing information\"}"
)
RDB_RIEGL_GEO_TAG_EXAMPLE = (
"{\"pose\":[[-0.269827776749716,-0.723017716139738,0.635954678449952,4063"
"882.500831],[0.962908599449764,-0.20260517250352,0.178208229833847,113"
"8787.607461],[0.0,0.660451759194338,0.7508684796801,4766084.550196],[0"
".0,0.0,0.0,1.0]],\"crs\":{\"name\":\"WGS84 "
"Geocentric\",\"epsg\":4978,\"wkt\":\"GEOCCS[\\\"WGS84 Geocentric\\\",DATUM[\\\"WGS"
"84\\\",SPHEROID[\\\"WGS84\\\",6378137.000,298.257223563,AUTHORITY[\\\"EPSG\\\",\\"
"\"7030\\\"]],AUTHORITY[\\\"EPSG\\\",\\\"6326\\\"]],PRIMEM[\\\"Greenwich\\\",0.0000000"
"000000000,AUTHORITY[\\\"EPSG\\\",\\\"8901\\\"]],UNIT[\\\"Meter\\\",1.0000000000000"
"0000000,AUTHORITY[\\\"EPSG\\\",\\\"9001\\\"]],AXIS[\\\"X\\\",OTHER],AXIS[\\\"Y\\\",EAS"
"T],AXIS[\\\"Z\\\",NORTH],AUTHORITY[\\\"EPSG\\\",\\\"4978\\\"]]\"}}"
)

# Geometric scale factor applied to point coordinates
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR             = "riegl.geometric_scale_factor"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_TITLE       = "Geometric Scale Factor"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_DESCRIPTION = "Geometric scale factor applied to point coordinates"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_STATUS      = "optional"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_SCHEMA = (
"{\"type\":\"number\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\""
"description\":\"Geometric scale factor applied to point "
"coordinates\",\"exclusiveMinimum\":true,\"minimum\":0}"
)
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_EXAMPLE = (
"1.0"
)

# Parameters used for georeferencing of the point cloud
RDB_RIEGL_GEOREFERENCING_PARAMETERS             = "riegl.georeferencing_parameters"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_TITLE       = "Georeferencing Parameters"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_DESCRIPTION = "Parameters used for georeferencing of the point cloud"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_STATUS      = "optional"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_SCHEMA = (
"{\"type\":\"object\",\"properties\":{\"body_coordinate_system_type\":{\"type\":\""
"string\",\"description\":\"BODY coordinate frame (NED: North-East-Down, "
"ENU: East-North-Up), default: NED\",\"enum\":[\"NED\",\"ENU\"]},\"socs_to_rocs"
"_matrix\":{\"type\":\"array\",\"description\":\"Coordinate Transformation "
"Matrix to transform from Scanner's Own Coordinate System to Record "
"Coordinate System. 4x4 matrix stored as two dimensional array, row "
"major order.\",\"items\":{\"type\":\"array\",\"description\":\"rows\",\"items\":{\"t"
"ype\":\"number\",\"description\":\"columns\"},\"maxItems\":4,\"minItems\":4},\"max"
"Items\":4,\"minItems\":4},\"socs_to_body_matrix\":{\"type\":\"array\",\"descript"
"ion\":\"Coordinate Transformation Matrix to transform from Scanner's Own"
" Coordinate System to Body Coordinate System. 4x4 matrix stored as two"
" dimensional array, row major order.\",\"items\":{\"type\":\"array\",\"descrip"
"tion\":\"rows\",\"items\":{\"type\":\"number\",\"description\":\"columns\"},\"maxIte"
"ms\":4,\"minItems\":4},\"maxItems\":4,\"minItems\":4},\"trajectory_file\":{\"typ"
"e\":\"object\",\"properties\":{\"file_extension\":{\"type\":\"string\",\"descripti"
"on\":\"Trajectory file extension, without the leading "
"dot\"},\"file_uuid\":{\"type\":\"string\",\"description\":\"File's Universally "
"Unique Identifier (RFC 4122)\"}},\"description\":\"Trajectory data used "
"for georeferencing of the point cloud\",\"required\":[\"file_extension\"]},"
"\"trajectory_offsets\":{\"type\":\"object\",\"properties\":{\"version\":{\"type\":"
"\"integer\",\"description\":\"Meaning of offset values and how to apply "
"them; version 0: "
"Rz(yaw+offset_yaw)*Ry(pitch+offset_pitch)*Rx(roll+offset_roll), "
"version 1: Rz(yaw)*Ry(pitch)*Rx(roll) * Rz(yaw_offset)*Ry(pitch_offset"
")*Rx(roll_offset)\"},\"offset_time\":{\"type\":\"number\",\"description\":\"[s]\""
"},\"offset_yaw\":{\"type\":\"number\",\"description\":\"[deg]\"},\"offset_pitch\":"
"{\"type\":\"number\",\"description\":\"[deg]\"},\"offset_east\":{\"type\":\"number\""
",\"description\":\"[m]\"},\"offset_height\":{\"type\":\"number\",\"description\":\""
"[m]\"},\"offset_north\":{\"type\":\"number\",\"description\":\"[m]\"},\"offset_rol"
"l\":{\"type\":\"number\",\"description\":\"[deg]\"}},\"description\":\"Correction "
"offsets applied to the trajectory data\"}},\"$schema\":\"http://json-schem"
"a.org/draft-04/schema#\",\"title\":\"Georeferencing "
"Parameters\",\"description\":\"Parameters used for georeferencing of the "
"point cloud\"}"
)
RDB_RIEGL_GEOREFERENCING_PARAMETERS_EXAMPLE = (
"{\"body_coordinate_system_type\":\"NED\",\"socs_to_body_matrix\":[[-0.269827"
"776749716,-0.723017716139738,0.635954678449952,0.0],[0.962908599449764"
",-0.20260517250352,0.178208229833847,0.0],[0.0,0.660451759194338,0.750"
"8684796801,0.0],[0.0,0.0,0.0,1.0]],\"trajectory_file\":{\"file_extension\""
":\"pofx\",\"file_uuid\":\"93a03615-66c0-4bea-8ff8-c577378fe660\"},\"trajector"
"y_offsets\":{\"version\":0,\"offset_time\":18.007,\"offset_yaw\":-0.45,\"offse"
"t_pitch\":0.01,\"offset_east\":0.15,\"offset_height\":-0.2,\"offset_north\":0"
".07,\"offset_roll\":0.03}}"
)

# License keys for software features
RDB_RIEGL_LICENSES             = "riegl.licenses"
RDB_RIEGL_LICENSES_TITLE       = "Software License Keys"
RDB_RIEGL_LICENSES_DESCRIPTION = "License keys for software features"
RDB_RIEGL_LICENSES_STATUS      = "optional"
RDB_RIEGL_LICENSES_SCHEMA = (
"{\"description\":\"License keys for software features\",\"type\":\"object\",\"a"
"dditionalProperties\":false,\"$schema\":\"http://json-schema.org/draft-04/"
"schema#\",\"title\":\"Software License "
"Keys\",\"patternProperties\":{\"^.*$\":{\"type\":\"array\",\"description\":\"Each "
"field of the object represents a feature and holds a list of license "
"keys, where the field name is the feature "
"name.\",\"items\":{\"type\":\"string\",\"description\":\"License key (example: "
"'46AE032A - 39882AC4 - 9EC0A184 - 6F163D73')\"},\"minItems\":1}}}"
)
RDB_RIEGL_LICENSES_EXAMPLE = (
"{\"MTA resolution\":[\"468E020A - 39A922E4 - B681A184 - 673E3D72\"],\"Full "
"Waveform Analysis Topography\":[\"0FD5FF07 - 011A1255 - 9F76CACA - "
"8D2ED557\"],\"Full Waveform Analysis Topography with GPU "
"support\":[\"8AB44126 - 23B92250 - 16E2689F - "
"34EF7E7B\"],\"Georeferencing\":[\"46AE032A - 39882AC4 - 9EC0A184 - "
"6F163D73\"]}"
)

# Parameters for MTA processing
RDB_RIEGL_MTA_SETTINGS             = "riegl.mta_settings"
RDB_RIEGL_MTA_SETTINGS_TITLE       = "MTA Settings"
RDB_RIEGL_MTA_SETTINGS_DESCRIPTION = "Parameters for MTA processing"
RDB_RIEGL_MTA_SETTINGS_STATUS      = "optional"
RDB_RIEGL_MTA_SETTINGS_SCHEMA = (
"{\"type\":\"object\",\"properties\":{\"modulation_depth\":{\"type\":\"number\",\"de"
"scription\":\"Depth of pulse position modulation in meter.\",\"minimum\":0}"
",\"zone_count\":{\"type\":\"integer\",\"maximum\":255,\"description\":\"Maximum "
"number of MTA zones.\",\"minimum\":0},\"zone_width\":{\"type\":\"number\",\"desc"
"ription\":\"Width of a MTA zone in meter.\",\"minimum\":0}},\"$schema\":\"http"
"://json-schema.org/draft-04/schema#\",\"title\":\"MTA "
"Settings\",\"description\":\"Parameters for MTA processing\"}"
)
RDB_RIEGL_MTA_SETTINGS_EXAMPLE = (
"{\"modulation_depth\":9.368514,\"zone_count\":23,\"zone_width\":149.896225}"
)

# Lookup table for range correction based on raw range
RDB_RIEGL_NEAR_RANGE_CORRECTION             = "riegl.near_range_correction"
RDB_RIEGL_NEAR_RANGE_CORRECTION_TITLE       = "Near Range Correction Table"
RDB_RIEGL_NEAR_RANGE_CORRECTION_DESCRIPTION = "Lookup table for range correction based on raw range"
RDB_RIEGL_NEAR_RANGE_CORRECTION_STATUS      = "optional"
RDB_RIEGL_NEAR_RANGE_CORRECTION_SCHEMA = (
"{\"properties\":{\"content\":{\"type\":\"array\",\"description\":\"Correction "
"value [m] to be added to the raw range\",\"items\":{\"type\":\"number\"},\"max"
"Items\":2000,\"minItems\":1},\"delta\":{\"type\":\"number\",\"description\":\"Delt"
"a between table entries [m], first entry is at range = 0 "
"m\"}},\"description\":\"Lookup table for range correction based on raw ran"
"ge\",\"required\":[\"delta\",\"content\"],\"type\":\"object\",\"$schema\":\"http://j"
"son-schema.org/draft-04/schema#\",\"title\":\"Near Range Correction "
"Table\"}"
)
RDB_RIEGL_NEAR_RANGE_CORRECTION_EXAMPLE = (
"{\"content\":[0.0],\"delta\":0.512}"
)

# Standard deviation for range and amplitude as a function of amplitude
RDB_RIEGL_NOISE_ESTIMATES             = "riegl.noise_estimates"
RDB_RIEGL_NOISE_ESTIMATES_TITLE       = "Noise Estimates"
RDB_RIEGL_NOISE_ESTIMATES_DESCRIPTION = "Standard deviation for range and amplitude as a function of amplitude"
RDB_RIEGL_NOISE_ESTIMATES_STATUS      = "optional"
RDB_RIEGL_NOISE_ESTIMATES_SCHEMA = (
"{\"properties\":{\"amplitude_sigma\":{\"type\":\"array\",\"description\":\"Sigma "
"amplitude [dB]\",\"items\":{\"type\":\"number\"}},\"range_sigma\":{\"type\":\"arra"
"y\",\"description\":\"Sigma range [m]\",\"items\":{\"type\":\"number\"}},\"amplitu"
"de\":{\"type\":\"array\",\"description\":\"Amplitude "
"[dB]\",\"items\":{\"type\":\"number\"}}},\"description\":\"Standard deviation "
"for range and amplitude as a function of amplitude\",\"required\":[\"ampli"
"tude\",\"range_sigma\",\"amplitude_sigma\"],\"type\":\"object\",\"$schema\":\"http"
"://json-schema.org/draft-04/schema#\",\"title\":\"Noise Estimates\"}"
)
RDB_RIEGL_NOISE_ESTIMATES_EXAMPLE = (
"{\"amplitude_sigma\":[0.988,0.988,0.875,0.774,0.686,0.608,0.54,0.482,0.4"
"32,0.39,0.354],\"range_sigma\":[0.065,0.056,0.046,0.038,0.032,0.027,0.02"
"4,0.021,0.018,0.016,0.014],\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7."
"0,8.0,9.0,10.0]}"
)

# Notch filter parameters for window glass echoes
RDB_RIEGL_NOTCH_FILTER             = "riegl.notch_filter"
RDB_RIEGL_NOTCH_FILTER_TITLE       = "Notch Filter"
RDB_RIEGL_NOTCH_FILTER_DESCRIPTION = "Notch filter parameters for window glass echoes"
RDB_RIEGL_NOTCH_FILTER_STATUS      = "optional"
RDB_RIEGL_NOTCH_FILTER_SCHEMA = (
"{\"properties\":{\"amplitude_maximum\":{\"type\":\"number\",\"description\":\"Max"
"imum amplitude [dB]\",\"minimum\":0},\"range_maximum\":{\"type\":\"number\",\"de"
"scription\":\"Maximum range "
"[m]\"},\"range_minimum\":{\"type\":\"number\",\"description\":\"Minimum range "
"[m]\"}},\"description\":\"Notch filter parameters for window glass echoes\""
",\"required\":[\"range_minimum\",\"range_maximum\",\"amplitude_maximum\"],\"typ"
"e\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title"
"\":\"Notch Filter\"}"
)
RDB_RIEGL_NOTCH_FILTER_EXAMPLE = (
"{\"amplitude_maximum\":18.0,\"range_maximum\":0.2,\"range_minimum\":-0.5}"
)

# Details about the pixels contained in the file
RDB_RIEGL_PIXEL_INFO             = "riegl.pixel_info"
RDB_RIEGL_PIXEL_INFO_TITLE       = "Pixel Information"
RDB_RIEGL_PIXEL_INFO_DESCRIPTION = "Details about the pixels contained in the file"
RDB_RIEGL_PIXEL_INFO_STATUS      = "optional"
RDB_RIEGL_PIXEL_INFO_SCHEMA = (
"{\"properties\":{\"size\":{\"description\":\"Size of pixels in file "
"coordinate system.\",\"$ref\":\"#/definitions/pixel_size\"},\"size_llcs\":{\"d"
"escription\":\"Size of pixels in a locally levelled cartesian coordinate"
" system (xy). This is only used for pixels based on a map projection.\""
",\"$ref\":\"#/definitions/pixel_size\"}},\"description\":\"Details about the "
"pixels contained in the file\",\"required\":[\"size\"],\"type\":\"object\",\"$sc"
"hema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Pixel Informa"
"tion\",\"definitions\":{\"pixel_size\":{\"type\":\"array\",\"description\":\"Size "
"of pixels.\",\"items\":{\"type\":\"number\",\"description\":\"Length of pixel "
"edge [m].\",\"minimum\":0},\"maxItems\":2,\"minItems\":2}}}"
)
RDB_RIEGL_PIXEL_INFO_EXAMPLE = (
"{\"size\":[0.5971642834779395,0.5971642834779395],\"size_llcs\":[0.5156575"
"252891171,0.5130835356683303]}"
)

# Details about the plane patch matching process
RDB_RIEGL_PLANE_PATCH_MATCHING             = "riegl.plane_patch_matching"
RDB_RIEGL_PLANE_PATCH_MATCHING_TITLE       = "Plane Patch Matching"
RDB_RIEGL_PLANE_PATCH_MATCHING_DESCRIPTION = "Details about the plane patch matching process"
RDB_RIEGL_PLANE_PATCH_MATCHING_STATUS      = "optional"
RDB_RIEGL_PLANE_PATCH_MATCHING_SCHEMA = (
"{\"properties\":{\"plane_patch_file_one\":{\"description\":\"Reference to the"
" plane patch file one\",\"$ref\":\"#/definitions/file_reference\"},\"plane_p"
"atch_file_two\":{\"description\":\"Reference to the plane patch file "
"two\",\"$ref\":\"#/definitions/file_reference\"}},\"description\":\"Details "
"about the plane patch matching process\",\"required\":[\"plane_patch_file_"
"one\",\"plane_patch_file_two\"],\"type\":\"object\",\"$schema\":\"http://json-sc"
"hema.org/draft-04/schema#\",\"title\":\"Plane Patch Matching\",\"definitions"
"\":{\"file_reference\":{\"type\":\"object\",\"properties\":{\"file_path\":{\"type\""
":\"string\",\"description\":\"Path of the plane patch file relative to the "
"match file\"},\"file_uuid\":{\"type\":\"string\",\"description\":\"Plane patch "
"file's Universally Unique Identifier (RFC "
"4122)\"}},\"description\":\"Reference to a plane patch "
"file\",\"required\":[\"file_uuid\",\"file_path\"]}}}"
)
RDB_RIEGL_PLANE_PATCH_MATCHING_EXAMPLE = (
"{\"plane_patch_file_one\":{\"file_path\":\"Record009_Line001/191025_121410_"
"Scanner_1.ptch\",\"file_uuid\":\"810f5d57-eccf-49ed-b07a-0cdd109b4213\"},\"p"
"lane_patch_file_two\":{\"file_path\":\"project.ptch\",\"file_uuid\":\"fa47d509"
"-a64e-49ce-8b14-ff3130fbefa9\"}}"
)

# Statistics about plane patches found by plane patch extractor
RDB_RIEGL_PLANE_PATCH_STATISTICS             = "riegl.plane_patch_statistics"
RDB_RIEGL_PLANE_PATCH_STATISTICS_TITLE       = "Plane Patch Statistics"
RDB_RIEGL_PLANE_PATCH_STATISTICS_DESCRIPTION = "Statistics about plane patches found by plane patch extractor"
RDB_RIEGL_PLANE_PATCH_STATISTICS_STATUS      = "optional"
RDB_RIEGL_PLANE_PATCH_STATISTICS_SCHEMA = (
"{\"type\":\"object\",\"properties\":{\"total_horizontal_area\":{\"type\":\"number"
"\",\"description\":\"sum of all plane patch areas projected to horizontal "
"plane [m\\u00b2]\"},\"total_area\":{\"type\":\"number\",\"description\":\"sum of "
"all plane patch areas [m\\u00b2]\"}},\"$schema\":\"http://json-schema.org/d"
"raft-04/schema#\",\"title\":\"Plane Patch "
"Statistics\",\"description\":\"Statistics about plane patches found by "
"plane patch extractor\"}"
)
RDB_RIEGL_PLANE_PATCH_STATISTICS_EXAMPLE = (
"{\"total_horizontal_area\":13954.601,\"total_area\":14007.965}"
)

# Settings and classes for plane slope classification
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO             = "riegl.plane_slope_class_info"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_TITLE       = "Plane Slope Class Info"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_DESCRIPTION = "Settings and classes for plane slope classification"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_STATUS      = "optional"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_SCHEMA = (
"{\"properties\":{\"classes\":{\"type\":\"object\",\"additionalProperties\":false"
",\"description\":\"Class definition table\",\"patternProperties\":{\"^[0-9]+$"
"\":{\"type\":\"string\",\"description\":\"one field per class, field name is "
"class number, field value is class name\"}}},\"settings\":{\"type\":\"object"
"\",\"oneOf\":[{\"$ref\":\"#/definitions/method-1\"},{\"$ref\":\"#/definitions/me"
"thod-2\"}],\"description\":\"Classification settings, details see "
"documentation of rdbplanes\"}},\"description\":\"Settings and classes for "
"plane slope classification\",\"required\":[\"settings\",\"classes\"],\"type\":\""
"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"P"
"lane Slope Class Info\",\"definitions\":{\"method-1\":{\"type\":\"object\",\"pro"
"perties\":{\"plane_classification_method\":{\"type\":\"integer\",\"maximum\":1,"
"\"description\":\"method ID (=1)\",\"minimum\":1},\"maximum_inclination_angle"
"_horizontal\":{\"type\":\"number\",\"maximum\":360.0,\"description\":\"maximum "
"inclination angle of horizontal plane patches "
"[deg]\",\"minimum\":-360.0}},\"description\":\"Classification method 1\",\"req"
"uired\":[\"plane_classification_method\",\"maximum_inclination_angle_horiz"
"ontal\"]},\"method-2\":{\"type\":\"object\",\"properties\":{\"plane_classificati"
"on_method\":{\"type\":\"integer\",\"maximum\":2,\"description\":\"method ID (=2)"
"\",\"minimum\":2},\"sloping_plane_classes_minimum_angle\":{\"type\":\"number\","
"\"maximum\":360.0,\"description\":\"minimum inclination angle of sloping "
"plane patches [deg]\",\"minimum\":-360.0},\"sloping_plane_classes_maximum_"
"angle\":{\"type\":\"number\",\"maximum\":360.0,\"description\":\"maximum "
"inclination angle of sloping plane patches "
"[deg]\",\"minimum\":-360.0}},\"description\":\"Classification method 2\",\"req"
"uired\":[\"plane_classification_method\",\"sloping_plane_classes_minimum_a"
"ngle\",\"sloping_plane_classes_maximum_angle\"]}}}"
)
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_EXAMPLE = (
"{\"classes\":{\"14\":\"horizontal, pointing down\",\"3\":\"sloping, pointing up"
" and south\",\"2\":\"sloping, pointing up and east\",\"12\":\"sloping, "
"pointing down and north\",\"11\":\"sloping, pointing down and "
"south\",\"10\":\"sloping, pointing down and east\",\"6\":\"vertical, pointing "
"east\",\"5\":\"sloping, pointing up and west\",\"1\":\"horizontal, pointing "
"up\",\"7\":\"vertical, pointing south\",\"8\":\"vertical, pointing "
"north\",\"9\":\"vertical, pointing west\",\"4\":\"sloping, pointing up and "
"north\",\"13\":\"sloping, pointing down and west\"},\"settings\":{\"plane_clas"
"sification_method\":2,\"sloping_plane_classes_minimum_angle\":10.0,\"slopi"
"ng_plane_classes_maximum_angle\":70.0}}"
)

# Grouping and sorting of point attributes for visualization purposes
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS             = "riegl.point_attribute_groups"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_TITLE       = "Point Attribute Groups"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_DESCRIPTION = "Grouping and sorting of point attributes for visualization purposes"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_STATUS      = "optional"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_SCHEMA = (
"{\"description\":\"Grouping and sorting of point attributes for "
"visualization purposes\",\"type\":\"object\",\"additionalProperties\":false,\""
"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Point "
"Attribute Groups\",\"patternProperties\":{\"^.*$\":{\"type\":\"array\",\"descrip"
"tion\":\"Each field of the object represents a point attribute group and"
" holds a list of point attributes, where the field name is the group "
"name.\",\"items\":{\"type\":\"string\",\"description\":\"Point attribute full "
"name or name pattern (perl regular expression "
"syntax)\"},\"minItems\":1}}}"
)
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_EXAMPLE = (
"{\"Time\":[\"riegl.timestamp\"],\"Coordinates/Vectors\":[\"riegl.xyz\",\"riegl."
"range\",\"riegl.theta\",\"riegl.phi\"],\"Other "
"Attributes\":[\"riegl.selected\",\"riegl.visible\"],\"Primary Attributes\":[\""
"riegl.reflectance\",\"riegl.amplitude\",\"riegl.deviation\"],\"Secondary "
"Attributes\":[\"riegl.mirror_facet\",\"riegl.waveform_available\"]}"
)

# Details about point cloud files
RDB_RIEGL_POINTCLOUD_INFO             = "riegl.pointcloud_info"
RDB_RIEGL_POINTCLOUD_INFO_TITLE       = "Point Cloud Information"
RDB_RIEGL_POINTCLOUD_INFO_DESCRIPTION = "Details about point cloud files"
RDB_RIEGL_POINTCLOUD_INFO_STATUS      = "optional"
RDB_RIEGL_POINTCLOUD_INFO_SCHEMA = (
"{\"type\":\"object\",\"properties\":{\"project\":{\"type\":\"string\",\"description"
"\":\"Project "
"name\"},\"field_of_application\":{\"type\":\"string\",\"description\":\"Field of"
" application\",\"enum\":[\"unknown\",\"SLS\",\"TLS\",\"KLS\",\"MLS\",\"ULS\",\"ALS\",\"B"
"LS\",\"ILS\"]},\"comments\":{\"type\":\"string\",\"description\":\"Comments\"}},\"$s"
"chema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Point Cloud "
"Information\",\"description\":\"Details about point cloud files\"}"
)
RDB_RIEGL_POINTCLOUD_INFO_EXAMPLE = (
"{\"project\":\"Campaign 4\",\"field_of_application\":\"ALS\",\"comments\":\"Line "
"3\"}"
)

# Estimated position and orientation information
RDB_RIEGL_POSE_ESTIMATION             = "riegl.pose_estimation"
RDB_RIEGL_POSE_ESTIMATION_TITLE       = "Pose Estimation"
RDB_RIEGL_POSE_ESTIMATION_DESCRIPTION = "Estimated position and orientation information"
RDB_RIEGL_POSE_ESTIMATION_STATUS      = "optional"
RDB_RIEGL_POSE_ESTIMATION_SCHEMA = (
"{\"properties\":{\"barometric_height_amsl\":{\"type\":\"number\",\"description\""
":\"Altitude determined based on the atmospheric pressure according to "
"the standard atmosphere laws [m].\"},\"orientation\":{\"type\":\"object\",\"pr"
"operties\":{\"pitch_accuracy\":{\"type\":\"number\",\"description\":\"Pitch "
"angle accuracy [deg]\",\"exclusiveMinimum\":true,\"minimum\":0},\"roll_accur"
"acy\":{\"type\":\"number\",\"description\":\"Roll angle accuracy [deg]\",\"exclu"
"siveMinimum\":true,\"minimum\":0},\"roll\":{\"type\":\"number\",\"maximum\":360,\""
"description\":\"Roll angle about scanner X-axis [deg]\",\"minimum\":-360},\""
"yaw\":{\"type\":\"number\",\"maximum\":360,\"description\":\"Yaw angle about "
"scanner Z-axis [deg]\",\"minimum\":-360},\"yaw_accuracy\":{\"type\":\"number\","
"\"description\":\"Yaw angle accuracy [deg]\",\"exclusiveMinimum\":true,\"mini"
"mum\":0},\"pitch\":{\"type\":\"number\",\"maximum\":360,\"description\":\"Pitch "
"angle about scanner Y-axis "
"[deg]\",\"minimum\":-360}},\"description\":\"Orientation values and "
"orientation accuracies, measured with IMU or inclination sensors.\",\"re"
"quired\":[\"roll\",\"pitch\",\"yaw\",\"roll_accuracy\",\"pitch_accuracy\",\"yaw_ac"
"curacy\"]},\"position\":{\"type\":\"object\",\"properties\":{\"coordinate_3\":{\"t"
"ype\":\"number\",\"description\":\"Coordinate 3 as defined by axis 3 of the "
"specified CRS (e.g., Z, Altitude)\"},\"crs\":{\"type\":\"object\",\"properties"
"\":{\"epsg\":{\"type\":\"integer\",\"description\":\"EPSG "
"code\",\"minimum\":0},\"wkt\":{\"type\":\"string\",\"description\":\"\\\"Well-Known "
"Text\\\" string, OGC WKT dialect (see http://www.opengeospatial.org/stan"
"dards/wkt-crs)\"}},\"description\":\"Global Coordinate Reference System\",\""
"required\":[\"epsg\"]},\"coordinate_1\":{\"type\":\"number\",\"description\":\"Coo"
"rdinate 1 as defined by axis 1 of the specified CRS (e.g., X, Latitude"
")\"},\"vertical_accuracy\":{\"type\":\"number\",\"description\":\"Vertical "
"accuracy [m]\",\"exclusiveMinimum\":true,\"minimum\":0},\"horizontal_accurac"
"y\":{\"type\":\"number\",\"description\":\"Horizontal accuracy [m]\",\"exclusive"
"Minimum\":true,\"minimum\":0},\"coordinate_2\":{\"type\":\"number\",\"descriptio"
"n\":\"Coordinate 2 as defined by axis 2 of the specified CRS (e.g., Y, "
"Longitude)\"}},\"description\":\"Position coordinates and position "
"accuracy values as measured by GNSS in the specified Coordinate "
"Reference System (CRS)\",\"required\":[\"coordinate_1\",\"coordinate_2\",\"coo"
"rdinate_3\",\"horizontal_accuracy\",\"vertical_accuracy\",\"crs\"]}},\"descrip"
"tion\":\"Estimated position and orientation information as measured by "
"GNSS, IMU or inclination sensors\",\"required\":[\"orientation\"],\"type\":\"o"
"bject\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Po"
"se Estimation\"}"
)
RDB_RIEGL_POSE_ESTIMATION_EXAMPLE = (
"{\"barometric_height_amsl\":386.7457796227932,\"orientation\":{\"pitch_accu"
"racy\":0.009433783936875745,\"roll_accuracy\":0.009433783936875745,\"roll\""
":3.14743073066123,\"yaw\":101.87293630292045,\"yaw_accuracy\":1.0094337839"
"368757,\"pitch\":1.509153024827064},\"position\":{\"coordinate_3\":362.71249"
"38964844,\"crs\":{\"epsg\":4979,\"wkt\":\"GEOGCS[\\\"WGS84 / Geographic\\\",DATUM"
"[\\\"WGS84\\\",SPHEROID[\\\"WGS84\\\",6378137.000,298.257223563,AUTHORITY[\\\"EP"
"SG\\\",\\\"7030\\\"]],AUTHORITY[\\\"EPSG\\\",\\\"6326\\\"]],PRIMEM[\\\"Greenwich\\\",0.0"
"000000000000000,AUTHORITY[\\\"EPSG\\\",\\\"8901\\\"]],UNIT[\\\"Degree\\\",0.017453"
"29251994329547,AUTHORITY[\\\"EPSG\\\",\\\"9102\\\"]],AXIS[\\\"Latitude\\\",NORTH],"
"AXIS[\\\"Longitude\\\",EAST],AUTHORITY[\\\"EPSG\\\",\\\"4979\\\"]]\"},\"coordinate_1"
"\":48.655799473,\"vertical_accuracy\":1.3314999341964722,\"horizontal_accu"
"racy\":0.810699999332428,\"coordinate_2\":15.645033406}}"
)

# Details on position and orientation sensors
RDB_RIEGL_POSE_SENSORS             = "riegl.pose_sensors"
RDB_RIEGL_POSE_SENSORS_TITLE       = "Pose Sensors"
RDB_RIEGL_POSE_SENSORS_DESCRIPTION = "Details on position and orientation sensors"
RDB_RIEGL_POSE_SENSORS_STATUS      = "optional"
RDB_RIEGL_POSE_SENSORS_SCHEMA = (
"{\"properties\":{\"accelerometer\":{\"type\":\"object\",\"properties\":{\"origin\""
":{\"description\":\"Sensor origin in SOCS [m] at frame angle = 0\",\"$ref\":"
"\"#/definitions/vector\"},\"unit\":{\"type\":\"number\",\"description\":\"Unit of"
" raw data and calibration values, 1 LSB in 9.81 m/s\\u00b2\",\"exclusiveM"
"inimum\":true,\"minimum\":0},\"offset\":{\"description\":\"Value to be "
"subtracted from raw measurement values\",\"$ref\":\"#/definitions/vector\"}"
",\"z_axis\":{\"description\":\"Sensitive Z axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":{\"description\":\"Sensitive Y"
" axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"x_axis\":{\"description\":\"Sensitive X"
" axis of sensor at frame angle = 0\",\"$ref\":\"#/definitions/vector\"},\"re"
"lative_nonlinearity\":{\"description\":\"Relative nonlinearity, dimensionl"
"ess\",\"$ref\":\"#/definitions/vector\"}},\"description\":\"Accelerometer deta"
"ils\",\"required\":[\"unit\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\",\"origin\",\""
"relative_nonlinearity\"]},\"gyroscope\":{\"type\":\"object\",\"properties\":{\"o"
"rigin\":{\"description\":\"Sensor origin in SOCS [m] at frame angle = 0\",\""
"$ref\":\"#/definitions/vector\"},\"unit\":{\"type\":\"number\",\"description\":\"U"
"nit of raw data and calibration values, 1 LSB in rad/s\",\"exclusiveMini"
"mum\":true,\"minimum\":0},\"offset\":{\"description\":\"Value to be subtracted"
" from raw measurement values\",\"$ref\":\"#/definitions/vector\"},\"z_axis\":"
"{\"description\":\"Sensitive Z axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":{\"description\":\"Sensitive Y"
" axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"x_axis\":{\"description\":\"Sensitive X"
" axis of sensor at frame angle = 0\",\"$ref\":\"#/definitions/vector\"},\"re"
"lative_nonlinearity\":{\"description\":\"Relative nonlinearity, dimensionl"
"ess\",\"$ref\":\"#/definitions/vector\"}},\"description\":\"Gyroscope details\""
",\"required\":[\"unit\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\",\"origin\",\"rela"
"tive_nonlinearity\"]},\"magnetic_field_sensor\":{\"type\":\"object\",\"propert"
"ies\":{\"relative_nonlinearity\":{\"description\":\"Relative nonlinearity, d"
"imensionless\",\"$ref\":\"#/definitions/vector\"},\"unit\":{\"type\":\"number\",\""
"description\":\"Unit of raw data and calibration values, 1 LSB in nT\",\"e"
"xclusiveMinimum\":true,\"minimum\":0},\"offset\":{\"description\":\"Value to "
"be subtracted from raw measurement values\",\"$ref\":\"#/definitions/vecto"
"r\"},\"z_axis\":{\"description\":\"Sensitive Z axis of sensor at frame angle"
" = "
"0\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":{\"description\":\"Sensitive Y"
" axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"x_axis\":{\"description\":\"Sensitive X"
" axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"fixed\":{\"description\":\"Distortion "
"of magnetic field caused by non-rotating scanner "
"part\",\"$ref\":\"#/definitions/vector\"}},\"description\":\"Magnetic Field "
"Sensor details\",\"required\":[\"unit\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\""
",\"fixed\",\"relative_nonlinearity\"]}},\"description\":\"Details on position"
" and orientation sensors\",\"required\":[\"gyroscope\",\"accelerometer\",\"mag"
"netic_field_sensor\"],\"type\":\"object\",\"$schema\":\"http://json-schema.org"
"/draft-04/schema#\",\"title\":\"Pose Sensors\",\"definitions\":{\"vector\":{\"ty"
"pe\":\"array\",\"maxItems\":3,\"items\":{\"type\":\"number\",\"description\":\"Index"
" 0=X, 1=Y, 2=Z component\"},\"minItems\":3}}}"
)
RDB_RIEGL_POSE_SENSORS_EXAMPLE = (
"{\"accelerometer\":{\"origin\":[0.026900000870227814,-0.03999999910593033,"
"-0.08950000256299973],\"unit\":6.666666740784422e-05,\"offset\":[-733.3636"
"474609375,58.969032287597656,1060.2550048828125],\"z_axis\":[1.639882206"
"916809,15166.744140625,-116.99742889404297],\"y_axis\":[-7.0272889137268"
"07,-44.12333679199219,14952.3701171875],\"x_axis\":[-15008.123046875,56."
"956390380859375,-60.5175666809082],\"relative_nonlinearity\":[0.0,0.0,0."
"0]},\"gyroscope\":{\"origin\":[0.026900000870227814,-0.03999999910593033,-"
"0.08950000256299973],\"unit\":0.00014544410805683583,\"offset\":[-50.92609"
"786987305,146.15643310546875,62.4327278137207],\"z_axis\":[0.55586999654"
"7699,119.22135162353516,0.467585027217865],\"y_axis\":[-0.44076591730117"
"8,-0.7897399663925171,119.5894775390625],\"x_axis\":[-121.195556640625,0"
".8219714164733887,0.2313031703233719],\"relative_nonlinearity\":[2.88817"
"6311444113e-07,1.06274164579645e-07,-1.7186295080634935e-39]},\"magneti"
"c_field_sensor\":{\"relative_nonlinearity\":[0.0,0.0,0.0],\"unit\":91.74311"
"828613281,\"offset\":[-23812.052734375,5606.57666015625,2493.28125],\"z_a"
"xis\":[0.00041987866279669106,7.876977906562388e-05,0.01140710432082414"
"6],\"y_axis\":[0.00027888521435670555,-0.011427424848079681,-5.204829722"
"060822e-05],\"x_axis\":[-0.011162743903696537,-2.315962774446234e-05,0.0"
"0016818844596855342],\"fixed\":[-1576.010498046875,1596.081787109375,0.0"
"]}}"
)

# Laser pulse position modulation used for MTA resolution
RDB_RIEGL_PULSE_POSITION_MODULATION             = "riegl.pulse_position_modulation"
RDB_RIEGL_PULSE_POSITION_MODULATION_TITLE       = "Pulse Position Modulation"
RDB_RIEGL_PULSE_POSITION_MODULATION_DESCRIPTION = "Laser pulse position modulation used for MTA resolution"
RDB_RIEGL_PULSE_POSITION_MODULATION_STATUS      = "optional"
RDB_RIEGL_PULSE_POSITION_MODULATION_SCHEMA = (
"{\"properties\":{\"phase_step\":{\"type\":\"integer\",\"maximum\":255,\"descripti"
"on\":\"Step width in phase of modulation code from line to line\",\"minimu"
"m\":0},\"code_phase_mode\":{\"type\":\"integer\",\"maximum\":255,\"description\":"
"\"0: no synchronization, 1: toggle between 2 phases, 2: increment with "
"phase_increment\",\"minimum\":0},\"num_mod_ampl\":{\"type\":\"integer\",\"maximu"
"m\":255,\"description\":\"Number of different modulation amplitudes (2: "
"binary modulation)\",\"minimum\":0},\"length\":{\"type\":\"integer\",\"maximum\":"
"255,\"description\":\"Length of code\",\"minimum\":0},\"pulse_interval\":{\"typ"
"e\":\"array\",\"description\":\"Explicit table of the pulse position "
"modulation used for MTA resolution. Table gives times between "
"successive laser pulses in "
"seconds.\",\"items\":{\"type\":\"number\",\"minimum\":0}}},\"description\":\"Laser"
" pulse position modulation used for MTA resolution\",\"required\":[\"lengt"
"h\",\"num_mod_ampl\",\"pulse_interval\"],\"type\":\"object\",\"$schema\":\"http://"
"json-schema.org/draft-04/schema#\",\"title\":\"Pulse Position Modulation\"}"
)
RDB_RIEGL_PULSE_POSITION_MODULATION_EXAMPLE = (
"{\"phase_step\":5,\"code_phase_mode\":2,\"num_mod_ampl\":2,\"length\":31,\"puls"
"e_interval\":[2.759375e-06,2.759375e-06,2.759375e-06,2.759375e-06,2.821"
"875e-06,2.759375e-06,2.759375e-06,2.821875e-06,2.759375e-06,2.821875e-"
"06,2.821875e-06,2.759375e-06,2.759375e-06,2.821875e-06,2.821875e-06,2."
"821875e-06,2.821875e-06,2.821875e-06,2.759375e-06,2.759375e-06,2.75937"
"5e-06,2.821875e-06,2.821875e-06,2.759375e-06,2.821875e-06,2.821875e-06"
",2.821875e-06,2.759375e-06,2.821875e-06,2.759375e-06,2.821875e-06]}"
)

# Statistics about target distance wrt. SOCS origin
RDB_RIEGL_RANGE_STATISTICS             = "riegl.range_statistics"
RDB_RIEGL_RANGE_STATISTICS_TITLE       = "Range Statistics"
RDB_RIEGL_RANGE_STATISTICS_DESCRIPTION = "Statistics about target distance wrt. SOCS origin"
RDB_RIEGL_RANGE_STATISTICS_STATUS      = "optional"
RDB_RIEGL_RANGE_STATISTICS_SCHEMA = (
"{\"properties\":{\"maximum\":{\"type\":\"number\",\"description\":\"Maximum "
"value\"},\"std_dev\":{\"type\":\"number\",\"description\":\"Standard "
"deviation\"},\"average\":{\"type\":\"number\",\"description\":\"Average "
"value\"},\"minimum\":{\"type\":\"number\",\"description\":\"Minimum "
"value\"}},\"description\":\"Statistics about target distance wrt. SOCS ori"
"gin\",\"required\":[\"minimum\",\"average\",\"maximum\",\"std_dev\"],\"type\":\"obje"
"ct\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Range"
" Statistics\"}"
)
RDB_RIEGL_RANGE_STATISTICS_EXAMPLE = (
"{\"maximum\":574.35,\"std_dev\":24.349,\"average\":15.49738,\"minimum\":0.919}"
)

# Receiver Internals
RDB_RIEGL_RECEIVER_INTERNALS             = "riegl.receiver_internals"
RDB_RIEGL_RECEIVER_INTERNALS_TITLE       = "Receiver Internals"
RDB_RIEGL_RECEIVER_INTERNALS_DESCRIPTION = "Receiver Internals"
RDB_RIEGL_RECEIVER_INTERNALS_STATUS      = "optional"
RDB_RIEGL_RECEIVER_INTERNALS_SCHEMA = (
"{\"properties\":{\"si\":{\"type\":\"number\",\"maximum\":255,\"description\":\"Star"
"t index (hw_start)\",\"minimum\":0},\"a\":{\"type\":\"array\",\"maxItems\":256,\"i"
"tems\":{\"type\":\"number\"},\"description\":\"Amplitude "
"[dB]\",\"minItems\":1},\"sr\":{\"type\":\"number\",\"description\":\"Sample rate ["
"Hz]\",\"exclusiveMinimum\":true,\"minimum\":0},\"tbl\":{\"type\":\"array\",\"descr"
"iption\":\"various internal data\",\"items\":{\"$ref\":\"#/definitions/fp_tabl"
"e\"},\"minItems\":1},\"ns\":{\"type\":\"integer\",\"maximum\":4095,\"description\":"
"\"Number of samples\",\"minimum\":0},\"nt\":{\"type\":\"integer\",\"maximum\":255,"
"\"description\":\"Number of traces\",\"minimum\":0},\"mw\":{\"type\":\"number\",\"m"
"aximum\":4095,\"description\":\"Maximum weight\",\"exclusiveMinimum\":true,\"m"
"inimum\":0},\"t\":{\"type\":\"object\",\"additionalProperties\":false,\"patternP"
"roperties\":{\"^[0-9]+$\":{\"description\":\"one field per channel, field "
"name is channel index\",\"$ref\":\"#/definitions/fp\"}}},\"ex\":{\"type\":\"obje"
"ct\",\"description\":\"DEPRECATED, use 'riegl.exponential_decomposition' "
"instead\"}},\"description\":\"Receiver Internals\",\"type\":\"object\",\"$schema"
"\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Receiver Internal"
"s\",\"definitions\":{\"fp_table\":{\"type\":\"object\",\"desription\":\"scanner "
"internal data\",\"properties\":{\"tv\":{\"type\":\"array\",\"maxItems\":2048,\"ite"
"ms\":{\"oneOf\":[{\"$ref\":\"#/definitions/fp_table_row\"},{\"type\":\"number\"}]"
"},\"minItems\":1},\"nx\":{\"type\":\"integer\",\"min\":1,\"description\":\"number "
"of x entries\",\"max\":2048},\"ny\":{\"type\":\"integer\",\"min\":1,\"description\""
":\"number of y entries\",\"max\":2048},\"tc\":{\"type\":\"integer\",\"min\":0,\"des"
"cription\":\"table data type "
"code\",\"max\":255},\"ch\":{\"type\":\"integer\",\"min\":0,\"description\":\"channel"
" number\",\"max\":255}},\"required\":[\"ch\",\"tc\",\"nx\",\"ny\",\"tv\"]},\"fp\":{\"typ"
"e\":\"object\",\"properties\":{\"w\":{\"type\":\"array\",\"maxItems\":256,\"items\":{"
"\"type\":\"array\",\"maxItems\":5,\"items\":{\"type\":\"number\"},\"minItems\":5},\"m"
"inItems\":1},\"s\":{\"type\":\"array\",\"maxItems\":256,\"items\":{\"type\":\"array\""
",\"maxItems\":4096,\"items\":{\"type\":\"number\"},\"minItems\":1},\"minItems\":1}"
"},\"description\":\"Fingerprint values\",\"required\":[\"s\",\"w\"]},\"fp_table_r"
"ow\":{\"type\":\"array\",\"maxItems\":2048,\"items\":{\"type\":\"number\"},\"minItem"
"s\":1}}}"
)
RDB_RIEGL_RECEIVER_INTERNALS_EXAMPLE = (
"{\"si\":48,\"a\":[-1.55],\"sr\":7959997000.0,\"tbl\":[{\"tv\":[[1,2,3,4,5],[1.1,"
"2.2,3.3,4.4,5.5]],\"nx\":5,\"ny\":2,\"tc\":1,\"ch\":0}],\"ns\":400,\"nt\":128,\"mw\""
":31,\"t\":{\"1\":{\"w\":[[78,86,126,134,31],[78,86,126,134,31]],\"s\":[[1.23,4"
".56],[7.89,0.12]]},\"0\":{\"w\":[[78,86,126,134,31],[78,86,126,134,31]],\"s"
"\":[[1.23,4.56],[7.89,0.12]]}}}"
)

# List of names of the records
RDB_RIEGL_RECORD_NAMES             = "riegl.record_names"
RDB_RIEGL_RECORD_NAMES_TITLE       = "Record Names"
RDB_RIEGL_RECORD_NAMES_DESCRIPTION = "List of names of the records"
RDB_RIEGL_RECORD_NAMES_STATUS      = "optional"
RDB_RIEGL_RECORD_NAMES_SCHEMA = (
"{\"type\":\"object\",\"properties\":{\"names\":{\"type\":\"array\",\"description\":\""
"List of record names. The name of a record is the {riegl.id}th element"
" of this list. The number of elements must correspond to the maximum "
"riegl.id occurring in this "
"file.\",\"items\":{\"type\":\"string\",\"description\":\"Record name\"}}},\"$schem"
"a\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Record "
"Names\",\"description\":\"List of names of the records\"}"
)
RDB_RIEGL_RECORD_NAMES_EXAMPLE = (
"{\"names\":[\"Name of first record\",\"Name of second record\",\"Name of "
"third record\",\"Name of fourth record\"]}"
)

# Lookup table for reflectance calculation based on amplitude and range
RDB_RIEGL_REFLECTANCE_CALCULATION             = "riegl.reflectance_calculation"
RDB_RIEGL_REFLECTANCE_CALCULATION_TITLE       = "Reflectance Calculation Table"
RDB_RIEGL_REFLECTANCE_CALCULATION_DESCRIPTION = "Lookup table for reflectance calculation based on amplitude and range"
RDB_RIEGL_REFLECTANCE_CALCULATION_STATUS      = "optional"
RDB_RIEGL_REFLECTANCE_CALCULATION_SCHEMA = (
"{\"properties\":{\"content\":{\"type\":\"array\",\"description\":\"Correction "
"value [dB] to be added to the amplitude\",\"items\":{\"type\":\"number\"},\"ma"
"xItems\":2000,\"minItems\":1},\"delta\":{\"type\":\"number\",\"description\":\"Del"
"ta between table entries [m], first entry is at range = 0 "
"m\"}},\"description\":\"Lookup table for reflectance calculation based on "
"amplitude and range\",\"required\":[\"delta\",\"content\"],\"type\":\"object\",\"$"
"schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Reflectance"
" Calculation Table\"}"
)
RDB_RIEGL_REFLECTANCE_CALCULATION_EXAMPLE = (
"{\"content\":[-33.01],\"delta\":0.150918}"
)

# Range-dependent and scan-angle-dependent correction of reflectance reading
RDB_RIEGL_REFLECTANCE_CORRECTION             = "riegl.reflectance_correction"
RDB_RIEGL_REFLECTANCE_CORRECTION_TITLE       = "Near-range reflectance correction"
RDB_RIEGL_REFLECTANCE_CORRECTION_DESCRIPTION = "Range-dependent and scan-angle-dependent correction of reflectance reading"
RDB_RIEGL_REFLECTANCE_CORRECTION_STATUS      = "optional"
RDB_RIEGL_REFLECTANCE_CORRECTION_SCHEMA = (
"{\"properties\":{\"ranges_m\":{\"type\":\"array\",\"description\":\"Range [m]\",\"i"
"tems\":{\"type\":\"number\"}},\"reflectance_correction_db\":{\"type\":\"array\",\""
"description\":\"Near range reflectance correction in dB as a function of"
" range over angle\",\"items\":{\"type\":\"array\",\"description\":\"rows (each "
"array corresponds to a "
"range)\",\"items\":{\"type\":\"number\",\"description\":\"columns (each value "
"corresponds to an "
"angle)\"}}},\"line_angles_deg\":{\"type\":\"array\",\"description\":\"Angle "
"[deg]\",\"items\":{\"type\":\"number\"}}},\"description\":\"Range-dependent and "
"scan-angle-dependent correction of reflectance reading\",\"required\":[\"r"
"anges_m\",\"line_angles_deg\",\"reflectance_correction_db\"],\"type\":\"object"
"\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Near-ra"
"nge reflectance correction\"}"
)
RDB_RIEGL_REFLECTANCE_CORRECTION_EXAMPLE = (
"{\"ranges_m\":[0.0,1.0,2.0,3.0],\"reflectance_correction_db\":[[0.8,0.7,0."
"6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05"
",0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0."
"4,0.3,0.2,0.1,0.05,0.01]],\"line_angles_deg\":[0.0,0.5,1.0,1.5,1.0,2.0,2"
".5,3.0,3.5,4.0]}"
)

# Scan pattern description
RDB_RIEGL_SCAN_PATTERN             = "riegl.scan_pattern"
RDB_RIEGL_SCAN_PATTERN_TITLE       = "Scan Pattern"
RDB_RIEGL_SCAN_PATTERN_DESCRIPTION = "Scan pattern description"
RDB_RIEGL_SCAN_PATTERN_STATUS      = "optional"
RDB_RIEGL_SCAN_PATTERN_SCHEMA = (
"{\"properties\":{\"rectangular\":{\"type\":\"object\",\"properties\":{\"program\":"
"{\"$ref\":\"#/definitions/program\"},\"phi_stop\":{\"type\":\"number\",\"maximum\""
":720.0,\"description\":\"Stop phi angle in SOCS [deg]\",\"minimum\":0.0},\"ph"
"i_increment\":{\"type\":\"number\",\"maximum\":90.0,\"description\":\"Increment "
"of phi angle in SOCS [deg]\",\"minimum\":0.0},\"theta_increment\":{\"type\":\""
"number\",\"maximum\":90.0,\"description\":\"Increment of theta angle in SOCS"
" [deg]\",\"minimum\":0.0},\"theta_stop\":{\"type\":\"number\",\"maximum\":180.0,\""
"description\":\"Stop theta angle in SOCS [deg]\",\"minimum\":0.0},\"phi_star"
"t\":{\"type\":\"number\",\"maximum\":360.0,\"description\":\"Start phi angle in "
"SOCS [deg]\",\"minimum\":0.0},\"theta_start\":{\"type\":\"number\",\"maximum\":18"
"0.0,\"description\":\"Start theta angle in SOCS "
"[deg]\",\"minimum\":0.0}},\"description\":\"Rectangular Field Of View Scan P"
"attern\",\"required\":[\"phi_start\",\"phi_stop\",\"phi_increment\",\"theta_star"
"t\",\"theta_stop\",\"theta_increment\"]},\"segments\":{\"type\":\"object\",\"prope"
"rties\":{\"program\":{\"$ref\":\"#/definitions/program\"},\"list\":{\"type\":\"arr"
"ay\",\"items\":{\"type\":\"object\",\"properties\":{\"start\":{\"type\":\"number\",\"m"
"aximum\":360.0,\"description\":\"Start angle in SOCS [deg]\",\"minimum\":0.0}"
",\"stop\":{\"type\":\"number\",\"maximum\":720.0,\"description\":\"Stop angle in "
"SOCS [deg]\",\"minimum\":0.0},\"increment\":{\"type\":\"number\",\"maximum\":90.0"
",\"description\":\"Increment of angle in SOCS "
"[deg]\",\"minimum\":0.0}},\"description\":\"Line Scan Segment\",\"required\":[\""
"start\",\"stop\",\"increment\"]}}},\"description\":\"Segmented Line Scan Patte"
"rn\",\"required\":[\"list\"]},\"line\":{\"type\":\"object\",\"properties\":{\"progra"
"m\":{\"$ref\":\"#/definitions/program\"},\"start\":{\"type\":\"number\",\"maximum\""
":360.0,\"description\":\"Start angle in SOCS [deg]\",\"minimum\":0.0},\"stop\""
":{\"type\":\"number\",\"maximum\":720.0,\"description\":\"Stop angle in SOCS [d"
"eg]\",\"minimum\":0.0},\"increment\":{\"type\":\"number\",\"maximum\":90.0,\"descr"
"iption\":\"Increment of angle in SOCS "
"[deg]\",\"minimum\":0.0}},\"description\":\"Line Scan Pattern\",\"required\":[\""
"start\",\"stop\",\"increment\"]}},\"$schema\":\"http://json-schema.org/draft-0"
"4/schema#\",\"title\":\"Scan Pattern\",\"description\":\"Scan pattern descript"
"ion\",\"definitions\":{\"program\":{\"type\":\"object\",\"properties\":{\"name\":{\""
"type\":\"string\",\"description\":\"Name of measurement "
"program\"},\"laser_prr\":{\"type\":\"number\",\"description\":\"Laser Pulse "
"Repetition Rate [Hz]\",\"exclusiveMinimum\":false,\"minimum\":0}},\"descript"
"ion\":\"Measurement program\",\"required\":[\"name\"]}}}"
)
RDB_RIEGL_SCAN_PATTERN_EXAMPLE = (
"{\"rectangular\":{\"program\":{\"name\":\"High Speed\",\"laser_prr\":100000.0},\""
"phi_stop\":270.0,\"phi_increment\":0.04,\"theta_increment\":0.04,\"theta_sto"
"p\":130.0,\"phi_start\":45.0,\"theta_start\":30.0}}"
)

# Details about laser shot files
RDB_RIEGL_SHOT_INFO             = "riegl.shot_info"
RDB_RIEGL_SHOT_INFO_TITLE       = "Shot Information"
RDB_RIEGL_SHOT_INFO_DESCRIPTION = "Details about laser shot files"
RDB_RIEGL_SHOT_INFO_STATUS      = "optional"
RDB_RIEGL_SHOT_INFO_SCHEMA = (
"{\"type\":\"object\",\"properties\":{\"shot_file\":{\"type\":\"object\",\"propertie"
"s\":{\"file_extension\":{\"type\":\"string\",\"description\":\"Shot file "
"extension, without the leading "
"dot\"},\"file_uuid\":{\"type\":\"string\",\"description\":\"File's Universally "
"Unique Identifier (RFC 4122)\"}},\"required\":[\"file_extension\"]}},\"$sche"
"ma\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Shot "
"Information\",\"description\":\"Details about laser shot files\"}"
)
RDB_RIEGL_SHOT_INFO_EXAMPLE = (
"{\"shot_file\":{\"file_extension\":\"sodx\",\"file_uuid\":\"26a00815-67c0-4bff-"
"8fe8-c577378fe663\"}}"
)

# Conversion of background radiation raw values to temperatures in °C
RDB_RIEGL_TEMPERATURE_CALCULATION             = "riegl.temperature_calculation"
RDB_RIEGL_TEMPERATURE_CALCULATION_TITLE       = "Temperature Calculation Table"
RDB_RIEGL_TEMPERATURE_CALCULATION_DESCRIPTION = "Conversion of background radiation raw values to temperatures in °C"
RDB_RIEGL_TEMPERATURE_CALCULATION_STATUS      = "optional"
RDB_RIEGL_TEMPERATURE_CALCULATION_SCHEMA = (
"{\"properties\":{\"InGaAs\":{\"description\":\"Conversion table for InGaAs ch"
"annel\",\"$ref\":\"#/definitions/conversion_table\"},\"Si\":{\"description\":\"C"
"onversion table for Si channel\",\"$ref\":\"#/definitions/conversion_table"
"\"},\"InGaAs_Si_Difference\":{\"description\":\"Conversion table for InGaAs "
"- Si difference\",\"$ref\":\"#/definitions/conversion_table\"}},\"descriptio"
"n\":\"Conversion of background radiation raw values to temperatures in \\"
"u00b0C\",\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/sch"
"ema#\",\"title\":\"Temperature Calculation Table\",\"definitions\":{\"conversi"
"on_table\":{\"type\":\"object\",\"properties\":{\"value\":{\"type\":\"array\",\"desc"
"ription\":\"LSB [1]\",\"items\":{\"type\":\"number\"}},\"temperature\":{\"type\":\"a"
"rray\",\"description\":\"Temperature [\\u00b0C]\",\"items\":{\"type\":\"number\"}}"
"},\"required\":[\"value\",\"temperature\"]}}}"
)
RDB_RIEGL_TEMPERATURE_CALCULATION_EXAMPLE = (
"{\"InGaAs\":{\"value\":[0.0,64.00097659230323,128.0019531846065,192.002929"
"7769097,256.0039063692129,320.00488296151616,384.0058595538194,448.006"
"8361461226,512.0078127384259],\"temperature\":[307.22196722535614,309.11"
"53478247277,311.1188086915047,313.10025350480055,315.2137946389828,317"
".2172555057597,319.2207163725366,321.2021611858325,323.3157023200148]}"
",\"Si\":{\"value\":[0.0,64.00097659230323,128.0019531846065,192.0029297769"
"097,256.0039063692129,320.00488296151616,384.0058595538194,448.0068361"
"461226,512.0078127384259],\"temperature\":[546.300048828125,548.81640512"
"12026,551.3143938500972,554.0144257850053,556.604252334815,559.2124464"
"488079,561.8022729986177,564.4104671126105,567.0002936624203]},\"InGaAs"
"_Si_Difference\":{\"value\":[1000.0,1100.090029602954,1200.04425183874,13"
"00.1342814416948,1400.0885036774805,1500.0427259132668,1600.1327555162"
"209,1700.0869777520065,1800.0411999877924],\"temperature\":[1749.9771111"
"17893,1749.977111117893,1749.977111117893,1749.977111117893,1749.97711"
"1117893,1749.977111117893,1744.7813348796044,1681.9971312601092,1622.3"
"944822534868]}}"
)

# Base of timestamps (epoch)
RDB_RIEGL_TIME_BASE             = "riegl.time_base"
RDB_RIEGL_TIME_BASE_TITLE       = "Time Base"
RDB_RIEGL_TIME_BASE_DESCRIPTION = "Base of timestamps (epoch)"
RDB_RIEGL_TIME_BASE_STATUS      = "optional"
RDB_RIEGL_TIME_BASE_SCHEMA = (
"{\"properties\":{\"system\":{\"type\":\"string\",\"description\":\"Time system "
"(time standard)\",\"enum\":[\"unknown\",\"UTC\",\"GPS\"]},\"epoch\":{\"type\":\"stri"
"ng\",\"description\":\"Date and time of timestamp '0' as proposed by RFC "
"3339 (e.g. 2015-10-27T00:00:00+01:00).\"},\"source\":{\"type\":\"string\",\"de"
"scription\":\"Timestamp "
"source\",\"enum\":[\"unknown\",\"RTC\",\"GNSS\"]}},\"description\":\"Base of "
"timestamps (epoch)\",\"required\":[\"epoch\",\"source\"],\"type\":\"object\",\"$sc"
"hema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Time Base\"}"
)
RDB_RIEGL_TIME_BASE_EXAMPLE = (
"{\"system\":\"UTC\",\"epoch\":\"2015-10-27T00:00:00+00:00\",\"source\":\"GNSS\"}"
)

# Details about position+orientation files
RDB_RIEGL_TRAJECTORY_INFO             = "riegl.trajectory_info"
RDB_RIEGL_TRAJECTORY_INFO_TITLE       = "Trajectory Information"
RDB_RIEGL_TRAJECTORY_INFO_DESCRIPTION = "Details about position+orientation files"
RDB_RIEGL_TRAJECTORY_INFO_STATUS      = "optional"
RDB_RIEGL_TRAJECTORY_INFO_SCHEMA = (
"{\"properties\":{\"location\":{\"type\":\"string\",\"description\":\"Project "
"location, e.g. city/state/country\"},\"settings\":{\"type\":\"string\",\"descr"
"iption\":\"Settings used to calculate the trajectory (descriptive text)\""
"},\"time_interval\":{\"type\":\"object\",\"properties\":{\"maximum\":{\"type\":\"nu"
"mber\",\"description\":\"Maximum time interval "
"[s]\"},\"std_dev\":{\"type\":\"number\",\"description\":\"Standard deviation of "
"intervals [s]\"},\"average\":{\"type\":\"number\",\"description\":\"Average time"
" interval [s]\"},\"minimum\":{\"type\":\"number\",\"description\":\"Minimum time"
" interval [s]\"}},\"description\":\"Time interval statistics\",\"required\":["
"\"minimum\",\"average\",\"maximum\",\"std_dev\"]},\"navigation_frame\":{\"type\":\""
"string\",\"description\":\"Navigation frame (NED: North-East-Down, ENU: Ea"
"st-North-Up)\",\"enum\":[\"unknown\",\"NED\",\"ENU\"]},\"company\":{\"type\":\"strin"
"g\",\"description\":\"Company "
"name\"},\"software\":{\"type\":\"string\",\"description\":\"Software that "
"calculated the trajectory (this may be the same or different software "
"than the one that created the "
"file)\"},\"field_of_application\":{\"type\":\"string\",\"description\":\"Field "
"of application\",\"enum\":[\"unknown\",\"SLS\",\"TLS\",\"KLS\",\"MLS\",\"ULS\",\"ALS\","
"\"BLS\",\"ILS\"]},\"project\":{\"type\":\"string\",\"description\":\"Project "
"name\"},\"device\":{\"type\":\"string\",\"description\":\"Navigation device, "
"e.g. name/type/serial\"}},\"description\":\"Details about "
"position+orientation files\",\"required\":[\"time_interval\",\"navigation_fr"
"ame\"],\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schem"
"a#\",\"title\":\"Trajectory Information\"}"
)
RDB_RIEGL_TRAJECTORY_INFO_EXAMPLE = (
"{\"location\":\"Horn\",\"settings\":\"default\",\"time_interval\":{\"maximum\":0.0"
"05004883,\"std_dev\":5.51e-07,\"average\":0.00500053,\"minimum\":0.00500032}"
",\"navigation_frame\":\"NED\",\"company\":\"RIEGL LMS\",\"software\":\"Navigation"
" Software XYZ\",\"field_of_application\":\"MLS\",\"project\":\"Campaign "
"3\",\"device\":\"IMU Model 12/1, Serial# 12345\"}"
)

# Details about vertex file
RDB_RIEGL_VERTEX_INFO             = "riegl.vertex_info"
RDB_RIEGL_VERTEX_INFO_TITLE       = "Vertex Information"
RDB_RIEGL_VERTEX_INFO_DESCRIPTION = "Details about vertex file"
RDB_RIEGL_VERTEX_INFO_STATUS      = "optional"
RDB_RIEGL_VERTEX_INFO_SCHEMA = (
"{\"type\":\"object\",\"properties\":{\"vertex_file\":{\"type\":\"object\",\"propert"
"ies\":{\"file_extension\":{\"type\":\"string\",\"description\":\"Vertex file "
"extension, without the leading "
"dot\"},\"file_uuid\":{\"type\":\"string\",\"description\":\"File's Universally "
"Unique Identifier (RFC 4122)\"}},\"required\":[\"file_extension\"]}},\"$sche"
"ma\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Vertex "
"Information\",\"description\":\"Details about vertex file\"}"
)
RDB_RIEGL_VERTEX_INFO_EXAMPLE = (
"{\"vertex_file\":{\"file_extension\":\"vtx\",\"file_uuid\":\"51534d95-d71f-4f36"
"-ae1a-3e63a21fd1c7\"}}"
)

# Details about the voxels contained in the file
RDB_RIEGL_VOXEL_INFO             = "riegl.voxel_info"
RDB_RIEGL_VOXEL_INFO_TITLE       = "Voxel Information"
RDB_RIEGL_VOXEL_INFO_DESCRIPTION = "Details about the voxels contained in the file"
RDB_RIEGL_VOXEL_INFO_STATUS      = "optional"
RDB_RIEGL_VOXEL_INFO_SCHEMA = (
"{\"oneOf\":[{\"properties\":{\"size\":{\"oneOf\":[{\"$ref\":\"#/definitions/voxel"
"_size\"},{\"$ref\":\"#/definitions/voxel_size_cubic\"}],\"description\":\"Size"
" of voxels in file coordinate system.\"},\"voxel_type\":{\"$ref\":\"#/defini"
"tions/voxel_type\"},\"shape_thresholds\":{\"$ref\":\"#/definitions/shape_thr"
"esholds\"},\"voxel_origin\":{\"$ref\":\"#/definitions/voxel_origin_enum\"}},\""
"additionalProperties\":false,\"required\":[\"size\",\"voxel_origin\",\"voxel_t"
"ype\"]},{\"properties\":{\"size\":{\"description\":\"Size of voxels in file "
"coordinate system.\",\"$ref\":\"#/definitions/voxel_size\"},\"shape_threshol"
"ds\":{\"$ref\":\"#/definitions/shape_thresholds\"},\"voxel_origin\":{\"oneOf\":"
"[{\"$ref\":\"#/definitions/voxel_origin_enum\"},{\"description\":\"The base "
"point of the voxel grid. Used together with <tt>voxel_size</tt> and "
"<tt>voxel_index</tt> to compute actual point coordinates.\",\"$ref\":\"#/d"
"efinitions/voxel_origin_point\"}]},\"voxel_type\":{\"$ref\":\"#/definitions/"
"voxel_type\"},\"size_llcs\":{\"description\":\"Size of voxels in a locally "
"levelled cartesian coordinate system (xyz). This is only used for "
"voxels based on a map projection.\",\"$ref\":\"#/definitions/voxel_size\"},"
"\"reference_point\":{\"type\":\"array\",\"description\":\"Point in WGS84 "
"geodetic decimal degree (EPSG:4326) that was used to compute the "
"projection distortion parameters. The coefficient order is latitude, "
"longitude. Only voxels with corresponding geo_tag, voxel_size and "
"reference_point can be reliably processed together. This entry is "
"available for voxel files in projected CRS only.\",\"items\":{\"type\":\"num"
"ber\",\"maximum\":180,\"minimum\":-180},\"maxItems\":2,\"minItems\":2}},\"additi"
"onalProperties\":false,\"required\":[\"reference_point\",\"size_llcs\",\"size\""
",\"voxel_origin\",\"voxel_type\"]}],\"description\":\"Details about the "
"voxels contained in the file\",\"type\":\"object\",\"$schema\":\"http://json-s"
"chema.org/draft-04/schema#\",\"title\":\"Voxel Information\",\"definitions\":"
"{\"voxel_origin_point\":{\"type\":\"array\",\"description\":\"Origin point for "
"all voxel indices in voxel CRS.\",\"items\":{\"type\":\"number\"},\"maxItems\":"
"3,\"minItems\":3},\"shape_thresholds\":{\"type\":\"object\",\"properties\":{\"pla"
"ne\":{\"description\":\"If the smallest eigenvalue is smaller than the "
"median eigenvalue * plane_threshold, the voxel is considered a plane.\""
",\"exclusiveMaximum\":true,\"exclusiveMinimum\":true,\"type\":\"number\",\"maxi"
"mum\":1,\"minimum\":0},\"line\":{\"type\":\"number\",\"description\":\"If the "
"biggest eigenvalue is bigger than the median eigenvalue * "
"line_threshold, the voxel is considered a "
"line.\",\"exclusiveMinimum\":true,\"minimum\":1}},\"description\":\"Thresholds"
" used to compute the voxel's shape_id value.\",\"required\":[\"plane\",\"lin"
"e\"]},\"voxel_size_cubic\":{\"type\":\"number\",\"$ref\":\"#/definitions/edge_le"
"ngth\"},\"voxel_size\":{\"type\":\"array\",\"description\":\"Size of voxels.\",\"i"
"tems\":{\"$ref\":\"#/definitions/edge_length\"},\"maxItems\":3,\"minItems\":3},"
"\"voxel_type\":{\"description\":\"Whether a point in a voxel represents its"
" center or its centroid. If type is <tt>index</tt> there is no point "
"but only an integer voxel index.\",\"enum\":[\"center\",\"centroid\",\"index\"]"
",\"default\":\"centroid\"},\"edge_length\":{\"type\":\"number\",\"description\":\"L"
"ength of voxel edge [m].\",\"exclusiveMinimum\":true,\"minimum\":0},\"voxel_"
"origin_enum\":{\"description\":\"Defines whether the voxel's center or a "
"corner is placed on CRS origin "
"<tt>(0/0/0)</tt>.\",\"enum\":[\"center\",\"corner\"],\"default\":\"corner\"}}}"
)
RDB_RIEGL_VOXEL_INFO_EXAMPLE = (
"{\"size\":[0.5971642834779395,0.5971642834779395,0.5143705304787237],\"sh"
"ape_thresholds\":{\"plane\":0.16,\"line\":6},\"voxel_origin\":\"corner\",\"voxel"
"_type\":\"centroid\",\"size_llcs\":[0.5156575252891171,0.5130835356683303,0"
".5143705304787237],\"reference_point\":[48,16]}"
)

# Settings for waveform averaging
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS             = "riegl.waveform_averaging_settings"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_TITLE       = "Waveform Averaging Settings"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_DESCRIPTION = "Settings for waveform averaging"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_SCHEMA = (
"{\"properties\":{\"mta_zone\":{\"type\":\"integer\",\"description\":\"Fixed MTA "
"zone for averaging.\",\"minimum\":1},\"num_shots\":{\"type\":\"integer\",\"descr"
"iption\":\"Number of consecutive shots to be used for averaging.\",\"minim"
"um\":1},\"trim\":{\"type\":\"number\",\"maximum\":0.5,\"description\":\"Percentage"
" for robust "
"averaging.\",\"default\":0,\"minimum\":0}},\"description\":\"Settings for "
"waveform averaging\",\"required\":[\"num_shots\",\"mta_zone\"],\"type\":\"object"
"\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Wavefor"
"m Averaging Settings\"}"
)
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_EXAMPLE = (
"{\"mta_zone\":1,\"num_shots\":7,\"trim\":0.05}"
)

# Details about waveform files
RDB_RIEGL_WAVEFORM_INFO             = "riegl.waveform_info"
RDB_RIEGL_WAVEFORM_INFO_TITLE       = "Waveform Information"
RDB_RIEGL_WAVEFORM_INFO_DESCRIPTION = "Details about waveform files"
RDB_RIEGL_WAVEFORM_INFO_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_INFO_SCHEMA = (
"{\"properties\":{\"range_offset_waveform_samples_m\":{\"type\":\"number\",\"des"
"cription\":\"Calibrated device specific range offset for waveform "
"samples in "
"meters.\"},\"range_offset_m\":{\"type\":\"number\",\"description\":\"Calibrated "
"device specific range offset for waveform analysis by system response "
"fitting in meters.\"},\"sample_data_files\":{\"type\":\"array\",\"items\":{\"typ"
"e\":\"object\",\"properties\":{\"delta_st\":{\"type\":\"number\",\"description\":\"r"
"eserved\"},\"sample_interval\":{\"type\":\"number\",\"description\":\"Sampling "
"interval in seconds\",\"exclusiveMinimum\":false,\"minimum\":0},\"sample_bit"
"s\":{\"description\":\"Bitwidth of samples (e.g. 10 bit, 12 bit)\",\"exclusi"
"veMaximum\":false,\"exclusiveMinimum\":false,\"type\":\"integer\",\"maximum\":3"
"2,\"minimum\":0},\"file_uuid\":{\"type\":\"string\",\"description\":\"File's "
"Universally Unique Identifier (RFC "
"4122)\"},\"file_extension\":{\"type\":\"string\",\"description\":\"Sample data "
"file extension, without the leading "
"dot\"},\"channel\":{\"description\":\"Sample block channel number (255 = inv"
"alid)\",\"exclusiveMaximum\":false,\"exclusiveMinimum\":false,\"type\":\"integ"
"er\",\"maximum\":255,\"minimum\":0},\"laser_wavelength\":{\"type\":\"number\",\"de"
"scription\":\"Laser wavelength in meters (0 = unknown)\",\"exclusiveMinimu"
"m\":false,\"minimum\":0},\"channel_name\":{\"type\":\"string\",\"description\":\"S"
"ample block channel name\"}},\"required\":[\"channel\",\"channel_name\",\"samp"
"le_interval\",\"sample_bits\",\"laser_wavelength\",\"delta_st\",\"file_extensi"
"on\"]}},\"sample_block_file\":{\"type\":\"object\",\"properties\":{\"file_extens"
"ion\":{\"type\":\"string\",\"description\":\"Sample block file extension, "
"without the leading "
"dot\"},\"file_uuid\":{\"type\":\"string\",\"description\":\"File's Universally "
"Unique Identifier (RFC "
"4122)\"}},\"required\":[\"file_extension\"]}},\"description\":\"Details about "
"waveform files\",\"required\":[\"sample_block_file\",\"sample_data_files\"],\""
"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"ti"
"tle\":\"Waveform Information\"}"
)
RDB_RIEGL_WAVEFORM_INFO_EXAMPLE = (
"{\"range_offset_m\":3.1415,\"sample_data_files\":[{\"delta_st\":0,\"sample_in"
"terval\":1.00503e-09,\"file_extension\":\"sp0\",\"sample_bits\":12,\"file_uuid"
"\":\"da084413-e3e8-4655-a122-071de8490d8e\",\"channel_name\":\"high_power\",\""
"channel\":0,\"laser_wavelength\":0},{\"delta_st\":0,\"sample_interval\":1.005"
"03e-09,\"file_extension\":\"sp1\",\"sample_bits\":12,\"file_uuid\":\"93585b5e-5"
"ea9-43a1-947b-e7ba3be642d2\",\"channel_name\":\"low_power\",\"channel\":1,\"la"
"ser_wavelength\":0},{\"delta_st\":0,\"sample_interval\":1.00503e-09,\"file_e"
"xtension\":\"sp5\",\"sample_bits\":12,\"file_uuid\":\"9d2298c4-1036-464f-b5cb-"
"1cf8e517f3a0\",\"channel_name\":\"wwf\",\"channel\":5,\"laser_wavelength\":0}],"
"\"sample_block_file\":{\"file_extension\":\"sbx\",\"file_uuid\":\"93a03615-66c0"
"-4bea-8ff8-c577378fe660\"},\"range_offset_waveform_samples_m \":7.283}"
)

# Scanner settings for waveform output
RDB_RIEGL_WAVEFORM_SETTINGS             = "riegl.waveform_settings"
RDB_RIEGL_WAVEFORM_SETTINGS_TITLE       = "Waveform Settings"
RDB_RIEGL_WAVEFORM_SETTINGS_DESCRIPTION = "Scanner settings for waveform output"
RDB_RIEGL_WAVEFORM_SETTINGS_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_SETTINGS_SCHEMA = (
"{\"type\":\"array\",\"items\":{\"type\":\"object\",\"properties\":{\"logic_expressi"
"on\":{\"type\":\"string\",\"description\":\"Logic expression of smart "
"waveforms filter\"},\"sbl_name\":{\"type\":\"string\",\"description\":\"Name of "
"sample block, e.g.: wfm, "
"wwf\"},\"pass_dev_greater\":{\"type\":\"integer\",\"description\":\"Threshold "
"for deviation greater than "
"[1]\"},\"pass_ampl_less\":{\"type\":\"number\",\"description\":\"Threshold for "
"amplitude less than "
"[dB]\"},\"pass_rng_less\":{\"type\":\"number\",\"description\":\"Threshold for "
"range less than "
"[m]\"},\"enabled\":{\"type\":\"boolean\",\"description\":\"Waveform output "
"enabled\"},\"channel_idx_mask\":{\"type\":\"integer\",\"description\":\"Bit mask"
" for channels which belong to sbl_name: Channel 0 = Bit0, Channel 1 = "
"Bit1, "
"...\"},\"pass_ampl_greater\":{\"type\":\"number\",\"description\":\"Threshold "
"for amplitude greater than "
"[dB]\"},\"pass_rng_greater\":{\"type\":\"number\",\"description\":\"Threshold "
"for range greater than "
"[m]\"},\"smart_enabled\":{\"type\":\"boolean\",\"description\":\"Smart waveform "
"output "
"enabled\"},\"pass_dev_less\":{\"type\":\"integer\",\"description\":\"Threshold "
"for deviation less than [1]\"}},\"required\":[\"sbl_name\",\"enabled\",\"chann"
"el_idx_mask\"]},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"ti"
"tle\":\"Waveform Settings\",\"description\":\"Scanner settings for waveform "
"output\"}"
)
RDB_RIEGL_WAVEFORM_SETTINGS_EXAMPLE = (
"[{\"sbl_name\":\"wfm\",\"pass_ampl_less\":5.0,\"pass_rng_less\":13.11,\"enabled"
"\":true,\"channel_idx_mask\":11,\"pass_ampl_greater\":1.0,\"pass_rng_greater"
"\":9.27,\"smart_enabled\":true},{\"sbl_name\":\"wwf\",\"channel_idx_mask\":32,\""
"enabled\":false}]"
)

# Window analysis data estimated from scandata and resulting filter parameters
RDB_RIEGL_WINDOW_ANALYSIS             = "riegl.window_analysis"
RDB_RIEGL_WINDOW_ANALYSIS_TITLE       = "Window Analysis"
RDB_RIEGL_WINDOW_ANALYSIS_DESCRIPTION = "Window analysis data estimated from scandata and resulting filter parameters"
RDB_RIEGL_WINDOW_ANALYSIS_STATUS      = "optional"
RDB_RIEGL_WINDOW_ANALYSIS_SCHEMA = (
"{\"properties\":{\"settings\":{\"type\":\"object\",\"properties\":{\"range\":{\"typ"
"e\":\"object\",\"properties\":{\"additive_value\":{\"type\":\"number\"},\"sigma_fa"
"ctor\":{\"type\":\"number\"}},\"required\":[\"sigma_factor\",\"additive_value\"]}"
",\"amplitude\":{\"type\":\"object\",\"properties\":{\"additive_value\":{\"type\":\""
"number\"},\"sigma_factor\":{\"type\":\"number\"}},\"required\":[\"sigma_factor\","
"\"additive_value\"]}},\"required\":[\"range\",\"amplitude\"]},\"filter\":{\"type\""
":\"object\",\"properties\":{\"range_min\":{\"type\":\"array\",\"description\":\"[m]"
"\",\"items\":{\"type\":\"number\"}},\"amplitude_max\":{\"type\":\"array\",\"descript"
"ion\":\"[dB]\",\"items\":{\"type\":\"number\"}},\"angle\":{\"type\":\"array\",\"descri"
"ption\":\"[deg]\",\"items\":{\"type\":\"number\"}},\"range_max\":{\"type\":\"array\","
"\"description\":\"[m]\",\"items\":{\"type\":\"number\"}}},\"required\":[\"angle\",\"r"
"ange_min\",\"range_max\",\"amplitude_max\"]},\"result\":{\"type\":\"object\",\"pro"
"perties\":{\"timestamp\":{\"type\":\"array\",\"description\":\"[s]\",\"items\":{\"ty"
"pe\":\"number\"}},\"amplitude_mean\":{\"type\":\"array\",\"description\":\"[dB]\",\""
"items\":{\"type\":\"number\"}},\"range_sigma\":{\"type\":\"array\",\"description\":"
"\"[m]\",\"items\":{\"type\":\"number\"}},\"range_mean\":{\"type\":\"array\",\"descrip"
"tion\":\"[m]\",\"items\":{\"type\":\"number\"}},\"amplitude_sigma\":{\"type\":\"arra"
"y\",\"description\":\"[dB]\",\"items\":{\"type\":\"number\"}},\"angle\":{\"type\":\"ar"
"ray\",\"description\":\"[deg]\",\"items\":{\"type\":\"number\"}},\"amplitude_offse"
"t\":{\"type\":\"array\",\"description\":\"[dB]\",\"items\":{\"type\":\"number\"}}},\"r"
"equired\":[\"angle\",\"range_mean\",\"range_sigma\",\"amplitude_mean\",\"amplitu"
"de_sigma\",\"amplitude_offset\"]}},\"description\":\"Window analysis data "
"estimated from scandata and resulting filter parameters\",\"required\":[\""
"result\",\"filter\",\"settings\"],\"type\":\"object\",\"$schema\":\"http://json-sc"
"hema.org/draft-04/schema#\",\"title\":\"Window Analysis\"}"
)
RDB_RIEGL_WINDOW_ANALYSIS_EXAMPLE = (
"{\"settings\":{\"range\":{\"additive_value\":0.1,\"sigma_factor\":8},\"amplitud"
"e\":{\"additive_value\":1.0,\"sigma_factor\":4}},\"filter\":{\"range_min\":[-0."
"208,-0.21,-0.212,-0.214,-0.216,-0.218,-0.219,-0.221,-0.223,-0.225,-0.2"
"27],\"amplitude_max\":[8.04,8.01,7.99,7.96,7.93,7.9,7.88,7.85,7.83,7.8,7"
".78],\"angle\":[14.9,15.0,15.1,15.2,15.3,15.4,15.5,15.6,15.7,15.8,15.9],"
"\"range_max\":[0.424,0.425,0.426,0.427,0.428,0.428,0.429,0.43,0.431,0.43"
"1,0.432]},\"result\":{\"timestamp\":[408.4441,411.4443],\"amplitude_mean\":["
"5.347396,5.263155,5.224655,5.179926,5.097782,5.116479,5.051756,4.98347"
"3,5.007885,5.002441,4.982],\"range_sigma\":[0.01869652,0.02151435,0.0174"
"7969,0.01918765,0.01945776,0.01934862,0.01955329,0.02225589,0.02229977"
",0.01899122,0.02009433],\"range_mean\":[0.1105621,0.1079564,0.1087088,0."
"1067261,0.1054582,0.1090412,0.102871,0.1019044,0.1051523,0.1058445,0.1"
"031261],\"amplitude_sigma\":[0.4272844,0.4298479,0.4236816,0.4283583,0.4"
"362353,0.4315141,0.4373984,0.4472798,0.4346001,0.4345487,0.4540681],\"a"
"ngle\":[14.9,15.0,15.1,15.2,15.3,15.4,15.5,15.6,15.7,15.8,15.9],\"amplit"
"ude_offset\":[1.9,1.9]}}"
)

# Correction parameters for window glass echoes
RDB_RIEGL_WINDOW_ECHO_CORRECTION             = "riegl.window_echo_correction"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_TITLE       = "Window Echo Correction"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_DESCRIPTION = "Correction parameters for window glass echoes"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_STATUS      = "optional"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_SCHEMA = (
"{\"properties\":{\"slices\":{\"type\":\"array\",\"items\":{\"type\":\"object\",\"prop"
"erties\":{\"table\":{\"type\":\"array\",\"description\":\"Correction table "
"(dimension defined by the 'amplitude' and 'range' "
"objects)\",\"items\":{\"type\":\"array\",\"description\":\"Table row (= "
"amplitude axis)\",\"items\":{\"type\":\"array\",\"description\":\"Table column "
"(= range axis)\",\"items\":{\"type\":\"number\",\"description\":\"Table cell "
"(item 0: amplitude in dB, 1: range in m, 2: flags)\"},\"maxItems\":3,\"min"
"Items\":3},\"minItems\":1},\"minItems\":1},\"amplitude\":{\"type\":\"number\",\"de"
"scription\":\"Window echo amplitude of slice in "
"dB\"}},\"description\":\"Window echo correction parameter slice\",\"required"
"\":[\"amplitude\",\"table\"]}},\"range\":{\"type\":\"object\",\"properties\":{\"entr"
"ies\":{\"type\":\"integer\",\"description\":\"Number of range entries\",\"minimu"
"m\":1},\"maximum\":{\"type\":\"number\",\"maximum\":2.0,\"description\":\"Maximum "
"range in m\",\"minimum\":-2.0},\"minimum\":{\"type\":\"number\",\"maximum\":2.0,\""
"description\":\"Minimum range in "
"m\",\"minimum\":-2.0}},\"description\":\"Range axis of correction table\",\"re"
"quired\":[\"minimum\",\"maximum\",\"entries\"]},\"amplitude\":{\"type\":\"object\","
"\"properties\":{\"entries\":{\"type\":\"integer\",\"description\":\"Number of "
"amplitude entries\",\"minimum\":1},\"maximum\":{\"type\":\"number\",\"descriptio"
"n\":\"Maximum amplitude in "
"dB\",\"minimum\":0.0},\"minimum\":{\"type\":\"number\",\"description\":\"Minimum "
"amplitude in dB\",\"minimum\":0.0}},\"description\":\"Amplitude axis of "
"correction table\",\"required\":[\"minimum\",\"maximum\",\"entries\"]}},\"descri"
"ption\":\"Correction parameters for window glass echoes\",\"required\":[\"am"
"plitude\",\"range\",\"slices\"],\"type\":\"object\",\"$schema\":\"http://json-sche"
"ma.org/draft-04/schema#\",\"title\":\"Window Echo Correction\"}"
)
RDB_RIEGL_WINDOW_ECHO_CORRECTION_EXAMPLE = (
"{\"slices\":[{\"table\":[[[6.23,0.3535,1]],[[5.54,0.72375,1]]],\"amplitude\""
":1.5},{\"table\":[[[6.23,0.3535,1]],[[5.54,0.72375,1]]],\"amplitude\":2.0}"
"],\"range\":{\"entries\":128,\"maximum\":1.5060822940732335,\"minimum\":-1.506"
"0822940732335},\"amplitude\":{\"entries\":128,\"maximum\":20,\"minimum\":2}}"
)
