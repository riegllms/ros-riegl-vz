Python binding for the RIEGL RDB library.


