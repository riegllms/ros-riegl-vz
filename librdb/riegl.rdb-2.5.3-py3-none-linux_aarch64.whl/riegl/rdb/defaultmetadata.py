#
#*******************************************************************************
#
#  Copyright 2025 RIEGL Laser Measurement Systems
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
#  SPDX-License-Identifier: Apache-2.0
#
#*******************************************************************************
#
"""
*******************************************************************************
*
* \author  RIEGL LMS GmbH, Austria
* \brief   Description of RIEGL RDB 2 database meta data items.
* \version 2015-10-27/AW: Initial version
* \version 2015-11-25/AW: Item "Geo Tag" added
* \version 2016-10-27/AW: Item "Voxel Information" added
* \version 2016-11-17/AW: Item "Voxel Information" updated
* \version 2016-12-12/AW: Item "Range Statistics" added
* \version 2017-03-08/AW: Item "Plane Patch Statistics" added
* \version 2017-04-05/AW: Items "Atmosphere" and "Geometric Scale Factor" added
* \version 2017-08-22/AW: Items for waveform sample block and value files added
* \version 2017-10-24/AW: Item "Gaussian Decomposition" added
* \version 2017-11-13/AW: Item "riegl.scan_pattern" updated
* \version 2017-11-21/AW: Item "riegl.trajectory_info" added
* \version 2018-01-11/AW: Item "riegl.beam_geometry" added
* \version 2018-01-15/AW: Item "riegl.reflectance_calculation" added
* \version 2018-01-15/AW: Item "riegl.near_range_correction" added
* \version 2018-01-15/AW: Item "riegl.device_geometry" added
* \version 2018-02-13/AW: Item "riegl.notch_filter" added
* \version 2018-03-08/AW: Item "riegl.window_echo_correction" added
* \version 2018-03-15/AW: Item "riegl.pulse_position_modulation" added
* \version 2018-05-24/AW: Item "riegl.pixel_info" added
* \version 2018-06-08/AW: Item "riegl.shot_info" added
* \version 2018-06-08/AW: Item "riegl.echo_info" added
* \version 2018-06-14/AW: Item "riegl.mta_settings" added
* \version 2018-06-14/AW: Item "riegl.receiver_internals" added
* \version 2018-06-14/AW: Item "riegl.device_output_limits" added
* \version 2018-06-26/AW: Schema: replace "number" with "integer" if applicable
* \version 2018-07-09/AW: Item "riegl.pose_estimation" added
* \version 2018-07-09/AW: Item "riegl.pose_sensors" added
* \version 2018-09-20/AW: Item "riegl.pointcloud_info" added
* \version 2018-11-08/AW: Item "riegl.scan_pattern" updated
* \version 2018-11-13/AW: Item "riegl.receiver_internals" updated
* \version 2019-03-06/AW: Item "riegl.receiver_internals" updated
* \version 2019-03-21/AW: Item "riegl.device_geometry" updated
* \version 2019-04-15/AW: Item "riegl.point_attribute_groups" added
* \version 2019-04-30/AW: Item "riegl.waveform_settings" added
* \version 2019-10-03/AW: Item "riegl.angular_notch_filter" added
* \version 2019-10-03/AW: Item "riegl.noise_estimates" added
* \version 2019-10-25/AW: Item "riegl.window_analysis" added
* \version 2019-11-06/AW: Item "riegl.georeferencing_parameters" added
* \version 2019-11-27/AW: Item "riegl.plane_patch_matching" added
* \version 2019-12-13/AW: Items for tie-/control objects added
* \version 2019-12-19/AW: Items for tie-/control objects added
* \version 2020-02-04/AW: Item "riegl.detection_probability" added
* \version 2020-02-04/AW: Item "riegl.licenses" added
* \version 2020-04-27/AW: Item "riegl.waveform_info" updated (schema+example)
* \version 2020-09-03/AW: Item "riegl.reflectance_correction" added
* \version 2020-09-10/AW: Item "riegl.device_geometry_passive_channel" added
* \version 2020-09-25/AW: Item "riegl.georeferencing_parameters" updated
* \version 2020-09-25/AW: Item "riegl.trajectory_info" updated
* \version 2020-09-29/AW: Item "riegl.temperature_calculation" added
* \version 2020-10-23/AW: Item "riegl.exponential_decomposition" added (#3709)
* \version 2020-11-30/AW: Item "riegl.notch_filter" updated (schema)
* \version 2020-12-02/AW: Item "riegl.georeferencing_parameters" updated (schema)
* \version 2021-02-02/AW: Item "riegl.plane_slope_class_info" added (rdbplanes/#7)
* \version 2021-02-16/AW: Item "riegl.device_output_limits" updated (schema, #3811)
* \version 2021-03-03/AW: Item "riegl.exponential_decomposition" updated (schema, #3822)
* \version 2021-03-03/AW: Item "riegl.waveform_averaging_settings" added (#3821)
* \version 2021-04-01/AW: Item "riegl.voxel_info" updated (schema, #3854)
* \version 2021-04-16/AW: Item "riegl.voxel_info" updated (schema, #3866)
* \version 2021-09-30/AW: Item "riegl.waveform_info" updated (schema+example, #4016)
* \version 2021-10-04/AW: Improved spelling of the descriptions of some items
* \version 2021-11-04/AW: Rename "riegl.record_names" to "riegl.item_names" (#4034)
* \version 2022-03-11/AW: Item "riegl.devices" added (#4162)
* \version 2022-03-14/AW: Item "riegl.stored_filters" added (#4164)
* \version 2022-09-20/AW: Fix typos in schema of "riegl.georeferencing_parameters"
* \version 2022-09-30/AW: Item "riegl.system_description" added (#4368)
* \version 2022-10-10/AW: Correction of typos in the titles of some entries
* \version 2022-10-20/AW: Item "riegl.stored_filters" updated (example, #4164)
* \version 2023-01-19/AW: Item "riegl.ttip_configuration" added (#4449)
* \version 2024-09-26/AW: Item "riegl.dyntrig" added (#5310)
*
*******************************************************************************
"""

# Angular notch filter parameters for window glass echoes
RDB_RIEGL_ANGULAR_NOTCH_FILTER             = "riegl.angular_notch_filter"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_TITLE       = "Angular Notch Filter"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_DESCRIPTION = "Angular notch filter parameters for window glass echoes"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_STATUS      = "optional"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_SCHEMA = (
"{\"properties\":{\"amplitude_mean\":{\"items\":{\"type\":\"number\"},\"descriptio"
"n\":\"Mean amplitude [dB]\",\"type\":\"array\"},\"angle\":{\"items\":{\"type\":\"num"
"ber\"},\"description\":\"Angle [deg]\",\"type\":\"array\"},\"range_mean\":{\"items"
"\":{\"type\":\"number\"},\"description\":\"Mean range [m]\",\"type\":\"array\"}},\"r"
"equired\":[\"angle\",\"range_mean\",\"amplitude_mean\"],\"type\":\"object\",\"desc"
"ription\":\"Angular notch filter parameters for window glass "
"echoes\",\"title\":\"Angular Notch "
"Filter\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_ANGULAR_NOTCH_FILTER_EXAMPLE = (
"{\"amplitude_mean\":[3.780913,3.780913,3.480913,3.120913,2.850913,2.7209"
"13,2.680913,2.610913,2.530913,2.570913,2.570913],\"angle\":[14.0,15.0,16"
".0,17.0,18.0,19.0,20.0,21.0,22.0,23.0,24.0],\"range_mean\":[0.094,0.094,"
"0.09075,0.08675,0.0815,0.0775,0.074,0.071,0.068,0.0675,0.06475]}"
)

# Atmospheric parameters
RDB_RIEGL_ATMOSPHERE             = "riegl.atmosphere"
RDB_RIEGL_ATMOSPHERE_TITLE       = "Atmosphere"
RDB_RIEGL_ATMOSPHERE_DESCRIPTION = "Atmospheric parameters"
RDB_RIEGL_ATMOSPHERE_STATUS      = "optional"
RDB_RIEGL_ATMOSPHERE_SCHEMA = (
"{\"properties\":{\"amsl\":{\"description\":\"Height above mean sea level "
"(AMSL) [m]\",\"type\":\"number\"},\"pressure_sl\":{\"description\":\"Atmospheric"
" pressure at sea level "
"[mbar]\",\"type\":\"number\"},\"attenuation\":{\"description\":\"Atmospheric "
"attenuation "
"[1/km]\",\"type\":\"number\"},\"wavelength\":{\"description\":\"Laser wavelength"
" [nm]\",\"type\":\"number\"},\"pressure\":{\"description\":\"Pressure along "
"measurment path "
"[mbar]\",\"type\":\"number\"},\"group_velocity\":{\"description\":\"Group "
"velocity of laser beam "
"[m/s]\",\"type\":\"number\"},\"temperature\":{\"description\":\"Temperature "
"along measurement path "
"[\\u00b0C]\",\"type\":\"number\"},\"rel_humidity\":{\"description\":\"Relative "
"humidity along measurement path [%]\",\"type\":\"number\"}},\"required\":[\"te"
"mperature\",\"pressure\",\"rel_humidity\",\"pressure_sl\",\"amsl\",\"group_veloc"
"ity\",\"attenuation\",\"wavelength\"],\"type\":\"object\",\"description\":\"Atmosp"
"heric parameters\",\"title\":\"Atmospheric "
"Parameters\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_ATMOSPHERE_EXAMPLE = (
"{\"amsl\":0,\"pressure_sl\":970,\"attenuation\":0.028125,\"wavelength\":1550,\""
"pressure\":970,\"group_velocity\":299711000.0,\"temperature\":7,\"rel_humidi"
"ty\":63}"
)

# Laser beam geometry details
RDB_RIEGL_BEAM_GEOMETRY             = "riegl.beam_geometry"
RDB_RIEGL_BEAM_GEOMETRY_TITLE       = "Beam Geometry"
RDB_RIEGL_BEAM_GEOMETRY_DESCRIPTION = "Laser beam geometry details"
RDB_RIEGL_BEAM_GEOMETRY_STATUS      = "optional"
RDB_RIEGL_BEAM_GEOMETRY_SCHEMA = (
"{\"properties\":{\"beam_divergence\":{\"exclusiveMinimum\":false,\"descriptio"
"n\":\"Beam divergence in far field [rad]\",\"minimum\":0,\"type\":\"number\"},\""
"beam_exit_diameter\":{\"exclusiveMinimum\":false,\"description\":\"Beam "
"width at exit aperture [m]\",\"minimum\":0,\"type\":\"number\"}},\"required\":["
"\"beam_exit_diameter\",\"beam_divergence\"],\"type\":\"object\",\"description\":"
"\"Laser beam geometry details\",\"title\":\"Beam "
"Geometry\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_BEAM_GEOMETRY_EXAMPLE = (
"{\"beam_divergence\":0.0003,\"beam_exit_diameter\":0.0072}"
)

# List of control object type definitions
RDB_RIEGL_CONTROL_OBJECT_CATALOG             = "riegl.control_object_catalog"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_TITLE       = "Control Object Catalog"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_DESCRIPTION = "List of control object type definitions"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_STATUS      = "optional"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_SCHEMA = (
"{\"properties\":{\"types\":{\"items\":{\"oneOf\":[{\"$ref\":\"#/definitions/recta"
"ngle\"},{\"$ref\":\"#/definitions/checkerboard2x2\"},{\"$ref\":\"#/definitions"
"/chevron\"},{\"$ref\":\"#/definitions/circular_disk\"},{\"$ref\":\"#/definitio"
"ns/cylinder\"},{\"$ref\":\"#/definitions/sphere\"},{\"$ref\":\"#/definitions/r"
"ound_corner_cube_prism\"}],\"type\":\"object\"},\"uniqueItems\":true,\"type\":\""
"array\"}},\"required\":[\"types\"],\"type\":\"object\",\"description\":\"List of "
"control object type definitions\",\"title\":\"Control Object "
"Catalog\",\"definitions\":{\"common\":{\"description\":\"common object "
"properties\",\"properties\":{\"surface_type\":{\"description\":\"surface "
"material type\",\"enum\":[\"retro_reflective_foil\",\"diffuse\"],\"type\":\"stri"
"ng\"},\"name\":{\"minLength\":3,\"description\":\"unique type "
"identifier\",\"type\":\"string\"},\"shape\":{\"description\":\"shape identifier\""
",\"enum\":[\"rectangle\",\"checkerboard2x2\",\"chevron\",\"circular_disk\",\"cyli"
"nder\",\"sphere\",\"round_corner_cube_prism\"],\"type\":\"string\"},\"descriptio"
"n\":{\"description\":\"string describing the object\",\"type\":\"string\"}},\"re"
"quired\":[\"name\",\"shape\"],\"type\":\"object\"},\"round_corner_cube_prism\":{\""
"description\":\"round corner cube "
"prism\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"description\":\"round "
"corner cube prism specific "
"properties\",\"properties\":{\"offset\":{\"description\":\"offset in meters, "
"e.g. reflector constant (optional)\",\"type\":\"number\"},\"diameter\":{\"excl"
"usiveMinimum\":true,\"description\":\"diameter in "
"meters\",\"minimum\":0,\"type\":\"number\"},\"shape\":{\"description\":\"shape ide"
"ntifier\",\"enum\":[\"round_corner_cube_prism\"],\"type\":\"string\"}},\"require"
"d\":[\"shape\",\"diameter\"],\"type\":\"object\"}],\"type\":\"object\"},\"cylinder\":"
"{\"description\":\"cylinder\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"d"
"escription\":\"cylinder specific properties\",\"properties\":{\"height\":{\"ex"
"clusiveMinimum\":true,\"description\":\"height in meters\",\"minimum\":0,\"typ"
"e\":\"number\"},\"diameter\":{\"exclusiveMinimum\":true,\"description\":\"diamet"
"er in "
"meters\",\"minimum\":0,\"type\":\"number\"},\"shape\":{\"description\":\"shape ide"
"ntifier\",\"enum\":[\"cylinder\"],\"type\":\"string\"}},\"required\":[\"shape\",\"di"
"ameter\",\"height\"],\"type\":\"object\"}],\"type\":\"object\"},\"chevron\":{\"descr"
"iption\":\"chevron\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"descripti"
"on\":\"chevron specific "
"properties\",\"properties\":{\"shape\":{\"description\":\"shape identifier\",\"e"
"num\":[\"chevron\"],\"type\":\"string\"},\"thickness\":{\"exclusiveMinimum\":true"
",\"description\":\"thickness in meters\",\"minimum\":0,\"type\":\"number\"},\"out"
"side_edge_length\":{\"exclusiveMinimum\":true,\"description\":\"length of "
"the two outer edges in meters\",\"minimum\":0,\"type\":\"number\"}},\"required"
"\":[\"shape\",\"outside_edge_length\",\"thickness\"],\"type\":\"object\"}],\"type\""
":\"object\"},\"circular_disk\":{\"description\":\"circular disk\",\"allOf\":[{\"$"
"ref\":\"#/definitions/common\"},{\"description\":\"circular disk specific "
"properties\",\"properties\":{\"offset\":{\"description\":\"offset in meters, "
"e.g. reflector constant (optional)\",\"type\":\"number\"},\"diameter\":{\"excl"
"usiveMinimum\":true,\"description\":\"diameter in "
"meters\",\"minimum\":0,\"type\":\"number\"},\"shape\":{\"description\":\"shape ide"
"ntifier\",\"enum\":[\"circular_disk\"],\"type\":\"string\"}},\"required\":[\"shape"
"\",\"diameter\"],\"type\":\"object\"}],\"type\":\"object\"},\"rectangle\":{\"descrip"
"tion\":\"rectangle\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"descripti"
"on\":\"rectangle specific properties\",\"properties\":{\"width\":{\"exclusiveM"
"inimum\":true,\"description\":\"width in meters\",\"minimum\":0,\"type\":\"numbe"
"r\"},\"shape\":{\"enum\":[\"rectangle\"],\"type\":\"string\"},\"length\":{\"exclusiv"
"eMinimum\":true,\"description\":\"length in meters\",\"minimum\":0,\"type\":\"nu"
"mber\"}},\"required\":[\"shape\",\"length\",\"width\"],\"type\":\"object\"}],\"type\""
":\"object\"},\"checkerboard2x2\":{\"description\":\"checkerboard 2 by 2\",\"all"
"Of\":[{\"$ref\":\"#/definitions/common\"},{\"description\":\"checkerboard "
"specific properties\",\"properties\":{\"shape\":{\"description\":\"shape ident"
"ifier\",\"enum\":[\"checkerboard2x2\"],\"type\":\"string\"},\"square_length\":{\"e"
"xclusiveMinimum\":true,\"description\":\"length of a square of the "
"checkerboard in meters\",\"minimum\":0,\"type\":\"number\"}},\"required\":[\"sha"
"pe\",\"square_length\"],\"type\":\"object\"}],\"type\":\"object\"},\"sphere\":{\"des"
"cription\":\"sphere\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"descript"
"ion\":\"sphere specific properties\",\"properties\":{\"diameter\":{\"exclusive"
"Minimum\":true,\"description\":\"diameter in "
"meters\",\"minimum\":0,\"type\":\"number\"},\"shape\":{\"description\":\"shape ide"
"ntifier\",\"enum\":[\"sphere\"],\"type\":\"string\"}},\"required\":[\"shape\",\"diam"
"eter\"],\"type\":\"object\"}],\"type\":\"object\"}},\"$schema\":\"http://json-sche"
"ma.org/draft-04/schema#\"}"
)
RDB_RIEGL_CONTROL_OBJECT_CATALOG_EXAMPLE = (
"{\"comments\":[\"This file contains a list of control object types (aka. "
"'catalog').\",\"Each type is described by an object,\",\"which must "
"contain at least the following parameters:\",\"  - name: unique "
"identifier of the type\",\"  - shape: one of the following supported "
"shapes:\",\"      - rectangle\",\"      - checkerboard2x2\",\"      - "
"chevron\",\"      - circular_disk\",\"      - cylinder\",\"      - sphere\",\""
"      - round_corner_cube_prism\",\"Depending on 'shape', the following "
"parameters must/may be specified:\",\"  - rectangle:\",\"      - length: "
"length in meters\",\"      - width: width in meters\",\"  - "
"checkerboard2x2:\",\"      - square_length: length of a square of the "
"checkerboard in meters\",\"  - circular_disk:\",\"      - diameter: "
"diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
"constant (optional)\",\"  - chevron:\",\"      - outside_edge_length: "
"length of the two outer edges in meters\",\"      - thickness: thickness"
" in meters\",\"  - cylinder:\",\"      - diameter: diameter in meters\",\""
"      - height: height in meters\",\"  - sphere:\",\"      - diameter: "
"diameter in meters\",\"  - round_corner_cube_prism:\",\"      - diameter: "
"diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
"constant (optional)\",\"Optional parameters:\",\"    - description: string"
" describing the object\",\"    - surface_type: surface material type "
"(either 'retro_reflective_foil' or "
"'diffuse')\"],\"types\":[{\"name\":\"Rectangle 60x30\",\"width\":0.3,\"shape\":\"r"
"ectangle\",\"length\":0.6,\"description\":\"Rectangle (60cm x "
"30cm)\"},{\"name\":\"Rectangle 80x40\",\"width\":0.4,\"shape\":\"rectangle\",\"len"
"gth\":0.8,\"description\":\"Rectangle (80cm x "
"40cm)\"},{\"name\":\"Checkerboard2x2 30\",\"shape\":\"checkerboard2x2\",\"square"
"_length\":0.3,\"description\":\"Checkerboard (square length: "
"30cm)\"},{\"name\":\"Checkerboard2x2 50\",\"shape\":\"checkerboard2x2\",\"square"
"_length\":0.5,\"description\":\"Checkerboard (square length: "
"50cm)\"},{\"name\":\"Chevron 24''/4''\",\"shape\":\"chevron\",\"thickness\":0.101"
"6,\"outside_edge_length\":0.6096,\"description\":\"Chevron (a=24''; "
"b=4'')\"},{\"surface_type\":\"diffuse\",\"name\":\"Circular Disk "
"50\",\"diameter\":0.5,\"shape\":\"circular_disk\",\"description\":\" Circular "
"Disk (diameter: 50cm)\"},{\"offset\":0.0,\"diameter\":0.05,\"shape\":\"circula"
"r_disk\",\"description\":\"flat circular reflector from retro-reflective "
"foil\",\"name\":\"RIEGL flat reflector 50 mm\",\"surface_type\":\"retro_reflec"
"tive_foil\"},{\"offset\":0.0,\"diameter\":0.1,\"shape\":\"circular_disk\",\"desc"
"ription\":\"flat circular reflector from retro-reflective "
"foil\",\"name\":\"RIEGL flat reflector 100 mm\",\"surface_type\":\"retro_refle"
"ctive_foil\"},{\"offset\":0.0,\"diameter\":0.15,\"shape\":\"circular_disk\",\"de"
"scription\":\"flat circular reflector from retro-reflective "
"foil\",\"name\":\"RIEGL flat reflector 150 mm\",\"surface_type\":\"retro_refle"
"ctive_foil\"},{\"diameter\":0.05,\"shape\":\"cylinder\",\"description\":\"cylind"
"rical reflector from retro-reflective "
"foil\",\"height\":0.05,\"name\":\"RIEGL cylindrical reflector 50 mm\",\"surfac"
"e_type\":\"retro_reflective_foil\"},{\"diameter\":0.1,\"shape\":\"cylinder\",\"d"
"escription\":\"cylindrical reflector from retro-reflective "
"foil\",\"height\":0.1,\"name\":\"RIEGL cylindrical reflector 100 "
"mm\",\"surface_type\":\"retro_reflective_foil\"},{\"name\":\"Sphere 200 "
"mm\",\"diameter\":0.2,\"shape\":\"sphere\",\"description\":\"Sphere (diameter: "
"200 mm)\"},{\"name\":\"Corner Cube Prism 50 mm\",\"diameter\":0.05,\"shape\":\"r"
"ound_corner_cube_prism\",\"offset\":0.0,\"description\":\"round corner cube "
"prism\"}]}"
)

# Details about the control object reference file
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE             = "riegl.control_object_reference_file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_TITLE       = "Control Object Reference file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_DESCRIPTION = "Details about the control object reference file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_STATUS      = "optional"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_SCHEMA = (
"{\"description\":\"Details about the control object reference "
"file\",\"title\":\"Control Object Reference file\",\"type\":\"object\",\"propert"
"ies\":{\"reference_file\":{\"description\":\"Reference to a control object "
"file\",\"properties\":{\"file_uuid\":{\"description\":\"Control object file's "
"Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_path\":{\"description\":\"Path of the "
"control object file relative to referring file\",\"type\":\"string\"}},\"req"
"uired\":[\"file_uuid\",\"file_path\"],\"type\":\"object\"}},\"$schema\":\"http://j"
"son-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_EXAMPLE = (
"{\"reference_file\":{\"file_uuid\":\"810f5d57-eccf-49ed-b07a-0cdd109b4213\","
"\"file_path\":\"../../../10_CONTROL_OBJECTS/ControlPoints.cpx\"}}"
)

# Detection probability as a function of amplitude
RDB_RIEGL_DETECTION_PROBABILITY             = "riegl.detection_probability"
RDB_RIEGL_DETECTION_PROBABILITY_TITLE       = "Detection Probability"
RDB_RIEGL_DETECTION_PROBABILITY_DESCRIPTION = "Detection probability as a function of amplitude"
RDB_RIEGL_DETECTION_PROBABILITY_STATUS      = "optional"
RDB_RIEGL_DETECTION_PROBABILITY_SCHEMA = (
"{\"properties\":{\"detection_probability\":{\"items\":{\"type\":\"number\"},\"des"
"cription\":\"Detection probability [0..1]\",\"type\":\"array\"},\"amplitude\":{"
"\"items\":{\"type\":\"number\"},\"description\":\"Amplitude [dB]\",\"type\":\"array"
"\"}},\"required\":[\"amplitude\",\"detection_probability\"],\"type\":\"object\",\""
"description\":\"Detection probability as a function of "
"amplitude\",\"title\":\"Detection "
"Probability\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_DETECTION_PROBABILITY_EXAMPLE = (
"{\"detection_probability\":[0.0,0.5,0.8,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0]"
",\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0]}"
)

# Details about the device used to acquire the point cloud
RDB_RIEGL_DEVICE             = "riegl.device"
RDB_RIEGL_DEVICE_TITLE       = "Device Information"
RDB_RIEGL_DEVICE_DESCRIPTION = "Details about the device used to acquire the point cloud"
RDB_RIEGL_DEVICE_STATUS      = "optional"
RDB_RIEGL_DEVICE_SCHEMA = (
"{\"properties\":{\"device_name\":{\"description\":\"Optional device name "
"(e.g. 'Scanner 1' for multi-scanner "
"systems)\",\"type\":\"string\"},\"serial_number\":{\"description\":\"Device "
"serial number (e.g. "
"S2221234)\",\"type\":\"string\"},\"channel_text\":{\"description\":\"Optional "
"channel description (e.g. 'Green Channel' for multi-channel "
"devices)\",\"type\":\"string\"},\"device_build\":{\"description\":\"Device build"
" variant\",\"type\":\"string\"},\"channel_number\":{\"exclusiveMinimum\":false,"
"\"description\":\"Laser channel number (not defined or 0: single channel "
"device)\",\"minimum\":0,\"type\":\"integer\"},\"device_type\":{\"description\":\"D"
"evice type identifier (e.g. VZ-400i)\",\"type\":\"string\"}},\"required\":[\"d"
"evice_type\",\"serial_number\"],\"type\":\"object\",\"description\":\"Details "
"about the device used to acquire the point cloud\",\"title\":\"Device "
"Information\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_DEVICE_EXAMPLE = (
"{\"device_name\":\"Scanner 1\",\"serial_number\":\"S2221234\",\"channel_text\":\""
"\",\"device_build\":\"\",\"channel_number\":0,\"device_type\":\"VZ-400i\"}"
)

# Scanner device geometry details
RDB_RIEGL_DEVICE_GEOMETRY             = "riegl.device_geometry"
RDB_RIEGL_DEVICE_GEOMETRY_TITLE       = "Device Geometry"
RDB_RIEGL_DEVICE_GEOMETRY_DESCRIPTION = "Scanner device geometry details"
RDB_RIEGL_DEVICE_GEOMETRY_STATUS      = "optional"
RDB_RIEGL_DEVICE_GEOMETRY_SCHEMA = (
"{\"properties\":{\"primary\":{\"description\":\"Primary device geometry "
"structure (mandatory)\",\"properties\":{\"content\":{\"items\":{\"type\":\"numbe"
"r\"},\"description\":\"Internal calibration values\",\"type\":\"array\"},\"ID\":{"
"\"items\":{\"type\":\"integer\"},\"description\":\"Structure identifier\",\"minIt"
"ems\":2,\"maxItems\":2,\"type\":\"array\"}},\"required\":[\"ID\",\"content\"],\"type"
"\":\"object\"},\"amu\":{\"description\":\"Angle Measurement Unit\",\"properties\""
":{\"frameCC\":{\"exclusiveMinimum\":false,\"description\":\"Frame Circle "
"Count (number of LSBs per full rotation about frame axis)\",\"minimum\":0"
",\"type\":\"number\"},\"lineCC\":{\"exclusiveMinimum\":false,\"description\":\"Li"
"ne Circle Count (number of LSBs per full rotation about line axis)\",\"m"
"inimum\":0,\"type\":\"number\"}},\"type\":\"object\"},\"secondary\":{\"description"
"\":\"Additional device geometry structure (optional)\",\"properties\":{\"con"
"tent\":{\"items\":{\"type\":\"number\"},\"description\":\"Internal calibration v"
"alues\",\"type\":\"array\"},\"ID\":{\"items\":{\"type\":\"integer\"},\"description\":"
"\"Structure identifier\",\"minItems\":2,\"maxItems\":2,\"type\":\"array\"}},\"req"
"uired\":[\"ID\",\"content\"],\"type\":\"object\"}},\"required\":[\"primary\"],\"type"
"\":\"object\",\"description\":\"Scanner device geometry "
"details\",\"title\":\"Device "
"Geometry\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_DEVICE_GEOMETRY_EXAMPLE = (
"{\"primary\":{\"content\":[0],\"ID\":[4,0]},\"amu\":{\"frameCC\":124000,\"lineCC\""
":124000},\"secondary\":{\"content\":[0],\"ID\":[91,0]}}"
)

# Scanner passive channel device geometry details
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL             = "riegl.device_geometry_passive_channel"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_TITLE       = "Device Geometry Passive Channel"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_DESCRIPTION = "Scanner passive channel device geometry details"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_STATUS      = "optional"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_SCHEMA = (
"{\"properties\":{\"primary\":{\"description\":\"Primary device geometry "
"structure (mandatory)\",\"properties\":{\"content\":{\"items\":{\"type\":\"numbe"
"r\"},\"description\":\"Internal calibration values\",\"type\":\"array\"},\"ID\":{"
"\"items\":{\"type\":\"integer\"},\"description\":\"Structure identifier\",\"minIt"
"ems\":2,\"maxItems\":2,\"type\":\"array\"}},\"required\":[\"ID\",\"content\"],\"type"
"\":\"object\"}},\"required\":[\"primary\"],\"type\":\"object\",\"description\":\"Sca"
"nner passive channel device geometry details\",\"title\":\"Device Geometry"
" Passive Channel\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_EXAMPLE = (
"{\"primary\":{\"content\":[0],\"ID\":[143,0]}}"
)

# Limits of the measured values output by the device
RDB_RIEGL_DEVICE_OUTPUT_LIMITS             = "riegl.device_output_limits"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_TITLE       = "Device Output Limits"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_DESCRIPTION = "Limits of the measured values output by the device"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_STATUS      = "optional"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_SCHEMA = (
"{\"description\":\"Limits of the measured values output by the device. "
"The limits depend on the device type, measurement program and/or scan "
"pattern.\",\"title\":\"Device Output Limits\",\"type\":\"object\",\"properties\":"
"{\"amplitude_minimum\":{\"description\":\"Minimum possible amplitude in "
"dB.\",\"type\":\"number\"},\"amplitude_maximum\":{\"description\":\"Maximum "
"possible amplitude in "
"dB.\",\"type\":\"number\"},\"echo_count_maximum\":{\"description\":\"Maximum "
"number of echoes a laser shot can "
"have.\",\"type\":\"number\"},\"range_minimum\":{\"description\":\"Minimum "
"possible range in meters.\",\"type\":\"number\"},\"background_radiation_maxi"
"mum\":{\"description\":\"Maximum possible background radiation.\",\"type\":\"n"
"umber\"},\"mta_zone_count_maximum\":{\"description\":\"Maximum number of MTA"
" zones.\",\"type\":\"number\"},\"deviation_minimum\":{\"description\":\"Minimum "
"possible pulse shape "
"deviation.\",\"type\":\"number\"},\"range_maximum\":{\"description\":\"Maximum "
"possible range in meters.\",\"type\":\"number\"},\"reflectance_minimum\":{\"de"
"scription\":\"Minimum possible reflectance in dB.\",\"type\":\"number\"},\"bac"
"kground_radiation_minimum\":{\"description\":\"Minimum possible background"
" radiation.\",\"type\":\"number\"},\"reflectance_maximum\":{\"description\":\"Ma"
"ximum possible reflectance in "
"dB.\",\"type\":\"number\"},\"deviation_maximum\":{\"description\":\"Maximum "
"possible pulse shape deviation.\",\"type\":\"number\"}},\"$schema\":\"http://j"
"son-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_EXAMPLE = (
"{\"amplitude_minimum\":0.0,\"amplitude_maximum\":100.0,\"deviation_minimum\""
":-1,\"range_maximum\":10000.0,\"mta_zone_count_maximum\":7,\"reflectance_mi"
"nimum\":-100.0,\"range_minimum\":2.9,\"reflectance_maximum\":100.0,\"deviati"
"on_maximum\":32767,\"background_radiation_maximum\":0,\"background_radiati"
"on_minimum\":0}"
)

# Details about the devices used to acquire the point cloud
RDB_RIEGL_DEVICES             = "riegl.devices"
RDB_RIEGL_DEVICES_TITLE       = "Devices Information"
RDB_RIEGL_DEVICES_DESCRIPTION = "Details about the devices used to acquire the point cloud"
RDB_RIEGL_DEVICES_STATUS      = "optional"
RDB_RIEGL_DEVICES_SCHEMA = (
"{\"items\":{\"required\":[\"device_type\",\"serial_number\"],\"properties\":{\"de"
"vice_name\":{\"description\":\"Optional device name (e.g. 'Scanner 1' for "
"multi-scanner "
"systems)\",\"type\":\"string\"},\"serial_number\":{\"description\":\"Device "
"serial number (e.g. "
"S2221234)\",\"type\":\"string\"},\"channel_text\":{\"description\":\"Optional "
"channel description (e.g. 'Green Channel' for multi-channel "
"devices)\",\"type\":\"string\"},\"device_build\":{\"description\":\"Device build"
" variant\",\"type\":\"string\"},\"channel_number\":{\"exclusiveMinimum\":false,"
"\"description\":\"Laser channel number (not defined or 0: single channel "
"device)\",\"minimum\":0,\"type\":\"integer\"},\"signed\":{\"description\":\"Flag "
"that is set when the original 'riegl.device' entry in the source file "
"was correctly "
"signed.\",\"type\":\"boolean\"},\"device_type\":{\"description\":\"Device type "
"identifier (e.g. "
"VZ-400i)\",\"type\":\"string\"}},\"type\":\"object\"},\"description\":\"Details "
"about the devices used to acquire the point cloud (e.g. when merging "
"point clouds of different devices)\",\"title\":\"Devices Information\",\"typ"
"e\":\"array\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_DEVICES_EXAMPLE = (
"[{\"device_name\":\"Scanner 1\",\"serial_number\":\"S2221234\",\"channel_text\":"
"\"\",\"device_build\":\"\",\"channel_number\":0,\"signed\":false,\"device_type\":\""
"VZ-400i\"},{\"device_name\":\"Scanner 2\",\"serial_number\":\"S2222680\",\"chann"
"el_text\":\"\",\"device_build\":\"\",\"channel_number\":1,\"signed\":true,\"device"
"_type\":\"VQ-1560i-DW\"},{\"device_name\":\"Scanner 3\",\"serial_number\":\"S222"
"2680\",\"channel_text\":\"\",\"device_build\":\"\",\"channel_number\":2,\"signed\":"
"true,\"device_type\":\"VQ-1560i-DW\"}]"
)

# Dyntrig
RDB_RIEGL_DYNTRIG             = "riegl.dyntrig"
RDB_RIEGL_DYNTRIG_TITLE       = "Dyntrig"
RDB_RIEGL_DYNTRIG_DESCRIPTION = "Dyntrig"
RDB_RIEGL_DYNTRIG_STATUS      = "optional"
RDB_RIEGL_DYNTRIG_SCHEMA = (
"{\"description\":\"Dyntrig\",\"title\":\"Dyntrig\",\"properties\":{\"post\":{\"desc"
"ription\":\"Dyntrig post "
"values\",\"properties\":{\"nc\":{\"description\":\"Number of entries\",\"maximum"
"\":255,\"minimum\":0,\"type\":\"integer\"},\"a\":{\"items\":{\"type\":\"number\"},\"de"
"scription\":\"...\",\"minItems\":1,\"maxItems\":2080,\"type\":\"array\"}},\"requir"
"ed\":[\"nc\",\"a\"],\"type\":\"object\"},\"offset\":{\"description\":\"Offset in "
"units of dB, for calculation of "
"line\",\"type\":\"number\"},\"scale\":{\"description\":\"Scale in units of dB, "
"for calculation of line: line number N=(amplitude-offset)/scale\",\"type"
"\":\"number\"},\"pre\":{\"description\":\"Dyntrig pre "
"values\",\"properties\":{\"nc\":{\"description\":\"Number of entries\",\"maximum"
"\":255,\"minimum\":0,\"type\":\"integer\"},\"a\":{\"items\":{\"type\":\"number\"},\"de"
"scription\":\"...\",\"minItems\":1,\"maxItems\":2080,\"type\":\"array\"}},\"requir"
"ed\":[\"nc\",\"a\"],\"type\":\"object\"},\"tab\":{\"items\":{\"description\":\"...\",\"p"
"roperties\":{\"dec2\":{\"description\":\"Rise of pre-trigger threshold after"
" del2 in units of "
"dB/m\",\"type\":\"number\"},\"thra2\":{\"description\":\"Pre-trigger threshold "
"in units of dB\",\"type\":\"number\"},\"del2\":{\"description\":\"Length of "
"constant pre-trigger threshold elevation in units of "
"m\",\"type\":\"number\"},\"dec1\":{\"description\":\"Decay of post-trigger "
"threshold after del1 in units of "
"dB/m\",\"type\":\"number\"},\"thra1\":{\"description\":\"Post-trigger threshold "
"in units of dB\",\"type\":\"number\"},\"del1\":{\"description\":\"Length of "
"constant post-trigger threshold elevation in units of m\",\"type\":\"numbe"
"r\"}},\"required\":[\"thra1\",\"del1\",\"dec1\",\"thra2\",\"del2\",\"dec2\"],\"type\":\""
"object\"},\"description\":\"...\",\"minItems\":1,\"maxItems\":128,\"type\":\"array"
"\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_DYNTRIG_EXAMPLE = (
"{\"post\":{\"nc\":128,\"a\":[78,86,126,134,31]},\"offset\":0.0,\"scale\":1.0,\"pr"
"e\":{\"nc\":128,\"a\":[78,86,126,134,31]},\"tab\":[{\"dec2\":0.0,\"thra2\":0.0,\"d"
"el2\":0.0,\"dec1\":0.0,\"thra1\":0.0,\"del1\":0.0}]}"
)

# Details about echo files
RDB_RIEGL_ECHO_INFO             = "riegl.echo_info"
RDB_RIEGL_ECHO_INFO_TITLE       = "Echo Information"
RDB_RIEGL_ECHO_INFO_DESCRIPTION = "Details about echo files"
RDB_RIEGL_ECHO_INFO_STATUS      = "optional"
RDB_RIEGL_ECHO_INFO_SCHEMA = (
"{\"properties\":{\"echo_file\":{\"required\":[\"file_extension\"],\"properties\""
":{\"file_uuid\":{\"description\":\"File's Universally Unique Identifier "
"(RFC 4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Echo "
"file extension, without the leading dot\",\"type\":\"string\"}},\"type\":\"obj"
"ect\"}},\"required\":[\"echo_file\"],\"type\":\"object\",\"description\":\"Details"
" about echo files\",\"title\":\"Echo "
"Information\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_ECHO_INFO_EXAMPLE = (
"{\"echo_file\":{\"file_uuid\":\"26a03615-67c0-4bea-8fe8-c577378fe661\",\"file"
"_extension\":\"owp\"}}"
)

# Details for exponential decomposition of full waveform data
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION             = "riegl.exponential_decomposition"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_TITLE       = "Exponential Decomposition"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_DESCRIPTION = "Details for exponential decomposition of full waveform data"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_STATUS      = "optional"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_SCHEMA = (
"{\"type\":\"object\",\"description\":\"Details for exponential decomposition "
"of full waveform "
"data\",\"patternProperties\":{\"^[0-9]+$\":{\"description\":\"one field per "
"channel, field name is channel "
"index\",\"$ref\":\"#/definitions/channel\"}},\"title\":\"Exponential Decomposi"
"tion\",\"additionalProperties\":false,\"definitions\":{\"channel\":{\"required"
"\":[\"delay\",\"scale\",\"parameter\"],\"properties\":{\"a_lin\":{\"exclusiveMinim"
"um\":false,\"minimum\":0,\"type\":\"number\",\"exclusiveMaximum\":false,\"descri"
"ption\":\"relative linear amplitude range "
"[0..1]\",\"maximum\":1},\"scale\":{\"description\":\"amplitude "
"calibration\",\"type\":\"number\"},\"delay\":{\"description\":\"delay "
"calibration in "
"seconds\",\"type\":\"number\"},\"parameter\":{\"description\":\"parameters of "
"the syswave exponential sum\",\"properties\":{\"gamma\":{\"items\":{\"type\":\"n"
"umber\"},\"description\":\"decay in 1/second\",\"type\":\"array\"},\"B\":{\"items\""
":{\"type\":\"number\"},\"description\":\"imaginary part of amplitude factor "
"in units of full-scale\",\"type\":\"array\"},\"A\":{\"items\":{\"type\":\"number\"}"
",\"description\":\"real part of amplitude factor in units of full-scale\","
"\"type\":\"array\"},\"omega\":{\"items\":{\"type\":\"number\"},\"description\":\"angu"
"lar frequency in Hz\",\"type\":\"array\"}},\"required\":[\"A\",\"B\",\"gamma\",\"ome"
"ga\"],\"type\":\"object\"}},\"type\":\"object\"}},\"$schema\":\"http://json-schema"
".org/draft-04/schema#\"}"
)
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_EXAMPLE = (
"{\"1\":{\"a_lin\":0.9,\"scale\":1.0,\"delay\":3.5e-09,\"parameter\":{\"gamma\":[-1"
"094726528.0,-769562752.0,-848000064.0],\"B\":[-3.9,0.0,-0.3],\"A\":[0.9,0."
"3,-1.3],\"omega\":[352020896.0,3647927552.0,-1977987072.0]}},\"0\":{\"a_lin"
"\":0.27,\"scale\":1.0,\"delay\":3.783458418887631e-09,\"parameter\":{\"gamma\":"
"[-1094726528.0,-769562752.0,-848000064.0],\"B\":[-3.9813032150268555,0.0"
"8622030913829803,-0.3152860999107361],\"A\":[0.9772450923919678,0.335433"
"5129261017,-1.312678575515747],\"omega\":[352020896.0,3647927552.0,-1977"
"987072.0]}}}"
)

# Details for Gaussian decomposition of full waveform data
RDB_RIEGL_GAUSSIAN_DECOMPOSITION             = "riegl.gaussian_decomposition"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_TITLE       = "Gaussian Decomposition"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_DESCRIPTION = "Details for Gaussian decomposition of full waveform data"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_STATUS      = "optional"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_SCHEMA = (
"{\"properties\":{\"amplitude_lsb_high_power\":{\"items\":{\"type\":\"number\"},\""
"type\":\"array\"},\"range_offset_sec_low_power\":{\"items\":{\"type\":\"number\"}"
",\"type\":\"array\"},\"amplitude_lsb_low_power\":{\"items\":{\"type\":\"number\"},"
"\"type\":\"array\"},\"range_offset_sec_high_power\":{\"items\":{\"type\":\"number"
"\"},\"type\":\"array\"},\"amplitude_db\":{\"items\":{\"type\":\"number\"},\"type\":\"a"
"rray\"}},\"required\":[\"amplitude_lsb_low_power\",\"amplitude_lsb_high_powe"
"r\",\"amplitude_db\",\"range_offset_sec_low_power\",\"range_offset_sec_high_"
"power\"],\"type\":\"object\",\"description\":\"riegl.gaussian_decomposition "
"contains information relevant for extracting calibrated amplitudes and"
" calibrated ranges from a Gaussian decomposition of full waveform "
"data. This information is contained in a table with five columns. Two "
"columns are to be used as input: amplitude_lsb_low_power and "
"amplitude_lsb_high_power. The other three columns provide the outputs."
" Amplitude_db gives the calibrated amplitude in the optical regime in "
"decibels. The range offset columns provide additive range offsets, "
"given in units of seconds, for each channel.\",\"title\":\"Gaussian "
"Decomposition\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_EXAMPLE = (
"{\"amplitude_lsb_high_power\":[],\"range_offset_sec_low_power\":[],\"amplit"
"ude_lsb_low_power\":[],\"range_offset_sec_high_power\":[],\"amplitude_db\":"
"[]}"
)

# Point cloud georeferencing information
RDB_RIEGL_GEO_TAG             = "riegl.geo_tag"
RDB_RIEGL_GEO_TAG_TITLE       = "Geo Tag"
RDB_RIEGL_GEO_TAG_DESCRIPTION = "Point cloud georeferencing information"
RDB_RIEGL_GEO_TAG_STATUS      = "optional"
RDB_RIEGL_GEO_TAG_SCHEMA = (
"{\"description\":\"Point cloud georeferencing information\",\"title\":\"Geo T"
"ag\",\"type\":\"object\",\"properties\":{\"pose\":{\"items\":{\"items\":{\"descripti"
"on\":\"columns\",\"type\":\"number\"},\"description\":\"rows\",\"minItems\":4,\"maxI"
"tems\":4,\"type\":\"array\"},\"description\":\"Coordinate Transformation "
"Matrix to transform from File Coordinate System to Global Coordinate "
"Reference System. 4x4 matrix stored as two dimensional array, row "
"major order.\",\"minItems\":4,\"maxItems\":4,\"type\":\"array\"},\"crs\":{\"descri"
"ption\":\"Global Coordinate Reference System. Please note that only 3D "
"Cartesian Coordinate Systems are "
"allowed.\",\"properties\":{\"epsg\":{\"description\":\"EPSG "
"code\",\"minimum\":0,\"type\":\"integer\"},\"name\":{\"description\":\"Coordinate "
"reference system "
"name\",\"type\":\"string\"},\"wkt\":{\"description\":\"\\\"Well-Known Text\\\" "
"string, OGC WKT dialect (see http://www.opengeospatial.org/standards/w"
"kt-crs)\",\"type\":\"string\"}},\"type\":\"object\"}},\"$schema\":\"http://json-sc"
"hema.org/draft-04/schema#\"}"
)
RDB_RIEGL_GEO_TAG_EXAMPLE = (
"{\"pose\":[[-0.269827776749716,-0.723017716139738,0.635954678449952,4063"
"882.500831],[0.962908599449764,-0.20260517250352,0.178208229833847,113"
"8787.607461],[0.0,0.660451759194338,0.7508684796801,4766084.550196],[0"
".0,0.0,0.0,1.0]],\"crs\":{\"epsg\":4978,\"name\":\"WGS84 "
"Geocentric\",\"wkt\":\"GEOCCS[\\\"WGS84 Geocentric\\\",DATUM[\\\"WGS84\\\",SPHEROI"
"D[\\\"WGS84\\\",6378137.000,298.257223563,AUTHORITY[\\\"EPSG\\\",\\\"7030\\\"]],AU"
"THORITY[\\\"EPSG\\\",\\\"6326\\\"]],PRIMEM[\\\"Greenwich\\\",0.0000000000000000,AU"
"THORITY[\\\"EPSG\\\",\\\"8901\\\"]],UNIT[\\\"Meter\\\",1.00000000000000000000,AUTH"
"ORITY[\\\"EPSG\\\",\\\"9001\\\"]],AXIS[\\\"X\\\",OTHER],AXIS[\\\"Y\\\",EAST],AXIS[\\\"Z\\"
"\",NORTH],AUTHORITY[\\\"EPSG\\\",\\\"4978\\\"]]\"}}"
)

# Geometric scale factor applied to point coordinates
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR             = "riegl.geometric_scale_factor"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_TITLE       = "Geometric Scale Factor"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_DESCRIPTION = "Geometric scale factor applied to point coordinates"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_STATUS      = "optional"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_SCHEMA = (
"{\"exclusiveMinimum\":true,\"description\":\"Geometric scale factor applied"
" to point coordinates\",\"type\":\"number\",\"minimum\":0,\"$schema\":\"http://j"
"son-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_EXAMPLE = (
"1.0"
)

# Parameters used for georeferencing of the point cloud
RDB_RIEGL_GEOREFERENCING_PARAMETERS             = "riegl.georeferencing_parameters"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_TITLE       = "Georeferencing Parameters"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_DESCRIPTION = "Parameters used for georeferencing of the point cloud"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_STATUS      = "optional"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_SCHEMA = (
"{\"description\":\"Parameters used for georeferencing of the point "
"cloud\",\"title\":\"Georeferencing Parameters\",\"type\":\"object\",\"properties"
"\":{\"trajectory_file\":{\"description\":\"Trajectory data used for "
"georeferencing of the point "
"cloud\",\"properties\":{\"file_uuid\":{\"description\":\"File's Universally "
"Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Trajectory "
"file extension, without the leading dot\",\"type\":\"string\"}},\"required\":"
"[\"file_extension\"],\"type\":\"object\"},\"socs_to_body_matrix\":{\"items\":{\"i"
"tems\":{\"description\":\"columns\",\"type\":\"number\"},\"description\":\"rows\",\""
"minItems\":4,\"maxItems\":4,\"type\":\"array\"},\"description\":\"Coordinate "
"Transformation Matrix to transform from Scanner's Own Coordinate "
"System to Body Coordinate System. 4x4 matrix stored as two dimensional"
" array, row major order.\",\"minItems\":4,\"maxItems\":4,\"type\":\"array\"},\"t"
"rajectory_offsets\":{\"description\":\"Correction offsets applied to the "
"trajectory data\",\"properties\":{\"version\":{\"description\":\"Meaning of "
"offset values and how to apply them; version 0: "
"Rz(yaw+offset_yaw)*Ry(pitch+offset_pitch)*Rx(roll+offset_roll), "
"version 1: Rz(yaw)*Ry(pitch)*Rx(roll) * Rz(offset_yaw)*Ry(offset_pitch"
")*Rx(offset_roll)\",\"type\":\"integer\"},\"offset_north\":{\"description\":\"[m"
"]\",\"type\":\"number\"},\"offset_east\":{\"description\":\"[m]\",\"type\":\"number\""
"},\"offset_pitch\":{\"description\":\"[deg]\",\"type\":\"number\"},\"offset_time\""
":{\"description\":\"[s]\",\"type\":\"number\"},\"offset_roll\":{\"description\":\"["
"deg]\",\"type\":\"number\"},\"offset_height\":{\"description\":\"[m]\",\"type\":\"nu"
"mber\"},\"offset_yaw\":{\"description\":\"[deg]\",\"type\":\"number\"}},\"type\":\"o"
"bject\"},\"socs_to_rocs_matrix\":{\"items\":{\"items\":{\"description\":\"column"
"s\",\"type\":\"number\"},\"description\":\"rows\",\"minItems\":4,\"maxItems\":4,\"ty"
"pe\":\"array\"},\"description\":\"Coordinate Transformation Matrix to "
"transform from Scanner's Own Coordinate System to Record Coordinate "
"System. 4x4 matrix stored as two dimensional array, row major order.\","
"\"minItems\":4,\"maxItems\":4,\"type\":\"array\"},\"body_coordinate_system_type"
"\":{\"description\":\"BODY coordinate frame (NED: North-East-Down, ENU: "
"East-North-Up), default: NED\",\"enum\":[\"NED\",\"ENU\"],\"type\":\"string\"}},\""
"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_GEOREFERENCING_PARAMETERS_EXAMPLE = (
"{\"trajectory_file\":{\"file_uuid\":\"93a03615-66c0-4bea-8ff8-c577378fe660\""
",\"file_extension\":\"pofx\"},\"socs_to_body_matrix\":[[-0.269827776749716,-"
"0.723017716139738,0.635954678449952,0.0],[0.962908599449764,-0.2026051"
"7250352,0.178208229833847,0.0],[0.0,0.660451759194338,0.7508684796801,"
"0.0],[0.0,0.0,0.0,1.0]],\"trajectory_offsets\":{\"version\":0,\"offset_nort"
"h\":0.07,\"offset_east\":0.15,\"offset_pitch\":0.01,\"offset_time\":18.007,\"o"
"ffset_roll\":0.03,\"offset_height\":-0.2,\"offset_yaw\":-0.45},\"body_coordi"
"nate_system_type\":\"NED\"}"
)

# Map of item names
RDB_RIEGL_ITEM_NAMES             = "riegl.item_names"
RDB_RIEGL_ITEM_NAMES_TITLE       = "Item Names"
RDB_RIEGL_ITEM_NAMES_DESCRIPTION = "Map of item names"
RDB_RIEGL_ITEM_NAMES_STATUS      = "optional"
RDB_RIEGL_ITEM_NAMES_SCHEMA = (
"{\"type\":\"object\",\"description\":\"Map of item "
"names\",\"patternProperties\":{\"^-?[0-9]+$\":{\"description\":\"One field per"
" item, field name is item id, field value is item "
"name\",\"type\":\"string\"}},\"title\":\"Item Names\",\"additionalProperties\":fa"
"lse,\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_ITEM_NAMES_EXAMPLE = (
"{\"-1\":\"Name of item with id -1\",\"2\":\"Name of item with id 2\",\"1\":\"Name"
" of item with id 1\",\"47\":\"Name of item with id 47\"}"
)

# License keys for software features
RDB_RIEGL_LICENSES             = "riegl.licenses"
RDB_RIEGL_LICENSES_TITLE       = "Software License Keys"
RDB_RIEGL_LICENSES_DESCRIPTION = "License keys for software features"
RDB_RIEGL_LICENSES_STATUS      = "optional"
RDB_RIEGL_LICENSES_SCHEMA = (
"{\"type\":\"object\",\"description\":\"License keys for software "
"features\",\"patternProperties\":{\"^.*$\":{\"items\":{\"description\":\"License"
" key (example: '46AE032A - 39882AC4 - 9EC0A184 - "
"6F163D73')\",\"type\":\"string\"},\"description\":\"Each field of the object "
"represents a feature and holds a list of license keys, where the field"
" name is the feature "
"name.\",\"minItems\":1,\"type\":\"array\"}},\"title\":\"Software License Keys\",\""
"additionalProperties\":false,\"$schema\":\"http://json-schema.org/draft-04"
"/schema#\"}"
)
RDB_RIEGL_LICENSES_EXAMPLE = (
"{\"Full Waveform Analysis Topography\":[\"0FD5FF07 - 011A1255 - 9F76CACA "
"- 8D2ED557\"],\"Georeferencing\":[\"46AE032A - 39882AC4 - 9EC0A184 - "
"6F163D73\"],\"Full Waveform Analysis Topography with GPU "
"support\":[\"8AB44126 - 23B92250 - 16E2689F - 34EF7E7B\"],\"MTA "
"resolution\":[\"468E020A - 39A922E4 - B681A184 - 673E3D72\"]}"
)

# Parameters for MTA processing
RDB_RIEGL_MTA_SETTINGS             = "riegl.mta_settings"
RDB_RIEGL_MTA_SETTINGS_TITLE       = "MTA Settings"
RDB_RIEGL_MTA_SETTINGS_DESCRIPTION = "Parameters for MTA processing"
RDB_RIEGL_MTA_SETTINGS_STATUS      = "optional"
RDB_RIEGL_MTA_SETTINGS_SCHEMA = (
"{\"description\":\"Parameters for MTA processing\",\"title\":\"MTA Settings\","
"\"type\":\"object\",\"properties\":{\"zone_width\":{\"description\":\"Width of a "
"MTA zone in meter.\",\"minimum\":0,\"type\":\"number\"},\"modulation_depth\":{\""
"description\":\"Depth of pulse position modulation in meter.\",\"minimum\":"
"0,\"type\":\"number\"},\"zone_count\":{\"description\":\"Maximum number of MTA "
"zones.\",\"maximum\":255,\"minimum\":0,\"type\":\"integer\"}},\"$schema\":\"http:/"
"/json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_MTA_SETTINGS_EXAMPLE = (
"{\"zone_width\":149.896225,\"modulation_depth\":9.368514,\"zone_count\":23}"
)

# Lookup table for range correction based on raw range
RDB_RIEGL_NEAR_RANGE_CORRECTION             = "riegl.near_range_correction"
RDB_RIEGL_NEAR_RANGE_CORRECTION_TITLE       = "Near Range Correction Table"
RDB_RIEGL_NEAR_RANGE_CORRECTION_DESCRIPTION = "Lookup table for range correction based on raw range"
RDB_RIEGL_NEAR_RANGE_CORRECTION_STATUS      = "optional"
RDB_RIEGL_NEAR_RANGE_CORRECTION_SCHEMA = (
"{\"properties\":{\"content\":{\"items\":{\"type\":\"number\"},\"description\":\"Cor"
"rection value [m] to be added to the raw range\",\"minItems\":1,\"maxItems"
"\":2000,\"type\":\"array\"},\"delta\":{\"description\":\"Delta between table "
"entries [m], first entry is at range = 0 m\",\"type\":\"number\"}},\"require"
"d\":[\"delta\",\"content\"],\"type\":\"object\",\"description\":\"Lookup table for"
" range correction based on raw range\",\"title\":\"Near Range Correction "
"Table\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_NEAR_RANGE_CORRECTION_EXAMPLE = (
"{\"content\":[0.0],\"delta\":0.512}"
)

# Standard deviation for range and amplitude as a function of amplitude
RDB_RIEGL_NOISE_ESTIMATES             = "riegl.noise_estimates"
RDB_RIEGL_NOISE_ESTIMATES_TITLE       = "Noise Estimates"
RDB_RIEGL_NOISE_ESTIMATES_DESCRIPTION = "Standard deviation for range and amplitude as a function of amplitude"
RDB_RIEGL_NOISE_ESTIMATES_STATUS      = "optional"
RDB_RIEGL_NOISE_ESTIMATES_SCHEMA = (
"{\"properties\":{\"amplitude_sigma\":{\"items\":{\"type\":\"number\"},\"descripti"
"on\":\"Sigma amplitude [dB]\",\"type\":\"array\"},\"range_sigma\":{\"items\":{\"ty"
"pe\":\"number\"},\"description\":\"Sigma range [m]\",\"type\":\"array\"},\"amplitu"
"de\":{\"items\":{\"type\":\"number\"},\"description\":\"Amplitude [dB]\",\"type\":\""
"array\"}},\"required\":[\"amplitude\",\"range_sigma\",\"amplitude_sigma\"],\"typ"
"e\":\"object\",\"description\":\"Standard deviation for range and amplitude "
"as a function of amplitude\",\"title\":\"Noise "
"Estimates\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_NOISE_ESTIMATES_EXAMPLE = (
"{\"amplitude_sigma\":[0.988,0.988,0.875,0.774,0.686,0.608,0.54,0.482,0.4"
"32,0.39,0.354],\"range_sigma\":[0.065,0.056,0.046,0.038,0.032,0.027,0.02"
"4,0.021,0.018,0.016,0.014],\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7."
"0,8.0,9.0,10.0]}"
)

# Notch filter parameters for window glass echoes
RDB_RIEGL_NOTCH_FILTER             = "riegl.notch_filter"
RDB_RIEGL_NOTCH_FILTER_TITLE       = "Notch Filter"
RDB_RIEGL_NOTCH_FILTER_DESCRIPTION = "Notch filter parameters for window glass echoes"
RDB_RIEGL_NOTCH_FILTER_STATUS      = "optional"
RDB_RIEGL_NOTCH_FILTER_SCHEMA = (
"{\"properties\":{\"amplitude_maximum\":{\"description\":\"Maximum amplitude ["
"dB]\",\"minimum\":0,\"type\":\"number\"},\"range_maximum\":{\"description\":\"Maxi"
"mum range "
"[m]\",\"type\":\"number\"},\"range_minimum\":{\"description\":\"Minimum range [m"
"]\",\"type\":\"number\"}},\"required\":[\"range_minimum\",\"range_maximum\",\"ampl"
"itude_maximum\"],\"type\":\"object\",\"description\":\"Notch filter parameters"
" for window glass echoes\",\"title\":\"Notch "
"Filter\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_NOTCH_FILTER_EXAMPLE = (
"{\"amplitude_maximum\":18.0,\"range_maximum\":0.2,\"range_minimum\":-0.5}"
)

# Details about the pixels contained in the file
RDB_RIEGL_PIXEL_INFO             = "riegl.pixel_info"
RDB_RIEGL_PIXEL_INFO_TITLE       = "Pixel Information"
RDB_RIEGL_PIXEL_INFO_DESCRIPTION = "Details about the pixels contained in the file"
RDB_RIEGL_PIXEL_INFO_STATUS      = "optional"
RDB_RIEGL_PIXEL_INFO_SCHEMA = (
"{\"properties\":{\"size_llcs\":{\"description\":\"Size of pixels in a locally"
" levelled cartesian coordinate system (xy). This is only used for "
"pixels based on a map projection.\",\"$ref\":\"#/definitions/pixel_size\"},"
"\"size\":{\"description\":\"Size of pixels in file coordinate system.\",\"$re"
"f\":\"#/definitions/pixel_size\"}},\"required\":[\"size\"],\"type\":\"object\",\"d"
"escription\":\"Details about the pixels contained in the "
"file\",\"title\":\"Pixel Information\",\"definitions\":{\"pixel_size\":{\"items\""
":{\"description\":\"Length of pixel edge "
"[m].\",\"minimum\":0,\"type\":\"number\"},\"description\":\"Size of pixels.\",\"mi"
"nItems\":2,\"maxItems\":2,\"type\":\"array\"}},\"$schema\":\"http://json-schema."
"org/draft-04/schema#\"}"
)
RDB_RIEGL_PIXEL_INFO_EXAMPLE = (
"{\"size_llcs\":[0.5156575252891171,0.5130835356683303],\"size\":[0.5971642"
"834779395,0.5971642834779395]}"
)

# Details about the plane patch matching process
RDB_RIEGL_PLANE_PATCH_MATCHING             = "riegl.plane_patch_matching"
RDB_RIEGL_PLANE_PATCH_MATCHING_TITLE       = "Plane Patch Matching"
RDB_RIEGL_PLANE_PATCH_MATCHING_DESCRIPTION = "Details about the plane patch matching process"
RDB_RIEGL_PLANE_PATCH_MATCHING_STATUS      = "optional"
RDB_RIEGL_PLANE_PATCH_MATCHING_SCHEMA = (
"{\"properties\":{\"plane_patch_file_one\":{\"description\":\"Reference to the"
" plane patch file one\",\"$ref\":\"#/definitions/file_reference\"},\"plane_p"
"atch_file_two\":{\"description\":\"Reference to the plane patch file two\","
"\"$ref\":\"#/definitions/file_reference\"}},\"required\":[\"plane_patch_file_"
"one\",\"plane_patch_file_two\"],\"type\":\"object\",\"description\":\"Details "
"about the plane patch matching process\",\"title\":\"Plane Patch "
"Matching\",\"definitions\":{\"file_reference\":{\"description\":\"Reference to"
" a plane patch file\",\"properties\":{\"file_uuid\":{\"description\":\"Plane "
"patch file's Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_path\":{\"description\":\"Path of the plane "
"patch file relative to the match file\",\"type\":\"string\"}},\"required\":[\""
"file_uuid\",\"file_path\"],\"type\":\"object\"}},\"$schema\":\"http://json-schem"
"a.org/draft-04/schema#\"}"
)
RDB_RIEGL_PLANE_PATCH_MATCHING_EXAMPLE = (
"{\"plane_patch_file_one\":{\"file_uuid\":\"810f5d57-eccf-49ed-b07a-0cdd109b"
"4213\",\"file_path\":\"Record009_Line001/191025_121410_Scanner_1.ptch\"},\"p"
"lane_patch_file_two\":{\"file_uuid\":\"fa47d509-a64e-49ce-8b14-ff3130fbefa"
"9\",\"file_path\":\"project.ptch\"}}"
)

# Statistics about plane patches found by plane patch extractor
RDB_RIEGL_PLANE_PATCH_STATISTICS             = "riegl.plane_patch_statistics"
RDB_RIEGL_PLANE_PATCH_STATISTICS_TITLE       = "Plane Patch Statistics"
RDB_RIEGL_PLANE_PATCH_STATISTICS_DESCRIPTION = "Statistics about plane patches found by plane patch extractor"
RDB_RIEGL_PLANE_PATCH_STATISTICS_STATUS      = "optional"
RDB_RIEGL_PLANE_PATCH_STATISTICS_SCHEMA = (
"{\"description\":\"Statistics about plane patches found by plane patch "
"extractor\",\"title\":\"Plane Patch Statistics\",\"type\":\"object\",\"propertie"
"s\":{\"total_area\":{\"description\":\"sum of all plane patch areas [m\\u00b2"
"]\",\"type\":\"number\"},\"total_horizontal_area\":{\"description\":\"sum of all"
" plane patch areas projected to horizontal plane [m\\u00b2]\",\"type\":\"nu"
"mber\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_PLANE_PATCH_STATISTICS_EXAMPLE = (
"{\"total_area\":14007.965,\"total_horizontal_area\":13954.601}"
)

# Settings and classes for plane slope classification
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO             = "riegl.plane_slope_class_info"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_TITLE       = "Plane Slope Class Info"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_DESCRIPTION = "Settings and classes for plane slope classification"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_STATUS      = "optional"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_SCHEMA = (
"{\"properties\":{\"settings\":{\"description\":\"Classification settings, "
"details see documentation of rdbplanes\",\"oneOf\":[{\"$ref\":\"#/definition"
"s/method-1\"},{\"$ref\":\"#/definitions/method-2\"}],\"type\":\"object\"},\"clas"
"ses\":{\"description\":\"Class definition "
"table\",\"patternProperties\":{\"^[0-9]+$\":{\"description\":\"one field per "
"class, field name is class number, field value is class name\",\"type\":\""
"string\"}},\"additionalProperties\":false,\"type\":\"object\"}},\"required\":[\""
"settings\",\"classes\"],\"type\":\"object\",\"description\":\"Settings and "
"classes for plane slope classification\",\"title\":\"Plane Slope Class "
"Info\",\"definitions\":{\"method-1\":{\"description\":\"Classification method "
"1\",\"properties\":{\"maximum_inclination_angle_horizontal\":{\"description\""
":\"maximum inclination angle of horizontal plane patches [deg]\",\"maximu"
"m\":360.0,\"minimum\":-360.0,\"type\":\"number\"},\"plane_classification_metho"
"d\":{\"description\":\"method ID (=1)\",\"maximum\":1,\"minimum\":1,\"type\":\"int"
"eger\"}},\"required\":[\"plane_classification_method\",\"maximum_inclination"
"_angle_horizontal\"],\"type\":\"object\"},\"method-2\":{\"description\":\"Classi"
"fication method 2\",\"properties\":{\"sloping_plane_classes_minimum_angle\""
":{\"description\":\"minimum inclination angle of sloping plane patches [d"
"eg]\",\"maximum\":360.0,\"minimum\":-360.0,\"type\":\"number\"},\"sloping_plane_"
"classes_maximum_angle\":{\"description\":\"maximum inclination angle of "
"sloping plane patches [deg]\",\"maximum\":360.0,\"minimum\":-360.0,\"type\":\""
"number\"},\"plane_classification_method\":{\"description\":\"method ID (=2)\""
",\"maximum\":2,\"minimum\":2,\"type\":\"integer\"}},\"required\":[\"plane_classif"
"ication_method\",\"sloping_plane_classes_minimum_angle\",\"sloping_plane_c"
"lasses_maximum_angle\"],\"type\":\"object\"}},\"$schema\":\"http://json-schema"
".org/draft-04/schema#\"}"
)
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_EXAMPLE = (
"{\"settings\":{\"sloping_plane_classes_minimum_angle\":10.0,\"sloping_plane"
"_classes_maximum_angle\":70.0,\"plane_classification_method\":2},\"classes"
"\":{\"14\":\"horizontal, pointing down\",\"3\":\"sloping, pointing up and "
"south\",\"5\":\"sloping, pointing up and west\",\"9\":\"vertical, pointing "
"west\",\"1\":\"horizontal, pointing up\",\"8\":\"vertical, pointing "
"north\",\"13\":\"sloping, pointing down and west\",\"10\":\"sloping, pointing "
"down and east\",\"12\":\"sloping, pointing down and north\",\"4\":\"sloping, "
"pointing up and north\",\"7\":\"vertical, pointing south\",\"11\":\"sloping, "
"pointing down and south\",\"6\":\"vertical, pointing east\",\"2\":\"sloping, "
"pointing up and east\"}}"
)

# Grouping and sorting of point attributes for visualization purposes
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS             = "riegl.point_attribute_groups"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_TITLE       = "Point Attribute Groups"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_DESCRIPTION = "Grouping and sorting of point attributes for visualization purposes"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_STATUS      = "optional"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_SCHEMA = (
"{\"type\":\"object\",\"description\":\"Grouping and sorting of point "
"attributes for visualization "
"purposes\",\"patternProperties\":{\"^.*$\":{\"items\":{\"description\":\"Point "
"attribute full name or name pattern (perl regular expression "
"syntax)\",\"type\":\"string\"},\"description\":\"Each field of the object "
"represents a point attribute group and holds a list of point "
"attributes, where the field name is the group "
"name.\",\"minItems\":1,\"type\":\"array\"}},\"title\":\"Point Attribute Groups\","
"\"additionalProperties\":false,\"$schema\":\"http://json-schema.org/draft-0"
"4/schema#\"}"
)
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_EXAMPLE = (
"{\"Primary Attributes\":[\"riegl.reflectance\",\"riegl.amplitude\",\"riegl.de"
"viation\"],\"Time\":[\"riegl.timestamp\"],\"Secondary "
"Attributes\":[\"riegl.mirror_facet\",\"riegl.waveform_available\"],\"Other A"
"ttributes\":[\"riegl.selected\",\"riegl.visible\"],\"Coordinates/Vectors\":[\""
"riegl.xyz\",\"riegl.range\",\"riegl.theta\",\"riegl.phi\"]}"
)

# Details about point cloud files
RDB_RIEGL_POINTCLOUD_INFO             = "riegl.pointcloud_info"
RDB_RIEGL_POINTCLOUD_INFO_TITLE       = "Point Cloud Information"
RDB_RIEGL_POINTCLOUD_INFO_DESCRIPTION = "Details about point cloud files"
RDB_RIEGL_POINTCLOUD_INFO_STATUS      = "optional"
RDB_RIEGL_POINTCLOUD_INFO_SCHEMA = (
"{\"description\":\"Details about point cloud files\",\"title\":\"Point Cloud "
"Information\",\"type\":\"object\",\"properties\":{\"field_of_application\":{\"de"
"scription\":\"Field of application\",\"enum\":[\"unknown\",\"SLS\",\"TLS\",\"KLS\","
"\"MLS\",\"ULS\",\"ALS\",\"BLS\",\"ILS\"],\"type\":\"string\"},\"comments\":{\"descripti"
"on\":\"Comments\",\"type\":\"string\"},\"project\":{\"description\":\"Project name"
"\",\"type\":\"string\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#"
"\"}"
)
RDB_RIEGL_POINTCLOUD_INFO_EXAMPLE = (
"{\"field_of_application\":\"ALS\",\"comments\":\"Line 3\",\"project\":\"Campaign "
"4\"}"
)

# Estimated position and orientation information
RDB_RIEGL_POSE_ESTIMATION             = "riegl.pose_estimation"
RDB_RIEGL_POSE_ESTIMATION_TITLE       = "Pose Estimation"
RDB_RIEGL_POSE_ESTIMATION_DESCRIPTION = "Estimated position and orientation information"
RDB_RIEGL_POSE_ESTIMATION_STATUS      = "optional"
RDB_RIEGL_POSE_ESTIMATION_SCHEMA = (
"{\"properties\":{\"position\":{\"description\":\"Position coordinates and "
"position accuracy values as measured by GNSS in the specified "
"Coordinate Reference System (CRS)\",\"properties\":{\"vertical_accuracy\":{"
"\"exclusiveMinimum\":true,\"description\":\"Vertical accuracy "
"[m]\",\"minimum\":0,\"type\":\"number\"},\"crs\":{\"description\":\"Global "
"Coordinate Reference System\",\"properties\":{\"epsg\":{\"description\":\"EPSG"
" "
"code\",\"minimum\":0,\"type\":\"integer\"},\"wkt\":{\"description\":\"\\\"Well-Known"
" Text\\\" string, OGC WKT dialect (see http://www.opengeospatial.org/sta"
"ndards/wkt-crs)\",\"type\":\"string\"}},\"required\":[\"epsg\"],\"type\":\"object\""
"},\"horizontal_accuracy\":{\"exclusiveMinimum\":true,\"description\":\"Horizo"
"ntal accuracy [m]\",\"minimum\":0,\"type\":\"number\"},\"coordinate_1\":{\"descr"
"iption\":\"Coordinate 1 as defined by axis 1 of the specified CRS (e.g.,"
" X, "
"Latitude)\",\"type\":\"number\"},\"coordinate_2\":{\"description\":\"Coordinate "
"2 as defined by axis 2 of the specified CRS (e.g., Y, "
"Longitude)\",\"type\":\"number\"},\"coordinate_3\":{\"description\":\"Coordinate"
" 3 as defined by axis 3 of the specified CRS (e.g., Z, Altitude)\",\"typ"
"e\":\"number\"}},\"required\":[\"coordinate_1\",\"coordinate_2\",\"coordinate_3\""
",\"horizontal_accuracy\",\"vertical_accuracy\",\"crs\"],\"type\":\"object\"},\"ba"
"rometric_height_amsl\":{\"description\":\"Altitude determined based on the"
" atmospheric pressure according to the standard atmosphere laws "
"[m].\",\"type\":\"number\"},\"orientation\":{\"description\":\"Orientation "
"values and orientation accuracies, measured with IMU or inclination "
"sensors.\",\"properties\":{\"roll\":{\"description\":\"Roll angle about "
"scanner X-axis [deg]\",\"maximum\":360,\"minimum\":-360,\"type\":\"number\"},\"y"
"aw_accuracy\":{\"exclusiveMinimum\":true,\"description\":\"Yaw angle "
"accuracy [deg]\",\"minimum\":0,\"type\":\"number\"},\"roll_accuracy\":{\"exclusi"
"veMinimum\":true,\"description\":\"Roll angle accuracy [deg]\",\"minimum\":0,"
"\"type\":\"number\"},\"pitch_accuracy\":{\"exclusiveMinimum\":true,\"descriptio"
"n\":\"Pitch angle accuracy "
"[deg]\",\"minimum\":0,\"type\":\"number\"},\"pitch\":{\"description\":\"Pitch "
"angle about scanner Y-axis [deg]\",\"maximum\":360,\"minimum\":-360,\"type\":"
"\"number\"},\"yaw\":{\"description\":\"Yaw angle about scanner Z-axis [deg]\","
"\"maximum\":360,\"minimum\":-360,\"type\":\"number\"}},\"required\":[\"roll\",\"pit"
"ch\",\"yaw\",\"roll_accuracy\",\"pitch_accuracy\",\"yaw_accuracy\"],\"type\":\"obj"
"ect\"}},\"required\":[\"orientation\"],\"type\":\"object\",\"description\":\"Estim"
"ated position and orientation information as measured by GNSS, IMU or "
"inclination sensors\",\"title\":\"Pose "
"Estimation\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_POSE_ESTIMATION_EXAMPLE = (
"{\"position\":{\"vertical_accuracy\":1.3314999341964722,\"crs\":{\"epsg\":4979"
",\"wkt\":\"GEOGCS[\\\"WGS84 / Geographic\\\",DATUM[\\\"WGS84\\\",SPHEROID[\\\"WGS84"
"\\\",6378137.000,298.257223563,AUTHORITY[\\\"EPSG\\\",\\\"7030\\\"]],AUTHORITY[\\"
"\"EPSG\\\",\\\"6326\\\"]],PRIMEM[\\\"Greenwich\\\",0.0000000000000000,AUTHORITY[\\"
"\"EPSG\\\",\\\"8901\\\"]],UNIT[\\\"Degree\\\",0.01745329251994329547,AUTHORITY[\\\""
"EPSG\\\",\\\"9102\\\"]],AXIS[\\\"Latitude\\\",NORTH],AXIS[\\\"Longitude\\\",EAST],AU"
"THORITY[\\\"EPSG\\\",\\\"4979\\\"]]\"},\"horizontal_accuracy\":0.810699999332428,"
"\"coordinate_1\":48.655799473,\"coordinate_2\":15.645033406,\"coordinate_3\""
":362.7124938964844},\"barometric_height_amsl\":386.7457796227932,\"orient"
"ation\":{\"roll\":3.14743073066123,\"yaw_accuracy\":1.0094337839368757,\"rol"
"l_accuracy\":0.009433783936875745,\"pitch_accuracy\":0.009433783936875745"
",\"pitch\":1.509153024827064,\"yaw\":101.87293630292045}}"
)

# Details on position and orientation sensors
RDB_RIEGL_POSE_SENSORS             = "riegl.pose_sensors"
RDB_RIEGL_POSE_SENSORS_TITLE       = "Pose Sensors"
RDB_RIEGL_POSE_SENSORS_DESCRIPTION = "Details on position and orientation sensors"
RDB_RIEGL_POSE_SENSORS_STATUS      = "optional"
RDB_RIEGL_POSE_SENSORS_SCHEMA = (
"{\"properties\":{\"accelerometer\":{\"description\":\"Accelerometer "
"details\",\"properties\":{\"offset\":{\"description\":\"Value to be subtracted"
" from raw measurement values\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":"
"{\"description\":\"Sensitive Y axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"z_axis\":{\"description\":\"Sensitive Z"
" axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"origin\":{\"description\":\"Sensor "
"origin in SOCS [m] at frame angle = 0\",\"$ref\":\"#/definitions/vector\"},"
"\"relative_nonlinearity\":{\"description\":\"Relative nonlinearity, dimensi"
"onless\",\"$ref\":\"#/definitions/vector\"},\"unit\":{\"exclusiveMinimum\":true"
",\"description\":\"Unit of raw data and calibration values, 1 LSB in 9.81"
" m/s\\u00b2\",\"minimum\":0,\"type\":\"number\"},\"x_axis\":{\"description\":\"Sens"
"itive X axis of sensor at frame angle = 0\",\"$ref\":\"#/definitions/vecto"
"r\"}},\"required\":[\"unit\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\",\"origin\",\""
"relative_nonlinearity\"],\"type\":\"object\"},\"magnetic_field_sensor\":{\"des"
"cription\":\"Magnetic Field Sensor "
"details\",\"properties\":{\"offset\":{\"description\":\"Value to be subtracted"
" from raw measurement values\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":"
"{\"description\":\"Sensitive Y axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"z_axis\":{\"description\":\"Sensitive Z"
" axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"fixed\":{\"description\":\"Distortion "
"of magnetic field caused by non-rotating scanner part\",\"$ref\":\"#/defin"
"itions/vector\"},\"relative_nonlinearity\":{\"description\":\"Relative "
"nonlinearity, dimensionless\",\"$ref\":\"#/definitions/vector\"},\"unit\":{\"e"
"xclusiveMinimum\":true,\"description\":\"Unit of raw data and calibration "
"values, 1 LSB in "
"nT\",\"minimum\":0,\"type\":\"number\"},\"x_axis\":{\"description\":\"Sensitive X "
"axis of sensor at frame angle = 0\",\"$ref\":\"#/definitions/vector\"}},\"re"
"quired\":[\"unit\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\",\"fixed\",\"relative_"
"nonlinearity\"],\"type\":\"object\"},\"gyroscope\":{\"description\":\"Gyroscope "
"details\",\"properties\":{\"offset\":{\"description\":\"Value to be subtracted"
" from raw measurement values\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":"
"{\"description\":\"Sensitive Y axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"z_axis\":{\"description\":\"Sensitive Z"
" axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"origin\":{\"description\":\"Sensor "
"origin in SOCS [m] at frame angle = 0\",\"$ref\":\"#/definitions/vector\"},"
"\"relative_nonlinearity\":{\"description\":\"Relative nonlinearity, dimensi"
"onless\",\"$ref\":\"#/definitions/vector\"},\"unit\":{\"exclusiveMinimum\":true"
",\"description\":\"Unit of raw data and calibration values, 1 LSB in "
"rad/s\",\"minimum\":0,\"type\":\"number\"},\"x_axis\":{\"description\":\"Sensitive"
" X axis of sensor at frame angle = 0\",\"$ref\":\"#/definitions/vector\"}},"
"\"required\":[\"unit\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\",\"origin\",\"relat"
"ive_nonlinearity\"],\"type\":\"object\"}},\"required\":[\"gyroscope\",\"accelero"
"meter\",\"magnetic_field_sensor\"],\"type\":\"object\",\"description\":\"Details"
" on position and orientation sensors\",\"title\":\"Pose "
"Sensors\",\"definitions\":{\"vector\":{\"items\":{\"description\":\"Index 0=X, "
"1=Y, 2=Z component\",\"type\":\"number\"},\"minItems\":3,\"maxItems\":3,\"type\":"
"\"array\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_POSE_SENSORS_EXAMPLE = (
"{\"accelerometer\":{\"offset\":[-733.3636474609375,58.969032287597656,1060"
".2550048828125],\"y_axis\":[-7.027288913726807,-44.12333679199219,14952."
"3701171875],\"z_axis\":[1.639882206916809,15166.744140625,-116.997428894"
"04297],\"origin\":[0.026900000870227814,-0.03999999910593033,-0.08950000"
"256299973],\"relative_nonlinearity\":[0.0,0.0,0.0],\"unit\":6.666666740784"
"422e-05,\"x_axis\":[-15008.123046875,56.956390380859375,-60.517566680908"
"2]},\"magnetic_field_sensor\":{\"offset\":[-23812.052734375,5606.576660156"
"25,2493.28125],\"y_axis\":[0.00027888521435670555,-0.011427424848079681,"
"-5.204829722060822e-05],\"z_axis\":[0.00041987866279669106,7.87697790656"
"2388e-05,0.011407104320824146],\"fixed\":[-1576.010498046875,1596.081787"
"109375,0.0],\"relative_nonlinearity\":[0.0,0.0,0.0],\"unit\":91.7431182861"
"3281,\"x_axis\":[-0.011162743903696537,-2.315962774446234e-05,0.00016818"
"844596855342]},\"gyroscope\":{\"offset\":[-50.92609786987305,146.156433105"
"46875,62.4327278137207],\"y_axis\":[-0.440765917301178,-0.78973996639251"
"71,119.5894775390625],\"z_axis\":[0.555869996547699,119.22135162353516,0"
".467585027217865],\"origin\":[0.026900000870227814,-0.03999999910593033,"
"-0.08950000256299973],\"relative_nonlinearity\":[2.888176311444113e-07,1"
".06274164579645e-07,-1.7186295080634935e-39],\"unit\":0.0001454441080568"
"3583,\"x_axis\":[-121.195556640625,0.8219714164733887,0.2313031703233719"
"]}}"
)

# Laser pulse position modulation used for MTA resolution
RDB_RIEGL_PULSE_POSITION_MODULATION             = "riegl.pulse_position_modulation"
RDB_RIEGL_PULSE_POSITION_MODULATION_TITLE       = "Pulse Position Modulation"
RDB_RIEGL_PULSE_POSITION_MODULATION_DESCRIPTION = "Laser pulse position modulation used for MTA resolution"
RDB_RIEGL_PULSE_POSITION_MODULATION_STATUS      = "optional"
RDB_RIEGL_PULSE_POSITION_MODULATION_SCHEMA = (
"{\"properties\":{\"code_phase_mode\":{\"description\":\"0: no "
"synchronization, 1: toggle between 2 phases, 2: increment with phase_i"
"ncrement\",\"maximum\":255,\"minimum\":0,\"type\":\"integer\"},\"phase_step\":{\"d"
"escription\":\"Step width in phase of modulation code from line to line\""
",\"maximum\":255,\"minimum\":0,\"type\":\"integer\"},\"pulse_interval\":{\"items\""
":{\"minimum\":0,\"type\":\"number\"},\"description\":\"Explicit table of the "
"pulse position modulation used for MTA resolution. Table gives times "
"between successive laser pulses in "
"seconds.\",\"type\":\"array\"},\"num_mod_ampl\":{\"description\":\"Number of "
"different modulation amplitudes (2: binary modulation)\",\"maximum\":255,"
"\"minimum\":0,\"type\":\"integer\"},\"length\":{\"description\":\"Length of code\""
",\"maximum\":255,\"minimum\":0,\"type\":\"integer\"}},\"required\":[\"length\",\"nu"
"m_mod_ampl\",\"pulse_interval\"],\"type\":\"object\",\"description\":\"Laser "
"pulse position modulation used for MTA resolution\",\"title\":\"Pulse "
"Position "
"Modulation\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_PULSE_POSITION_MODULATION_EXAMPLE = (
"{\"code_phase_mode\":2,\"phase_step\":5,\"pulse_interval\":[2.759375e-06,2.7"
"59375e-06,2.759375e-06,2.759375e-06,2.821875e-06,2.759375e-06,2.759375"
"e-06,2.821875e-06,2.759375e-06,2.821875e-06,2.821875e-06,2.759375e-06,"
"2.759375e-06,2.821875e-06,2.821875e-06,2.821875e-06,2.821875e-06,2.821"
"875e-06,2.759375e-06,2.759375e-06,2.759375e-06,2.821875e-06,2.821875e-"
"06,2.759375e-06,2.821875e-06,2.821875e-06,2.821875e-06,2.759375e-06,2."
"821875e-06,2.759375e-06,2.821875e-06],\"num_mod_ampl\":2,\"length\":31}"
)

# Statistics about target distance wrt. SOCS origin
RDB_RIEGL_RANGE_STATISTICS             = "riegl.range_statistics"
RDB_RIEGL_RANGE_STATISTICS_TITLE       = "Range Statistics"
RDB_RIEGL_RANGE_STATISTICS_DESCRIPTION = "Statistics about target distance wrt. SOCS origin"
RDB_RIEGL_RANGE_STATISTICS_STATUS      = "optional"
RDB_RIEGL_RANGE_STATISTICS_SCHEMA = (
"{\"properties\":{\"maximum\":{\"description\":\"Maximum "
"value\",\"type\":\"number\"},\"std_dev\":{\"description\":\"Standard "
"deviation\",\"type\":\"number\"},\"minimum\":{\"description\":\"Minimum "
"value\",\"type\":\"number\"},\"average\":{\"description\":\"Average value\",\"type"
"\":\"number\"}},\"required\":[\"minimum\",\"average\",\"maximum\",\"std_dev\"],\"typ"
"e\":\"object\",\"description\":\"Statistics about target distance wrt. SOCS "
"origin\",\"title\":\"Range "
"Statistics\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_RANGE_STATISTICS_EXAMPLE = (
"{\"maximum\":574.35,\"std_dev\":24.349,\"minimum\":0.919,\"average\":15.49738}"
)

# Receiver Internals
RDB_RIEGL_RECEIVER_INTERNALS             = "riegl.receiver_internals"
RDB_RIEGL_RECEIVER_INTERNALS_TITLE       = "Receiver Internals"
RDB_RIEGL_RECEIVER_INTERNALS_DESCRIPTION = "Receiver Internals"
RDB_RIEGL_RECEIVER_INTERNALS_STATUS      = "optional"
RDB_RIEGL_RECEIVER_INTERNALS_SCHEMA = (
"{\"properties\":{\"mw\":{\"exclusiveMinimum\":true,\"maximum\":4095,\"descripti"
"on\":\"Maximum weight\",\"minimum\":0,\"type\":\"number\"},\"t\":{\"patternPropert"
"ies\":{\"^[0-9]+$\":{\"description\":\"one field per channel, field name is "
"channel index\",\"$ref\":\"#/definitions/fp\"}},\"additionalProperties\":fals"
"e,\"type\":\"object\"},\"tbl\":{\"items\":{\"$ref\":\"#/definitions/fp_table\"},\"d"
"escription\":\"various internal "
"data\",\"minItems\":1,\"type\":\"array\"},\"si\":{\"description\":\"Start index (h"
"w_start)\",\"maximum\":255,\"minimum\":0,\"type\":\"number\"},\"sr\":{\"exclusiveM"
"inimum\":true,\"description\":\"Sample rate "
"[Hz]\",\"minimum\":0,\"type\":\"number\"},\"ns\":{\"description\":\"Number of samp"
"les\",\"maximum\":4095,\"minimum\":0,\"type\":\"integer\"},\"a\":{\"items\":{\"type\""
":\"number\"},\"description\":\"Amplitude [dB]\",\"minItems\":1,\"maxItems\":256,"
"\"type\":\"array\"},\"nt\":{\"description\":\"Number of traces\",\"maximum\":255,\""
"minimum\":0,\"type\":\"integer\"},\"ex\":{\"description\":\"DEPRECATED, use "
"'riegl.exponential_decomposition' "
"instead\",\"type\":\"object\"}},\"type\":\"object\",\"description\":\"Receiver "
"Internals\",\"title\":\"Receiver Internals\",\"definitions\":{\"fp_table_row\":"
"{\"items\":{\"type\":\"number\"},\"minItems\":1,\"maxItems\":2048,\"type\":\"array\""
"},\"fp\":{\"description\":\"Fingerprint values\",\"properties\":{\"s\":{\"items\":"
"{\"items\":{\"type\":\"number\"},\"minItems\":1,\"maxItems\":4096,\"type\":\"array\""
"},\"minItems\":1,\"maxItems\":256,\"type\":\"array\"},\"w\":{\"items\":{\"items\":{\""
"type\":\"number\"},\"minItems\":5,\"maxItems\":5,\"type\":\"array\"},\"minItems\":1"
",\"maxItems\":256,\"type\":\"array\"}},\"required\":[\"s\",\"w\"],\"type\":\"object\"}"
",\"fp_table\":{\"required\":[\"ch\",\"tc\",\"nx\",\"ny\",\"tv\"],\"properties\":{\"ch\":"
"{\"description\":\"channel "
"number\",\"max\":255,\"min\":0,\"type\":\"integer\"},\"tc\":{\"description\":\"table"
" data type code\",\"max\":255,\"min\":0,\"type\":\"integer\"},\"tv\":{\"items\":{\"o"
"neOf\":[{\"$ref\":\"#/definitions/fp_table_row\"},{\"type\":\"number\"}]},\"minI"
"tems\":1,\"maxItems\":2048,\"type\":\"array\"},\"nx\":{\"description\":\"number of"
" x entries\",\"max\":2048,\"min\":1,\"type\":\"integer\"},\"ny\":{\"description\":\""
"number of y "
"entries\",\"max\":2048,\"min\":1,\"type\":\"integer\"}},\"desription\":\"scanner "
"internal data\",\"type\":\"object\"}},\"$schema\":\"http://json-schema.org/dra"
"ft-04/schema#\"}"
)
RDB_RIEGL_RECEIVER_INTERNALS_EXAMPLE = (
"{\"mw\":31,\"t\":{\"1\":{\"s\":[[1.23,4.56],[7.89,0.12]],\"w\":[[78,86,126,134,3"
"1],[78,86,126,134,31]]},\"0\":{\"s\":[[1.23,4.56],[7.89,0.12]],\"w\":[[78,86"
",126,134,31],[78,86,126,134,31]]}},\"tbl\":[{\"ch\":0,\"tc\":1,\"tv\":[[1,2,3,"
"4,5],[1.1,2.2,3.3,4.4,5.5]],\"nx\":5,\"ny\":2}],\"si\":48,\"sr\":7959997000.0,"
"\"ns\":400,\"a\":[-1.55],\"nt\":128}"
)

# Lookup table for reflectance calculation based on amplitude and range
RDB_RIEGL_REFLECTANCE_CALCULATION             = "riegl.reflectance_calculation"
RDB_RIEGL_REFLECTANCE_CALCULATION_TITLE       = "Reflectance Calculation Table"
RDB_RIEGL_REFLECTANCE_CALCULATION_DESCRIPTION = "Lookup table for reflectance calculation based on amplitude and range"
RDB_RIEGL_REFLECTANCE_CALCULATION_STATUS      = "optional"
RDB_RIEGL_REFLECTANCE_CALCULATION_SCHEMA = (
"{\"properties\":{\"content\":{\"items\":{\"type\":\"number\"},\"description\":\"Cor"
"rection value [dB] to be added to the amplitude\",\"minItems\":1,\"maxItem"
"s\":2000,\"type\":\"array\"},\"delta\":{\"description\":\"Delta between table "
"entries [m], first entry is at range = 0 m\",\"type\":\"number\"}},\"require"
"d\":[\"delta\",\"content\"],\"type\":\"object\",\"description\":\"Lookup table for"
" reflectance calculation based on amplitude and "
"range\",\"title\":\"Reflectance Calculation "
"Table\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_REFLECTANCE_CALCULATION_EXAMPLE = (
"{\"content\":[-33.01],\"delta\":0.150918}"
)

# Range-dependent and scan-angle-dependent correction of reflectance reading
RDB_RIEGL_REFLECTANCE_CORRECTION             = "riegl.reflectance_correction"
RDB_RIEGL_REFLECTANCE_CORRECTION_TITLE       = "Near-Range Reflectance Correction"
RDB_RIEGL_REFLECTANCE_CORRECTION_DESCRIPTION = "Range-dependent and scan-angle-dependent correction of reflectance reading"
RDB_RIEGL_REFLECTANCE_CORRECTION_STATUS      = "optional"
RDB_RIEGL_REFLECTANCE_CORRECTION_SCHEMA = (
"{\"properties\":{\"ranges_m\":{\"items\":{\"type\":\"number\"},\"description\":\"Ra"
"nge [m]\",\"type\":\"array\"},\"line_angles_deg\":{\"items\":{\"type\":\"number\"},"
"\"description\":\"Angle [deg]\",\"type\":\"array\"},\"reflectance_correction_db"
"\":{\"items\":{\"items\":{\"description\":\"columns (each value corresponds to"
" an angle)\",\"type\":\"number\"},\"description\":\"rows (each array "
"corresponds to a range)\",\"type\":\"array\"},\"description\":\"Near range "
"reflectance correction in dB as a function of range over angle\",\"type\""
":\"array\"}},\"required\":[\"ranges_m\",\"line_angles_deg\",\"reflectance_corre"
"ction_db\"],\"type\":\"object\",\"description\":\"Range-dependent and "
"scan-angle-dependent correction of reflectance "
"reading\",\"title\":\"Near-range reflectance "
"correction\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_REFLECTANCE_CORRECTION_EXAMPLE = (
"{\"ranges_m\":[0.0,1.0,2.0,3.0],\"line_angles_deg\":[0.0,0.5,1.0,1.5,1.0,2"
".0,2.5,3.0,3.5,4.0],\"reflectance_correction_db\":[[0.8,0.7,0.6,0.5,0.4,"
"0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0."
"8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,"
"0.1,0.05,0.01]]}"
)

# Scan pattern description
RDB_RIEGL_SCAN_PATTERN             = "riegl.scan_pattern"
RDB_RIEGL_SCAN_PATTERN_TITLE       = "Scan Pattern"
RDB_RIEGL_SCAN_PATTERN_DESCRIPTION = "Scan pattern description"
RDB_RIEGL_SCAN_PATTERN_STATUS      = "optional"
RDB_RIEGL_SCAN_PATTERN_SCHEMA = (
"{\"description\":\"Scan pattern description\",\"title\":\"Scan "
"Pattern\",\"definitions\":{\"program\":{\"description\":\"Measurement "
"program\",\"properties\":{\"name\":{\"description\":\"Name of measurement prog"
"ram\",\"type\":\"string\"},\"laser_prr\":{\"exclusiveMinimum\":false,\"descripti"
"on\":\"Laser Pulse Repetition Rate [Hz]\",\"minimum\":0,\"type\":\"number\"}},\""
"required\":[\"name\"],\"type\":\"object\"}},\"properties\":{\"line\":{\"descriptio"
"n\":\"Line Scan Pattern\",\"properties\":{\"start\":{\"description\":\"Start "
"angle in SOCS [deg]\",\"maximum\":360.0,\"minimum\":0.0,\"type\":\"number\"},\"p"
"rogram\":{\"$ref\":\"#/definitions/program\"},\"stop\":{\"description\":\"Stop "
"angle in SOCS [deg]\",\"maximum\":720.0,\"minimum\":0.0,\"type\":\"number\"},\"i"
"ncrement\":{\"description\":\"Increment of angle in SOCS [deg]\",\"maximum\":"
"90.0,\"minimum\":0.0,\"type\":\"number\"}},\"required\":[\"start\",\"stop\",\"incre"
"ment\"],\"type\":\"object\"},\"rectangular\":{\"description\":\"Rectangular "
"Field Of View Scan "
"Pattern\",\"properties\":{\"theta_increment\":{\"description\":\"Increment of "
"theta angle in SOCS [deg]\",\"maximum\":90.0,\"minimum\":0.0,\"type\":\"number"
"\"},\"theta_start\":{\"description\":\"Start theta angle in SOCS [deg]\",\"max"
"imum\":180.0,\"minimum\":0.0,\"type\":\"number\"},\"phi_start\":{\"description\":"
"\"Start phi angle in SOCS [deg]\",\"maximum\":360.0,\"minimum\":0.0,\"type\":\""
"number\"},\"phi_stop\":{\"description\":\"Stop phi angle in SOCS [deg]\",\"max"
"imum\":720.0,\"minimum\":0.0,\"type\":\"number\"},\"phi_increment\":{\"descripti"
"on\":\"Increment of phi angle in SOCS [deg]\",\"maximum\":90.0,\"minimum\":0."
"0,\"type\":\"number\"},\"program\":{\"$ref\":\"#/definitions/program\"},\"theta_s"
"top\":{\"description\":\"Stop theta angle in SOCS [deg]\",\"maximum\":180.0,\""
"minimum\":0.0,\"type\":\"number\"}},\"required\":[\"phi_start\",\"phi_stop\",\"phi"
"_increment\",\"theta_start\",\"theta_stop\",\"theta_increment\"],\"type\":\"obje"
"ct\"},\"segments\":{\"description\":\"Segmented Line Scan "
"Pattern\",\"properties\":{\"list\":{\"items\":{\"description\":\"Line Scan "
"Segment\",\"properties\":{\"start\":{\"description\":\"Start angle in SOCS [de"
"g]\",\"maximum\":360.0,\"minimum\":0.0,\"type\":\"number\"},\"stop\":{\"descriptio"
"n\":\"Stop angle in SOCS [deg]\",\"maximum\":720.0,\"minimum\":0.0,\"type\":\"nu"
"mber\"},\"increment\":{\"description\":\"Increment of angle in SOCS [deg]\",\""
"maximum\":90.0,\"minimum\":0.0,\"type\":\"number\"}},\"required\":[\"start\",\"sto"
"p\",\"increment\"],\"type\":\"object\"},\"type\":\"array\"},\"program\":{\"$ref\":\"#/"
"definitions/program\"}},\"required\":[\"list\"],\"type\":\"object\"}},\"$schema\""
":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_SCAN_PATTERN_EXAMPLE = (
"{\"rectangular\":{\"theta_increment\":0.04,\"theta_start\":30.0,\"phi_start\":"
"45.0,\"phi_stop\":270.0,\"phi_increment\":0.04,\"program\":{\"name\":\"High "
"Speed\",\"laser_prr\":100000.0},\"theta_stop\":130.0}}"
)

# Details about laser shot files
RDB_RIEGL_SHOT_INFO             = "riegl.shot_info"
RDB_RIEGL_SHOT_INFO_TITLE       = "Shot Information"
RDB_RIEGL_SHOT_INFO_DESCRIPTION = "Details about laser shot files"
RDB_RIEGL_SHOT_INFO_STATUS      = "optional"
RDB_RIEGL_SHOT_INFO_SCHEMA = (
"{\"description\":\"Details about laser shot files\",\"title\":\"Shot Informat"
"ion\",\"type\":\"object\",\"properties\":{\"shot_file\":{\"required\":[\"file_exte"
"nsion\"],\"properties\":{\"file_uuid\":{\"description\":\"File's Universally "
"Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Shot file "
"extension, without the leading dot\",\"type\":\"string\"}},\"type\":\"object\"}"
"},\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_SHOT_INFO_EXAMPLE = (
"{\"shot_file\":{\"file_uuid\":\"26a00815-67c0-4bff-8fe8-c577378fe663\",\"file"
"_extension\":\"sodx\"}}"
)

# Point filters applied in addition to the application-defined filters
RDB_RIEGL_STORED_FILTERS             = "riegl.stored_filters"
RDB_RIEGL_STORED_FILTERS_TITLE       = "Stored Filters"
RDB_RIEGL_STORED_FILTERS_DESCRIPTION = "Point filters applied in addition to the application-defined filters"
RDB_RIEGL_STORED_FILTERS_STATUS      = "optional"
RDB_RIEGL_STORED_FILTERS_SCHEMA = (
"{\"properties\":{\"filters\":{\"items\":{\"description\":\"Point filter "
"definition\",\"properties\":{\"description\":{\"description\":\"A brief "
"description of the filter (e.g. for display in a "
"tooltip)\",\"type\":\"string\"},\"title\":{\"description\":\"A short filter "
"title (e.g. for display in a selection "
"list)\",\"type\":\"string\"},\"activated\":{\"description\":\"Apply ('true') or "
"ignore ('false') this "
"filter\",\"type\":\"boolean\"},\"filter\":{\"description\":\"The RDB filter "
"string to apply (e.g. when reading points or index), details see "
"documentation of function select()\",\"type\":\"string\"}},\"required\":[\"act"
"ivated\",\"title\",\"description\",\"filter\"],\"type\":\"object\"},\"description\""
":\"List of point "
"filters\",\"type\":\"array\"},\"activated\":{\"description\":\"Apply ('true') or"
" ignore ('false') all filters\",\"type\":\"boolean\"}},\"required\":[\"activat"
"ed\",\"filters\"],\"type\":\"object\",\"description\":\"Point filters applied in"
" addition to the application-defined filters\",\"title\":\"Stored "
"filters\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_STORED_FILTERS_EXAMPLE = (
"{\"filters\":[{\"description\":\"Ignore points with uncertain MTA zone "
"assignment\",\"title\":\"Ignore uncertain points from MTA "
"resolution\",\"activated\":false,\"filter\":\"riegl.mta_uncertain_point == "
"0\"},{\"description\":\"Ignore points with an echo signal amplitude below "
"the dynamic trigger\",\"title\":\"Ignore points below dynamic trigger "
"level\",\"activated\":false,\"filter\":\"riegl.dyntrig_uncertain_point == "
"0\"},{\"description\":\"Ignore points that are outside the outer AABB in "
"BOCS\",\"title\":\"Ignore points outside outer "
"AABB\",\"activated\":false,\"filter\":\"riegl.point_outside_aabb_bocs == "
"0\"},{\"description\":\"Ignore points that are inside the inner AABB in "
"BOCS\",\"title\":\"Ignore points inside inner "
"AABB\",\"activated\":false,\"filter\":\"riegl.point_inside_aabb_bocs == "
"0\"}],\"activated\":true}"
)

# Details of major system components like lidar sensors, cameras and navigation devices
RDB_RIEGL_SYSTEM_DESCRIPTION             = "riegl.system_description"
RDB_RIEGL_SYSTEM_DESCRIPTION_TITLE       = "System Description"
RDB_RIEGL_SYSTEM_DESCRIPTION_DESCRIPTION = "Details of major system components like lidar sensors, cameras and navigation devices"
RDB_RIEGL_SYSTEM_DESCRIPTION_STATUS      = "optional"
RDB_RIEGL_SYSTEM_DESCRIPTION_SCHEMA = (
"{\"properties\":{\"version\":{\"description\":\"Document format "
"version\",\"type\":\"string\"},\"system\":{\"description\":\"The actual system "
"description, details see documentation of RIEGL System "
"Description\",\"type\":\"object\"},\"$class\":{\"description\":\"Object class na"
"me\",\"enum\":[\"Document\"],\"type\":\"string\"},\"timestamp\":{\"description\":\"D"
"ate and time of creation (e.g. 2019-06-19T13:32:10+02:00)\",\"type\":\"str"
"ing\"},\"author\":{\"description\":\"Name of the author that created the doc"
"ument\",\"type\":\"string\"}},\"required\":[\"$class\",\"version\",\"author\",\"time"
"stamp\",\"system\"],\"type\":\"object\",\"description\":\"Details of major "
"system components like lidar sensors, cameras and navigation "
"devices\",\"title\":\"System "
"Description\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_SYSTEM_DESCRIPTION_EXAMPLE = (
"{\"version\":\"1.2.1\",\"system\":{\"details\":\"see documentation of RIEGL "
"System Description\"},\"$class\":\"Document\",\"timestamp\":\"2022-09-30T11:56"
":26+00:00\",\"author\":\"RIEGL LMS GmbH, Austria\"}"
)

# Conversion of background radiation raw values to temperatures in °C
RDB_RIEGL_TEMPERATURE_CALCULATION             = "riegl.temperature_calculation"
RDB_RIEGL_TEMPERATURE_CALCULATION_TITLE       = "Temperature Calculation Table"
RDB_RIEGL_TEMPERATURE_CALCULATION_DESCRIPTION = "Conversion of background radiation raw values to temperatures in °C"
RDB_RIEGL_TEMPERATURE_CALCULATION_STATUS      = "optional"
RDB_RIEGL_TEMPERATURE_CALCULATION_SCHEMA = (
"{\"properties\":{\"InGaAs\":{\"description\":\"Conversion table for InGaAs ch"
"annel\",\"$ref\":\"#/definitions/conversion_table\"},\"Si\":{\"description\":\"C"
"onversion table for Si channel\",\"$ref\":\"#/definitions/conversion_table"
"\"},\"InGaAs_Si_Difference\":{\"description\":\"Conversion table for InGaAs "
"- Si difference\",\"$ref\":\"#/definitions/conversion_table\"}},\"type\":\"obj"
"ect\",\"description\":\"Conversion of background radiation raw values to "
"temperatures in \\u00b0C\",\"title\":\"Temperature Calculation Table\",\"defi"
"nitions\":{\"conversion_table\":{\"required\":[\"value\",\"temperature\"],\"prop"
"erties\":{\"temperature\":{\"items\":{\"type\":\"number\"},\"description\":\"Tempe"
"rature [\\u00b0C]\",\"type\":\"array\"},\"value\":{\"items\":{\"type\":\"number\"},\""
"description\":\"LSB [1]\",\"type\":\"array\"}},\"type\":\"object\"}},\"$schema\":\"h"
"ttp://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_TEMPERATURE_CALCULATION_EXAMPLE = (
"{\"InGaAs\":{\"temperature\":[307.22196722535614,309.1153478247277,311.118"
"8086915047,313.10025350480055,315.2137946389828,317.2172555057597,319."
"2207163725366,321.2021611858325,323.3157023200148],\"value\":[0.0,64.000"
"97659230323,128.0019531846065,192.0029297769097,256.0039063692129,320."
"00488296151616,384.0058595538194,448.0068361461226,512.0078127384259]}"
",\"Si\":{\"temperature\":[546.300048828125,548.8164051212026,551.314393850"
"0972,554.0144257850053,556.604252334815,559.2124464488079,561.80227299"
"86177,564.4104671126105,567.0002936624203],\"value\":[0.0,64.00097659230"
"323,128.0019531846065,192.0029297769097,256.0039063692129,320.00488296"
"151616,384.0058595538194,448.0068361461226,512.0078127384259]},\"InGaAs"
"_Si_Difference\":{\"temperature\":[1749.977111117893,1749.977111117893,17"
"49.977111117893,1749.977111117893,1749.977111117893,1749.977111117893,"
"1744.7813348796044,1681.9971312601092,1622.3944822534868],\"value\":[100"
"0.0,1100.090029602954,1200.04425183874,1300.1342814416948,1400.0885036"
"774805,1500.0427259132668,1600.1327555162209,1700.0869777520065,1800.0"
"411999877924]}}"
)

# Base of timestamps (epoch)
RDB_RIEGL_TIME_BASE             = "riegl.time_base"
RDB_RIEGL_TIME_BASE_TITLE       = "Time Base"
RDB_RIEGL_TIME_BASE_DESCRIPTION = "Base of timestamps (epoch)"
RDB_RIEGL_TIME_BASE_STATUS      = "optional"
RDB_RIEGL_TIME_BASE_SCHEMA = (
"{\"properties\":{\"system\":{\"description\":\"Time system (time standard)\",\""
"enum\":[\"unknown\",\"UTC\",\"GPS\"],\"type\":\"string\"},\"epoch\":{\"description\":"
"\"Date and time of timestamp '0' as proposed by RFC 3339 (e.g. 2015-10-"
"27T00:00:00+01:00).\",\"type\":\"string\"},\"source\":{\"description\":\"Timesta"
"mp source\",\"enum\":[\"unknown\",\"RTC\",\"GNSS\"],\"type\":\"string\"}},\"required"
"\":[\"epoch\",\"source\"],\"type\":\"object\",\"description\":\"Base of timestamps"
" (epoch)\",\"title\":\"Time "
"Base\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_TIME_BASE_EXAMPLE = (
"{\"system\":\"UTC\",\"epoch\":\"2015-10-27T00:00:00+00:00\",\"source\":\"GNSS\"}"
)

# Details about position+orientation files
RDB_RIEGL_TRAJECTORY_INFO             = "riegl.trajectory_info"
RDB_RIEGL_TRAJECTORY_INFO_TITLE       = "Trajectory Information"
RDB_RIEGL_TRAJECTORY_INFO_DESCRIPTION = "Details about position+orientation files"
RDB_RIEGL_TRAJECTORY_INFO_STATUS      = "optional"
RDB_RIEGL_TRAJECTORY_INFO_SCHEMA = (
"{\"properties\":{\"company\":{\"description\":\"Company "
"name\",\"type\":\"string\"},\"field_of_application\":{\"description\":\"Field of"
" application\",\"enum\":[\"unknown\",\"SLS\",\"TLS\",\"KLS\",\"MLS\",\"ULS\",\"ALS\",\"B"
"LS\",\"ILS\"],\"type\":\"string\"},\"software\":{\"description\":\"Software that "
"calculated the trajectory (this may be the same or different software "
"than the one that created the "
"file)\",\"type\":\"string\"},\"location\":{\"description\":\"Project location, "
"e.g. "
"city/state/country\",\"type\":\"string\"},\"project\":{\"description\":\"Project"
" name\",\"type\":\"string\"},\"device\":{\"description\":\"Navigation device, "
"e.g. "
"name/type/serial\",\"type\":\"string\"},\"settings\":{\"description\":\"Settings"
" used to calculate the trajectory (descriptive "
"text)\",\"type\":\"string\"},\"time_interval\":{\"description\":\"Time interval "
"statistics\",\"properties\":{\"maximum\":{\"description\":\"Maximum time "
"interval [s]\",\"type\":\"number\"},\"std_dev\":{\"description\":\"Standard "
"deviation of intervals "
"[s]\",\"type\":\"number\"},\"minimum\":{\"description\":\"Minimum time interval "
"[s]\",\"type\":\"number\"},\"average\":{\"description\":\"Average time interval "
"[s]\",\"type\":\"number\"}},\"required\":[\"minimum\",\"average\",\"maximum\",\"std_"
"dev\"],\"type\":\"object\"},\"navigation_frame\":{\"description\":\"Navigation "
"frame (NED: North-East-Down, ENU: East-North-Up)\",\"enum\":[\"unknown\",\"N"
"ED\",\"ENU\"],\"type\":\"string\"}},\"required\":[\"time_interval\",\"navigation_f"
"rame\"],\"type\":\"object\",\"description\":\"Details about "
"position+orientation files\",\"title\":\"Trajectory "
"Information\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_TRAJECTORY_INFO_EXAMPLE = (
"{\"company\":\"RIEGL "
"LMS\",\"field_of_application\":\"MLS\",\"software\":\"Navigation Software "
"XYZ\",\"location\":\"Horn\",\"project\":\"Campaign 3\",\"device\":\"IMU Model "
"12/1, Serial# 12345\",\"settings\":\"default\",\"time_interval\":{\"maximum\":0"
".005004883,\"std_dev\":5.51e-07,\"minimum\":0.00500032,\"average\":0.0050005"
"3},\"navigation_frame\":\"NED\"}"
)

# Trigger-Timestamping-Unit/IP configuration
RDB_RIEGL_TTIP_CONFIGURATION             = "riegl.ttip_configuration"
RDB_RIEGL_TTIP_CONFIGURATION_TITLE       = "TTIP Configuration"
RDB_RIEGL_TTIP_CONFIGURATION_DESCRIPTION = "Trigger-Timestamping-Unit/IP configuration"
RDB_RIEGL_TTIP_CONFIGURATION_STATUS      = "optional"
RDB_RIEGL_TTIP_CONFIGURATION_SCHEMA = (
"{\"properties\":{\"output_descr\":{\"description\":\"descriptive "
"string\",\"type\":\"string\"},\"out_interval\":{\"description\":\"output pulse "
"interval [0.1 msec]\",\"minimum\":0,\"type\":\"integer\"},\"ext_delay\":{\"descr"
"iption\":\"external trigger, time delay [0.1 "
"msec]\",\"minimum\":0,\"type\":\"integer\"},\"ext_signal\":{\"description\":\"0 .."
" use input signal, 1 .. use output signal of channel\",\"minimum\":0,\"typ"
"e\":\"integer\"},\"in_max_delay\":{\"description\":\"maximum delay to output "
"pulse before fake event is generated [0.1 msec], zero indicates that "
"no fake events are generated\",\"minimum\":0,\"type\":\"integer\"},\"ext_subdi"
"vider\":{\"description\":\"reduces the frequency, default "
"1\",\"minimum\":0,\"type\":\"integer\"},\"dmi_max_time\":{\"description\":\"dmi, "
"maximum time interval between trigger events [0.1 msec]\",\"minimum\":0,\""
"type\":\"integer\"},\"in_max_duration\":{\"description\":\"stops measurement "
"of pulse duration of input signal [0.1 "
"msec]\",\"minimum\":0,\"type\":\"integer\"},\"output_usage\":{\"description\":\"0 "
".. no output, 1 .. output derived from internal clock, 2 .. output "
"derived from dmi, 3 .. output derived from external signal, 4 .. "
"output static low, 5 .. output static high\",\"minimum\":0,\"type\":\"intege"
"r\"},\"out_num_pulses\":{\"description\":\"number of output pulses to be "
"generated, 0 .. infinite\",\"minimum\":0,\"type\":\"integer\"},\"dmi_incr\":{\"d"
"escription\":\"dmi, increment in "
"ticks\",\"type\":\"integer\"},\"in_min_duration\":{\"description\":\"input "
"signals with smaller pulse durations are ignored [0.1 msec]\",\"minimum\""
":0,\"type\":\"integer\"},\"num_channel\":{\"description\":\"number of "
"input/output channels\",\"minimum\":0,\"type\":\"integer\"},\"dmi_min_time\":{\""
"description\":\"dmi, minimum time interval between trigger events [0.1 m"
"sec]\",\"minimum\":0,\"type\":\"integer\"},\"ext_bitmask\":{\"description\":\"defi"
"nes which of the internal pulse generators are to be started\",\"minimum"
"\":0,\"type\":\"integer\"},\"out_duration\":{\"description\":\"output pulse "
"duration [0.1 "
"msec]\",\"minimum\":0,\"type\":\"integer\"},\"channel\":{\"description\":\"ID of "
"input/output channel\",\"minimum\":0,\"type\":\"integer\"},\"ttip_version\":{\"d"
"escription\":\"following main.sub.ss.sss\",\"minimum\":0,\"type\":\"integer\"},"
"\"ext_channel\":{\"description\":\"ID of channel used as external trigger "
"input, 32 indicates "
"none\",\"minimum\":0,\"type\":\"integer\"},\"input_usage\":{\"description\":\"0 .."
" deactivated, 1 .. just detecting and timestamping\",\"minimum\":0,\"type\""
":\"integer\"},\"dmi_dist_per_tick\":{\"description\":\"dmi, distance per "
"tick, just informative "
"[m]\",\"type\":\"number\"},\"out_polarity\":{\"description\":\"0 .. positive "
"edge, 1 .. negative "
"edge\",\"minimum\":0,\"type\":\"integer\"},\"in_polarity\":{\"description\":\"0 .."
" positive edge, 1 .. negative edge\",\"minimum\":0,\"type\":\"integer\"},\"inp"
"ut_descr\":{\"description\":\"descriptive "
"string\",\"type\":\"string\"},\"out_delay\":{\"description\":\"output pulse "
"initial delay after start [0.1 msec]\",\"minimum\":0,\"type\":\"integer\"}},\""
"required\":[\"ttip_version\",\"num_channel\",\"ext_channel\",\"ext_signal\",\"ex"
"t_delay\",\"ext_subdivider\",\"ext_bitmask\",\"dmi_incr\",\"dmi_min_time\",\"dmi"
"_max_time\",\"dmi_dist_per_tick\",\"channel\",\"output_descr\",\"input_descr\","
"\"output_usage\",\"input_usage\",\"out_polarity\",\"out_duration\",\"out_interv"
"al\",\"out_delay\",\"out_num_pulses\",\"in_polarity\",\"in_min_duration\",\"in_m"
"ax_duration\",\"in_max_delay\"],\"type\":\"object\",\"description\":\"Trigger-Ti"
"mestamping-Unit/IP configuration\",\"title\":\"TTIP "
"Configuration\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_TTIP_CONFIGURATION_EXAMPLE = (
"{\"output_descr\":\"Port 1 - Trigger\",\"out_interval\":10000,\"ext_delay\":0,"
"\"ext_signal\":0,\"in_max_delay\":9990,\"ext_subdivider\":1,\"dmi_max_time\":0"
",\"in_max_duration\":10000,\"output_usage\":1,\"out_num_pulses\":1,\"dmi_incr"
"\":0,\"in_min_duration\":0,\"num_channel\":9,\"dmi_min_time\":0,\"ext_bitmask\""
":0,\"out_duration\":300,\"channel\":0,\"ttip_version\":1,\"ext_channel\":32,\"i"
"nput_usage\":1,\"dmi_dist_per_tick\":0.0,\"out_polarity\":0,\"in_polarity\":0"
",\"input_descr\":\"Port 1 - Exposure\",\"out_delay\":0}"
)

# Details about vertex file
RDB_RIEGL_VERTEX_INFO             = "riegl.vertex_info"
RDB_RIEGL_VERTEX_INFO_TITLE       = "Vertex Information"
RDB_RIEGL_VERTEX_INFO_DESCRIPTION = "Details about vertex file"
RDB_RIEGL_VERTEX_INFO_STATUS      = "optional"
RDB_RIEGL_VERTEX_INFO_SCHEMA = (
"{\"description\":\"Details about vertex file\",\"title\":\"Vertex Information"
"\",\"type\":\"object\",\"properties\":{\"vertex_file\":{\"required\":[\"file_exten"
"sion\"],\"properties\":{\"file_uuid\":{\"description\":\"File's Universally "
"Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Vertex file "
"extension, without the leading dot\",\"type\":\"string\"}},\"type\":\"object\"}"
"},\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_VERTEX_INFO_EXAMPLE = (
"{\"vertex_file\":{\"file_uuid\":\"51534d95-d71f-4f36-ae1a-3e63a21fd1c7\",\"fi"
"le_extension\":\"vtx\"}}"
)

# Details about the voxels contained in the file
RDB_RIEGL_VOXEL_INFO             = "riegl.voxel_info"
RDB_RIEGL_VOXEL_INFO_TITLE       = "Voxel Information"
RDB_RIEGL_VOXEL_INFO_DESCRIPTION = "Details about the voxels contained in the file"
RDB_RIEGL_VOXEL_INFO_STATUS      = "optional"
RDB_RIEGL_VOXEL_INFO_SCHEMA = (
"{\"oneOf\":[{\"properties\":{\"voxel_type\":{\"$ref\":\"#/definitions/voxel_typ"
"e\"},\"size\":{\"description\":\"Size of voxels in file coordinate system.\","
"\"oneOf\":[{\"$ref\":\"#/definitions/voxel_size\"},{\"$ref\":\"#/definitions/vo"
"xel_size_cubic\"}]},\"shape_thresholds\":{\"$ref\":\"#/definitions/shape_thr"
"esholds\"},\"voxel_origin\":{\"$ref\":\"#/definitions/voxel_origin_enum\"}},\""
"additionalProperties\":false,\"required\":[\"size\",\"voxel_origin\",\"voxel_t"
"ype\"]},{\"properties\":{\"size_llcs\":{\"description\":\"Size of voxels in a "
"locally levelled cartesian coordinate system (xyz). This is only used "
"for voxels based on a map projection.\",\"$ref\":\"#/definitions/voxel_siz"
"e\"},\"reference_point\":{\"items\":{\"maximum\":180,\"minimum\":-180,\"type\":\"n"
"umber\"},\"description\":\"Point in WGS84 geodetic decimal degree "
"(EPSG:4326) that was used to compute the projection distortion "
"parameters. The coefficient order is latitude, longitude. Only voxels "
"with corresponding geo_tag, voxel_size and reference_point can be "
"reliably processed together. This entry is available for voxel files "
"in projected CRS only.\",\"minItems\":2,\"maxItems\":2,\"type\":\"array\"},\"siz"
"e\":{\"description\":\"Size of voxels in file coordinate system.\",\"$ref\":\""
"#/definitions/voxel_size\"},\"voxel_type\":{\"$ref\":\"#/definitions/voxel_t"
"ype\"},\"shape_thresholds\":{\"$ref\":\"#/definitions/shape_thresholds\"},\"vo"
"xel_origin\":{\"oneOf\":[{\"$ref\":\"#/definitions/voxel_origin_enum\"},{\"des"
"cription\":\"The base point of the voxel grid. Used together with "
"<tt>voxel_size</tt> and <tt>voxel_index</tt> to compute actual point c"
"oordinates.\",\"$ref\":\"#/definitions/voxel_origin_point\"}]}},\"additional"
"Properties\":false,\"required\":[\"reference_point\",\"size_llcs\",\"size\",\"vo"
"xel_origin\",\"voxel_type\"]}],\"type\":\"object\",\"description\":\"Details "
"about the voxels contained in the file\",\"title\":\"Voxel Information\",\"d"
"efinitions\":{\"voxel_origin_point\":{\"items\":{\"type\":\"number\"},\"descript"
"ion\":\"Origin point for all voxel indices in voxel CRS.\",\"minItems\":3,\""
"maxItems\":3,\"type\":\"array\"},\"voxel_size_cubic\":{\"$ref\":\"#/definitions/"
"edge_length\",\"type\":\"number\"},\"edge_length\":{\"exclusiveMinimum\":true,\""
"description\":\"Length of voxel edge [m].\",\"minimum\":0,\"type\":\"number\"},"
"\"voxel_origin_enum\":{\"description\":\"Defines whether the voxel's center"
" or a corner is placed on CRS origin <tt>(0/0/0)</tt>.\",\"enum\":[\"cente"
"r\",\"corner\"],\"default\":\"corner\"},\"voxel_type\":{\"description\":\"Whether "
"a point in a voxel represents its center or its centroid. If type is "
"<tt>index</tt> there is no point but only an integer voxel index.\",\"en"
"um\":[\"center\",\"centroid\",\"index\"],\"default\":\"centroid\"},\"shape_thresho"
"lds\":{\"description\":\"Thresholds used to compute the voxel's shape_id v"
"alue.\",\"type\":\"object\",\"properties\":{\"line\":{\"exclusiveMinimum\":true,\""
"description\":\"If the biggest eigenvalue is bigger than the median "
"eigenvalue * line_threshold, the voxel is considered a line.\",\"minimum"
"\":1,\"type\":\"number\"},\"plane\":{\"exclusiveMinimum\":true,\"minimum\":0,\"typ"
"e\":\"number\",\"exclusiveMaximum\":true,\"description\":\"If the smallest "
"eigenvalue is smaller than the median eigenvalue * plane_threshold, "
"the voxel is considered a plane.\",\"maximum\":1}},\"required\":[\"plane\",\"l"
"ine\"]},\"voxel_size\":{\"items\":{\"$ref\":\"#/definitions/edge_length\"},\"des"
"cription\":\"Size of voxels.\",\"minItems\":3,\"maxItems\":3,\"type\":\"array\"}}"
",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_VOXEL_INFO_EXAMPLE = (
"{\"size_llcs\":[0.5156575252891171,0.5130835356683303,0.5143705304787237"
"],\"reference_point\":[48,16],\"size\":[0.5971642834779395,0.5971642834779"
"395,0.5143705304787237],\"voxel_type\":\"centroid\",\"shape_thresholds\":{\"l"
"ine\":6,\"plane\":0.16},\"voxel_origin\":\"corner\"}"
)

# Settings for waveform averaging
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS             = "riegl.waveform_averaging_settings"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_TITLE       = "Waveform Averaging Settings"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_DESCRIPTION = "Settings for waveform averaging"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_SCHEMA = (
"{\"properties\":{\"mta_zone\":{\"description\":\"Fixed MTA zone for averaging"
".\",\"minimum\":1,\"type\":\"integer\"},\"num_shots\":{\"description\":\"Number of"
" consecutive shots to be used for averaging.\",\"minimum\":1,\"type\":\"inte"
"ger\"},\"trim\":{\"default\":0,\"description\":\"Percentage for robust averagi"
"ng.\",\"maximum\":0.5,\"minimum\":0,\"type\":\"number\"}},\"required\":[\"num_shot"
"s\",\"mta_zone\"],\"type\":\"object\",\"description\":\"Settings for waveform "
"averaging\",\"title\":\"Waveform Averaging "
"Settings\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_EXAMPLE = (
"{\"mta_zone\":1,\"num_shots\":7,\"trim\":0.05}"
)

# Details about waveform files
RDB_RIEGL_WAVEFORM_INFO             = "riegl.waveform_info"
RDB_RIEGL_WAVEFORM_INFO_TITLE       = "Waveform Information"
RDB_RIEGL_WAVEFORM_INFO_DESCRIPTION = "Details about waveform files"
RDB_RIEGL_WAVEFORM_INFO_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_INFO_SCHEMA = (
"{\"properties\":{\"range_offset_waveform_samples_m\":{\"description\":\"Calib"
"rated device specific range offset for waveform samples in meters.\",\"t"
"ype\":\"number\"},\"sample_block_file\":{\"required\":[\"file_extension\"],\"pro"
"perties\":{\"file_uuid\":{\"description\":\"File's Universally Unique "
"Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Sample block "
"file extension, without the leading dot\",\"type\":\"string\"}},\"type\":\"obj"
"ect\"},\"sample_data_files\":{\"items\":{\"required\":[\"channel\",\"channel_nam"
"e\",\"sample_interval\",\"sample_bits\",\"laser_wavelength\",\"delta_st\",\"file"
"_extension\"],\"properties\":{\"file_uuid\":{\"description\":\"File's "
"Universally Unique Identifier (RFC 4122)\",\"type\":\"string\"},\"laser_wave"
"length\":{\"exclusiveMinimum\":false,\"description\":\"Laser wavelength in "
"meters (0 = unknown)\",\"minimum\":0,\"type\":\"number\"},\"delta_st\":{\"descri"
"ption\":\"reserved\",\"type\":\"number\"},\"channel_name\":{\"description\":\"Samp"
"le block channel name\",\"type\":\"string\"},\"channel\":{\"exclusiveMinimum\":"
"false,\"minimum\":0,\"type\":\"integer\",\"exclusiveMaximum\":false,\"descripti"
"on\":\"Sample block channel number (255 = "
"invalid)\",\"maximum\":255},\"file_extension\":{\"description\":\"Sample data "
"file extension, without the leading dot\",\"type\":\"string\"},\"sample_bits"
"\":{\"exclusiveMinimum\":false,\"minimum\":0,\"type\":\"integer\",\"exclusiveMax"
"imum\":false,\"description\":\"Bitwidth of samples (e.g. 10 bit, 12 bit)\","
"\"maximum\":32},\"sample_interval\":{\"exclusiveMinimum\":false,\"description"
"\":\"Sampling interval in seconds\",\"minimum\":0,\"type\":\"number\"}},\"type\":"
"\"object\"},\"type\":\"array\"},\"range_offset_m\":{\"description\":\"Calibrated "
"device specific range offset for waveform analysis by system response "
"fitting in meters.\",\"type\":\"number\"}},\"required\":[\"sample_block_file\","
"\"sample_data_files\"],\"type\":\"object\",\"description\":\"Details about "
"waveform files\",\"title\":\"Waveform "
"Information\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_WAVEFORM_INFO_EXAMPLE = (
"{\"sample_block_file\":{\"file_uuid\":\"93a03615-66c0-4bea-8ff8-c577378fe66"
"0\",\"file_extension\":\"sbx\"},\"sample_data_files\":[{\"file_uuid\":\"da084413"
"-e3e8-4655-a122-071de8490d8e\",\"channel_name\":\"high_power\",\"laser_wavel"
"ength\":0,\"file_extension\":\"sp0\",\"sample_bits\":12,\"channel\":0,\"sample_i"
"nterval\":1.00503e-09,\"delta_st\":0},{\"file_uuid\":\"93585b5e-5ea9-43a1-94"
"7b-e7ba3be642d2\",\"channel_name\":\"low_power\",\"laser_wavelength\":0,\"file"
"_extension\":\"sp1\",\"sample_bits\":12,\"channel\":1,\"sample_interval\":1.005"
"03e-09,\"delta_st\":0},{\"file_uuid\":\"9d2298c4-1036-464f-b5cb-1cf8e517f3a"
"0\",\"channel_name\":\"wwf\",\"laser_wavelength\":0,\"file_extension\":\"sp5\",\"s"
"ample_bits\":12,\"channel\":5,\"sample_interval\":1.00503e-09,\"delta_st\":0}"
"],\"range_offset_waveform_samples_m \":7.283,\"range_offset_m\":3.1415}"
)

# Scanner settings for waveform output
RDB_RIEGL_WAVEFORM_SETTINGS             = "riegl.waveform_settings"
RDB_RIEGL_WAVEFORM_SETTINGS_TITLE       = "Waveform Settings"
RDB_RIEGL_WAVEFORM_SETTINGS_DESCRIPTION = "Scanner settings for waveform output"
RDB_RIEGL_WAVEFORM_SETTINGS_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_SETTINGS_SCHEMA = (
"{\"items\":{\"required\":[\"sbl_name\",\"enabled\",\"channel_idx_mask\"],\"proper"
"ties\":{\"smart_enabled\":{\"description\":\"Smart waveform output "
"enabled\",\"type\":\"boolean\"},\"sbl_name\":{\"description\":\"Name of sample "
"block, e.g.: wfm, "
"wwf\",\"type\":\"string\"},\"enabled\":{\"description\":\"Waveform output enable"
"d\",\"type\":\"boolean\"},\"pass_dev_greater\":{\"description\":\"Threshold for "
"deviation greater than "
"[1]\",\"type\":\"integer\"},\"pass_dev_less\":{\"description\":\"Threshold for "
"deviation less than "
"[1]\",\"type\":\"integer\"},\"pass_ampl_less\":{\"description\":\"Threshold for "
"amplitude less than "
"[dB]\",\"type\":\"number\"},\"channel_idx_mask\":{\"description\":\"Bit mask for"
" channels which belong to sbl_name: Channel 0 = Bit0, Channel 1 = "
"Bit1, ...\",\"type\":\"integer\"},\"pass_rng_less\":{\"description\":\"Threshold"
" for range less than "
"[m]\",\"type\":\"number\"},\"pass_ampl_greater\":{\"description\":\"Threshold "
"for amplitude greater than "
"[dB]\",\"type\":\"number\"},\"pass_rng_greater\":{\"description\":\"Threshold "
"for range greater than "
"[m]\",\"type\":\"number\"},\"logic_expression\":{\"description\":\"Logic "
"expression of smart waveforms "
"filter\",\"type\":\"string\"}},\"type\":\"object\"},\"description\":\"Scanner "
"settings for waveform output\",\"title\":\"Waveform Settings\",\"type\":\"arra"
"y\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_WAVEFORM_SETTINGS_EXAMPLE = (
"[{\"smart_enabled\":true,\"sbl_name\":\"wfm\",\"enabled\":true,\"pass_ampl_less"
"\":5.0,\"pass_rng_less\":13.11,\"pass_ampl_greater\":1.0,\"pass_rng_greater\""
":9.27,\"channel_idx_mask\":11},{\"sbl_name\":\"wwf\",\"enabled\":false,\"channe"
"l_idx_mask\":32}]"
)

# Window analysis data estimated from scandata and resulting filter parameters
RDB_RIEGL_WINDOW_ANALYSIS             = "riegl.window_analysis"
RDB_RIEGL_WINDOW_ANALYSIS_TITLE       = "Window Analysis"
RDB_RIEGL_WINDOW_ANALYSIS_DESCRIPTION = "Window analysis data estimated from scandata and resulting filter parameters"
RDB_RIEGL_WINDOW_ANALYSIS_STATUS      = "optional"
RDB_RIEGL_WINDOW_ANALYSIS_SCHEMA = (
"{\"properties\":{\"result\":{\"required\":[\"angle\",\"range_mean\",\"range_sigma"
"\",\"amplitude_mean\",\"amplitude_sigma\",\"amplitude_offset\"],\"properties\":"
"{\"amplitude_sigma\":{\"items\":{\"type\":\"number\"},\"description\":\"[dB]\",\"ty"
"pe\":\"array\"},\"timestamp\":{\"items\":{\"type\":\"number\"},\"description\":\"[s]"
"\",\"type\":\"array\"},\"range_mean\":{\"items\":{\"type\":\"number\"},\"description"
"\":\"[m]\",\"type\":\"array\"},\"amplitude_mean\":{\"items\":{\"type\":\"number\"},\"d"
"escription\":\"[dB]\",\"type\":\"array\"},\"angle\":{\"items\":{\"type\":\"number\"},"
"\"description\":\"[deg]\",\"type\":\"array\"},\"amplitude_offset\":{\"items\":{\"ty"
"pe\":\"number\"},\"description\":\"[dB]\",\"type\":\"array\"},\"range_sigma\":{\"ite"
"ms\":{\"type\":\"number\"},\"description\":\"[m]\",\"type\":\"array\"}},\"type\":\"obj"
"ect\"},\"filter\":{\"required\":[\"angle\",\"range_min\",\"range_max\",\"amplitude"
"_max\"],\"properties\":{\"amplitude_max\":{\"items\":{\"type\":\"number\"},\"descr"
"iption\":\"[dB]\",\"type\":\"array\"},\"angle\":{\"items\":{\"type\":\"number\"},\"des"
"cription\":\"[deg]\",\"type\":\"array\"},\"range_min\":{\"items\":{\"type\":\"number"
"\"},\"description\":\"[m]\",\"type\":\"array\"},\"range_max\":{\"items\":{\"type\":\"n"
"umber\"},\"description\":\"[m]\",\"type\":\"array\"}},\"type\":\"object\"},\"setting"
"s\":{\"required\":[\"range\",\"amplitude\"],\"properties\":{\"range\":{\"required\""
":[\"sigma_factor\",\"additive_value\"],\"properties\":{\"sigma_factor\":{\"type"
"\":\"number\"},\"additive_value\":{\"type\":\"number\"}},\"type\":\"object\"},\"ampl"
"itude\":{\"required\":[\"sigma_factor\",\"additive_value\"],\"properties\":{\"si"
"gma_factor\":{\"type\":\"number\"},\"additive_value\":{\"type\":\"number\"}},\"typ"
"e\":\"object\"}},\"type\":\"object\"}},\"required\":[\"result\",\"filter\",\"setting"
"s\"],\"type\":\"object\",\"description\":\"Window analysis data estimated from"
" scandata and resulting filter parameters\",\"title\":\"Window "
"Analysis\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_WINDOW_ANALYSIS_EXAMPLE = (
"{\"result\":{\"amplitude_sigma\":[0.4272844,0.4298479,0.4236816,0.4283583,"
"0.4362353,0.4315141,0.4373984,0.4472798,0.4346001,0.4345487,0.4540681]"
",\"timestamp\":[408.4441,411.4443],\"range_mean\":[0.1105621,0.1079564,0.1"
"087088,0.1067261,0.1054582,0.1090412,0.102871,0.1019044,0.1051523,0.10"
"58445,0.1031261],\"amplitude_mean\":[5.347396,5.263155,5.224655,5.179926"
",5.097782,5.116479,5.051756,4.983473,5.007885,5.002441,4.982],\"angle\":"
"[14.9,15.0,15.1,15.2,15.3,15.4,15.5,15.6,15.7,15.8,15.9],\"amplitude_of"
"fset\":[1.9,1.9],\"range_sigma\":[0.01869652,0.02151435,0.01747969,0.0191"
"8765,0.01945776,0.01934862,0.01955329,0.02225589,0.02229977,0.01899122"
",0.02009433]},\"filter\":{\"amplitude_max\":[8.04,8.01,7.99,7.96,7.93,7.9,"
"7.88,7.85,7.83,7.8,7.78],\"angle\":[14.9,15.0,15.1,15.2,15.3,15.4,15.5,1"
"5.6,15.7,15.8,15.9],\"range_min\":[-0.208,-0.21,-0.212,-0.214,-0.216,-0."
"218,-0.219,-0.221,-0.223,-0.225,-0.227],\"range_max\":[0.424,0.425,0.426"
",0.427,0.428,0.428,0.429,0.43,0.431,0.431,0.432]},\"settings\":{\"range\":"
"{\"sigma_factor\":8,\"additive_value\":0.1},\"amplitude\":{\"sigma_factor\":4,"
"\"additive_value\":1.0}}}"
)

# Correction parameters for window glass echoes
RDB_RIEGL_WINDOW_ECHO_CORRECTION             = "riegl.window_echo_correction"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_TITLE       = "Window Echo Correction"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_DESCRIPTION = "Correction parameters for window glass echoes"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_STATUS      = "optional"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_SCHEMA = (
"{\"properties\":{\"range\":{\"description\":\"Range axis of correction "
"table\",\"properties\":{\"maximum\":{\"description\":\"Maximum range in m\",\"ma"
"ximum\":2.0,\"minimum\":-2.0,\"type\":\"number\"},\"minimum\":{\"description\":\"M"
"inimum range in m\",\"maximum\":2.0,\"minimum\":-2.0,\"type\":\"number\"},\"entr"
"ies\":{\"description\":\"Number of range entries\",\"minimum\":1,\"type\":\"inte"
"ger\"}},\"required\":[\"minimum\",\"maximum\",\"entries\"],\"type\":\"object\"},\"sl"
"ices\":{\"items\":{\"description\":\"Window echo correction parameter slice\""
",\"properties\":{\"table\":{\"items\":{\"items\":{\"items\":{\"description\":\"Tabl"
"e cell (item 0: amplitude in dB, 1: range in m, 2: "
"flags)\",\"type\":\"number\"},\"description\":\"Table column (= range "
"axis)\",\"minItems\":3,\"maxItems\":3,\"type\":\"array\"},\"description\":\"Table "
"row (= amplitude "
"axis)\",\"minItems\":1,\"type\":\"array\"},\"description\":\"Correction table "
"(dimension defined by the 'amplitude' and 'range' objects)\",\"minItems\""
":1,\"type\":\"array\"},\"amplitude\":{\"description\":\"Window echo amplitude "
"of slice in dB\",\"type\":\"number\"}},\"required\":[\"amplitude\",\"table\"],\"ty"
"pe\":\"object\"},\"type\":\"array\"},\"amplitude\":{\"description\":\"Amplitude "
"axis of correction "
"table\",\"properties\":{\"maximum\":{\"description\":\"Maximum amplitude in "
"dB\",\"minimum\":0.0,\"type\":\"number\"},\"minimum\":{\"description\":\"Minimum "
"amplitude in "
"dB\",\"minimum\":0.0,\"type\":\"number\"},\"entries\":{\"description\":\"Number of"
" amplitude entries\",\"minimum\":1,\"type\":\"integer\"}},\"required\":[\"minimu"
"m\",\"maximum\",\"entries\"],\"type\":\"object\"}},\"required\":[\"amplitude\",\"ran"
"ge\",\"slices\"],\"type\":\"object\",\"description\":\"Correction parameters for"
" window glass echoes\",\"title\":\"Window Echo "
"Correction\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_WINDOW_ECHO_CORRECTION_EXAMPLE = (
"{\"range\":{\"maximum\":1.5060822940732335,\"minimum\":-1.5060822940732335,\""
"entries\":128},\"slices\":[{\"table\":[[[6.23,0.3535,1]],[[5.54,0.72375,1]]"
"],\"amplitude\":1.5},{\"table\":[[[6.23,0.3535,1]],[[5.54,0.72375,1]]],\"am"
"plitude\":2.0}],\"amplitude\":{\"maximum\":20,\"minimum\":2,\"entries\":128}}"
)
