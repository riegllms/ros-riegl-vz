#
#*******************************************************************************
#
#  Copyright 2025 RIEGL Laser Measurement Systems
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
#  SPDX-License-Identifier: Apache-2.0
#
#*******************************************************************************
#
"""
*******************************************************************************
*
* \author  RIEGL LMS GmbH, Austria
* \brief   Description of RIEGL RDB 2 database meta data items.
* \version 2015-10-27/AW: Initial version
* \version 2015-11-25/AW: Item "Geo Tag" added
* \version 2016-10-27/AW: Item "Voxel Information" added
* \version 2016-11-17/AW: Item "Voxel Information" updated
* \version 2016-12-12/AW: Item "Range Statistics" added
* \version 2017-03-08/AW: Item "Plane Patch Statistics" added
* \version 2017-04-05/AW: Items "Atmosphere" and "Geometric Scale Factor" added
* \version 2017-08-22/AW: Items for waveform sample block and value files added
* \version 2017-10-24/AW: Item "Gaussian Decomposition" added
* \version 2017-11-13/AW: Item "riegl.scan_pattern" updated
* \version 2017-11-21/AW: Item "riegl.trajectory_info" added
* \version 2018-01-11/AW: Item "riegl.beam_geometry" added
* \version 2018-01-15/AW: Item "riegl.reflectance_calculation" added
* \version 2018-01-15/AW: Item "riegl.near_range_correction" added
* \version 2018-01-15/AW: Item "riegl.device_geometry" added
* \version 2018-02-13/AW: Item "riegl.notch_filter" added
* \version 2018-03-08/AW: Item "riegl.window_echo_correction" added
* \version 2018-03-15/AW: Item "riegl.pulse_position_modulation" added
* \version 2018-05-24/AW: Item "riegl.pixel_info" added
* \version 2018-06-08/AW: Item "riegl.shot_info" added
* \version 2018-06-08/AW: Item "riegl.echo_info" added
* \version 2018-06-14/AW: Item "riegl.mta_settings" added
* \version 2018-06-14/AW: Item "riegl.receiver_internals" added
* \version 2018-06-14/AW: Item "riegl.device_output_limits" added
* \version 2018-06-26/AW: Schema: replace "number" with "integer" if applicable
* \version 2018-07-09/AW: Item "riegl.pose_estimation" added
* \version 2018-07-09/AW: Item "riegl.pose_sensors" added
* \version 2018-09-20/AW: Item "riegl.pointcloud_info" added
* \version 2018-11-08/AW: Item "riegl.scan_pattern" updated
* \version 2018-11-13/AW: Item "riegl.receiver_internals" updated
* \version 2019-03-06/AW: Item "riegl.receiver_internals" updated
* \version 2019-03-21/AW: Item "riegl.device_geometry" updated
* \version 2019-04-15/AW: Item "riegl.point_attribute_groups" added
* \version 2019-04-30/AW: Item "riegl.waveform_settings" added
* \version 2019-10-03/AW: Item "riegl.angular_notch_filter" added
* \version 2019-10-03/AW: Item "riegl.noise_estimates" added
* \version 2019-10-25/AW: Item "riegl.window_analysis" added
* \version 2019-11-06/AW: Item "riegl.georeferencing_parameters" added
* \version 2019-11-27/AW: Item "riegl.plane_patch_matching" added
* \version 2019-12-13/AW: Items for tie-/control objects added
* \version 2019-12-19/AW: Items for tie-/control objects added
* \version 2020-02-04/AW: Item "riegl.detection_probability" added
* \version 2020-02-04/AW: Item "riegl.licenses" added
* \version 2020-04-27/AW: Item "riegl.waveform_info" updated (schema+example)
* \version 2020-09-03/AW: Item "riegl.reflectance_correction" added
* \version 2020-09-10/AW: Item "riegl.device_geometry_passive_channel" added
* \version 2020-09-25/AW: Item "riegl.georeferencing_parameters" updated
* \version 2020-09-25/AW: Item "riegl.trajectory_info" updated
* \version 2020-09-29/AW: Item "riegl.temperature_calculation" added
* \version 2020-10-23/AW: Item "riegl.exponential_decomposition" added (#3709)
* \version 2020-11-30/AW: Item "riegl.notch_filter" updated (schema)
* \version 2020-12-02/AW: Item "riegl.georeferencing_parameters" updated (schema)
* \version 2021-02-02/AW: Item "riegl.plane_slope_class_info" added (rdbplanes/#7)
* \version 2021-02-16/AW: Item "riegl.device_output_limits" updated (schema, #3811)
* \version 2021-03-03/AW: Item "riegl.exponential_decomposition" updated (schema, #3822)
* \version 2021-03-03/AW: Item "riegl.waveform_averaging_settings" added (#3821)
* \version 2021-04-01/AW: Item "riegl.voxel_info" updated (schema, #3854)
* \version 2021-04-16/AW: Item "riegl.voxel_info" updated (schema, #3866)
* \version 2021-09-30/AW: Item "riegl.waveform_info" updated (schema+example, #4016)
* \version 2021-10-04/AW: Improved spelling of the descriptions of some items
* \version 2021-11-04/AW: Rename "riegl.record_names" to "riegl.item_names" (#4034)
* \version 2022-03-11/AW: Item "riegl.devices" added (#4162)
* \version 2022-03-14/AW: Item "riegl.stored_filters" added (#4164)
* \version 2022-09-20/AW: Fix typos in schema of "riegl.georeferencing_parameters"
* \version 2022-09-30/AW: Item "riegl.system_description" added (#4368)
* \version 2022-10-10/AW: Correction of typos in the titles of some entries
* \version 2022-10-20/AW: Item "riegl.stored_filters" updated (example, #4164)
* \version 2023-01-19/AW: Item "riegl.ttip_configuration" added (#4449)
* \version 2024-09-26/AW: Item "riegl.dyntrig" added (#5310)
*
*******************************************************************************
"""

# Angular notch filter parameters for window glass echoes
RDB_RIEGL_ANGULAR_NOTCH_FILTER             = "riegl.angular_notch_filter"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_TITLE       = "Angular Notch Filter"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_DESCRIPTION = "Angular notch filter parameters for window glass echoes"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_STATUS      = "optional"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_SCHEMA = (
"{\"title\":\"Angular Notch Filter\",\"properties\":{\"range_mean\":{\"type\":\"ar"
"ray\",\"items\":{\"type\":\"number\"},\"description\":\"Mean range [m]\"},\"angle\""
":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"description\":\"Angle [deg]\""
"},\"amplitude_mean\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"descript"
"ion\":\"Mean amplitude [dB]\"}},\"$schema\":\"http://json-schema.org/draft-0"
"4/schema#\",\"type\":\"object\",\"description\":\"Angular notch filter "
"parameters for window glass "
"echoes\",\"required\":[\"angle\",\"range_mean\",\"amplitude_mean\"]}"
)
RDB_RIEGL_ANGULAR_NOTCH_FILTER_EXAMPLE = (
"{\"range_mean\":[0.094,0.094,0.09075,0.08675,0.0815,0.0775,0.074,0.071,0"
".068,0.0675,0.06475],\"angle\":[14.0,15.0,16.0,17.0,18.0,19.0,20.0,21.0,"
"22.0,23.0,24.0],\"amplitude_mean\":[3.780913,3.780913,3.480913,3.120913,"
"2.850913,2.720913,2.680913,2.610913,2.530913,2.570913,2.570913]}"
)

# Atmospheric parameters
RDB_RIEGL_ATMOSPHERE             = "riegl.atmosphere"
RDB_RIEGL_ATMOSPHERE_TITLE       = "Atmosphere"
RDB_RIEGL_ATMOSPHERE_DESCRIPTION = "Atmospheric parameters"
RDB_RIEGL_ATMOSPHERE_STATUS      = "optional"
RDB_RIEGL_ATMOSPHERE_SCHEMA = (
"{\"title\":\"Atmospheric Parameters\",\"properties\":{\"rel_humidity\":{\"type\""
":\"number\",\"description\":\"Relative humidity along measurement path "
"[%]\"},\"group_velocity\":{\"type\":\"number\",\"description\":\"Group velocity "
"of laser beam [m/s]\"},\"amsl\":{\"type\":\"number\",\"description\":\"Height "
"above mean sea level (AMSL) "
"[m]\"},\"temperature\":{\"type\":\"number\",\"description\":\"Temperature along "
"measurement path "
"[\\u00b0C]\"},\"attenuation\":{\"type\":\"number\",\"description\":\"Atmospheric "
"attenuation "
"[1/km]\"},\"pressure\":{\"type\":\"number\",\"description\":\"Pressure along "
"measurment path "
"[mbar]\"},\"pressure_sl\":{\"type\":\"number\",\"description\":\"Atmospheric "
"pressure at sea level "
"[mbar]\"},\"wavelength\":{\"type\":\"number\",\"description\":\"Laser wavelength"
" [nm]\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"o"
"bject\",\"description\":\"Atmospheric parameters\",\"required\":[\"temperature"
"\",\"pressure\",\"rel_humidity\",\"pressure_sl\",\"amsl\",\"group_velocity\",\"att"
"enuation\",\"wavelength\"]}"
)
RDB_RIEGL_ATMOSPHERE_EXAMPLE = (
"{\"rel_humidity\":63,\"group_velocity\":299711000.0,\"amsl\":0,\"temperature\""
":7,\"attenuation\":0.028125,\"pressure\":970,\"pressure_sl\":970,\"wavelength"
"\":1550}"
)

# Laser beam geometry details
RDB_RIEGL_BEAM_GEOMETRY             = "riegl.beam_geometry"
RDB_RIEGL_BEAM_GEOMETRY_TITLE       = "Beam Geometry"
RDB_RIEGL_BEAM_GEOMETRY_DESCRIPTION = "Laser beam geometry details"
RDB_RIEGL_BEAM_GEOMETRY_STATUS      = "optional"
RDB_RIEGL_BEAM_GEOMETRY_SCHEMA = (
"{\"title\":\"Beam Geometry\",\"properties\":{\"beam_divergence\":{\"minimum\":0,"
"\"description\":\"Beam divergence in far field [rad]\",\"type\":\"number\",\"ex"
"clusiveMinimum\":false},\"beam_exit_diameter\":{\"minimum\":0,\"description\""
":\"Beam width at exit aperture [m]\",\"type\":\"number\",\"exclusiveMinimum\":"
"false}},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"ob"
"ject\",\"description\":\"Laser beam geometry "
"details\",\"required\":[\"beam_exit_diameter\",\"beam_divergence\"]}"
)
RDB_RIEGL_BEAM_GEOMETRY_EXAMPLE = (
"{\"beam_divergence\":0.0003,\"beam_exit_diameter\":0.0072}"
)

# List of control object type definitions
RDB_RIEGL_CONTROL_OBJECT_CATALOG             = "riegl.control_object_catalog"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_TITLE       = "Control Object Catalog"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_DESCRIPTION = "List of control object type definitions"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_STATUS      = "optional"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_SCHEMA = (
"{\"title\":\"Control Object Catalog\",\"properties\":{\"types\":{\"uniqueItems\""
":true,\"type\":\"array\",\"items\":{\"oneOf\":[{\"$ref\":\"#/definitions/rectangl"
"e\"},{\"$ref\":\"#/definitions/checkerboard2x2\"},{\"$ref\":\"#/definitions/ch"
"evron\"},{\"$ref\":\"#/definitions/circular_disk\"},{\"$ref\":\"#/definitions/"
"cylinder\"},{\"$ref\":\"#/definitions/sphere\"},{\"$ref\":\"#/definitions/roun"
"d_corner_cube_prism\"}],\"type\":\"object\"}}},\"$schema\":\"http://json-schem"
"a.org/draft-04/schema#\",\"type\":\"object\",\"definitions\":{\"cylinder\":{\"de"
"scription\":\"cylinder\",\"type\":\"object\",\"allOf\":[{\"$ref\":\"#/definitions/"
"common\"},{\"properties\":{\"diameter\":{\"minimum\":0,\"description\":\"diamete"
"r in meters\",\"type\":\"number\",\"exclusiveMinimum\":true},\"height\":{\"minim"
"um\":0,\"description\":\"height in meters\",\"type\":\"number\",\"exclusiveMinim"
"um\":true},\"shape\":{\"enum\":[\"cylinder\"],\"description\":\"shape identifier"
"\",\"type\":\"string\"}},\"required\":[\"shape\",\"diameter\",\"height\"],\"descript"
"ion\":\"cylinder specific properties\",\"type\":\"object\"}]},\"chevron\":{\"des"
"cription\":\"chevron\",\"type\":\"object\",\"allOf\":[{\"$ref\":\"#/definitions/co"
"mmon\"},{\"properties\":{\"outside_edge_length\":{\"minimum\":0,\"description\""
":\"length of the two outer edges in meters\",\"type\":\"number\",\"exclusiveM"
"inimum\":true},\"shape\":{\"enum\":[\"chevron\"],\"description\":\"shape identif"
"ier\",\"type\":\"string\"},\"thickness\":{\"minimum\":0,\"description\":\"thicknes"
"s in meters\",\"type\":\"number\",\"exclusiveMinimum\":true}},\"required\":[\"sh"
"ape\",\"outside_edge_length\",\"thickness\"],\"description\":\"chevron "
"specific properties\",\"type\":\"object\"}]},\"checkerboard2x2\":{\"descriptio"
"n\":\"checkerboard 2 by 2\",\"type\":\"object\",\"allOf\":[{\"$ref\":\"#/definitio"
"ns/common\"},{\"properties\":{\"shape\":{\"enum\":[\"checkerboard2x2\"],\"descri"
"ption\":\"shape identifier\",\"type\":\"string\"},\"square_length\":{\"minimum\":"
"0,\"description\":\"length of a square of the checkerboard in meters\",\"ty"
"pe\":\"number\",\"exclusiveMinimum\":true}},\"required\":[\"shape\",\"square_len"
"gth\"],\"description\":\"checkerboard specific properties\",\"type\":\"object\""
"}]},\"rectangle\":{\"description\":\"rectangle\",\"type\":\"object\",\"allOf\":[{\""
"$ref\":\"#/definitions/common\"},{\"properties\":{\"length\":{\"minimum\":0,\"de"
"scription\":\"length in meters\",\"type\":\"number\",\"exclusiveMinimum\":true}"
",\"shape\":{\"type\":\"string\",\"enum\":[\"rectangle\"]},\"width\":{\"minimum\":0,\""
"description\":\"width in meters\",\"type\":\"number\",\"exclusiveMinimum\":true"
"}},\"required\":[\"shape\",\"length\",\"width\"],\"description\":\"rectangle "
"specific properties\",\"type\":\"object\"}]},\"sphere\":{\"description\":\"spher"
"e\",\"type\":\"object\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"properti"
"es\":{\"diameter\":{\"minimum\":0,\"description\":\"diameter in meters\",\"type\""
":\"number\",\"exclusiveMinimum\":true},\"shape\":{\"enum\":[\"sphere\"],\"descrip"
"tion\":\"shape identifier\",\"type\":\"string\"}},\"required\":[\"shape\",\"diamet"
"er\"],\"description\":\"sphere specific properties\",\"type\":\"object\"}]},\"ro"
"und_corner_cube_prism\":{\"description\":\"round corner cube prism\",\"type\""
":\"object\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"properties\":{\"dia"
"meter\":{\"minimum\":0,\"description\":\"diameter in meters\",\"type\":\"number\""
",\"exclusiveMinimum\":true},\"offset\":{\"description\":\"offset in meters, "
"e.g. reflector constant (optional)\",\"type\":\"number\"},\"shape\":{\"enum\":["
"\"round_corner_cube_prism\"],\"description\":\"shape identifier\",\"type\":\"st"
"ring\"}},\"required\":[\"shape\",\"diameter\"],\"description\":\"round corner "
"cube prism specific properties\",\"type\":\"object\"}]},\"common\":{\"properti"
"es\":{\"surface_type\":{\"enum\":[\"retro_reflective_foil\",\"diffuse\"],\"descr"
"iption\":\"surface material "
"type\",\"type\":\"string\"},\"description\":{\"description\":\"string describing"
" the object\",\"type\":\"string\"},\"shape\":{\"enum\":[\"rectangle\",\"checkerboa"
"rd2x2\",\"chevron\",\"circular_disk\",\"cylinder\",\"sphere\",\"round_corner_cub"
"e_prism\"],\"description\":\"shape "
"identifier\",\"type\":\"string\"},\"name\":{\"description\":\"unique type identi"
"fier\",\"type\":\"string\",\"minLength\":3}},\"required\":[\"name\",\"shape\"],\"des"
"cription\":\"common object "
"properties\",\"type\":\"object\"},\"circular_disk\":{\"description\":\"circular "
"disk\",\"type\":\"object\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"prope"
"rties\":{\"diameter\":{\"minimum\":0,\"description\":\"diameter in meters\",\"ty"
"pe\":\"number\",\"exclusiveMinimum\":true},\"offset\":{\"description\":\"offset "
"in meters, e.g. reflector constant (optional)\",\"type\":\"number\"},\"shape"
"\":{\"enum\":[\"circular_disk\"],\"description\":\"shape identifier\",\"type\":\"s"
"tring\"}},\"required\":[\"shape\",\"diameter\"],\"description\":\"circular disk "
"specific properties\",\"type\":\"object\"}]}},\"description\":\"List of "
"control object type definitions\",\"required\":[\"types\"]}"
)
RDB_RIEGL_CONTROL_OBJECT_CATALOG_EXAMPLE = (
"{\"comments\":[\"This file contains a list of control object types (aka. "
"'catalog').\",\"Each type is described by an object,\",\"which must "
"contain at least the following parameters:\",\"  - name: unique "
"identifier of the type\",\"  - shape: one of the following supported "
"shapes:\",\"      - rectangle\",\"      - checkerboard2x2\",\"      - "
"chevron\",\"      - circular_disk\",\"      - cylinder\",\"      - sphere\",\""
"      - round_corner_cube_prism\",\"Depending on 'shape', the following "
"parameters must/may be specified:\",\"  - rectangle:\",\"      - length: "
"length in meters\",\"      - width: width in meters\",\"  - "
"checkerboard2x2:\",\"      - square_length: length of a square of the "
"checkerboard in meters\",\"  - circular_disk:\",\"      - diameter: "
"diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
"constant (optional)\",\"  - chevron:\",\"      - outside_edge_length: "
"length of the two outer edges in meters\",\"      - thickness: thickness"
" in meters\",\"  - cylinder:\",\"      - diameter: diameter in meters\",\""
"      - height: height in meters\",\"  - sphere:\",\"      - diameter: "
"diameter in meters\",\"  - round_corner_cube_prism:\",\"      - diameter: "
"diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
"constant (optional)\",\"Optional parameters:\",\"    - description: string"
" describing the object\",\"    - surface_type: surface material type "
"(either 'retro_reflective_foil' or "
"'diffuse')\"],\"types\":[{\"length\":0.6,\"description\":\"Rectangle (60cm x "
"30cm)\",\"shape\":\"rectangle\",\"width\":0.3,\"name\":\"Rectangle "
"60x30\"},{\"length\":0.8,\"description\":\"Rectangle (80cm x "
"40cm)\",\"shape\":\"rectangle\",\"width\":0.4,\"name\":\"Rectangle "
"80x40\"},{\"description\":\"Checkerboard (square length: "
"30cm)\",\"shape\":\"checkerboard2x2\",\"name\":\"Checkerboard2x2 "
"30\",\"square_length\":0.3},{\"description\":\"Checkerboard (square length: "
"50cm)\",\"shape\":\"checkerboard2x2\",\"name\":\"Checkerboard2x2 50\",\"square_l"
"ength\":0.5},{\"outside_edge_length\":0.6096,\"description\":\"Chevron "
"(a=24''; b=4'')\",\"shape\":\"chevron\",\"name\":\"Chevron 24''/4''\",\"thicknes"
"s\":0.1016},{\"diameter\":0.5,\"surface_type\":\"diffuse\",\"description\":\" "
"Circular Disk (diameter: "
"50cm)\",\"shape\":\"circular_disk\",\"name\":\"Circular Disk "
"50\"},{\"surface_type\":\"retro_reflective_foil\",\"name\":\"RIEGL flat "
"reflector 50 mm\",\"diameter\":0.05,\"offset\":0.0,\"description\":\"flat "
"circular reflector from retro-reflective foil\",\"shape\":\"circular_disk\""
"},{\"surface_type\":\"retro_reflective_foil\",\"name\":\"RIEGL flat reflector"
" 100 mm\",\"diameter\":0.1,\"offset\":0.0,\"description\":\"flat circular "
"reflector from retro-reflective foil\",\"shape\":\"circular_disk\"},{\"surfa"
"ce_type\":\"retro_reflective_foil\",\"name\":\"RIEGL flat reflector 150 "
"mm\",\"diameter\":0.15,\"offset\":0.0,\"description\":\"flat circular "
"reflector from retro-reflective foil\",\"shape\":\"circular_disk\"},{\"surfa"
"ce_type\":\"retro_reflective_foil\",\"name\":\"RIEGL cylindrical reflector "
"50 mm\",\"diameter\":0.05,\"shape\":\"cylinder\",\"description\":\"cylindrical "
"reflector from retro-reflective foil\",\"height\":0.05},{\"surface_type\":\""
"retro_reflective_foil\",\"name\":\"RIEGL cylindrical reflector 100 "
"mm\",\"diameter\":0.1,\"shape\":\"cylinder\",\"description\":\"cylindrical "
"reflector from retro-reflective "
"foil\",\"height\":0.1},{\"diameter\":0.2,\"description\":\"Sphere (diameter: "
"200 mm)\",\"shape\":\"sphere\",\"name\":\"Sphere 200 "
"mm\"},{\"diameter\":0.05,\"offset\":0.0,\"description\":\"round corner cube "
"prism\",\"shape\":\"round_corner_cube_prism\",\"name\":\"Corner Cube Prism 50 "
"mm\"}]}"
)

# Details about the control object reference file
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE             = "riegl.control_object_reference_file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_TITLE       = "Control Object Reference file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_DESCRIPTION = "Details about the control object reference file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_STATUS      = "optional"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_SCHEMA = (
"{\"title\":\"Control Object Reference file\",\"properties\":{\"reference_file"
"\":{\"properties\":{\"file_uuid\":{\"description\":\"Control object file's "
"Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_path\":{\"description\":\"Path of the "
"control object file relative to referring file\",\"type\":\"string\"}},\"req"
"uired\":[\"file_uuid\",\"file_path\"],\"type\":\"object\",\"description\":\"Refere"
"nce to a control object file\"}},\"$schema\":\"http://json-schema.org/draf"
"t-04/schema#\",\"description\":\"Details about the control object "
"reference file\",\"type\":\"object\"}"
)
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_EXAMPLE = (
"{\"reference_file\":{\"file_uuid\":\"810f5d57-eccf-49ed-b07a-0cdd109b4213\","
"\"file_path\":\"../../../10_CONTROL_OBJECTS/ControlPoints.cpx\"}}"
)

# Detection probability as a function of amplitude
RDB_RIEGL_DETECTION_PROBABILITY             = "riegl.detection_probability"
RDB_RIEGL_DETECTION_PROBABILITY_TITLE       = "Detection Probability"
RDB_RIEGL_DETECTION_PROBABILITY_DESCRIPTION = "Detection probability as a function of amplitude"
RDB_RIEGL_DETECTION_PROBABILITY_STATUS      = "optional"
RDB_RIEGL_DETECTION_PROBABILITY_SCHEMA = (
"{\"title\":\"Detection Probability\",\"properties\":{\"amplitude\":{\"type\":\"ar"
"ray\",\"items\":{\"type\":\"number\"},\"description\":\"Amplitude [dB]\"},\"detect"
"ion_probability\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"descriptio"
"n\":\"Detection probability [0..1]\"}},\"$schema\":\"http://json-schema.org/"
"draft-04/schema#\",\"type\":\"object\",\"description\":\"Detection probability"
" as a function of "
"amplitude\",\"required\":[\"amplitude\",\"detection_probability\"]}"
)
RDB_RIEGL_DETECTION_PROBABILITY_EXAMPLE = (
"{\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0],\"detection"
"_probability\":[0.0,0.5,0.8,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0]}"
)

# Details about the device used to acquire the point cloud
RDB_RIEGL_DEVICE             = "riegl.device"
RDB_RIEGL_DEVICE_TITLE       = "Device Information"
RDB_RIEGL_DEVICE_DESCRIPTION = "Details about the device used to acquire the point cloud"
RDB_RIEGL_DEVICE_STATUS      = "optional"
RDB_RIEGL_DEVICE_SCHEMA = (
"{\"title\":\"Device "
"Information\",\"properties\":{\"device_type\":{\"description\":\"Device type "
"identifier (e.g. "
"VZ-400i)\",\"type\":\"string\"},\"device_build\":{\"description\":\"Device build"
" variant\",\"type\":\"string\"},\"channel_number\":{\"minimum\":0,\"description\""
":\"Laser channel number (not defined or 0: single channel device)\",\"typ"
"e\":\"integer\",\"exclusiveMinimum\":false},\"device_name\":{\"description\":\"O"
"ptional device name (e.g. 'Scanner 1' for multi-scanner "
"systems)\",\"type\":\"string\"},\"serial_number\":{\"description\":\"Device "
"serial number (e.g. "
"S2221234)\",\"type\":\"string\"},\"channel_text\":{\"description\":\"Optional "
"channel description (e.g. 'Green Channel' for multi-channel devices)\","
"\"type\":\"string\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\","
"\"type\":\"object\",\"description\":\"Details about the device used to "
"acquire the point cloud\",\"required\":[\"device_type\",\"serial_number\"]}"
)
RDB_RIEGL_DEVICE_EXAMPLE = (
"{\"device_type\":\"VZ-400i\",\"device_build\":\"\",\"channel_number\":0,\"device_"
"name\":\"Scanner 1\",\"serial_number\":\"S2221234\",\"channel_text\":\"\"}"
)

# Scanner device geometry details
RDB_RIEGL_DEVICE_GEOMETRY             = "riegl.device_geometry"
RDB_RIEGL_DEVICE_GEOMETRY_TITLE       = "Device Geometry"
RDB_RIEGL_DEVICE_GEOMETRY_DESCRIPTION = "Scanner device geometry details"
RDB_RIEGL_DEVICE_GEOMETRY_STATUS      = "optional"
RDB_RIEGL_DEVICE_GEOMETRY_SCHEMA = (
"{\"title\":\"Device Geometry\",\"properties\":{\"primary\":{\"properties\":{\"ID\""
":{\"minItems\":2,\"description\":\"Structure identifier\",\"type\":\"array\",\"it"
"ems\":{\"type\":\"integer\"},\"maxItems\":2},\"content\":{\"description\":\"Intern"
"al calibration values\",\"type\":\"array\",\"items\":{\"type\":\"number\"}}},\"req"
"uired\":[\"ID\",\"content\"],\"description\":\"Primary device geometry "
"structure (mandatory)\",\"type\":\"object\"},\"secondary\":{\"properties\":{\"ID"
"\":{\"minItems\":2,\"description\":\"Structure identifier\",\"type\":\"array\",\"i"
"tems\":{\"type\":\"integer\"},\"maxItems\":2},\"content\":{\"description\":\"Inter"
"nal calibration values\",\"type\":\"array\",\"items\":{\"type\":\"number\"}}},\"re"
"quired\":[\"ID\",\"content\"],\"description\":\"Additional device geometry "
"structure (optional)\",\"type\":\"object\"},\"amu\":{\"properties\":{\"lineCC\":{"
"\"minimum\":0,\"description\":\"Line Circle Count (number of LSBs per full "
"rotation about line axis)\",\"type\":\"number\",\"exclusiveMinimum\":false},\""
"frameCC\":{\"minimum\":0,\"description\":\"Frame Circle Count (number of "
"LSBs per full rotation about frame "
"axis)\",\"type\":\"number\",\"exclusiveMinimum\":false}},\"description\":\"Angle"
" Measurement Unit\",\"type\":\"object\"}},\"$schema\":\"http://json-schema.org"
"/draft-04/schema#\",\"type\":\"object\",\"description\":\"Scanner device "
"geometry details\",\"required\":[\"primary\"]}"
)
RDB_RIEGL_DEVICE_GEOMETRY_EXAMPLE = (
"{\"primary\":{\"ID\":[4,0],\"content\":[0]},\"secondary\":{\"ID\":[91,0],\"conten"
"t\":[0]},\"amu\":{\"lineCC\":124000,\"frameCC\":124000}}"
)

# Scanner passive channel device geometry details
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL             = "riegl.device_geometry_passive_channel"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_TITLE       = "Device Geometry Passive Channel"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_DESCRIPTION = "Scanner passive channel device geometry details"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_STATUS      = "optional"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_SCHEMA = (
"{\"title\":\"Device Geometry Passive Channel\",\"properties\":{\"primary\":{\"p"
"roperties\":{\"ID\":{\"minItems\":2,\"description\":\"Structure identifier\",\"t"
"ype\":\"array\",\"items\":{\"type\":\"integer\"},\"maxItems\":2},\"content\":{\"desc"
"ription\":\"Internal calibration values\",\"type\":\"array\",\"items\":{\"type\":"
"\"number\"}}},\"required\":[\"ID\",\"content\"],\"description\":\"Primary device "
"geometry structure (mandatory)\",\"type\":\"object\"}},\"$schema\":\"http://js"
"on-schema.org/draft-04/schema#\",\"type\":\"object\",\"description\":\"Scanner"
" passive channel device geometry details\",\"required\":[\"primary\"]}"
)
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_EXAMPLE = (
"{\"primary\":{\"ID\":[143,0],\"content\":[0]}}"
)

# Limits of the measured values output by the device
RDB_RIEGL_DEVICE_OUTPUT_LIMITS             = "riegl.device_output_limits"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_TITLE       = "Device Output Limits"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_DESCRIPTION = "Limits of the measured values output by the device"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_STATUS      = "optional"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_SCHEMA = (
"{\"title\":\"Device Output Limits\",\"properties\":{\"background_radiation_ma"
"ximum\":{\"type\":\"number\",\"description\":\"Maximum possible background rad"
"iation.\"},\"echo_count_maximum\":{\"type\":\"number\",\"description\":\"Maximum"
" number of echoes a laser shot can have.\"},\"mta_zone_count_maximum\":{\""
"type\":\"number\",\"description\":\"Maximum number of MTA "
"zones.\"},\"range_maximum\":{\"type\":\"number\",\"description\":\"Maximum "
"possible range in meters.\"},\"background_radiation_minimum\":{\"type\":\"nu"
"mber\",\"description\":\"Minimum possible background radiation.\"},\"reflect"
"ance_minimum\":{\"type\":\"number\",\"description\":\"Minimum possible "
"reflectance in "
"dB.\"},\"range_minimum\":{\"type\":\"number\",\"description\":\"Minimum possible"
" range in "
"meters.\"},\"deviation_minimum\":{\"type\":\"number\",\"description\":\"Minimum "
"possible pulse shape deviation.\"},\"reflectance_maximum\":{\"type\":\"numbe"
"r\",\"description\":\"Maximum possible reflectance in "
"dB.\"},\"amplitude_minimum\":{\"type\":\"number\",\"description\":\"Minimum "
"possible amplitude in "
"dB.\"},\"amplitude_maximum\":{\"type\":\"number\",\"description\":\"Maximum "
"possible amplitude in "
"dB.\"},\"deviation_maximum\":{\"type\":\"number\",\"description\":\"Maximum "
"possible pulse shape deviation.\"}},\"$schema\":\"http://json-schema.org/d"
"raft-04/schema#\",\"description\":\"Limits of the measured values output "
"by the device. The limits depend on the device type, measurement "
"program and/or scan pattern.\",\"type\":\"object\"}"
)
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_EXAMPLE = (
"{\"mta_zone_count_maximum\":7,\"range_minimum\":2.9,\"background_radiation_"
"maximum\":0,\"reflectance_maximum\":100.0,\"deviation_minimum\":-1,\"range_m"
"aximum\":10000.0,\"background_radiation_minimum\":0,\"amplitude_minimum\":0"
".0,\"reflectance_minimum\":-100.0,\"amplitude_maximum\":100.0,\"deviation_m"
"aximum\":32767}"
)

# Details about the devices used to acquire the point cloud
RDB_RIEGL_DEVICES             = "riegl.devices"
RDB_RIEGL_DEVICES_TITLE       = "Devices Information"
RDB_RIEGL_DEVICES_DESCRIPTION = "Details about the devices used to acquire the point cloud"
RDB_RIEGL_DEVICES_STATUS      = "optional"
RDB_RIEGL_DEVICES_SCHEMA = (
"{\"title\":\"Devices Information\",\"$schema\":\"http://json-schema.org/draft"
"-04/schema#\",\"description\":\"Details about the devices used to acquire "
"the point cloud (e.g. when merging point clouds of different devices)\""
",\"type\":\"array\",\"items\":{\"properties\":{\"device_type\":{\"description\":\"D"
"evice type identifier (e.g. "
"VZ-400i)\",\"type\":\"string\"},\"device_build\":{\"description\":\"Device build"
" variant\",\"type\":\"string\"},\"channel_number\":{\"minimum\":0,\"description\""
":\"Laser channel number (not defined or 0: single channel device)\",\"typ"
"e\":\"integer\",\"exclusiveMinimum\":false},\"device_name\":{\"description\":\"O"
"ptional device name (e.g. 'Scanner 1' for multi-scanner "
"systems)\",\"type\":\"string\"},\"serial_number\":{\"description\":\"Device "
"serial number (e.g. "
"S2221234)\",\"type\":\"string\"},\"channel_text\":{\"description\":\"Optional "
"channel description (e.g. 'Green Channel' for multi-channel "
"devices)\",\"type\":\"string\"},\"signed\":{\"description\":\"Flag that is set "
"when the original 'riegl.device' entry in the source file was "
"correctly signed.\",\"type\":\"boolean\"}},\"required\":[\"device_type\",\"seria"
"l_number\"],\"type\":\"object\"}}"
)
RDB_RIEGL_DEVICES_EXAMPLE = (
"[{\"device_type\":\"VZ-400i\",\"device_build\":\"\",\"channel_number\":0,\"device"
"_name\":\"Scanner 1\",\"serial_number\":\"S2221234\",\"channel_text\":\"\",\"signe"
"d\":false},{\"device_type\":\"VQ-1560i-DW\",\"device_build\":\"\",\"channel_numb"
"er\":1,\"device_name\":\"Scanner 2\",\"serial_number\":\"S2222680\",\"channel_te"
"xt\":\"\",\"signed\":true},{\"device_type\":\"VQ-1560i-DW\",\"device_build\":\"\",\""
"channel_number\":2,\"device_name\":\"Scanner "
"3\",\"serial_number\":\"S2222680\",\"channel_text\":\"\",\"signed\":true}]"
)

# Dyntrig
RDB_RIEGL_DYNTRIG             = "riegl.dyntrig"
RDB_RIEGL_DYNTRIG_TITLE       = "Dyntrig"
RDB_RIEGL_DYNTRIG_DESCRIPTION = "Dyntrig"
RDB_RIEGL_DYNTRIG_STATUS      = "optional"
RDB_RIEGL_DYNTRIG_SCHEMA = (
"{\"title\":\"Dyntrig\",\"properties\":{\"scale\":{\"type\":\"number\",\"description"
"\":\"Scale in units of dB, for calculation of line: line number N=(ampli"
"tude-offset)/scale\"},\"post\":{\"properties\":{\"a\":{\"description\":\"...\",\"m"
"inItems\":1,\"type\":\"array\",\"items\":{\"type\":\"number\"},\"maxItems\":2080},\""
"nc\":{\"minimum\":0,\"type\":\"integer\",\"description\":\"Number of entries\",\"m"
"aximum\":255}},\"required\":[\"nc\",\"a\"],\"type\":\"object\",\"description\":\"Dyn"
"trig post values\"},\"offset\":{\"type\":\"number\",\"description\":\"Offset in "
"units of dB, for calculation of line\"},\"tab\":{\"description\":\"...\",\"min"
"Items\":1,\"type\":\"array\",\"items\":{\"properties\":{\"del1\":{\"description\":\""
"Length of constant post-trigger threshold elevation in units of "
"m\",\"type\":\"number\"},\"thra2\":{\"description\":\"Pre-trigger threshold in "
"units of dB\",\"type\":\"number\"},\"dec1\":{\"description\":\"Decay of "
"post-trigger threshold after del1 in units of "
"dB/m\",\"type\":\"number\"},\"dec2\":{\"description\":\"Rise of pre-trigger "
"threshold after del2 in units of "
"dB/m\",\"type\":\"number\"},\"thra1\":{\"description\":\"Post-trigger threshold "
"in units of dB\",\"type\":\"number\"},\"del2\":{\"description\":\"Length of "
"constant pre-trigger threshold elevation in units of m\",\"type\":\"number"
"\"}},\"required\":[\"thra1\",\"del1\",\"dec1\",\"thra2\",\"del2\",\"dec2\"],\"descript"
"ion\":\"...\",\"type\":\"object\"},\"maxItems\":128},\"pre\":{\"properties\":{\"a\":{"
"\"description\":\"...\",\"minItems\":1,\"type\":\"array\",\"items\":{\"type\":\"numbe"
"r\"},\"maxItems\":2080},\"nc\":{\"minimum\":0,\"type\":\"integer\",\"description\":"
"\"Number of entries\",\"maximum\":255}},\"required\":[\"nc\",\"a\"],\"type\":\"obje"
"ct\",\"description\":\"Dyntrig pre values\"}},\"$schema\":\"http://json-schema"
".org/draft-04/schema#\",\"description\":\"Dyntrig\"}"
)
RDB_RIEGL_DYNTRIG_EXAMPLE = (
"{\"scale\":1.0,\"post\":{\"a\":[78,86,126,134,31],\"nc\":128},\"offset\":0.0,\"ta"
"b\":[{\"del1\":0.0,\"thra2\":0.0,\"dec1\":0.0,\"dec2\":0.0,\"thra1\":0.0,\"del2\":0"
".0}],\"pre\":{\"a\":[78,86,126,134,31],\"nc\":128}}"
)

# Details about echo files
RDB_RIEGL_ECHO_INFO             = "riegl.echo_info"
RDB_RIEGL_ECHO_INFO_TITLE       = "Echo Information"
RDB_RIEGL_ECHO_INFO_DESCRIPTION = "Details about echo files"
RDB_RIEGL_ECHO_INFO_STATUS      = "optional"
RDB_RIEGL_ECHO_INFO_SCHEMA = (
"{\"title\":\"Echo Information\",\"properties\":{\"echo_file\":{\"properties\":{\""
"file_uuid\":{\"description\":\"File's Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Echo file "
"extension, without the leading dot\",\"type\":\"string\"}},\"required\":[\"fil"
"e_extension\"],\"type\":\"object\"}},\"$schema\":\"http://json-schema.org/draf"
"t-04/schema#\",\"type\":\"object\",\"description\":\"Details about echo "
"files\",\"required\":[\"echo_file\"]}"
)
RDB_RIEGL_ECHO_INFO_EXAMPLE = (
"{\"echo_file\":{\"file_uuid\":\"26a03615-67c0-4bea-8fe8-c577378fe661\",\"file"
"_extension\":\"owp\"}}"
)

# Details for exponential decomposition of full waveform data
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION             = "riegl.exponential_decomposition"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_TITLE       = "Exponential Decomposition"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_DESCRIPTION = "Details for exponential decomposition of full waveform data"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_STATUS      = "optional"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_SCHEMA = (
"{\"title\":\"Exponential Decomposition\",\"$schema\":\"http://json-schema.org"
"/draft-04/schema#\",\"type\":\"object\",\"patternProperties\":{\"^[0-9]+$\":{\"$"
"ref\":\"#/definitions/channel\",\"description\":\"one field per channel, "
"field name is channel index\"}},\"definitions\":{\"channel\":{\"properties\":"
"{\"scale\":{\"description\":\"amplitude calibration\",\"type\":\"number\"},\"para"
"meter\":{\"properties\":{\"omega\":{\"description\":\"angular frequency in Hz\""
",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"gamma\":{\"description\":\"dec"
"ay in 1/second\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"A\":{\"descri"
"ption\":\"real part of amplitude factor in units of full-scale\",\"type\":\""
"array\",\"items\":{\"type\":\"number\"}},\"B\":{\"description\":\"imaginary part "
"of amplitude factor in units of full-scale\",\"type\":\"array\",\"items\":{\"t"
"ype\":\"number\"}}},\"required\":[\"A\",\"B\",\"gamma\",\"omega\"],\"description\":\"p"
"arameters of the syswave exponential "
"sum\",\"type\":\"object\"},\"delay\":{\"description\":\"delay calibration in sec"
"onds\",\"type\":\"number\"},\"a_lin\":{\"minimum\":0,\"type\":\"number\",\"exclusive"
"Minimum\":false,\"maximum\":1,\"description\":\"relative linear amplitude "
"range [0..1]\",\"exclusiveMaximum\":false}},\"required\":[\"delay\",\"scale\",\""
"parameter\"],\"type\":\"object\"}},\"description\":\"Details for exponential "
"decomposition of full waveform data\",\"additionalProperties\":false}"
)
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_EXAMPLE = (
"{\"1\":{\"scale\":1.0,\"parameter\":{\"omega\":[352020896.0,3647927552.0,-1977"
"987072.0],\"gamma\":[-1094726528.0,-769562752.0,-848000064.0],\"A\":[0.9,0"
".3,-1.3],\"B\":[-3.9,0.0,-0.3]},\"delay\":3.5e-09,\"a_lin\":0.9},\"0\":{\"scale"
"\":1.0,\"parameter\":{\"omega\":[352020896.0,3647927552.0,-1977987072.0],\"g"
"amma\":[-1094726528.0,-769562752.0,-848000064.0],\"A\":[0.977245092391967"
"8,0.3354335129261017,-1.312678575515747],\"B\":[-3.9813032150268555,0.08"
"622030913829803,-0.3152860999107361]},\"delay\":3.783458418887631e-09,\"a"
"_lin\":0.27}}"
)

# Details for Gaussian decomposition of full waveform data
RDB_RIEGL_GAUSSIAN_DECOMPOSITION             = "riegl.gaussian_decomposition"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_TITLE       = "Gaussian Decomposition"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_DESCRIPTION = "Details for Gaussian decomposition of full waveform data"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_STATUS      = "optional"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_SCHEMA = (
"{\"title\":\"Gaussian Decomposition\",\"properties\":{\"range_offset_sec_high"
"_power\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplitude_lsb_high"
"_power\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"range_offset_sec_l"
"ow_power\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplitude_db\":{\""
"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplitude_lsb_low_power\":{\"t"
"ype\":\"array\",\"items\":{\"type\":\"number\"}}},\"$schema\":\"http://json-schema"
".org/draft-04/schema#\",\"type\":\"object\",\"description\":\"riegl.gaussian_d"
"ecomposition contains information relevant for extracting calibrated "
"amplitudes and calibrated ranges from a Gaussian decomposition of full"
" waveform data. This information is contained in a table with five "
"columns. Two columns are to be used as input: amplitude_lsb_low_power "
"and amplitude_lsb_high_power. The other three columns provide the "
"outputs. Amplitude_db gives the calibrated amplitude in the optical "
"regime in decibels. The range offset columns provide additive range "
"offsets, given in units of seconds, for each channel.\",\"required\":[\"am"
"plitude_lsb_low_power\",\"amplitude_lsb_high_power\",\"amplitude_db\",\"rang"
"e_offset_sec_low_power\",\"range_offset_sec_high_power\"]}"
)
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_EXAMPLE = (
"{\"range_offset_sec_high_power\":[],\"amplitude_lsb_high_power\":[],\"range"
"_offset_sec_low_power\":[],\"amplitude_db\":[],\"amplitude_lsb_low_power\":"
"[]}"
)

# Point cloud georeferencing information
RDB_RIEGL_GEO_TAG             = "riegl.geo_tag"
RDB_RIEGL_GEO_TAG_TITLE       = "Geo Tag"
RDB_RIEGL_GEO_TAG_DESCRIPTION = "Point cloud georeferencing information"
RDB_RIEGL_GEO_TAG_STATUS      = "optional"
RDB_RIEGL_GEO_TAG_SCHEMA = (
"{\"title\":\"Geo Tag\",\"properties\":{\"pose\":{\"maxItems\":4,\"type\":\"array\",\""
"minItems\":4,\"items\":{\"maxItems\":4,\"description\":\"rows\",\"type\":\"array\","
"\"items\":{\"description\":\"columns\",\"type\":\"number\"},\"minItems\":4},\"descr"
"iption\":\"Coordinate Transformation Matrix to transform from File "
"Coordinate System to Global Coordinate Reference System. 4x4 matrix "
"stored as two dimensional array, row major "
"order.\"},\"crs\":{\"properties\":{\"wkt\":{\"description\":\"\\\"Well-Known "
"Text\\\" string, OGC WKT dialect (see http://www.opengeospatial.org/stan"
"dards/wkt-crs)\",\"type\":\"string\"},\"epsg\":{\"minimum\":0,\"description\":\"EP"
"SG code\",\"type\":\"integer\"},\"name\":{\"description\":\"Coordinate reference"
" system name\",\"type\":\"string\"}},\"type\":\"object\",\"description\":\"Global "
"Coordinate Reference System. Please note that only 3D Cartesian "
"Coordinate Systems are allowed.\"}},\"$schema\":\"http://json-schema.org/d"
"raft-04/schema#\",\"description\":\"Point cloud georeferencing "
"information\",\"type\":\"object\"}"
)
RDB_RIEGL_GEO_TAG_EXAMPLE = (
"{\"pose\":[[-0.269827776749716,-0.723017716139738,0.635954678449952,4063"
"882.500831],[0.962908599449764,-0.20260517250352,0.178208229833847,113"
"8787.607461],[0.0,0.660451759194338,0.7508684796801,4766084.550196],[0"
".0,0.0,0.0,1.0]],\"crs\":{\"wkt\":\"GEOCCS[\\\"WGS84 Geocentric\\\",DATUM[\\\"WGS"
"84\\\",SPHEROID[\\\"WGS84\\\",6378137.000,298.257223563,AUTHORITY[\\\"EPSG\\\",\\"
"\"7030\\\"]],AUTHORITY[\\\"EPSG\\\",\\\"6326\\\"]],PRIMEM[\\\"Greenwich\\\",0.0000000"
"000000000,AUTHORITY[\\\"EPSG\\\",\\\"8901\\\"]],UNIT[\\\"Meter\\\",1.0000000000000"
"0000000,AUTHORITY[\\\"EPSG\\\",\\\"9001\\\"]],AXIS[\\\"X\\\",OTHER],AXIS[\\\"Y\\\",EAS"
"T],AXIS[\\\"Z\\\",NORTH],AUTHORITY[\\\"EPSG\\\",\\\"4978\\\"]]\",\"epsg\":4978,\"name\""
":\"WGS84 Geocentric\"}}"
)

# Geometric scale factor applied to point coordinates
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR             = "riegl.geometric_scale_factor"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_TITLE       = "Geometric Scale Factor"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_DESCRIPTION = "Geometric scale factor applied to point coordinates"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_STATUS      = "optional"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_SCHEMA = (
"{\"minimum\":0,\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"desc"
"ription\":\"Geometric scale factor applied to point "
"coordinates\",\"type\":\"number\",\"exclusiveMinimum\":true}"
)
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_EXAMPLE = (
"1.0"
)

# Parameters used for georeferencing of the point cloud
RDB_RIEGL_GEOREFERENCING_PARAMETERS             = "riegl.georeferencing_parameters"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_TITLE       = "Georeferencing Parameters"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_DESCRIPTION = "Parameters used for georeferencing of the point cloud"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_STATUS      = "optional"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_SCHEMA = (
"{\"title\":\"Georeferencing Parameters\",\"properties\":{\"trajectory_offsets"
"\":{\"properties\":{\"offset_height\":{\"type\":\"number\",\"description\":\"[m]\"}"
",\"version\":{\"type\":\"integer\",\"description\":\"Meaning of offset values "
"and how to apply them; version 0: "
"Rz(yaw+offset_yaw)*Ry(pitch+offset_pitch)*Rx(roll+offset_roll), "
"version 1: Rz(yaw)*Ry(pitch)*Rx(roll) * Rz(offset_yaw)*Ry(offset_pitch"
")*Rx(offset_roll)\"},\"offset_north\":{\"type\":\"number\",\"description\":\"[m]"
"\"},\"offset_time\":{\"type\":\"number\",\"description\":\"[s]\"},\"offset_pitch\":"
"{\"type\":\"number\",\"description\":\"[deg]\"},\"offset_roll\":{\"type\":\"number\""
",\"description\":\"[deg]\"},\"offset_east\":{\"type\":\"number\",\"description\":\""
"[m]\"},\"offset_yaw\":{\"type\":\"number\",\"description\":\"[deg]\"}},\"type\":\"ob"
"ject\",\"description\":\"Correction offsets applied to the trajectory data"
"\"},\"trajectory_file\":{\"properties\":{\"file_uuid\":{\"description\":\"File's"
" Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Trajectory "
"file extension, without the leading dot\",\"type\":\"string\"}},\"required\":"
"[\"file_extension\"],\"type\":\"object\",\"description\":\"Trajectory data used"
" for georeferencing of the point cloud\"},\"socs_to_rocs_matrix\":{\"maxIt"
"ems\":4,\"type\":\"array\",\"minItems\":4,\"items\":{\"maxItems\":4,\"description\""
":\"rows\",\"type\":\"array\",\"items\":{\"description\":\"columns\",\"type\":\"number"
"\"},\"minItems\":4},\"description\":\"Coordinate Transformation Matrix to "
"transform from Scanner's Own Coordinate System to Record Coordinate "
"System. 4x4 matrix stored as two dimensional array, row major order.\"}"
",\"body_coordinate_system_type\":{\"type\":\"string\",\"enum\":[\"NED\",\"ENU\"],\""
"description\":\"BODY coordinate frame (NED: North-East-Down, ENU: "
"East-North-Up), default: NED\"},\"socs_to_body_matrix\":{\"maxItems\":4,\"ty"
"pe\":\"array\",\"minItems\":4,\"items\":{\"maxItems\":4,\"description\":\"rows\",\"t"
"ype\":\"array\",\"items\":{\"description\":\"columns\",\"type\":\"number\"},\"minIte"
"ms\":4},\"description\":\"Coordinate Transformation Matrix to transform "
"from Scanner's Own Coordinate System to Body Coordinate System. 4x4 "
"matrix stored as two dimensional array, row major order.\"}},\"$schema\":"
"\"http://json-schema.org/draft-04/schema#\",\"description\":\"Parameters "
"used for georeferencing of the point cloud\",\"type\":\"object\"}"
)
RDB_RIEGL_GEOREFERENCING_PARAMETERS_EXAMPLE = (
"{\"trajectory_offsets\":{\"offset_height\":-0.2,\"version\":0,\"offset_north\""
":0.07,\"offset_time\":18.007,\"offset_pitch\":0.01,\"offset_roll\":0.03,\"off"
"set_east\":0.15,\"offset_yaw\":-0.45},\"trajectory_file\":{\"file_uuid\":\"93a"
"03615-66c0-4bea-8ff8-c577378fe660\",\"file_extension\":\"pofx\"},\"body_coor"
"dinate_system_type\":\"NED\",\"socs_to_body_matrix\":[[-0.269827776749716,-"
"0.723017716139738,0.635954678449952,0.0],[0.962908599449764,-0.2026051"
"7250352,0.178208229833847,0.0],[0.0,0.660451759194338,0.7508684796801,"
"0.0],[0.0,0.0,0.0,1.0]]}"
)

# Map of item names
RDB_RIEGL_ITEM_NAMES             = "riegl.item_names"
RDB_RIEGL_ITEM_NAMES_TITLE       = "Item Names"
RDB_RIEGL_ITEM_NAMES_DESCRIPTION = "Map of item names"
RDB_RIEGL_ITEM_NAMES_STATUS      = "optional"
RDB_RIEGL_ITEM_NAMES_SCHEMA = (
"{\"title\":\"Item Names\",\"$schema\":\"http://json-schema.org/draft-04/schem"
"a#\",\"type\":\"object\",\"patternProperties\":{\"^-?[0-9]+$\":{\"description\":\""
"One field per item, field name is item id, field value is item "
"name\",\"type\":\"string\"}},\"description\":\"Map of item "
"names\",\"additionalProperties\":false}"
)
RDB_RIEGL_ITEM_NAMES_EXAMPLE = (
"{\"-1\":\"Name of item with id -1\",\"1\":\"Name of item with id "
"1\",\"47\":\"Name of item with id 47\",\"2\":\"Name of item with id 2\"}"
)

# License keys for software features
RDB_RIEGL_LICENSES             = "riegl.licenses"
RDB_RIEGL_LICENSES_TITLE       = "Software License Keys"
RDB_RIEGL_LICENSES_DESCRIPTION = "License keys for software features"
RDB_RIEGL_LICENSES_STATUS      = "optional"
RDB_RIEGL_LICENSES_SCHEMA = (
"{\"title\":\"Software License Keys\",\"$schema\":\"http://json-schema.org/dra"
"ft-04/schema#\",\"type\":\"object\",\"patternProperties\":{\"^.*$\":{\"minItems\""
":1,\"description\":\"Each field of the object represents a feature and "
"holds a list of license keys, where the field name is the feature "
"name.\",\"type\":\"array\",\"items\":{\"description\":\"License key (example: "
"'46AE032A - 39882AC4 - 9EC0A184 - "
"6F163D73')\",\"type\":\"string\"}}},\"description\":\"License keys for "
"software features\",\"additionalProperties\":false}"
)
RDB_RIEGL_LICENSES_EXAMPLE = (
"{\"MTA resolution\":[\"468E020A - 39A922E4 - B681A184 - "
"673E3D72\"],\"Georeferencing\":[\"46AE032A - 39882AC4 - 9EC0A184 - "
"6F163D73\"],\"Full Waveform Analysis Topography with GPU "
"support\":[\"8AB44126 - 23B92250 - 16E2689F - 34EF7E7B\"],\"Full Waveform "
"Analysis Topography\":[\"0FD5FF07 - 011A1255 - 9F76CACA - 8D2ED557\"]}"
)

# Parameters for MTA processing
RDB_RIEGL_MTA_SETTINGS             = "riegl.mta_settings"
RDB_RIEGL_MTA_SETTINGS_TITLE       = "MTA Settings"
RDB_RIEGL_MTA_SETTINGS_DESCRIPTION = "Parameters for MTA processing"
RDB_RIEGL_MTA_SETTINGS_STATUS      = "optional"
RDB_RIEGL_MTA_SETTINGS_SCHEMA = (
"{\"title\":\"MTA Settings\",\"properties\":{\"modulation_depth\":{\"minimum\":0,"
"\"type\":\"number\",\"description\":\"Depth of pulse position modulation in m"
"eter.\"},\"zone_width\":{\"minimum\":0,\"type\":\"number\",\"description\":\"Width"
" of a MTA zone in meter.\"},\"zone_count\":{\"minimum\":0,\"type\":\"integer\","
"\"description\":\"Maximum number of MTA zones.\",\"maximum\":255}},\"$schema\""
":\"http://json-schema.org/draft-04/schema#\",\"description\":\"Parameters "
"for MTA processing\",\"type\":\"object\"}"
)
RDB_RIEGL_MTA_SETTINGS_EXAMPLE = (
"{\"modulation_depth\":9.368514,\"zone_width\":149.896225,\"zone_count\":23}"
)

# Lookup table for range correction based on raw range
RDB_RIEGL_NEAR_RANGE_CORRECTION             = "riegl.near_range_correction"
RDB_RIEGL_NEAR_RANGE_CORRECTION_TITLE       = "Near Range Correction Table"
RDB_RIEGL_NEAR_RANGE_CORRECTION_DESCRIPTION = "Lookup table for range correction based on raw range"
RDB_RIEGL_NEAR_RANGE_CORRECTION_STATUS      = "optional"
RDB_RIEGL_NEAR_RANGE_CORRECTION_SCHEMA = (
"{\"title\":\"Near Range Correction "
"Table\",\"properties\":{\"delta\":{\"description\":\"Delta between table "
"entries [m], first entry is at range = 0 "
"m\",\"type\":\"number\"},\"content\":{\"minItems\":1,\"description\":\"Correction "
"value [m] to be added to the raw range\",\"type\":\"array\",\"items\":{\"type\""
":\"number\"},\"maxItems\":2000}},\"$schema\":\"http://json-schema.org/draft-0"
"4/schema#\",\"type\":\"object\",\"description\":\"Lookup table for range "
"correction based on raw range\",\"required\":[\"delta\",\"content\"]}"
)
RDB_RIEGL_NEAR_RANGE_CORRECTION_EXAMPLE = (
"{\"delta\":0.512,\"content\":[0.0]}"
)

# Standard deviation for range and amplitude as a function of amplitude
RDB_RIEGL_NOISE_ESTIMATES             = "riegl.noise_estimates"
RDB_RIEGL_NOISE_ESTIMATES_TITLE       = "Noise Estimates"
RDB_RIEGL_NOISE_ESTIMATES_DESCRIPTION = "Standard deviation for range and amplitude as a function of amplitude"
RDB_RIEGL_NOISE_ESTIMATES_STATUS      = "optional"
RDB_RIEGL_NOISE_ESTIMATES_SCHEMA = (
"{\"title\":\"Noise Estimates\",\"properties\":{\"amplitude\":{\"type\":\"array\",\""
"items\":{\"type\":\"number\"},\"description\":\"Amplitude [dB]\"},\"range_sigma\""
":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"description\":\"Sigma range "
"[m]\"},\"amplitude_sigma\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"des"
"cription\":\"Sigma amplitude [dB]\"}},\"$schema\":\"http://json-schema.org/d"
"raft-04/schema#\",\"type\":\"object\",\"description\":\"Standard deviation for"
" range and amplitude as a function of "
"amplitude\",\"required\":[\"amplitude\",\"range_sigma\",\"amplitude_sigma\"]}"
)
RDB_RIEGL_NOISE_ESTIMATES_EXAMPLE = (
"{\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0],\"range_sig"
"ma\":[0.065,0.056,0.046,0.038,0.032,0.027,0.024,0.021,0.018,0.016,0.014"
"],\"amplitude_sigma\":[0.988,0.988,0.875,0.774,0.686,0.608,0.54,0.482,0."
"432,0.39,0.354]}"
)

# Notch filter parameters for window glass echoes
RDB_RIEGL_NOTCH_FILTER             = "riegl.notch_filter"
RDB_RIEGL_NOTCH_FILTER_TITLE       = "Notch Filter"
RDB_RIEGL_NOTCH_FILTER_DESCRIPTION = "Notch filter parameters for window glass echoes"
RDB_RIEGL_NOTCH_FILTER_STATUS      = "optional"
RDB_RIEGL_NOTCH_FILTER_SCHEMA = (
"{\"title\":\"Notch Filter\",\"properties\":{\"range_maximum\":{\"type\":\"number\""
",\"description\":\"Maximum range "
"[m]\"},\"range_minimum\":{\"type\":\"number\",\"description\":\"Minimum range [m"
"]\"},\"amplitude_maximum\":{\"minimum\":0,\"type\":\"number\",\"description\":\"Ma"
"ximum amplitude [dB]\"}},\"$schema\":\"http://json-schema.org/draft-04/sch"
"ema#\",\"type\":\"object\",\"description\":\"Notch filter parameters for "
"window glass echoes\",\"required\":[\"range_minimum\",\"range_maximum\",\"ampl"
"itude_maximum\"]}"
)
RDB_RIEGL_NOTCH_FILTER_EXAMPLE = (
"{\"range_maximum\":0.2,\"range_minimum\":-0.5,\"amplitude_maximum\":18.0}"
)

# Details about the pixels contained in the file
RDB_RIEGL_PIXEL_INFO             = "riegl.pixel_info"
RDB_RIEGL_PIXEL_INFO_TITLE       = "Pixel Information"
RDB_RIEGL_PIXEL_INFO_DESCRIPTION = "Details about the pixels contained in the file"
RDB_RIEGL_PIXEL_INFO_STATUS      = "optional"
RDB_RIEGL_PIXEL_INFO_SCHEMA = (
"{\"title\":\"Pixel Information\",\"properties\":{\"size\":{\"$ref\":\"#/definitio"
"ns/pixel_size\",\"description\":\"Size of pixels in file coordinate system"
".\"},\"size_llcs\":{\"$ref\":\"#/definitions/pixel_size\",\"description\":\"Size"
" of pixels in a locally levelled cartesian coordinate system (xy). "
"This is only used for pixels based on a map projection.\"}},\"$schema\":\""
"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\"definitions\""
":{\"pixel_size\":{\"maxItems\":2,\"type\":\"array\",\"minItems\":2,\"items\":{\"min"
"imum\":0,\"type\":\"number\",\"description\":\"Length of pixel edge "
"[m].\"},\"description\":\"Size of pixels.\"}},\"description\":\"Details about "
"the pixels contained in the file\",\"required\":[\"size\"]}"
)
RDB_RIEGL_PIXEL_INFO_EXAMPLE = (
"{\"size\":[0.5971642834779395,0.5971642834779395],\"size_llcs\":[0.5156575"
"252891171,0.5130835356683303]}"
)

# Details about the plane patch matching process
RDB_RIEGL_PLANE_PATCH_MATCHING             = "riegl.plane_patch_matching"
RDB_RIEGL_PLANE_PATCH_MATCHING_TITLE       = "Plane Patch Matching"
RDB_RIEGL_PLANE_PATCH_MATCHING_DESCRIPTION = "Details about the plane patch matching process"
RDB_RIEGL_PLANE_PATCH_MATCHING_STATUS      = "optional"
RDB_RIEGL_PLANE_PATCH_MATCHING_SCHEMA = (
"{\"title\":\"Plane Patch Matching\",\"properties\":{\"plane_patch_file_one\":{"
"\"$ref\":\"#/definitions/file_reference\",\"description\":\"Reference to the "
"plane patch file one\"},\"plane_patch_file_two\":{\"$ref\":\"#/definitions/f"
"ile_reference\",\"description\":\"Reference to the plane patch file two\"}}"
",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
"definitions\":{\"file_reference\":{\"properties\":{\"file_uuid\":{\"descriptio"
"n\":\"Plane patch file's Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_path\":{\"description\":\"Path of the plane "
"patch file relative to the match file\",\"type\":\"string\"}},\"required\":[\""
"file_uuid\",\"file_path\"],\"type\":\"object\",\"description\":\"Reference to a "
"plane patch file\"}},\"description\":\"Details about the plane patch "
"matching "
"process\",\"required\":[\"plane_patch_file_one\",\"plane_patch_file_two\"]}"
)
RDB_RIEGL_PLANE_PATCH_MATCHING_EXAMPLE = (
"{\"plane_patch_file_one\":{\"file_uuid\":\"810f5d57-eccf-49ed-b07a-0cdd109b"
"4213\",\"file_path\":\"Record009_Line001/191025_121410_Scanner_1.ptch\"},\"p"
"lane_patch_file_two\":{\"file_uuid\":\"fa47d509-a64e-49ce-8b14-ff3130fbefa"
"9\",\"file_path\":\"project.ptch\"}}"
)

# Statistics about plane patches found by plane patch extractor
RDB_RIEGL_PLANE_PATCH_STATISTICS             = "riegl.plane_patch_statistics"
RDB_RIEGL_PLANE_PATCH_STATISTICS_TITLE       = "Plane Patch Statistics"
RDB_RIEGL_PLANE_PATCH_STATISTICS_DESCRIPTION = "Statistics about plane patches found by plane patch extractor"
RDB_RIEGL_PLANE_PATCH_STATISTICS_STATUS      = "optional"
RDB_RIEGL_PLANE_PATCH_STATISTICS_SCHEMA = (
"{\"title\":\"Plane Patch Statistics\",\"properties\":{\"total_horizontal_area"
"\":{\"type\":\"number\",\"description\":\"sum of all plane patch areas "
"projected to horizontal plane "
"[m\\u00b2]\"},\"total_area\":{\"type\":\"number\",\"description\":\"sum of all "
"plane patch areas [m\\u00b2]\"}},\"$schema\":\"http://json-schema.org/draft"
"-04/schema#\",\"description\":\"Statistics about plane patches found by "
"plane patch extractor\",\"type\":\"object\"}"
)
RDB_RIEGL_PLANE_PATCH_STATISTICS_EXAMPLE = (
"{\"total_horizontal_area\":13954.601,\"total_area\":14007.965}"
)

# Settings and classes for plane slope classification
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO             = "riegl.plane_slope_class_info"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_TITLE       = "Plane Slope Class Info"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_DESCRIPTION = "Settings and classes for plane slope classification"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_STATUS      = "optional"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_SCHEMA = (
"{\"title\":\"Plane Slope Class Info\",\"properties\":{\"classes\":{\"type\":\"obj"
"ect\",\"patternProperties\":{\"^[0-9]+$\":{\"description\":\"one field per "
"class, field name is class number, field value is class "
"name\",\"type\":\"string\"}},\"description\":\"Class definition table\",\"additi"
"onalProperties\":false},\"settings\":{\"oneOf\":[{\"$ref\":\"#/definitions/met"
"hod-1\"},{\"$ref\":\"#/definitions/method-2\"}],\"type\":\"object\",\"descriptio"
"n\":\"Classification settings, details see documentation of rdbplanes\"}}"
",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
"definitions\":{\"method-1\":{\"properties\":{\"maximum_inclination_angle_hor"
"izontal\":{\"minimum\":-360.0,\"type\":\"number\",\"description\":\"maximum "
"inclination angle of horizontal plane patches [deg]\",\"maximum\":360.0},"
"\"plane_classification_method\":{\"minimum\":1,\"type\":\"integer\",\"descripti"
"on\":\"method ID (=1)\",\"maximum\":1}},\"required\":[\"plane_classification_m"
"ethod\",\"maximum_inclination_angle_horizontal\"],\"type\":\"object\",\"descri"
"ption\":\"Classification method 1\"},\"method-2\":{\"properties\":{\"sloping_p"
"lane_classes_minimum_angle\":{\"minimum\":-360.0,\"type\":\"number\",\"descrip"
"tion\":\"minimum inclination angle of sloping plane patches [deg]\",\"maxi"
"mum\":360.0},\"sloping_plane_classes_maximum_angle\":{\"minimum\":-360.0,\"t"
"ype\":\"number\",\"description\":\"maximum inclination angle of sloping "
"plane patches [deg]\",\"maximum\":360.0},\"plane_classification_method\":{\""
"minimum\":2,\"type\":\"integer\",\"description\":\"method ID (=2)\",\"maximum\":2"
"}},\"required\":[\"plane_classification_method\",\"sloping_plane_classes_mi"
"nimum_angle\",\"sloping_plane_classes_maximum_angle\"],\"type\":\"object\",\"d"
"escription\":\"Classification method 2\"}},\"description\":\"Settings and "
"classes for plane slope "
"classification\",\"required\":[\"settings\",\"classes\"]}"
)
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_EXAMPLE = (
"{\"classes\":{\"11\":\"sloping, pointing down and south\",\"6\":\"vertical, "
"pointing east\",\"7\":\"vertical, pointing south\",\"3\":\"sloping, pointing "
"up and south\",\"1\":\"horizontal, pointing up\",\"8\":\"vertical, pointing "
"north\",\"9\":\"vertical, pointing west\",\"14\":\"horizontal, pointing "
"down\",\"2\":\"sloping, pointing up and east\",\"13\":\"sloping, pointing down"
" and west\",\"4\":\"sloping, pointing up and north\",\"12\":\"sloping, "
"pointing down and north\",\"5\":\"sloping, pointing up and "
"west\",\"10\":\"sloping, pointing down and east\"},\"settings\":{\"sloping_pla"
"ne_classes_minimum_angle\":10.0,\"sloping_plane_classes_maximum_angle\":7"
"0.0,\"plane_classification_method\":2}}"
)

# Grouping and sorting of point attributes for visualization purposes
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS             = "riegl.point_attribute_groups"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_TITLE       = "Point Attribute Groups"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_DESCRIPTION = "Grouping and sorting of point attributes for visualization purposes"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_STATUS      = "optional"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_SCHEMA = (
"{\"title\":\"Point Attribute Groups\",\"$schema\":\"http://json-schema.org/dr"
"aft-04/schema#\",\"type\":\"object\",\"patternProperties\":{\"^.*$\":{\"minItems"
"\":1,\"description\":\"Each field of the object represents a point "
"attribute group and holds a list of point attributes, where the field "
"name is the group name.\",\"type\":\"array\",\"items\":{\"description\":\"Point "
"attribute full name or name pattern (perl regular expression "
"syntax)\",\"type\":\"string\"}}},\"description\":\"Grouping and sorting of "
"point attributes for visualization "
"purposes\",\"additionalProperties\":false}"
)
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_EXAMPLE = (
"{\"Coordinates/Vectors\":[\"riegl.xyz\",\"riegl.range\",\"riegl.theta\",\"riegl"
".phi\"],\"Time\":[\"riegl.timestamp\"],\"Other "
"Attributes\":[\"riegl.selected\",\"riegl.visible\"],\"Primary Attributes\":[\""
"riegl.reflectance\",\"riegl.amplitude\",\"riegl.deviation\"],\"Secondary "
"Attributes\":[\"riegl.mirror_facet\",\"riegl.waveform_available\"]}"
)

# Details about point cloud files
RDB_RIEGL_POINTCLOUD_INFO             = "riegl.pointcloud_info"
RDB_RIEGL_POINTCLOUD_INFO_TITLE       = "Point Cloud Information"
RDB_RIEGL_POINTCLOUD_INFO_DESCRIPTION = "Details about point cloud files"
RDB_RIEGL_POINTCLOUD_INFO_STATUS      = "optional"
RDB_RIEGL_POINTCLOUD_INFO_SCHEMA = (
"{\"title\":\"Point Cloud Information\",\"properties\":{\"comments\":{\"descript"
"ion\":\"Comments\",\"type\":\"string\"},\"field_of_application\":{\"enum\":[\"unkn"
"own\",\"SLS\",\"TLS\",\"KLS\",\"MLS\",\"ULS\",\"ALS\",\"BLS\",\"ILS\"],\"description\":\"F"
"ield of "
"application\",\"type\":\"string\"},\"project\":{\"description\":\"Project name\","
"\"type\":\"string\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\","
"\"description\":\"Details about point cloud files\",\"type\":\"object\"}"
)
RDB_RIEGL_POINTCLOUD_INFO_EXAMPLE = (
"{\"comments\":\"Line 3\",\"field_of_application\":\"ALS\",\"project\":\"Campaign "
"4\"}"
)

# Estimated position and orientation information
RDB_RIEGL_POSE_ESTIMATION             = "riegl.pose_estimation"
RDB_RIEGL_POSE_ESTIMATION_TITLE       = "Pose Estimation"
RDB_RIEGL_POSE_ESTIMATION_DESCRIPTION = "Estimated position and orientation information"
RDB_RIEGL_POSE_ESTIMATION_STATUS      = "optional"
RDB_RIEGL_POSE_ESTIMATION_SCHEMA = (
"{\"title\":\"Pose Estimation\",\"properties\":{\"position\":{\"properties\":{\"co"
"ordinate_2\":{\"description\":\"Coordinate 2 as defined by axis 2 of the "
"specified CRS (e.g., Y, Longitude)\",\"type\":\"number\"},\"crs\":{\"propertie"
"s\":{\"wkt\":{\"description\":\"\\\"Well-Known Text\\\" string, OGC WKT dialect "
"(see http://www.opengeospatial.org/standards/wkt-crs)\",\"type\":\"string\""
"},\"epsg\":{\"minimum\":0,\"description\":\"EPSG code\",\"type\":\"integer\"}},\"re"
"quired\":[\"epsg\"],\"type\":\"object\",\"description\":\"Global Coordinate "
"Reference "
"System\"},\"vertical_accuracy\":{\"minimum\":0,\"description\":\"Vertical "
"accuracy [m]\",\"type\":\"number\",\"exclusiveMinimum\":true},\"coordinate_1\":"
"{\"description\":\"Coordinate 1 as defined by axis 1 of the specified CRS"
" (e.g., X, Latitude)\",\"type\":\"number\"},\"horizontal_accuracy\":{\"minimum"
"\":0,\"description\":\"Horizontal accuracy [m]\",\"type\":\"number\",\"exclusive"
"Minimum\":true},\"coordinate_3\":{\"description\":\"Coordinate 3 as defined "
"by axis 3 of the specified CRS (e.g., Z, Altitude)\",\"type\":\"number\"}},"
"\"required\":[\"coordinate_1\",\"coordinate_2\",\"coordinate_3\",\"horizontal_a"
"ccuracy\",\"vertical_accuracy\",\"crs\"],\"description\":\"Position "
"coordinates and position accuracy values as measured by GNSS in the "
"specified Coordinate Reference System (CRS)\",\"type\":\"object\"},\"orienta"
"tion\":{\"properties\":{\"pitch\":{\"minimum\":-360,\"description\":\"Pitch "
"angle about scanner Y-axis [deg]\",\"type\":\"number\",\"maximum\":360},\"pitc"
"h_accuracy\":{\"minimum\":0,\"description\":\"Pitch angle accuracy [deg]\",\"t"
"ype\":\"number\",\"exclusiveMinimum\":true},\"yaw\":{\"minimum\":-360,\"descript"
"ion\":\"Yaw angle about scanner Z-axis [deg]\",\"type\":\"number\",\"maximum\":"
"360},\"roll_accuracy\":{\"minimum\":0,\"description\":\"Roll angle accuracy ["
"deg]\",\"type\":\"number\",\"exclusiveMinimum\":true},\"roll\":{\"minimum\":-360,"
"\"description\":\"Roll angle about scanner X-axis [deg]\",\"type\":\"number\","
"\"maximum\":360},\"yaw_accuracy\":{\"minimum\":0,\"description\":\"Yaw angle "
"accuracy [deg]\",\"type\":\"number\",\"exclusiveMinimum\":true}},\"required\":["
"\"roll\",\"pitch\",\"yaw\",\"roll_accuracy\",\"pitch_accuracy\",\"yaw_accuracy\"],"
"\"description\":\"Orientation values and orientation accuracies, measured"
" with IMU or inclination sensors.\",\"type\":\"object\"},\"barometric_height"
"_amsl\":{\"description\":\"Altitude determined based on the atmospheric "
"pressure according to the standard atmosphere laws [m].\",\"type\":\"numbe"
"r\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"objec"
"t\",\"description\":\"Estimated position and orientation information as "
"measured by GNSS, IMU or inclination "
"sensors\",\"required\":[\"orientation\"]}"
)
RDB_RIEGL_POSE_ESTIMATION_EXAMPLE = (
"{\"position\":{\"coordinate_2\":15.645033406,\"crs\":{\"wkt\":\"GEOGCS[\\\"WGS84 "
"/ Geographic\\\",DATUM[\\\"WGS84\\\",SPHEROID[\\\"WGS84\\\",6378137.000,298.2572"
"23563,AUTHORITY[\\\"EPSG\\\",\\\"7030\\\"]],AUTHORITY[\\\"EPSG\\\",\\\"6326\\\"]],PRIM"
"EM[\\\"Greenwich\\\",0.0000000000000000,AUTHORITY[\\\"EPSG\\\",\\\"8901\\\"]],UNIT"
"[\\\"Degree\\\",0.01745329251994329547,AUTHORITY[\\\"EPSG\\\",\\\"9102\\\"]],AXIS["
"\\\"Latitude\\\",NORTH],AXIS[\\\"Longitude\\\",EAST],AUTHORITY[\\\"EPSG\\\",\\\"4979"
"\\\"]]\",\"epsg\":4979},\"vertical_accuracy\":1.3314999341964722,\"coordinate_"
"1\":48.655799473,\"horizontal_accuracy\":0.810699999332428,\"coordinate_3\""
":362.7124938964844},\"orientation\":{\"pitch\":1.509153024827064,\"pitch_ac"
"curacy\":0.009433783936875745,\"yaw\":101.87293630292045,\"roll_accuracy\":"
"0.009433783936875745,\"roll\":3.14743073066123,\"yaw_accuracy\":1.00943378"
"39368757},\"barometric_height_amsl\":386.7457796227932}"
)

# Details on position and orientation sensors
RDB_RIEGL_POSE_SENSORS             = "riegl.pose_sensors"
RDB_RIEGL_POSE_SENSORS_TITLE       = "Pose Sensors"
RDB_RIEGL_POSE_SENSORS_DESCRIPTION = "Details on position and orientation sensors"
RDB_RIEGL_POSE_SENSORS_STATUS      = "optional"
RDB_RIEGL_POSE_SENSORS_SCHEMA = (
"{\"title\":\"Pose Sensors\",\"properties\":{\"accelerometer\":{\"properties\":{\""
"origin\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Sensor origin in"
" SOCS [m] at frame angle = "
"0\"},\"z_axis\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Sensitive Z"
" axis of sensor at frame angle = 0\"},\"relative_nonlinearity\":{\"$ref\":\""
"#/definitions/vector\",\"description\":\"Relative nonlinearity, dimensionl"
"ess\"},\"unit\":{\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\":true,\"des"
"cription\":\"Unit of raw data and calibration values, 1 LSB in 9.81 m/s\\"
"u00b2\"},\"offset\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Value "
"to be subtracted from raw measurement values\"},\"x_axis\":{\"$ref\":\"#/def"
"initions/vector\",\"description\":\"Sensitive X axis of sensor at frame "
"angle = "
"0\"},\"y_axis\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Sensitive Y"
" axis of sensor at frame angle = 0\"}},\"required\":[\"unit\",\"x_axis\",\"y_a"
"xis\",\"z_axis\",\"offset\",\"origin\",\"relative_nonlinearity\"],\"type\":\"objec"
"t\",\"description\":\"Accelerometer details\"},\"gyroscope\":{\"properties\":{\""
"origin\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Sensor origin in"
" SOCS [m] at frame angle = "
"0\"},\"z_axis\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Sensitive Z"
" axis of sensor at frame angle = 0\"},\"relative_nonlinearity\":{\"$ref\":\""
"#/definitions/vector\",\"description\":\"Relative nonlinearity, dimensionl"
"ess\"},\"unit\":{\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\":true,\"des"
"cription\":\"Unit of raw data and calibration values, 1 LSB in "
"rad/s\"},\"offset\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Value "
"to be subtracted from raw measurement values\"},\"x_axis\":{\"$ref\":\"#/def"
"initions/vector\",\"description\":\"Sensitive X axis of sensor at frame "
"angle = "
"0\"},\"y_axis\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Sensitive Y"
" axis of sensor at frame angle = 0\"}},\"required\":[\"unit\",\"x_axis\",\"y_a"
"xis\",\"z_axis\",\"offset\",\"origin\",\"relative_nonlinearity\"],\"type\":\"objec"
"t\",\"description\":\"Gyroscope details\"},\"magnetic_field_sensor\":{\"proper"
"ties\":{\"z_axis\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Sensitiv"
"e Z axis of sensor at frame angle = 0\"},\"relative_nonlinearity\":{\"$ref"
"\":\"#/definitions/vector\",\"description\":\"Relative nonlinearity, dimensi"
"onless\"},\"fixed\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Distort"
"ion of magnetic field caused by non-rotating scanner part\"},\"unit\":{\"m"
"inimum\":0,\"type\":\"number\",\"exclusiveMinimum\":true,\"description\":\"Unit "
"of raw data and calibration values, 1 LSB in "
"nT\"},\"offset\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Value to "
"be subtracted from raw measurement values\"},\"x_axis\":{\"$ref\":\"#/defini"
"tions/vector\",\"description\":\"Sensitive X axis of sensor at frame angle"
" = "
"0\"},\"y_axis\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Sensitive Y"
" axis of sensor at frame angle = 0\"}},\"required\":[\"unit\",\"x_axis\",\"y_a"
"xis\",\"z_axis\",\"offset\",\"fixed\",\"relative_nonlinearity\"],\"type\":\"object"
"\",\"description\":\"Magnetic Field Sensor details\"}},\"$schema\":\"http://js"
"on-schema.org/draft-04/schema#\",\"type\":\"object\",\"definitions\":{\"vector"
"\":{\"minItems\":3,\"type\":\"array\",\"items\":{\"type\":\"number\",\"description\":"
"\"Index 0=X, 1=Y, 2=Z component\"},\"maxItems\":3}},\"description\":\"Details"
" on position and orientation sensors\",\"required\":[\"gyroscope\",\"acceler"
"ometer\",\"magnetic_field_sensor\"]}"
)
RDB_RIEGL_POSE_SENSORS_EXAMPLE = (
"{\"accelerometer\":{\"origin\":[0.026900000870227814,-0.03999999910593033,"
"-0.08950000256299973],\"z_axis\":[1.639882206916809,15166.744140625,-116"
".99742889404297],\"relative_nonlinearity\":[0.0,0.0,0.0],\"unit\":6.666666"
"740784422e-05,\"offset\":[-733.3636474609375,58.969032287597656,1060.255"
"0048828125],\"x_axis\":[-15008.123046875,56.956390380859375,-60.51756668"
"09082],\"y_axis\":[-7.027288913726807,-44.12333679199219,14952.370117187"
"5]},\"gyroscope\":{\"origin\":[0.026900000870227814,-0.03999999910593033,-"
"0.08950000256299973],\"z_axis\":[0.555869996547699,119.22135162353516,0."
"467585027217865],\"relative_nonlinearity\":[2.888176311444113e-07,1.0627"
"4164579645e-07,-1.7186295080634935e-39],\"unit\":0.00014544410805683583,"
"\"offset\":[-50.92609786987305,146.15643310546875,62.4327278137207],\"x_a"
"xis\":[-121.195556640625,0.8219714164733887,0.2313031703233719],\"y_axis"
"\":[-0.440765917301178,-0.7897399663925171,119.5894775390625]},\"magneti"
"c_field_sensor\":{\"z_axis\":[0.00041987866279669106,7.876977906562388e-0"
"5,0.011407104320824146],\"relative_nonlinearity\":[0.0,0.0,0.0],\"fixed\":"
"[-1576.010498046875,1596.081787109375,0.0],\"unit\":91.74311828613281,\"o"
"ffset\":[-23812.052734375,5606.57666015625,2493.28125],\"x_axis\":[-0.011"
"162743903696537,-2.315962774446234e-05,0.00016818844596855342],\"y_axis"
"\":[0.00027888521435670555,-0.011427424848079681,-5.204829722060822e-05"
"]}}"
)

# Laser pulse position modulation used for MTA resolution
RDB_RIEGL_PULSE_POSITION_MODULATION             = "riegl.pulse_position_modulation"
RDB_RIEGL_PULSE_POSITION_MODULATION_TITLE       = "Pulse Position Modulation"
RDB_RIEGL_PULSE_POSITION_MODULATION_DESCRIPTION = "Laser pulse position modulation used for MTA resolution"
RDB_RIEGL_PULSE_POSITION_MODULATION_STATUS      = "optional"
RDB_RIEGL_PULSE_POSITION_MODULATION_SCHEMA = (
"{\"title\":\"Pulse Position Modulation\",\"properties\":{\"pulse_interval\":{\""
"type\":\"array\",\"items\":{\"minimum\":0,\"type\":\"number\"},\"description\":\"Exp"
"licit table of the pulse position modulation used for MTA resolution. "
"Table gives times between successive laser pulses in seconds.\"},\"lengt"
"h\":{\"minimum\":0,\"type\":\"integer\",\"description\":\"Length of code\",\"maxim"
"um\":255},\"code_phase_mode\":{\"minimum\":0,\"type\":\"integer\",\"description\""
":\"0: no synchronization, 1: toggle between 2 phases, 2: increment with"
" phase_increment\",\"maximum\":255},\"num_mod_ampl\":{\"minimum\":0,\"type\":\"i"
"nteger\",\"description\":\"Number of different modulation amplitudes (2: "
"binary modulation)\",\"maximum\":255},\"phase_step\":{\"minimum\":0,\"type\":\"i"
"nteger\",\"description\":\"Step width in phase of modulation code from "
"line to line\",\"maximum\":255}},\"$schema\":\"http://json-schema.org/draft-"
"04/schema#\",\"type\":\"object\",\"description\":\"Laser pulse position "
"modulation used for MTA "
"resolution\",\"required\":[\"length\",\"num_mod_ampl\",\"pulse_interval\"]}"
)
RDB_RIEGL_PULSE_POSITION_MODULATION_EXAMPLE = (
"{\"pulse_interval\":[2.759375e-06,2.759375e-06,2.759375e-06,2.759375e-06"
",2.821875e-06,2.759375e-06,2.759375e-06,2.821875e-06,2.759375e-06,2.82"
"1875e-06,2.821875e-06,2.759375e-06,2.759375e-06,2.821875e-06,2.821875e"
"-06,2.821875e-06,2.821875e-06,2.821875e-06,2.759375e-06,2.759375e-06,2"
".759375e-06,2.821875e-06,2.821875e-06,2.759375e-06,2.821875e-06,2.8218"
"75e-06,2.821875e-06,2.759375e-06,2.821875e-06,2.759375e-06,2.821875e-0"
"6],\"length\":31,\"code_phase_mode\":2,\"num_mod_ampl\":2,\"phase_step\":5}"
)

# Statistics about target distance wrt. SOCS origin
RDB_RIEGL_RANGE_STATISTICS             = "riegl.range_statistics"
RDB_RIEGL_RANGE_STATISTICS_TITLE       = "Range Statistics"
RDB_RIEGL_RANGE_STATISTICS_DESCRIPTION = "Statistics about target distance wrt. SOCS origin"
RDB_RIEGL_RANGE_STATISTICS_STATUS      = "optional"
RDB_RIEGL_RANGE_STATISTICS_SCHEMA = (
"{\"title\":\"Range Statistics\",\"properties\":{\"minimum\":{\"type\":\"number\",\""
"description\":\"Minimum "
"value\"},\"average\":{\"type\":\"number\",\"description\":\"Average "
"value\"},\"std_dev\":{\"type\":\"number\",\"description\":\"Standard "
"deviation\"},\"maximum\":{\"type\":\"number\",\"description\":\"Maximum value\"}}"
",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
"description\":\"Statistics about target distance wrt. SOCS "
"origin\",\"required\":[\"minimum\",\"average\",\"maximum\",\"std_dev\"]}"
)
RDB_RIEGL_RANGE_STATISTICS_EXAMPLE = (
"{\"minimum\":0.919,\"average\":15.49738,\"std_dev\":24.349,\"maximum\":574.35}"
)

# Receiver Internals
RDB_RIEGL_RECEIVER_INTERNALS             = "riegl.receiver_internals"
RDB_RIEGL_RECEIVER_INTERNALS_TITLE       = "Receiver Internals"
RDB_RIEGL_RECEIVER_INTERNALS_DESCRIPTION = "Receiver Internals"
RDB_RIEGL_RECEIVER_INTERNALS_STATUS      = "optional"
RDB_RIEGL_RECEIVER_INTERNALS_SCHEMA = (
"{\"title\":\"Receiver Internals\",\"properties\":{\"ns\":{\"minimum\":0,\"type\":\""
"integer\",\"description\":\"Number of "
"samples\",\"maximum\":4095},\"a\":{\"description\":\"Amplitude [dB]\",\"minItems"
"\":1,\"type\":\"array\",\"items\":{\"type\":\"number\"},\"maxItems\":256},\"nt\":{\"mi"
"nimum\":0,\"type\":\"integer\",\"description\":\"Number of traces\",\"maximum\":2"
"55},\"tbl\":{\"minItems\":1,\"type\":\"array\",\"items\":{\"$ref\":\"#/definitions/"
"fp_table\"},\"description\":\"various internal "
"data\"},\"ex\":{\"type\":\"object\",\"description\":\"DEPRECATED, use "
"'riegl.exponential_decomposition' instead\"},\"t\":{\"type\":\"object\",\"patt"
"ernProperties\":{\"^[0-9]+$\":{\"$ref\":\"#/definitions/fp\",\"description\":\"o"
"ne field per channel, field name is channel index\"}},\"additionalProper"
"ties\":false},\"mw\":{\"minimum\":0,\"type\":\"number\",\"description\":\"Maximum "
"weight\",\"exclusiveMinimum\":true,\"maximum\":4095},\"si\":{\"minimum\":0,\"typ"
"e\":\"number\",\"description\":\"Start index (hw_start)\",\"maximum\":255},\"sr\""
":{\"minimum\":0,\"type\":\"number\",\"description\":\"Sample rate [Hz]\",\"exclus"
"iveMinimum\":true}},\"$schema\":\"http://json-schema.org/draft-04/schema#\""
",\"type\":\"object\",\"definitions\":{\"fp\":{\"properties\":{\"w\":{\"minItems\":1,"
"\"type\":\"array\",\"items\":{\"minItems\":5,\"type\":\"array\",\"items\":{\"type\":\"n"
"umber\"},\"maxItems\":5},\"maxItems\":256},\"s\":{\"minItems\":1,\"type\":\"array\""
",\"items\":{\"minItems\":1,\"type\":\"array\",\"items\":{\"type\":\"number\"},\"maxIt"
"ems\":4096},\"maxItems\":256}},\"required\":[\"s\",\"w\"],\"type\":\"object\",\"desc"
"ription\":\"Fingerprint values\"},\"fp_table_row\":{\"minItems\":1,\"type\":\"ar"
"ray\",\"items\":{\"type\":\"number\"},\"maxItems\":2048},\"fp_table\":{\"propertie"
"s\":{\"tc\":{\"min\":0,\"type\":\"integer\",\"max\":255,\"description\":\"table data"
" type "
"code\"},\"ch\":{\"min\":0,\"type\":\"integer\",\"max\":255,\"description\":\"channel"
" number\"},\"tv\":{\"minItems\":1,\"type\":\"array\",\"items\":{\"oneOf\":[{\"$ref\":"
"\"#/definitions/fp_table_row\"},{\"type\":\"number\"}]},\"maxItems\":2048},\"nx"
"\":{\"min\":1,\"type\":\"integer\",\"max\":2048,\"description\":\"number of x entr"
"ies\"},\"ny\":{\"min\":1,\"type\":\"integer\",\"max\":2048,\"description\":\"number "
"of y entries\"}},\"required\":[\"ch\",\"tc\",\"nx\",\"ny\",\"tv\"],\"type\":\"object\","
"\"desription\":\"scanner internal data\"}},\"description\":\"Receiver "
"Internals\"}"
)
RDB_RIEGL_RECEIVER_INTERNALS_EXAMPLE = (
"{\"ns\":400,\"a\":[-1.55],\"nt\":128,\"tbl\":[{\"tc\":1,\"ch\":0,\"tv\":[[1,2,3,4,5]"
",[1.1,2.2,3.3,4.4,5.5]],\"nx\":5,\"ny\":2}],\"t\":{\"1\":{\"w\":[[78,86,126,134,"
"31],[78,86,126,134,31]],\"s\":[[1.23,4.56],[7.89,0.12]]},\"0\":{\"w\":[[78,8"
"6,126,134,31],[78,86,126,134,31]],\"s\":[[1.23,4.56],[7.89,0.12]]}},\"mw\""
":31,\"si\":48,\"sr\":7959997000.0}"
)

# Lookup table for reflectance calculation based on amplitude and range
RDB_RIEGL_REFLECTANCE_CALCULATION             = "riegl.reflectance_calculation"
RDB_RIEGL_REFLECTANCE_CALCULATION_TITLE       = "Reflectance Calculation Table"
RDB_RIEGL_REFLECTANCE_CALCULATION_DESCRIPTION = "Lookup table for reflectance calculation based on amplitude and range"
RDB_RIEGL_REFLECTANCE_CALCULATION_STATUS      = "optional"
RDB_RIEGL_REFLECTANCE_CALCULATION_SCHEMA = (
"{\"title\":\"Reflectance Calculation "
"Table\",\"properties\":{\"delta\":{\"description\":\"Delta between table "
"entries [m], first entry is at range = 0 "
"m\",\"type\":\"number\"},\"content\":{\"minItems\":1,\"description\":\"Correction "
"value [dB] to be added to the amplitude\",\"type\":\"array\",\"items\":{\"type"
"\":\"number\"},\"maxItems\":2000}},\"$schema\":\"http://json-schema.org/draft-"
"04/schema#\",\"type\":\"object\",\"description\":\"Lookup table for "
"reflectance calculation based on amplitude and "
"range\",\"required\":[\"delta\",\"content\"]}"
)
RDB_RIEGL_REFLECTANCE_CALCULATION_EXAMPLE = (
"{\"delta\":0.150918,\"content\":[-33.01]}"
)

# Range-dependent and scan-angle-dependent correction of reflectance reading
RDB_RIEGL_REFLECTANCE_CORRECTION             = "riegl.reflectance_correction"
RDB_RIEGL_REFLECTANCE_CORRECTION_TITLE       = "Near-Range Reflectance Correction"
RDB_RIEGL_REFLECTANCE_CORRECTION_DESCRIPTION = "Range-dependent and scan-angle-dependent correction of reflectance reading"
RDB_RIEGL_REFLECTANCE_CORRECTION_STATUS      = "optional"
RDB_RIEGL_REFLECTANCE_CORRECTION_SCHEMA = (
"{\"title\":\"Near-range reflectance correction\",\"properties\":{\"line_angle"
"s_deg\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"description\":\"Angle "
"[deg]\"},\"ranges_m\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"descript"
"ion\":\"Range [m]\"},\"reflectance_correction_db\":{\"type\":\"array\",\"items\":"
"{\"description\":\"rows (each array corresponds to a "
"range)\",\"type\":\"array\",\"items\":{\"description\":\"columns (each value "
"corresponds to an angle)\",\"type\":\"number\"}},\"description\":\"Near range "
"reflectance correction in dB as a function of range over angle\"}},\"$sc"
"hema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\"descr"
"iption\":\"Range-dependent and scan-angle-dependent correction of "
"reflectance reading\",\"required\":[\"ranges_m\",\"line_angles_deg\",\"reflect"
"ance_correction_db\"]}"
)
RDB_RIEGL_REFLECTANCE_CORRECTION_EXAMPLE = (
"{\"line_angles_deg\":[0.0,0.5,1.0,1.5,1.0,2.0,2.5,3.0,3.5,4.0],\"ranges_m"
"\":[0.0,1.0,2.0,3.0],\"reflectance_correction_db\":[[0.8,0.7,0.6,0.5,0.4,"
"0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0."
"8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,"
"0.1,0.05,0.01]]}"
)

# Scan pattern description
RDB_RIEGL_SCAN_PATTERN             = "riegl.scan_pattern"
RDB_RIEGL_SCAN_PATTERN_TITLE       = "Scan Pattern"
RDB_RIEGL_SCAN_PATTERN_DESCRIPTION = "Scan pattern description"
RDB_RIEGL_SCAN_PATTERN_STATUS      = "optional"
RDB_RIEGL_SCAN_PATTERN_SCHEMA = (
"{\"title\":\"Scan Pattern\",\"definitions\":{\"program\":{\"properties\":{\"laser"
"_prr\":{\"minimum\":0,\"description\":\"Laser Pulse Repetition Rate [Hz]\",\"t"
"ype\":\"number\",\"exclusiveMinimum\":false},\"name\":{\"description\":\"Name of"
" measurement program\",\"type\":\"string\"}},\"required\":[\"name\"],\"descripti"
"on\":\"Measurement program\",\"type\":\"object\"}},\"$schema\":\"http://json-sch"
"ema.org/draft-04/schema#\",\"description\":\"Scan pattern description\",\"pr"
"operties\":{\"rectangular\":{\"properties\":{\"theta_stop\":{\"minimum\":0.0,\"d"
"escription\":\"Stop theta angle in SOCS [deg]\",\"type\":\"number\",\"maximum\""
":180.0},\"theta_increment\":{\"minimum\":0.0,\"description\":\"Increment of "
"theta angle in SOCS [deg]\",\"type\":\"number\",\"maximum\":90.0},\"theta_star"
"t\":{\"minimum\":0.0,\"description\":\"Start theta angle in SOCS [deg]\",\"typ"
"e\":\"number\",\"maximum\":180.0},\"program\":{\"$ref\":\"#/definitions/program\""
"},\"phi_increment\":{\"minimum\":0.0,\"description\":\"Increment of phi angle"
" in SOCS [deg]\",\"type\":\"number\",\"maximum\":90.0},\"phi_stop\":{\"minimum\":"
"0.0,\"description\":\"Stop phi angle in SOCS [deg]\",\"type\":\"number\",\"maxi"
"mum\":720.0},\"phi_start\":{\"minimum\":0.0,\"description\":\"Start phi angle "
"in SOCS [deg]\",\"type\":\"number\",\"maximum\":360.0}},\"required\":[\"phi_star"
"t\",\"phi_stop\",\"phi_increment\",\"theta_start\",\"theta_stop\",\"theta_increm"
"ent\"],\"description\":\"Rectangular Field Of View Scan Pattern\",\"type\":\"o"
"bject\"},\"segments\":{\"properties\":{\"program\":{\"$ref\":\"#/definitions/pro"
"gram\"},\"list\":{\"type\":\"array\",\"items\":{\"properties\":{\"increment\":{\"min"
"imum\":0.0,\"description\":\"Increment of angle in SOCS [deg]\",\"type\":\"num"
"ber\",\"maximum\":90.0},\"stop\":{\"minimum\":0.0,\"description\":\"Stop angle "
"in SOCS [deg]\",\"type\":\"number\",\"maximum\":720.0},\"start\":{\"minimum\":0.0"
",\"description\":\"Start angle in SOCS [deg]\",\"type\":\"number\",\"maximum\":3"
"60.0}},\"required\":[\"start\",\"stop\",\"increment\"],\"description\":\"Line "
"Scan Segment\",\"type\":\"object\"}}},\"required\":[\"list\"],\"description\":\"Se"
"gmented Line Scan Pattern\",\"type\":\"object\"},\"line\":{\"properties\":{\"pro"
"gram\":{\"$ref\":\"#/definitions/program\"},\"increment\":{\"minimum\":0.0,\"des"
"cription\":\"Increment of angle in SOCS [deg]\",\"type\":\"number\",\"maximum\""
":90.0},\"stop\":{\"minimum\":0.0,\"description\":\"Stop angle in SOCS [deg]\","
"\"type\":\"number\",\"maximum\":720.0},\"start\":{\"minimum\":0.0,\"description\":"
"\"Start angle in SOCS [deg]\",\"type\":\"number\",\"maximum\":360.0}},\"require"
"d\":[\"start\",\"stop\",\"increment\"],\"description\":\"Line Scan "
"Pattern\",\"type\":\"object\"}}}"
)
RDB_RIEGL_SCAN_PATTERN_EXAMPLE = (
"{\"rectangular\":{\"theta_stop\":130.0,\"theta_increment\":0.04,\"theta_start"
"\":30.0,\"program\":{\"laser_prr\":100000.0,\"name\":\"High "
"Speed\"},\"phi_increment\":0.04,\"phi_stop\":270.0,\"phi_start\":45.0}}"
)

# Details about laser shot files
RDB_RIEGL_SHOT_INFO             = "riegl.shot_info"
RDB_RIEGL_SHOT_INFO_TITLE       = "Shot Information"
RDB_RIEGL_SHOT_INFO_DESCRIPTION = "Details about laser shot files"
RDB_RIEGL_SHOT_INFO_STATUS      = "optional"
RDB_RIEGL_SHOT_INFO_SCHEMA = (
"{\"title\":\"Shot Information\",\"properties\":{\"shot_file\":{\"properties\":{\""
"file_uuid\":{\"description\":\"File's Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Shot file "
"extension, without the leading dot\",\"type\":\"string\"}},\"required\":[\"fil"
"e_extension\"],\"type\":\"object\"}},\"$schema\":\"http://json-schema.org/draf"
"t-04/schema#\",\"description\":\"Details about laser shot "
"files\",\"type\":\"object\"}"
)
RDB_RIEGL_SHOT_INFO_EXAMPLE = (
"{\"shot_file\":{\"file_uuid\":\"26a00815-67c0-4bff-8fe8-c577378fe663\",\"file"
"_extension\":\"sodx\"}}"
)

# Point filters applied in addition to the application-defined filters
RDB_RIEGL_STORED_FILTERS             = "riegl.stored_filters"
RDB_RIEGL_STORED_FILTERS_TITLE       = "Stored Filters"
RDB_RIEGL_STORED_FILTERS_DESCRIPTION = "Point filters applied in addition to the application-defined filters"
RDB_RIEGL_STORED_FILTERS_STATUS      = "optional"
RDB_RIEGL_STORED_FILTERS_SCHEMA = (
"{\"title\":\"Stored filters\",\"properties\":{\"filters\":{\"description\":\"List"
" of point filters\",\"type\":\"array\",\"items\":{\"properties\":{\"title\":{\"des"
"cription\":\"A short filter title (e.g. for display in a selection "
"list)\",\"type\":\"string\"},\"description\":{\"description\":\"A brief "
"description of the filter (e.g. for display in a "
"tooltip)\",\"type\":\"string\"},\"activated\":{\"description\":\"Apply ('true') "
"or ignore ('false') this "
"filter\",\"type\":\"boolean\"},\"filter\":{\"description\":\"The RDB filter "
"string to apply (e.g. when reading points or index), details see "
"documentation of function select()\",\"type\":\"string\"}},\"required\":[\"act"
"ivated\",\"title\",\"description\",\"filter\"],\"description\":\"Point filter "
"definition\",\"type\":\"object\"}},\"activated\":{\"description\":\"Apply "
"('true') or ignore ('false') all filters\",\"type\":\"boolean\"}},\"$schema\""
":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\"descriptio"
"n\":\"Point filters applied in addition to the application-defined "
"filters\",\"required\":[\"activated\",\"filters\"]}"
)
RDB_RIEGL_STORED_FILTERS_EXAMPLE = (
"{\"filters\":[{\"title\":\"Ignore uncertain points from MTA "
"resolution\",\"description\":\"Ignore points with uncertain MTA zone "
"assignment\",\"activated\":false,\"filter\":\"riegl.mta_uncertain_point == "
"0\"},{\"title\":\"Ignore points below dynamic trigger "
"level\",\"description\":\"Ignore points with an echo signal amplitude "
"below the dynamic "
"trigger\",\"activated\":false,\"filter\":\"riegl.dyntrig_uncertain_point == "
"0\"},{\"title\":\"Ignore points outside outer AABB\",\"description\":\"Ignore "
"points that are outside the outer AABB in "
"BOCS\",\"activated\":false,\"filter\":\"riegl.point_outside_aabb_bocs == "
"0\"},{\"title\":\"Ignore points inside inner AABB\",\"description\":\"Ignore "
"points that are inside the inner AABB in "
"BOCS\",\"activated\":false,\"filter\":\"riegl.point_inside_aabb_bocs == "
"0\"}],\"activated\":true}"
)

# Details of major system components like lidar sensors, cameras and navigation devices
RDB_RIEGL_SYSTEM_DESCRIPTION             = "riegl.system_description"
RDB_RIEGL_SYSTEM_DESCRIPTION_TITLE       = "System Description"
RDB_RIEGL_SYSTEM_DESCRIPTION_DESCRIPTION = "Details of major system components like lidar sensors, cameras and navigation devices"
RDB_RIEGL_SYSTEM_DESCRIPTION_STATUS      = "optional"
RDB_RIEGL_SYSTEM_DESCRIPTION_SCHEMA = (
"{\"title\":\"System "
"Description\",\"properties\":{\"timestamp\":{\"description\":\"Date and time "
"of creation (e.g. 2019-06-19T13:32:10+02:00)\",\"type\":\"string\"},\"versio"
"n\":{\"description\":\"Document format version\",\"type\":\"string\"},\"$class\":"
"{\"enum\":[\"Document\"],\"description\":\"Object class "
"name\",\"type\":\"string\"},\"author\":{\"description\":\"Name of the author "
"that created the "
"document\",\"type\":\"string\"},\"system\":{\"description\":\"The actual system "
"description, details see documentation of RIEGL System Description\",\"t"
"ype\":\"object\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"t"
"ype\":\"object\",\"description\":\"Details of major system components like "
"lidar sensors, cameras and navigation devices\",\"required\":[\"$class\",\"v"
"ersion\",\"author\",\"timestamp\",\"system\"]}"
)
RDB_RIEGL_SYSTEM_DESCRIPTION_EXAMPLE = (
"{\"timestamp\":\"2022-09-30T11:56:26+00:00\",\"version\":\"1.2.1\",\"$class\":\"D"
"ocument\",\"author\":\"RIEGL LMS GmbH, Austria\",\"system\":{\"details\":\"see "
"documentation of RIEGL System Description\"}}"
)

# Conversion of background radiation raw values to temperatures in °C
RDB_RIEGL_TEMPERATURE_CALCULATION             = "riegl.temperature_calculation"
RDB_RIEGL_TEMPERATURE_CALCULATION_TITLE       = "Temperature Calculation Table"
RDB_RIEGL_TEMPERATURE_CALCULATION_DESCRIPTION = "Conversion of background radiation raw values to temperatures in °C"
RDB_RIEGL_TEMPERATURE_CALCULATION_STATUS      = "optional"
RDB_RIEGL_TEMPERATURE_CALCULATION_SCHEMA = (
"{\"title\":\"Temperature Calculation Table\",\"properties\":{\"InGaAs_Si_Diff"
"erence\":{\"$ref\":\"#/definitions/conversion_table\",\"description\":\"Conver"
"sion table for InGaAs - Si difference\"},\"Si\":{\"$ref\":\"#/definitions/co"
"nversion_table\",\"description\":\"Conversion table for Si channel\"},\"InGa"
"As\":{\"$ref\":\"#/definitions/conversion_table\",\"description\":\"Conversion"
" table for InGaAs channel\"}},\"$schema\":\"http://json-schema.org/draft-0"
"4/schema#\",\"type\":\"object\",\"definitions\":{\"conversion_table\":{\"propert"
"ies\":{\"temperature\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"descrip"
"tion\":\"Temperature [\\u00b0C]\"},\"value\":{\"type\":\"array\",\"items\":{\"type\""
":\"number\"},\"description\":\"LSB [1]\"}},\"required\":[\"value\",\"temperature\""
"],\"type\":\"object\"}},\"description\":\"Conversion of background radiation "
"raw values to temperatures in \\u00b0C\"}"
)
RDB_RIEGL_TEMPERATURE_CALCULATION_EXAMPLE = (
"{\"InGaAs_Si_Difference\":{\"temperature\":[1749.977111117893,1749.9771111"
"17893,1749.977111117893,1749.977111117893,1749.977111117893,1749.97711"
"1117893,1744.7813348796044,1681.9971312601092,1622.3944822534868],\"val"
"ue\":[1000.0,1100.090029602954,1200.04425183874,1300.1342814416948,1400"
".0885036774805,1500.0427259132668,1600.1327555162209,1700.086977752006"
"5,1800.0411999877924]},\"Si\":{\"temperature\":[546.300048828125,548.81640"
"51212026,551.3143938500972,554.0144257850053,556.604252334815,559.2124"
"464488079,561.8022729986177,564.4104671126105,567.0002936624203],\"valu"
"e\":[0.0,64.00097659230323,128.0019531846065,192.0029297769097,256.0039"
"063692129,320.00488296151616,384.0058595538194,448.0068361461226,512.0"
"078127384259]},\"InGaAs\":{\"temperature\":[307.22196722535614,309.1153478"
"247277,311.1188086915047,313.10025350480055,315.2137946389828,317.2172"
"555057597,319.2207163725366,321.2021611858325,323.3157023200148],\"valu"
"e\":[0.0,64.00097659230323,128.0019531846065,192.0029297769097,256.0039"
"063692129,320.00488296151616,384.0058595538194,448.0068361461226,512.0"
"078127384259]}}"
)

# Base of timestamps (epoch)
RDB_RIEGL_TIME_BASE             = "riegl.time_base"
RDB_RIEGL_TIME_BASE_TITLE       = "Time Base"
RDB_RIEGL_TIME_BASE_DESCRIPTION = "Base of timestamps (epoch)"
RDB_RIEGL_TIME_BASE_STATUS      = "optional"
RDB_RIEGL_TIME_BASE_SCHEMA = (
"{\"title\":\"Time Base\",\"properties\":{\"system\":{\"enum\":[\"unknown\",\"UTC\",\""
"GPS\"],\"description\":\"Time system (time "
"standard)\",\"type\":\"string\"},\"epoch\":{\"description\":\"Date and time of "
"timestamp '0' as proposed by RFC 3339 (e.g. 2015-10-27T00:00:00+01:00)"
".\",\"type\":\"string\"},\"source\":{\"enum\":[\"unknown\",\"RTC\",\"GNSS\"],\"descrip"
"tion\":\"Timestamp source\",\"type\":\"string\"}},\"$schema\":\"http://json-sche"
"ma.org/draft-04/schema#\",\"type\":\"object\",\"description\":\"Base of "
"timestamps (epoch)\",\"required\":[\"epoch\",\"source\"]}"
)
RDB_RIEGL_TIME_BASE_EXAMPLE = (
"{\"system\":\"UTC\",\"epoch\":\"2015-10-27T00:00:00+00:00\",\"source\":\"GNSS\"}"
)

# Details about position+orientation files
RDB_RIEGL_TRAJECTORY_INFO             = "riegl.trajectory_info"
RDB_RIEGL_TRAJECTORY_INFO_TITLE       = "Trajectory Information"
RDB_RIEGL_TRAJECTORY_INFO_DESCRIPTION = "Details about position+orientation files"
RDB_RIEGL_TRAJECTORY_INFO_STATUS      = "optional"
RDB_RIEGL_TRAJECTORY_INFO_SCHEMA = (
"{\"title\":\"Trajectory "
"Information\",\"properties\":{\"company\":{\"description\":\"Company name\",\"ty"
"pe\":\"string\"},\"time_interval\":{\"properties\":{\"minimum\":{\"description\":"
"\"Minimum time interval "
"[s]\",\"type\":\"number\"},\"average\":{\"description\":\"Average time interval "
"[s]\",\"type\":\"number\"},\"std_dev\":{\"description\":\"Standard deviation of "
"intervals [s]\",\"type\":\"number\"},\"maximum\":{\"description\":\"Maximum time"
" interval [s]\",\"type\":\"number\"}},\"required\":[\"minimum\",\"average\",\"maxi"
"mum\",\"std_dev\"],\"description\":\"Time interval statistics\",\"type\":\"objec"
"t\"},\"field_of_application\":{\"enum\":[\"unknown\",\"SLS\",\"TLS\",\"KLS\",\"MLS\","
"\"ULS\",\"ALS\",\"BLS\",\"ILS\"],\"description\":\"Field of "
"application\",\"type\":\"string\"},\"location\":{\"description\":\"Project "
"location, e.g. city/state/country\",\"type\":\"string\"},\"navigation_frame\""
":{\"enum\":[\"unknown\",\"NED\",\"ENU\"],\"description\":\"Navigation frame (NED:"
" North-East-Down, ENU: "
"East-North-Up)\",\"type\":\"string\"},\"settings\":{\"description\":\"Settings "
"used to calculate the trajectory (descriptive "
"text)\",\"type\":\"string\"},\"device\":{\"description\":\"Navigation device, "
"e.g. "
"name/type/serial\",\"type\":\"string\"},\"project\":{\"description\":\"Project "
"name\",\"type\":\"string\"},\"software\":{\"description\":\"Software that "
"calculated the trajectory (this may be the same or different software "
"than the one that created the file)\",\"type\":\"string\"}},\"$schema\":\"http"
"://json-schema.org/draft-04/schema#\",\"type\":\"object\",\"description\":\"De"
"tails about position+orientation "
"files\",\"required\":[\"time_interval\",\"navigation_frame\"]}"
)
RDB_RIEGL_TRAJECTORY_INFO_EXAMPLE = (
"{\"company\":\"RIEGL LMS\",\"time_interval\":{\"minimum\":0.00500032,\"average\""
":0.00500053,\"std_dev\":5.51e-07,\"maximum\":0.005004883},\"field_of_applic"
"ation\":\"MLS\",\"location\":\"Horn\",\"navigation_frame\":\"NED\",\"settings\":\"de"
"fault\",\"device\":\"IMU Model 12/1, Serial# 12345\",\"project\":\"Campaign "
"3\",\"software\":\"Navigation Software XYZ\"}"
)

# Trigger-Timestamping-Unit/IP configuration
RDB_RIEGL_TTIP_CONFIGURATION             = "riegl.ttip_configuration"
RDB_RIEGL_TTIP_CONFIGURATION_TITLE       = "TTIP Configuration"
RDB_RIEGL_TTIP_CONFIGURATION_DESCRIPTION = "Trigger-Timestamping-Unit/IP configuration"
RDB_RIEGL_TTIP_CONFIGURATION_STATUS      = "optional"
RDB_RIEGL_TTIP_CONFIGURATION_SCHEMA = (
"{\"title\":\"TTIP Configuration\",\"properties\":{\"ext_bitmask\":{\"minimum\":0"
",\"description\":\"defines which of the internal pulse generators are to "
"be started\",\"type\":\"integer\"},\"in_min_duration\":{\"minimum\":0,\"descript"
"ion\":\"input signals with smaller pulse durations are ignored [0.1 msec"
"]\",\"type\":\"integer\"},\"dmi_max_time\":{\"minimum\":0,\"description\":\"dmi, "
"maximum time interval between trigger events [0.1 "
"msec]\",\"type\":\"integer\"},\"out_polarity\":{\"minimum\":0,\"description\":\"0 "
".. positive edge, 1 .. negative "
"edge\",\"type\":\"integer\"},\"output_usage\":{\"minimum\":0,\"description\":\"0 "
".. no output, 1 .. output derived from internal clock, 2 .. output "
"derived from dmi, 3 .. output derived from external signal, 4 .. "
"output static low, 5 .. output static "
"high\",\"type\":\"integer\"},\"output_descr\":{\"description\":\"descriptive "
"string\",\"type\":\"string\"},\"channel\":{\"minimum\":0,\"description\":\"ID of "
"input/output channel\",\"type\":\"integer\"},\"out_duration\":{\"minimum\":0,\"d"
"escription\":\"output pulse duration [0.1 msec]\",\"type\":\"integer\"},\"in_m"
"ax_duration\":{\"minimum\":0,\"description\":\"stops measurement of pulse "
"duration of input signal [0.1 msec]\",\"type\":\"integer\"},\"out_interval\":"
"{\"minimum\":0,\"description\":\"output pulse interval [0.1 "
"msec]\",\"type\":\"integer\"},\"dmi_dist_per_tick\":{\"description\":\"dmi, "
"distance per tick, just informative "
"[m]\",\"type\":\"number\"},\"ext_channel\":{\"minimum\":0,\"description\":\"ID of "
"channel used as external trigger input, 32 indicates "
"none\",\"type\":\"integer\"},\"in_polarity\":{\"minimum\":0,\"description\":\"0 .."
" positive edge, 1 .. negative edge\",\"type\":\"integer\"},\"in_max_delay\":{"
"\"minimum\":0,\"description\":\"maximum delay to output pulse before fake "
"event is generated [0.1 msec], zero indicates that no fake events are "
"generated\",\"type\":\"integer\"},\"dmi_incr\":{\"description\":\"dmi, increment"
" in ticks\",\"type\":\"integer\"},\"num_channel\":{\"minimum\":0,\"description\":"
"\"number of input/output channels\",\"type\":\"integer\"},\"out_delay\":{\"mini"
"mum\":0,\"description\":\"output pulse initial delay after start [0.1 msec"
"]\",\"type\":\"integer\"},\"dmi_min_time\":{\"minimum\":0,\"description\":\"dmi, "
"minimum time interval between trigger events [0.1 msec]\",\"type\":\"integ"
"er\"},\"ext_subdivider\":{\"minimum\":0,\"description\":\"reduces the "
"frequency, default 1\",\"type\":\"integer\"},\"out_num_pulses\":{\"minimum\":0,"
"\"description\":\"number of output pulses to be generated, 0 .. infinite\""
",\"type\":\"integer\"},\"ext_delay\":{\"minimum\":0,\"description\":\"external "
"trigger, time delay [0.1 msec]\",\"type\":\"integer\"},\"ttip_version\":{\"min"
"imum\":0,\"description\":\"following main.sub.ss.sss\",\"type\":\"integer\"},\"e"
"xt_signal\":{\"minimum\":0,\"description\":\"0 .. use input signal, 1 .. use"
" output signal of "
"channel\",\"type\":\"integer\"},\"input_descr\":{\"description\":\"descriptive "
"string\",\"type\":\"string\"},\"input_usage\":{\"minimum\":0,\"description\":\"0 "
".. deactivated, 1 .. just detecting and timestamping\",\"type\":\"integer\""
"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\""
",\"description\":\"Trigger-Timestamping-Unit/IP configuration\",\"required\""
":[\"ttip_version\",\"num_channel\",\"ext_channel\",\"ext_signal\",\"ext_delay\","
"\"ext_subdivider\",\"ext_bitmask\",\"dmi_incr\",\"dmi_min_time\",\"dmi_max_time"
"\",\"dmi_dist_per_tick\",\"channel\",\"output_descr\",\"input_descr\",\"output_u"
"sage\",\"input_usage\",\"out_polarity\",\"out_duration\",\"out_interval\",\"out_"
"delay\",\"out_num_pulses\",\"in_polarity\",\"in_min_duration\",\"in_max_durati"
"on\",\"in_max_delay\"]}"
)
RDB_RIEGL_TTIP_CONFIGURATION_EXAMPLE = (
"{\"ext_bitmask\":0,\"in_min_duration\":0,\"dmi_max_time\":0,\"out_polarity\":0"
",\"output_usage\":1,\"output_descr\":\"Port 1 - Trigger\",\"channel\":0,\"out_d"
"uration\":300,\"in_max_duration\":10000,\"out_interval\":10000,\"dmi_dist_pe"
"r_tick\":0.0,\"ext_channel\":32,\"in_polarity\":0,\"in_max_delay\":9990,\"dmi_"
"incr\":0,\"num_channel\":9,\"out_delay\":0,\"dmi_min_time\":0,\"ext_subdivider"
"\":1,\"out_num_pulses\":1,\"ext_delay\":0,\"ttip_version\":1,\"ext_signal\":0,\""
"input_descr\":\"Port 1 - Exposure\",\"input_usage\":1}"
)

# Details about vertex file
RDB_RIEGL_VERTEX_INFO             = "riegl.vertex_info"
RDB_RIEGL_VERTEX_INFO_TITLE       = "Vertex Information"
RDB_RIEGL_VERTEX_INFO_DESCRIPTION = "Details about vertex file"
RDB_RIEGL_VERTEX_INFO_STATUS      = "optional"
RDB_RIEGL_VERTEX_INFO_SCHEMA = (
"{\"title\":\"Vertex Information\",\"properties\":{\"vertex_file\":{\"properties"
"\":{\"file_uuid\":{\"description\":\"File's Universally Unique Identifier "
"(RFC 4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Vertex "
"file extension, without the leading dot\",\"type\":\"string\"}},\"required\":"
"[\"file_extension\"],\"type\":\"object\"}},\"$schema\":\"http://json-schema.org"
"/draft-04/schema#\",\"description\":\"Details about vertex "
"file\",\"type\":\"object\"}"
)
RDB_RIEGL_VERTEX_INFO_EXAMPLE = (
"{\"vertex_file\":{\"file_uuid\":\"51534d95-d71f-4f36-ae1a-3e63a21fd1c7\",\"fi"
"le_extension\":\"vtx\"}}"
)

# Details about the voxels contained in the file
RDB_RIEGL_VOXEL_INFO             = "riegl.voxel_info"
RDB_RIEGL_VOXEL_INFO_TITLE       = "Voxel Information"
RDB_RIEGL_VOXEL_INFO_DESCRIPTION = "Details about the voxels contained in the file"
RDB_RIEGL_VOXEL_INFO_STATUS      = "optional"
RDB_RIEGL_VOXEL_INFO_SCHEMA = (
"{\"title\":\"Voxel Information\",\"$schema\":\"http://json-schema.org/draft-0"
"4/schema#\",\"description\":\"Details about the voxels contained in the fi"
"le\",\"type\":\"object\",\"definitions\":{\"voxel_size_cubic\":{\"$ref\":\"#/defin"
"itions/edge_length\",\"type\":\"number\"},\"edge_length\":{\"minimum\":0,\"descr"
"iption\":\"Length of voxel edge [m].\",\"type\":\"number\",\"exclusiveMinimum\""
":true},\"voxel_type\":{\"default\":\"centroid\",\"description\":\"Whether a "
"point in a voxel represents its center or its centroid. If type is "
"<tt>index</tt> there is no point but only an integer voxel index.\",\"en"
"um\":[\"center\",\"centroid\",\"index\"]},\"voxel_size\":{\"minItems\":3,\"items\":"
"{\"$ref\":\"#/definitions/edge_length\"},\"type\":\"array\",\"description\":\"Siz"
"e of voxels.\",\"maxItems\":3},\"shape_thresholds\":{\"properties\":{\"plane\":"
"{\"maximum\":1,\"type\":\"number\",\"exclusiveMinimum\":true,\"minimum\":0,\"desc"
"ription\":\"If the smallest eigenvalue is smaller than the median "
"eigenvalue * plane_threshold, the voxel is considered a "
"plane.\",\"exclusiveMaximum\":true},\"line\":{\"minimum\":1,\"description\":\"If"
" the biggest eigenvalue is bigger than the median eigenvalue * "
"line_threshold, the voxel is considered a line.\",\"type\":\"number\",\"excl"
"usiveMinimum\":true}},\"required\":[\"plane\",\"line\"],\"description\":\"Thresh"
"olds used to compute the voxel's shape_id value.\",\"type\":\"object\"},\"vo"
"xel_origin_enum\":{\"default\":\"corner\",\"description\":\"Defines whether "
"the voxel's center or a corner is placed on CRS origin <tt>(0/0/0)</tt"
">.\",\"enum\":[\"center\",\"corner\"]},\"voxel_origin_point\":{\"minItems\":3,\"de"
"scription\":\"Origin point for all voxel indices in voxel CRS.\",\"type\":\""
"array\",\"items\":{\"type\":\"number\"},\"maxItems\":3}},\"oneOf\":[{\"properties\""
":{\"voxel_type\":{\"$ref\":\"#/definitions/voxel_type\"},\"size\":{\"oneOf\":[{\""
"$ref\":\"#/definitions/voxel_size\"},{\"$ref\":\"#/definitions/voxel_size_cu"
"bic\"}],\"description\":\"Size of voxels in file coordinate system.\"},\"vox"
"el_origin\":{\"$ref\":\"#/definitions/voxel_origin_enum\"},\"shape_threshold"
"s\":{\"$ref\":\"#/definitions/shape_thresholds\"}},\"required\":[\"size\",\"voxe"
"l_origin\",\"voxel_type\"],\"additionalProperties\":false},{\"properties\":{\""
"reference_point\":{\"minItems\":2,\"items\":{\"minimum\":-180,\"type\":\"number\""
",\"maximum\":180},\"type\":\"array\",\"description\":\"Point in WGS84 geodetic "
"decimal degree (EPSG:4326) that was used to compute the projection "
"distortion parameters. The coefficient order is latitude, longitude. "
"Only voxels with corresponding geo_tag, voxel_size and reference_point"
" can be reliably processed together. This entry is available for voxel"
" files in projected CRS only.\",\"maxItems\":2},\"size\":{\"$ref\":\"#/definit"
"ions/voxel_size\",\"description\":\"Size of voxels in file coordinate syst"
"em.\"},\"size_llcs\":{\"$ref\":\"#/definitions/voxel_size\",\"description\":\"Si"
"ze of voxels in a locally levelled cartesian coordinate system (xyz). "
"This is only used for voxels based on a map projection.\"},\"shape_thres"
"holds\":{\"$ref\":\"#/definitions/shape_thresholds\"},\"voxel_type\":{\"$ref\":"
"\"#/definitions/voxel_type\"},\"voxel_origin\":{\"oneOf\":[{\"$ref\":\"#/defini"
"tions/voxel_origin_enum\"},{\"$ref\":\"#/definitions/voxel_origin_point\",\""
"description\":\"The base point of the voxel grid. Used together with "
"<tt>voxel_size</tt> and <tt>voxel_index</tt> to compute actual point c"
"oordinates.\"}]}},\"required\":[\"reference_point\",\"size_llcs\",\"size\",\"vox"
"el_origin\",\"voxel_type\"],\"additionalProperties\":false}]}"
)
RDB_RIEGL_VOXEL_INFO_EXAMPLE = (
"{\"reference_point\":[48,16],\"size\":[0.5971642834779395,0.59716428347793"
"95,0.5143705304787237],\"size_llcs\":[0.5156575252891171,0.5130835356683"
"303,0.5143705304787237],\"shape_thresholds\":{\"plane\":0.16,\"line\":6},\"vo"
"xel_type\":\"centroid\",\"voxel_origin\":\"corner\"}"
)

# Settings for waveform averaging
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS             = "riegl.waveform_averaging_settings"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_TITLE       = "Waveform Averaging Settings"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_DESCRIPTION = "Settings for waveform averaging"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_SCHEMA = (
"{\"title\":\"Waveform Averaging Settings\",\"properties\":{\"mta_zone\":{\"mini"
"mum\":1,\"type\":\"integer\",\"description\":\"Fixed MTA zone for averaging.\"}"
",\"trim\":{\"minimum\":0,\"type\":\"number\",\"default\":0,\"description\":\"Percen"
"tage for robust averaging.\",\"maximum\":0.5},\"num_shots\":{\"minimum\":1,\"t"
"ype\":\"integer\",\"description\":\"Number of consecutive shots to be used "
"for averaging.\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\","
"\"type\":\"object\",\"description\":\"Settings for waveform "
"averaging\",\"required\":[\"num_shots\",\"mta_zone\"]}"
)
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_EXAMPLE = (
"{\"mta_zone\":1,\"trim\":0.05,\"num_shots\":7}"
)

# Details about waveform files
RDB_RIEGL_WAVEFORM_INFO             = "riegl.waveform_info"
RDB_RIEGL_WAVEFORM_INFO_TITLE       = "Waveform Information"
RDB_RIEGL_WAVEFORM_INFO_DESCRIPTION = "Details about waveform files"
RDB_RIEGL_WAVEFORM_INFO_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_INFO_SCHEMA = (
"{\"title\":\"Waveform Information\",\"properties\":{\"sample_block_file\":{\"pr"
"operties\":{\"file_uuid\":{\"description\":\"File's Universally Unique "
"Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Sample block "
"file extension, without the leading dot\",\"type\":\"string\"}},\"required\":"
"[\"file_extension\"],\"type\":\"object\"},\"range_offset_waveform_samples_m\":"
"{\"description\":\"Calibrated device specific range offset for waveform "
"samples in "
"meters.\",\"type\":\"number\"},\"range_offset_m\":{\"description\":\"Calibrated "
"device specific range offset for waveform analysis by system response "
"fitting in meters.\",\"type\":\"number\"},\"sample_data_files\":{\"type\":\"arra"
"y\",\"items\":{\"properties\":{\"channel_name\":{\"description\":\"Sample block "
"channel name\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's "
"Universally Unique Identifier (RFC 4122)\",\"type\":\"string\"},\"delta_st\":"
"{\"description\":\"reserved\",\"type\":\"number\"},\"file_extension\":{\"descript"
"ion\":\"Sample data file extension, without the leading dot\",\"type\":\"str"
"ing\"},\"sample_interval\":{\"minimum\":0,\"description\":\"Sampling interval "
"in seconds\",\"type\":\"number\",\"exclusiveMinimum\":false},\"sample_bits\":{\""
"minimum\":0,\"type\":\"integer\",\"exclusiveMinimum\":false,\"maximum\":32,\"des"
"cription\":\"Bitwidth of samples (e.g. 10 bit, 12 bit)\",\"exclusiveMaximu"
"m\":false},\"laser_wavelength\":{\"minimum\":0,\"description\":\"Laser "
"wavelength in meters (0 = unknown)\",\"type\":\"number\",\"exclusiveMinimum\""
":false},\"channel\":{\"minimum\":0,\"type\":\"integer\",\"exclusiveMinimum\":fal"
"se,\"maximum\":255,\"description\":\"Sample block channel number (255 = inv"
"alid)\",\"exclusiveMaximum\":false}},\"required\":[\"channel\",\"channel_name\""
",\"sample_interval\",\"sample_bits\",\"laser_wavelength\",\"delta_st\",\"file_e"
"xtension\"],\"type\":\"object\"}}},\"$schema\":\"http://json-schema.org/draft-"
"04/schema#\",\"type\":\"object\",\"description\":\"Details about waveform "
"files\",\"required\":[\"sample_block_file\",\"sample_data_files\"]}"
)
RDB_RIEGL_WAVEFORM_INFO_EXAMPLE = (
"{\"sample_block_file\":{\"file_uuid\":\"93a03615-66c0-4bea-8ff8-c577378fe66"
"0\",\"file_extension\":\"sbx\"},\"range_offset_m\":3.1415,\"sample_data_files\""
":[{\"channel_name\":\"high_power\",\"sample_interval\":1.00503e-09,\"file_ext"
"ension\":\"sp0\",\"delta_st\":0,\"file_uuid\":\"da084413-e3e8-4655-a122-071de8"
"490d8e\",\"sample_bits\":12,\"laser_wavelength\":0,\"channel\":0},{\"channel_n"
"ame\":\"low_power\",\"sample_interval\":1.00503e-09,\"file_extension\":\"sp1\","
"\"delta_st\":0,\"file_uuid\":\"93585b5e-5ea9-43a1-947b-e7ba3be642d2\",\"sampl"
"e_bits\":12,\"laser_wavelength\":0,\"channel\":1},{\"channel_name\":\"wwf\",\"sa"
"mple_interval\":1.00503e-09,\"file_extension\":\"sp5\",\"delta_st\":0,\"file_u"
"uid\":\"9d2298c4-1036-464f-b5cb-1cf8e517f3a0\",\"sample_bits\":12,\"laser_wa"
"velength\":0,\"channel\":5}],\"range_offset_waveform_samples_m \":7.283}"
)

# Scanner settings for waveform output
RDB_RIEGL_WAVEFORM_SETTINGS             = "riegl.waveform_settings"
RDB_RIEGL_WAVEFORM_SETTINGS_TITLE       = "Waveform Settings"
RDB_RIEGL_WAVEFORM_SETTINGS_DESCRIPTION = "Scanner settings for waveform output"
RDB_RIEGL_WAVEFORM_SETTINGS_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_SETTINGS_SCHEMA = (
"{\"title\":\"Waveform Settings\",\"$schema\":\"http://json-schema.org/draft-0"
"4/schema#\",\"description\":\"Scanner settings for waveform output\",\"type\""
":\"array\",\"items\":{\"properties\":{\"pass_dev_less\":{\"description\":\"Thresh"
"old for deviation less than "
"[1]\",\"type\":\"integer\"},\"channel_idx_mask\":{\"description\":\"Bit mask for"
" channels which belong to sbl_name: Channel 0 = Bit0, Channel 1 = "
"Bit1, ...\",\"type\":\"integer\"},\"sbl_name\":{\"description\":\"Name of sample"
" block, e.g.: wfm, "
"wwf\",\"type\":\"string\"},\"pass_dev_greater\":{\"description\":\"Threshold for"
" deviation greater than "
"[1]\",\"type\":\"integer\"},\"pass_rng_greater\":{\"description\":\"Threshold "
"for range greater than "
"[m]\",\"type\":\"number\"},\"pass_rng_less\":{\"description\":\"Threshold for "
"range less than "
"[m]\",\"type\":\"number\"},\"pass_ampl_greater\":{\"description\":\"Threshold "
"for amplitude greater than "
"[dB]\",\"type\":\"number\"},\"enabled\":{\"description\":\"Waveform output "
"enabled\",\"type\":\"boolean\"},\"smart_enabled\":{\"description\":\"Smart "
"waveform output "
"enabled\",\"type\":\"boolean\"},\"logic_expression\":{\"description\":\"Logic "
"expression of smart waveforms "
"filter\",\"type\":\"string\"},\"pass_ampl_less\":{\"description\":\"Threshold "
"for amplitude less than [dB]\",\"type\":\"number\"}},\"required\":[\"sbl_name\""
",\"enabled\",\"channel_idx_mask\"],\"type\":\"object\"}}"
)
RDB_RIEGL_WAVEFORM_SETTINGS_EXAMPLE = (
"[{\"channel_idx_mask\":11,\"sbl_name\":\"wfm\",\"pass_rng_greater\":9.27,\"pass"
"_rng_less\":13.11,\"pass_ampl_greater\":1.0,\"enabled\":true,\"smart_enabled"
"\":true,\"pass_ampl_less\":5.0},{\"channel_idx_mask\":32,\"enabled\":false,\"s"
"bl_name\":\"wwf\"}]"
)

# Window analysis data estimated from scandata and resulting filter parameters
RDB_RIEGL_WINDOW_ANALYSIS             = "riegl.window_analysis"
RDB_RIEGL_WINDOW_ANALYSIS_TITLE       = "Window Analysis"
RDB_RIEGL_WINDOW_ANALYSIS_DESCRIPTION = "Window analysis data estimated from scandata and resulting filter parameters"
RDB_RIEGL_WINDOW_ANALYSIS_STATUS      = "optional"
RDB_RIEGL_WINDOW_ANALYSIS_SCHEMA = (
"{\"title\":\"Window Analysis\",\"properties\":{\"settings\":{\"properties\":{\"am"
"plitude\":{\"properties\":{\"sigma_factor\":{\"type\":\"number\"},\"additive_val"
"ue\":{\"type\":\"number\"}},\"required\":[\"sigma_factor\",\"additive_value\"],\"t"
"ype\":\"object\"},\"range\":{\"properties\":{\"sigma_factor\":{\"type\":\"number\"}"
",\"additive_value\":{\"type\":\"number\"}},\"required\":[\"sigma_factor\",\"addit"
"ive_value\"],\"type\":\"object\"}},\"required\":[\"range\",\"amplitude\"],\"type\":"
"\"object\"},\"result\":{\"properties\":{\"angle\":{\"type\":\"array\",\"items\":{\"ty"
"pe\":\"number\"},\"description\":\"[deg]\"},\"amplitude_sigma\":{\"type\":\"array\""
",\"items\":{\"type\":\"number\"},\"description\":\"[dB]\"},\"range_sigma\":{\"type\""
":\"array\",\"items\":{\"type\":\"number\"},\"description\":\"[m]\"},\"timestamp\":{\""
"type\":\"array\",\"items\":{\"type\":\"number\"},\"description\":\"[s]\"},\"range_me"
"an\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"description\":\"[m]\"},\"am"
"plitude_mean\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"description\":"
"\"[dB]\"},\"amplitude_offset\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\""
"description\":\"[dB]\"}},\"required\":[\"angle\",\"range_mean\",\"range_sigma\",\""
"amplitude_mean\",\"amplitude_sigma\",\"amplitude_offset\"],\"type\":\"object\"}"
",\"filter\":{\"properties\":{\"range_max\":{\"type\":\"array\",\"items\":{\"type\":\""
"number\"},\"description\":\"[m]\"},\"amplitude_max\":{\"type\":\"array\",\"items\":"
"{\"type\":\"number\"},\"description\":\"[dB]\"},\"angle\":{\"type\":\"array\",\"items"
"\":{\"type\":\"number\"},\"description\":\"[deg]\"},\"range_min\":{\"type\":\"array\""
",\"items\":{\"type\":\"number\"},\"description\":\"[m]\"}},\"required\":[\"angle\",\""
"range_min\",\"range_max\",\"amplitude_max\"],\"type\":\"object\"}},\"$schema\":\"h"
"ttp://json-schema.org/draft-04/schema#\",\"type\":\"object\",\"description\":"
"\"Window analysis data estimated from scandata and resulting filter "
"parameters\",\"required\":[\"result\",\"filter\",\"settings\"]}"
)
RDB_RIEGL_WINDOW_ANALYSIS_EXAMPLE = (
"{\"settings\":{\"amplitude\":{\"sigma_factor\":4,\"additive_value\":1.0},\"rang"
"e\":{\"sigma_factor\":8,\"additive_value\":0.1}},\"result\":{\"angle\":[14.9,15"
".0,15.1,15.2,15.3,15.4,15.5,15.6,15.7,15.8,15.9],\"amplitude_sigma\":[0."
"4272844,0.4298479,0.4236816,0.4283583,0.4362353,0.4315141,0.4373984,0."
"4472798,0.4346001,0.4345487,0.4540681],\"range_sigma\":[0.01869652,0.021"
"51435,0.01747969,0.01918765,0.01945776,0.01934862,0.01955329,0.0222558"
"9,0.02229977,0.01899122,0.02009433],\"timestamp\":[408.4441,411.4443],\"r"
"ange_mean\":[0.1105621,0.1079564,0.1087088,0.1067261,0.1054582,0.109041"
"2,0.102871,0.1019044,0.1051523,0.1058445,0.1031261],\"amplitude_mean\":["
"5.347396,5.263155,5.224655,5.179926,5.097782,5.116479,5.051756,4.98347"
"3,5.007885,5.002441,4.982],\"amplitude_offset\":[1.9,1.9]},\"filter\":{\"ra"
"nge_max\":[0.424,0.425,0.426,0.427,0.428,0.428,0.429,0.43,0.431,0.431,0"
".432],\"amplitude_max\":[8.04,8.01,7.99,7.96,7.93,7.9,7.88,7.85,7.83,7.8"
",7.78],\"angle\":[14.9,15.0,15.1,15.2,15.3,15.4,15.5,15.6,15.7,15.8,15.9"
"],\"range_min\":[-0.208,-0.21,-0.212,-0.214,-0.216,-0.218,-0.219,-0.221,"
"-0.223,-0.225,-0.227]}}"
)

# Correction parameters for window glass echoes
RDB_RIEGL_WINDOW_ECHO_CORRECTION             = "riegl.window_echo_correction"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_TITLE       = "Window Echo Correction"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_DESCRIPTION = "Correction parameters for window glass echoes"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_STATUS      = "optional"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_SCHEMA = (
"{\"title\":\"Window Echo Correction\",\"properties\":{\"amplitude\":{\"properti"
"es\":{\"entries\":{\"minimum\":1,\"type\":\"integer\",\"description\":\"Number of "
"amplitude entries\"},\"minimum\":{\"minimum\":0.0,\"type\":\"number\",\"descript"
"ion\":\"Minimum amplitude in "
"dB\"},\"maximum\":{\"minimum\":0.0,\"type\":\"number\",\"description\":\"Maximum "
"amplitude in dB\"}},\"required\":[\"minimum\",\"maximum\",\"entries\"],\"type\":\""
"object\",\"description\":\"Amplitude axis of correction table\"},\"range\":{\""
"properties\":{\"entries\":{\"minimum\":1,\"type\":\"integer\",\"description\":\"Nu"
"mber of range entries\"},\"minimum\":{\"minimum\":-2.0,\"type\":\"number\",\"des"
"cription\":\"Minimum range in m\",\"maximum\":2.0},\"maximum\":{\"minimum\":-2."
"0,\"type\":\"number\",\"description\":\"Maximum range in m\",\"maximum\":2.0}},\""
"required\":[\"minimum\",\"maximum\",\"entries\"],\"type\":\"object\",\"description"
"\":\"Range axis of correction table\"},\"slices\":{\"type\":\"array\",\"items\":{"
"\"properties\":{\"amplitude\":{\"type\":\"number\",\"description\":\"Window echo "
"amplitude of slice in dB\"},\"table\":{\"minItems\":1,\"type\":\"array\",\"items"
"\":{\"minItems\":1,\"type\":\"array\",\"items\":{\"minItems\":3,\"type\":\"array\",\"i"
"tems\":{\"description\":\"Table cell (item 0: amplitude in dB, 1: range in"
" m, 2: flags)\",\"type\":\"number\"},\"description\":\"Table column (= range "
"axis)\",\"maxItems\":3},\"description\":\"Table row (= amplitude "
"axis)\"},\"description\":\"Correction table (dimension defined by the "
"'amplitude' and 'range' objects)\"}},\"required\":[\"amplitude\",\"table\"],\""
"type\":\"object\",\"description\":\"Window echo correction parameter slice\"}"
"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\""
",\"description\":\"Correction parameters for window glass "
"echoes\",\"required\":[\"amplitude\",\"range\",\"slices\"]}"
)
RDB_RIEGL_WINDOW_ECHO_CORRECTION_EXAMPLE = (
"{\"amplitude\":{\"entries\":128,\"minimum\":2,\"maximum\":20},\"range\":{\"entrie"
"s\":128,\"minimum\":-1.5060822940732335,\"maximum\":1.5060822940732335},\"sl"
"ices\":[{\"amplitude\":1.5,\"table\":[[[6.23,0.3535,1]],[[5.54,0.72375,1]]]"
"},{\"amplitude\":2.0,\"table\":[[[6.23,0.3535,1]],[[5.54,0.72375,1]]]}]}"
)
