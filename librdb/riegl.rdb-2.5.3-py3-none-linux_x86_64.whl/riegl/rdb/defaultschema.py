#
#*******************************************************************************
#
#  Copyright 2025 RIEGL Laser Measurement Systems
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
#  SPDX-License-Identifier: Apache-2.0
#
#*******************************************************************************
#
"""
*******************************************************************************
*
* \author RIEGL LMS GmbH, Austria
* \brief  Description of RIEGL RDB 2 database file contents
*
*  NOTE: All information in this file is preliminary, since the
*        definition of the database schemas is not yet complete.
*
*******************************************************************************
"""

# File schema version
RDB_SCHEMA_VERSION = "f274d50d"
RDB_SCHEMA_DATE = "2023-11-30"

# Schema for ".avg.fwa" files
RDB_SCHEMA_RIEGL_AVG_FWA = (
"{\"attributes\":[\"riegl.id*\",\"riegl.amplitude\",\"riegl.gain\",\"riegl.raw_r"
"ange\",\"riegl.wfm_echo_time_offset\",\"riegl.wfm_sbl_id\",\"riegl.deviation"
"?\",\"riegl.pulse_width?\"],\"extension\":\"avg.fwa\",\"identifier\":\"avg.fwa\","
"\"metadata\":[]}"
)

# Schema for ".avg.sbx" files
RDB_SCHEMA_RIEGL_AVG_SBX = (
"{\"attributes\":[\"riegl.id*\",\"riegl.wfm_sbl_channel\",\"riegl.wfm_sbl_mean"
"\",\"riegl.wfm_sbl_std_dev\",\"riegl.wfm_sbl_time_offset\",\"riegl.wfm_sda_f"
"irst\",\"riegl.wfm_sda_count\"],\"extension\":\"avg.sbx\",\"identifier\":\"avg.s"
"bx\",\"metadata\":[]}"
)

# Schema for ".avg.sidx" files
RDB_SCHEMA_RIEGL_AVG_SIDX = (
"{\"attributes\":[\"riegl.id\",\"riegl.shot_timestamp_hr*\",\"riegl.wfm_sbl_fi"
"rst\",\"riegl.wfm_sbl_count\",\"riegl.echo_first?\",\"riegl.echo_count?\"],\"e"
"xtension\":\"avg.sidx\",\"identifier\":\"avg.sidx\",\"metadata\":[\"riegl.shot_i"
"nfo\",\"riegl.waveform_info\",\"riegl.echo_info?\",\"riegl.waveform_averagin"
"g_settings\"]}"
)

# Schema for ".avg.sp{C}" files
RDB_SCHEMA_RIEGL_AVG_SPC = (
"{\"attributes\":[\"riegl.id*\",\"riegl.wfm_sample_value\"],\"extension\":\"avg."
"sp{C}\",\"identifier\":\"avg.sp{C}\",\"metadata\":[]}"
)

# Schema for ".cpx" files
RDB_SCHEMA_RIEGL_CPX = (
"{\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_accuracies\",\"riegl.c"
"ontrol_object_type\",\"riegl.zenith_vector\",\"riegl.used_for_adjustment\","
"\"riegl.acquisition_date?\",\"riegl.cp_surface_inclination_angle\",\"riegl."
"cp_surface_inclination_tolerance_angle\",\"riegl.cp_search_radius?\",\"rie"
"gl.cp_maximum_distance?\",\"riegl.import_line_number\"],\"extension\":\"cpx\""
",\"identifier\":\"cpx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.control_object_"
"catalog\",\"riegl.item_names\",\"riegl.imported_files\"]}"
)

# Schema for ".doix" files
RDB_SCHEMA_RIEGL_DOIX = (
"{\"attributes\":[\"riegl.id\",\"riegl.shot_origin\",\"riegl.shot_direction*\","
"\"riegl.scan_line_index\",\"riegl.shot_index_line\"],\"extension\":\"doix\",\"i"
"dentifier\":\"doix\",\"metadata\":[]}"
)

# Schema for ".eifx" files
RDB_SCHEMA_RIEGL_EIFX = (
"{\"attributes\":[\"riegl.id\",\"riegl.event_timestamp*\",\"riegl.event_index?"
"\",\"riegl.event_pulse_width?\",\"riegl.event_fake_pulse?\",\"riegl.raw_line"
"_angle?\",\"riegl.raw_frame_angle?\"],\"extension\":\"eifx\",\"identifier\":\"ei"
"fx\",\"metadata\":[\"riegl.device?\",\"riegl.time_base\",\"riegl.ttip_configur"
"ation?\"]}"
)

# Schema for ".epfx" files
RDB_SCHEMA_RIEGL_EPFX = (
"{\"attributes\":[\"riegl.id\",\"riegl.event_timestamp*\",\"riegl.event_index?"
"\",\"riegl.event_pulse_width?\",\"riegl.event_fake_pulse?\",\"riegl.raw_line"
"_angle?\",\"riegl.raw_frame_angle?\",\"riegl.xyz\",\"riegl.model_cs_axis_x\","
"\"riegl.model_cs_axis_y\",\"riegl.model_cs_axis_z\"],\"extension\":\"epfx\",\"i"
"dentifier\":\"epfx\",\"metadata\":[\"riegl.device?\",\"riegl.geo_tag\",\"riegl.t"
"ime_base\",\"riegl.ttip_configuration?\"]}"
)

# Schema for ".fwa" files
RDB_SCHEMA_RIEGL_FWA = (
"{\"attributes\":[\"riegl.id*\",\"riegl.amplitude\",\"riegl.gain\",\"riegl.raw_r"
"ange\",\"riegl.wfm_echo_time_offset\",\"riegl.wfm_sbl_id\",\"riegl.deviation"
"?\",\"riegl.pulse_width?\",\"riegl.extinction?\",\"riegl.svb_amplitude_volum"
"etric?\",\"riegl.svb_surface?\",\"riegl.svb_bottom?\",\"riegl.svb_path_lengt"
"h?\"],\"extension\":\"fwa\",\"identifier\":\"fwa\",\"metadata\":[]}"
)

# Schema for ".llhx" files
RDB_SCHEMA_RIEGL_LLHX = (
"{\"attributes\":[\"riegl.pof_latitude\",\"riegl.pof_longitude\",\"riegl.pof_h"
"eight\",\"riegl.pof_timestamp*\",\"riegl.pof_accuracy_north\",\"riegl.pof_ac"
"curacy_east\",\"riegl.pof_accuracy_down\",\"riegl.pof_pdop\",\"riegl.pof_hdo"
"p\",\"riegl.pof_vdop\",\"riegl.pof_age_of_corrections\",\"riegl.pof_baseline"
"_length\",\"riegl.pof_solution_gnss\",\"riegl.pof_satellites_gnss\",\"riegl."
"id\"],\"extension\":\"llhx\",\"identifier\":\"llhx\",\"metadata\":[\"riegl.device?"
"\",\"riegl.geo_tag\",\"riegl.time_base\"]}"
)

# Schema for ".mpx" files
RDB_SCHEMA_RIEGL_MPX = (
"{\"attributes\":[\"riegl.id\",\"riegl.xy_map*\",\"riegl.amplitude\",\"riegl.ref"
"lectance\",\"riegl.deviation\",\"riegl.timestamp_min?\",\"riegl.timestamp_ma"
"x?\",\"riegl.point_count\",\"riegl.point_count_grid_cell\",\"riegl.pixel_lin"
"ear_sums?\",\"riegl.pixel_square_sums?\",\"riegl.height_min\",\"riegl.height"
"_max\",\"riegl.height_mean\",\"riegl.height_center\",\"riegl.surface_normal\""
",\"riegl.pca_thickness\",\"riegl.std_dev\",\"riegl.voxel_count\"],\"extension"
"\":\"mpx\",\"identifier\":\"mpx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.pixel_in"
"fo\",\"riegl.time_base?\"]}"
)

# Schema for ".mtch" files
RDB_SCHEMA_RIEGL_MTCH = (
"{\"attributes\":[\"riegl.xyz*\",\"riegl.plane_references\",\"riegl.plane_patc"
"h_distance\",\"riegl.plane_patch_lateral_distance\",\"riegl.plane_patch_li"
"nk_vector\",\"riegl.id\"],\"extension\":\"mtch\",\"identifier\":\"mtch\",\"metadat"
"a\":[\"riegl.plane_patch_matching\"]}"
)

# Schema for ".mvx" files
RDB_SCHEMA_RIEGL_MVX = (
"{\"attributes\":[\"riegl.id\",\"riegl.xyz_map*\",\"riegl.amplitude\",\"riegl.re"
"flectance\",\"riegl.deviation\",\"riegl.timestamp_min?\",\"riegl.timestamp_m"
"ax?\",\"riegl.point_count\",\"riegl.shape_id\",\"riegl.covariances?\",\"riegl."
"pca_axis_min\",\"riegl.pca_axis_max\",\"riegl.pca_extents\",\"riegl.std_dev\""
",\"riegl.voxel_collapsed\"],\"extension\":\"mvx\",\"identifier\":\"mvx\",\"metada"
"ta\":[\"riegl.geo_tag\",\"riegl.time_base?\",\"riegl.voxel_info\"]}"
)

# Schema for ".obsx" files
RDB_SCHEMA_RIEGL_OBSX = (
"{\"attributes\":[\"riegl.xyz\",\"riegl.surface_normal\",\"riegl.plane_slope_c"
"lass?\",\"riegl.id*\",\"riegl.sda1_plane_patch_one\",\"riegl.sda1_plane_patc"
"h_two\",\"riegl.sda1_source_file_one\",\"riegl.sda1_source_file_two\"],\"ext"
"ension\":\"obsx\",\"identifier\":\"obsx\",\"metadata\":[\"riegl.geo_tag\",\"riegl."
"plane_slope_class_info?\",\"riegl.pointcloud_info\",\"riegl.sda1_source_fi"
"les\"]}"
)

# Schema for ".opefx" files
RDB_SCHEMA_RIEGL_OPEFX = (
"{\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_accuracies?\",\"riegl."
"surface_normal\",\"riegl.plane_up\",\"riegl.point_count\",\"riegl.std_dev\",\""
"riegl.plane_width\",\"riegl.plane_height\",\"riegl.plane_confidence_normal"
"\",\"riegl.model_fit_quality?\",\"riegl.used_for_adjustment\",\"riegl.xyz_so"
"cs\",\"riegl.timestamp\",\"riegl.mirror_facet\",\"riegl.platform_rpy_ROCS_NE"
"D\",\"riegl.platform_drpy_ROCS_NED\",\"riegl.platform_xyz_ROCS_ENU\",\"riegl"
".platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_vector\",\"riegl.raw_range\",\"r"
"iegl.raw_frame_angle\",\"riegl.raw_line_angle\",\"riegl.reference_object_i"
"d\"],\"extension\":\"opefx\",\"identifier\":\"opefx\",\"metadata\":[\"riegl.device"
"\",\"riegl.device_geometry\",\"riegl.geo_tag\",\"riegl.georeferencing_parame"
"ters\",\"riegl.scan_pattern?\",\"riegl.time_base\",\"riegl.item_names\",\"rieg"
"l.control_object_reference_file\"]}"
)

# Schema for ".opp" files
RDB_SCHEMA_RIEGL_OPP = (
"{\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_accuracies?\",\"riegl."
"surface_normal\",\"riegl.plane_up\",\"riegl.point_count\",\"riegl.std_dev\",\""
"riegl.plane_width\",\"riegl.plane_height\",\"riegl.plane_confidence_normal"
"\",\"riegl.model_fit_quality?\",\"riegl.used_for_adjustment\",\"riegl.xyz_so"
"cs\",\"riegl.timestamp\",\"riegl.mirror_facet\",\"riegl.platform_rpy_ROCS_NE"
"D\",\"riegl.platform_drpy_ROCS_NED\",\"riegl.platform_xyz_ROCS_ENU\",\"riegl"
".platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_vector\",\"riegl.raw_range\",\"r"
"iegl.raw_frame_angle\",\"riegl.raw_line_angle\",\"riegl.reference_object_i"
"d\"],\"extension\":\"opp\",\"identifier\":\"opp\",\"metadata\":[\"riegl.device\",\"r"
"iegl.device_geometry\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters"
"\",\"riegl.scan_pattern?\",\"riegl.time_base\",\"riegl.item_names\",\"riegl.co"
"ntrol_object_reference_file\"]}"
)

# Schema for ".opx" files
RDB_SCHEMA_RIEGL_OPX = (
"{\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.control_object_type\",\"ri"
"egl.model_cs_axis_x?\",\"riegl.model_cs_axis_y?\",\"riegl.model_cs_axis_z?"
"\",\"riegl.model_fit_quality?\",\"riegl.obs_confidence_xy?\",\"riegl.obs_con"
"fidence_z?\",\"riegl.obs_signal_confidence_rot?\",\"riegl.obs_confidence_r"
"ange?\",\"riegl.obs_confidence_theta?\",\"riegl.obs_confidence_phi?\",\"rieg"
"l.point_count?\",\"riegl.used_for_adjustment\",\"riegl.xyz_socs\",\"riegl.ti"
"mestamp\",\"riegl.mirror_facet\",\"riegl.platform_rpy_ROCS_NED\",\"riegl.pla"
"tform_drpy_ROCS_NED\",\"riegl.platform_xyz_ROCS_ENU\",\"riegl.platform_dxy"
"z_ROCS_ENU\",\"riegl.sda.shift_vector\",\"riegl.raw_range\",\"riegl.raw_fram"
"e_angle\",\"riegl.raw_line_angle\",\"riegl.reference_object_id\"],\"extensio"
"n\":\"opx\",\"identifier\":\"opx\",\"metadata\":[\"riegl.device\",\"riegl.device_g"
"eometry\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"riegl.scan"
"_pattern?\",\"riegl.time_base\",\"riegl.control_object_catalog\",\"riegl.ite"
"m_names\",\"riegl.control_object_reference_file\"]}"
)

# Schema for ".owp" files
RDB_SCHEMA_RIEGL_OWP = (
"{\"attributes\":[\"riegl.id*\",\"riegl.raw_range\",\"riegl.amplitude\",\"riegl."
"deviation\",\"riegl.gain\"],\"extension\":\"owp\",\"identifier\":\"owp\",\"metadat"
"a\":[]}"
)

# Schema for ".pefx" files
RDB_SCHEMA_RIEGL_PEFX = (
"{\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_accuracies?\",\"riegl."
"surface_normal\",\"riegl.plane_up\",\"riegl.std_dev\",\"riegl.plane_confiden"
"ce_normal\",\"riegl.plane_width\",\"riegl.plane_height\",\"riegl.vertex_firs"
"t\",\"riegl.vertex_count\",\"riegl.used_for_adjustment\",\"riegl.acquisition"
"_date?\",\"riegl.import_line_number\",\"riegl.import_line_count\"],\"extensi"
"on\":\"pefx\",\"identifier\":\"pefx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.vert"
"ex_info\",\"riegl.item_names\",\"riegl.imported_files\"]}"
)

# Schema for ".pofx" files
RDB_SCHEMA_RIEGL_PROJECT_POFX = (
"{\"attributes\":[\"riegl.id\",\"riegl.pof_timestamp*\",\"riegl.pof_latitude\","
"\"riegl.pof_longitude\",\"riegl.pof_height\",\"riegl.pof_roll\",\"riegl.pof_p"
"itch\",\"riegl.pof_yaw\",\"riegl.pof_path_length?\"],\"extension\":\"pofx\",\"id"
"entifier\":\"project.pofx\",\"metadata\":[\"riegl.device?\",\"riegl.time_base\""
",\"riegl.trajectory_info\"]}"
)

# Schema for ".pofx" files
RDB_SCHEMA_RIEGL_SCAN_POFX = (
"{\"attributes\":[\"riegl.id\",\"riegl.pof_timestamp*\",\"riegl.pof_latitude\","
"\"riegl.pof_longitude\",\"riegl.pof_height\",\"riegl.pof_roll\",\"riegl.pof_p"
"itch\",\"riegl.pof_yaw\",\"riegl.pof_path_length?\",\"riegl.pof_xyz\",\"riegl."
"pof_roll_ned\",\"riegl.pof_pitch_ned\",\"riegl.pof_yaw_ned\"],\"extension\":\""
"pofx\",\"identifier\":\"scan.pofx\",\"metadata\":[\"riegl.device?\",\"riegl.time"
"_base\",\"riegl.geo_tag\",\"riegl.trajectory_info\"]}"
)

# Schema for ".poqx" files
RDB_SCHEMA_RIEGL_PROJECT_POQX = (
"{\"attributes\":[\"riegl.id\",\"riegl.pof_timestamp*\",\"riegl.pof_accuracy_n"
"orth\",\"riegl.pof_accuracy_east\",\"riegl.pof_accuracy_down\",\"riegl.pof_a"
"ccuracy_roll\",\"riegl.pof_accuracy_pitch\",\"riegl.pof_accuracy_yaw\",\"rie"
"gl.pof_path_length?\",\"riegl.pof_pdop\",\"riegl.pof_satellites_gnss?\",\"ri"
"egl.pof_satellites_gps?\",\"riegl.pof_satellites_glonass?\",\"riegl.pof_sa"
"tellites_beidou?\",\"riegl.pof_satellites_galileo?\",\"riegl.pof_satellite"
"s_qzss?\"],\"extension\":\"poqx\",\"identifier\":\"project.poqx\",\"metadata\":[\""
"riegl.time_base\",\"riegl.trajectory_info\"]}"
)

# Schema for ".poqx" files
RDB_SCHEMA_RIEGL_SCAN_POQX = (
"{\"attributes\":[\"riegl.id\",\"riegl.pof_timestamp*\",\"riegl.pof_accuracy_n"
"orth\",\"riegl.pof_accuracy_east\",\"riegl.pof_accuracy_down\",\"riegl.pof_a"
"ccuracy_roll\",\"riegl.pof_accuracy_pitch\",\"riegl.pof_accuracy_yaw\",\"rie"
"gl.pof_path_length?\",\"riegl.pof_pdop\",\"riegl.pof_satellites_gnss?\",\"ri"
"egl.pof_satellites_gps?\",\"riegl.pof_satellites_glonass?\",\"riegl.pof_sa"
"tellites_beidou?\",\"riegl.pof_satellites_galileo?\",\"riegl.pof_satellite"
"s_qzss?\"],\"extension\":\"poqx\",\"identifier\":\"scan.poqx\",\"metadata\":[\"rie"
"gl.time_base\",\"riegl.trajectory_info\"]}"
)

# Schema for ".ppx" files
RDB_SCHEMA_RIEGL_PPX = (
"{\"attributes\":[\"riegl.id\",\"riegl.pps_timestamp_intern*\",\"riegl.pps_tim"
"estamp_extern\"],\"extension\":\"ppx\",\"identifier\":\"ppx\",\"metadata\":[\"rieg"
"l.device\",\"riegl.time_base\"]}"
)

# Schema for ".ptch" files
RDB_SCHEMA_RIEGL_PROJECT_PTCH = (
"{\"attributes\":[\"riegl.xyz*\",\"riegl.surface_normal\",\"riegl.plane_up\",\"r"
"iegl.reflectance?\",\"riegl.point_count\",\"riegl.std_dev\",\"riegl.plane_wi"
"dth\",\"riegl.plane_height\",\"riegl.plane_count\",\"riegl.covariances\",\"rie"
"gl.id\"],\"extension\":\"ptch\",\"identifier\":\"project.ptch\",\"metadata\":[\"ri"
"egl.device\",\"riegl.geo_tag?\",\"riegl.scan_pattern?\",\"riegl.time_base?\","
"\"riegl.plane_patch_statistics?\"]}"
)

# Schema for ".ptch" files
RDB_SCHEMA_RIEGL_SCAN_PTCH = (
"{\"attributes\":[\"riegl.xyz*\",\"riegl.xyz_socs\",\"riegl.direction?\",\"riegl"
".direction_medium?\",\"riegl.direction_coarse?\",\"riegl.surface_normal\",\""
"riegl.plane_up\",\"riegl.timestamp\",\"riegl.reflectance?\",\"riegl.point_co"
"unt\",\"riegl.std_dev\",\"riegl.plane_width\",\"riegl.plane_height\",\"riegl.p"
"lane_count\",\"riegl.mirror_facet\",\"riegl.covariances\",\"riegl.id\",\"riegl"
".plane_slope_class?\",\"riegl.plane_occupancy\",\"riegl.plane_confidence_n"
"ormal\",\"riegl.plane_cog_link\",\"riegl.match_count\",\"riegl.platform_rpy_"
"ROCS_NED\",\"riegl.platform_xyz_ROCS_ENU\",\"riegl.platform_drpy_ROCS_NED\""
",\"riegl.platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_vector\",\"riegl.raw_ra"
"nge\",\"riegl.raw_frame_angle\",\"riegl.raw_line_angle\"],\"extension\":\"ptch"
"\",\"identifier\":\"scan.ptch\",\"metadata\":[\"riegl.device\",\"riegl.device_ge"
"ometry\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"riegl.scan_"
"pattern?\",\"riegl.time_base\",\"riegl.plane_patch_statistics?\",\"riegl.pla"
"ne_slope_class_info?\"]}"
)

# Schema for ".ptch" files
RDB_SCHEMA_RIEGL_SCANPOS_PTCH = (
"{\"attributes\":[\"riegl.xyz*\",\"riegl.surface_normal\",\"riegl.plane_up\",\"r"
"iegl.reflectance?\",\"riegl.point_count\",\"riegl.std_dev\",\"riegl.plane_wi"
"dth\",\"riegl.plane_height\",\"riegl.plane_count\",\"riegl.covariances\",\"rie"
"gl.id\"],\"extension\":\"ptch\",\"identifier\":\"scanpos.ptch\",\"metadata\":[\"ri"
"egl.device\",\"riegl.geo_tag?\",\"riegl.scan_pattern?\",\"riegl.time_base?\","
"\"riegl.plane_patch_statistics?\"]}"
)

# Schema for ".rdbx" files
RDB_SCHEMA_RIEGL_RDBX = (
"{\"attributes\":[\"riegl.id\",\"riegl.timestamp\",\"riegl.xyz*\",\"riegl.xyz_so"
"cs\",\"riegl.direction_medium?\",\"riegl.direction?\",\"riegl.amplitude\",\"ri"
"egl.reflectance?\",\"riegl.deviation?\",\"riegl.pulse_width?\",\"riegl.targe"
"t_index\",\"riegl.target_count\",\"riegl.mirror_facet?\",\"riegl.scan_segmen"
"t?\",\"riegl.mta_uncertain_point?\",\"riegl.mta_zone?\",\"riegl.window_echo_"
"impact_corrected?\",\"riegl.dyntrig_uncertain_point?\",\"riegl.rgba?\",\"rie"
"gl.class?\",\"riegl.start_of_scan_line?\",\"riegl.end_of_scan_line?\",\"rieg"
"l.source_indicator?\",\"riegl.fwa?\",\"riegl.waveform_available?\",\"riegl.w"
"fm_sbl_id?\",\"riegl.wfm_echo_time_offset?\",\"riegl.scan_angle\",\"riegl.sc"
"an_direction\",\"riegl.source_index?\",\"riegl.scan_line_index?\",\"riegl.sh"
"ot_index_line?\",\"riegl.hydro_intersection_point?\",\"riegl.hydro_interse"
"ction_normal?\",\"riegl.extinction?\",\"riegl.svb_amplitude_volumetric?\",\""
"riegl.svb_surface?\",\"riegl.svb_bottom?\",\"riegl.svb_path_length?\"],\"ext"
"ension\":\"rdbx\",\"identifier\":\"rdbx\",\"metadata\":[\"riegl.atmosphere\",\"rie"
"gl.beam_geometry\",\"riegl.device_geometry\",\"riegl.device\",\"riegl.gaussi"
"an_decomposition?\",\"riegl.exponential_decomposition?\",\"riegl.geo_tag\","
"\"riegl.georeferencing_parameters\",\"riegl.mta_settings?\",\"riegl.near_ra"
"nge_correction?\",\"riegl.noise_estimates?\",\"riegl.angular_notch_filter?"
"\",\"riegl.notch_filter?\",\"riegl.pointcloud_info?\",\"riegl.pulse_position"
"_modulation?\",\"riegl.range_statistics?\",\"riegl.receiver_internals?\",\"r"
"iegl.reflectance_calculation?\",\"riegl.reflectance_correction?\",\"riegl."
"scan_pattern\",\"riegl.time_base\",\"riegl.waveform_settings?\",\"riegl.wind"
"ow_analysis?\",\"riegl.window_echo_correction?\"]}"
)

# Schema for ".rmvx" files
RDB_SCHEMA_RIEGL_RMVX = (
"{\"attributes\":[\"riegl.id\",\"riegl.voxel_index*\",\"riegl.amplitude\",\"rieg"
"l.reflectance\",\"riegl.deviation\",\"riegl.direction_medium\",\"riegl.point"
"_count\",\"riegl.voxel_linear_sums\",\"riegl.voxel_square_sums\",\"riegl.tim"
"estamp_min?\",\"riegl.timestamp_max?\"],\"extension\":\"rmvx\",\"identifier\":\""
"rmvx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.voxel_info\",\"riegl.time_base?"
"\"]}"
)

# Schema for ".s10x" files
RDB_SCHEMA_RIEGL_S10X = (
"{\"attributes\":[\"riegl.id\",\"riegl.timestamp*\",\"riegl.frame_angle_coarse"
"\",\"riegl.gyroscope_raw\",\"riegl.accelerometer_raw\",\"riegl.magnetic_fiel"
"d_sensor_raw\",\"riegl.gyroscope\",\"riegl.accelerometer\",\"riegl.magnetic_"
"field_sensor\",\"riegl.barometric_height_amsl\",\"riegl.temperature\",\"rieg"
"l.line_scan_active\",\"riegl.frame_scan_active\",\"riegl.data_acquisition_"
"active\"],\"extension\":\"s10x\",\"identifier\":\"s10x\",\"metadata\":[\"riegl.tim"
"e_base\",\"riegl.device?\",\"riegl.pose_sensors\"]}"
)

# Schema for ".sbx" files
RDB_SCHEMA_RIEGL_SBX = (
"{\"attributes\":[\"riegl.id*\",\"riegl.wfm_sbl_channel\",\"riegl.wfm_sbl_mean"
"\",\"riegl.wfm_sbl_std_dev\",\"riegl.wfm_sbl_time_offset\",\"riegl.wfm_sda_f"
"irst\",\"riegl.wfm_sda_count\"],\"extension\":\"sbx\",\"identifier\":\"sbx\",\"met"
"adata\":[]}"
)

# Schema for ".sdcx" files
RDB_SCHEMA_RIEGL_SDCX = (
"{\"attributes\":[\"riegl.id\",\"riegl.timestamp*\",\"riegl.xyz\",\"riegl.amplit"
"ude\",\"riegl.reflectance?\",\"riegl.deviation?\",\"riegl.pulse_width?\",\"rie"
"gl.target_index\",\"riegl.target_count\",\"riegl.mirror_facet?\",\"riegl.sca"
"n_segment?\",\"riegl.mta_uncertain_point?\",\"riegl.mta_zone?\",\"riegl.wind"
"ow_echo_impact_corrected?\",\"riegl.dyntrig_uncertain_point?\",\"riegl.cla"
"ss?\",\"riegl.start_of_scan_line?\",\"riegl.end_of_scan_line?\",\"riegl.sour"
"ce_indicator?\",\"riegl.fwa?\",\"riegl.waveform_available?\",\"riegl.wfm_sbl"
"_id?\",\"riegl.wfm_echo_time_offset?\",\"riegl.extinction?\",\"riegl.svb_amp"
"litude_volumetric?\",\"riegl.svb_surface?\",\"riegl.svb_bottom?\",\"riegl.sv"
"b_path_length?\"],\"extension\":\"sdcx\",\"identifier\":\"sdcx\",\"metadata\":[\"r"
"iegl.atmosphere\",\"riegl.beam_geometry\",\"riegl.device_geometry\",\"riegl."
"device\",\"riegl.gaussian_decomposition?\",\"riegl.exponential_decompositi"
"on?\",\"riegl.mta_settings?\",\"riegl.near_range_correction?\",\"riegl.noise"
"_estimates?\",\"riegl.angular_notch_filter?\",\"riegl.notch_filter?\",\"rieg"
"l.pointcloud_info?\",\"riegl.pulse_position_modulation?\",\"riegl.range_st"
"atistics?\",\"riegl.receiver_internals?\",\"riegl.reflectance_calculation?"
"\",\"riegl.reflectance_correction?\",\"riegl.scan_pattern\",\"riegl.time_bas"
"e\",\"riegl.window_analysis?\",\"riegl.window_echo_correction?\"]}"
)

# Schema for ".sidx" files
RDB_SCHEMA_RIEGL_SIDX = (
"{\"attributes\":[\"riegl.id\",\"riegl.shot_timestamp_hr*\",\"riegl.echo_first"
"\",\"riegl.echo_count\"],\"extension\":\"sidx\",\"identifier\":\"sidx\",\"metadata"
"\":[\"riegl.shot_info\",\"riegl.echo_info\"]}"
)

# Schema for ".sodx" files
RDB_SCHEMA_RIEGL_SODX = (
"{\"attributes\":[\"riegl.id\",\"riegl.shot_timestamp_hr*\",\"riegl.mirror_fac"
"et\",\"riegl.scan_segment\",\"riegl.start_of_scan_line\",\"riegl.line_angle_"
"coarse\",\"riegl.shot_origin\",\"riegl.shot_biaxial_shift?\",\"riegl.shot_di"
"rection\",\"riegl.shot_direction_levelled?\",\"riegl.wfm_sbl_first?\",\"rieg"
"l.wfm_sbl_count?\",\"riegl.echo_first?\",\"riegl.echo_count?\"],\"extension\""
":\"sodx\",\"identifier\":\"sodx\",\"metadata\":[\"riegl.atmosphere\",\"riegl.devi"
"ce\",\"riegl.device_geometry\",\"riegl.device_output_limits\",\"riegl.beam_g"
"eometry\",\"riegl.near_range_correction?\",\"riegl.window_echo_correction?"
"\",\"riegl.receiver_internals?\",\"riegl.gaussian_decomposition?\",\"riegl.e"
"xponential_decomposition?\",\"riegl.mta_settings?\",\"riegl.pulse_position"
"_modulation?\",\"riegl.notch_filter?\",\"riegl.reflectance_calculation?\",\""
"riegl.scan_pattern\",\"riegl.time_base\",\"riegl.waveform_info?\",\"riegl.ec"
"ho_info?\"]}"
)

# Schema for ".sp{C}" files
RDB_SCHEMA_RIEGL_SPC = (
"{\"attributes\":[\"riegl.id*\",\"riegl.wfm_sample_value\"],\"extension\":\"sp{C"
"}\",\"identifier\":\"sp{C}\",\"metadata\":[]}"
)

# Schema for ".vtx" files
RDB_SCHEMA_RIEGL_VTX = (
"{\"attributes\":[\"riegl.id*\",\"riegl.xyz\",\"riegl.xyz_accuracies?\"],\"exten"
"sion\":\"vtx\",\"identifier\":\"vtx\",\"metadata\":[\"riegl.geo_tag\"]}"
)

# Schema for ".vxls" files
RDB_SCHEMA_RIEGL_VXLS = (
"{\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.covariances\",\"riegl.pca_"
"axis_max\",\"riegl.pca_axis_min\",\"riegl.pca_extents\",\"riegl.point_count\""
",\"riegl.reflectance\",\"riegl.shape_id\",\"riegl.voxel_collapsed\",\"riegl.s"
"td_dev?\"],\"extension\":\"vxls\",\"identifier\":\"vxls\",\"metadata\":[\"riegl.vo"
"xel_info\",\"riegl.geo_tag?\"]}"
)

# Schema for ".wdcx" files
RDB_SCHEMA_RIEGL_WDCX = (
"{\"attributes\":[\"riegl.id\",\"riegl.timestamp\",\"riegl.xyz*\",\"riegl.xyz_so"
"cs\",\"riegl.direction_medium?\",\"riegl.direction?\",\"riegl.amplitude\",\"ri"
"egl.reflectance?\",\"riegl.deviation?\",\"riegl.pulse_width?\",\"riegl.targe"
"t_index\",\"riegl.target_count\",\"riegl.mirror_facet?\",\"riegl.scan_segmen"
"t?\",\"riegl.mta_uncertain_point?\",\"riegl.mta_zone?\",\"riegl.window_echo_"
"impact_corrected?\",\"riegl.dyntrig_uncertain_point?\",\"riegl.rgba?\",\"rie"
"gl.class?\",\"riegl.start_of_scan_line?\",\"riegl.end_of_scan_line?\",\"rieg"
"l.source_indicator?\",\"riegl.fwa?\",\"riegl.waveform_available?\",\"riegl.w"
"fm_sbl_id?\",\"riegl.wfm_echo_time_offset?\",\"riegl.scan_angle\",\"riegl.sc"
"an_direction\",\"riegl.source_index?\",\"riegl.scan_line_index?\",\"riegl.sh"
"ot_index_line?\",\"riegl.hydro_intersection_point?\",\"riegl.hydro_interse"
"ction_normal?\",\"riegl.extinction?\",\"riegl.svb_amplitude_volumetric?\",\""
"riegl.svb_surface?\",\"riegl.svb_bottom?\",\"riegl.svb_path_length?\"],\"ext"
"ension\":\"wdcx\",\"identifier\":\"wdcx\",\"metadata\":[\"riegl.atmosphere\",\"rie"
"gl.beam_geometry\",\"riegl.device_geometry\",\"riegl.device\",\"riegl.gaussi"
"an_decomposition?\",\"riegl.exponential_decomposition?\",\"riegl.geo_tag\","
"\"riegl.georeferencing_parameters\",\"riegl.mta_settings?\",\"riegl.near_ra"
"nge_correction?\",\"riegl.noise_estimates?\",\"riegl.angular_notch_filter?"
"\",\"riegl.notch_filter?\",\"riegl.pointcloud_info?\",\"riegl.pulse_position"
"_modulation?\",\"riegl.range_statistics?\",\"riegl.receiver_internals?\",\"r"
"iegl.reflectance_calculation?\",\"riegl.reflectance_correction?\",\"riegl."
"scan_pattern\",\"riegl.time_base\",\"riegl.waveform_settings?\",\"riegl.wind"
"ow_analysis?\",\"riegl.window_echo_correction?\"]}"
)

# Schema for ".wex" files
RDB_SCHEMA_RIEGL_WEX = (
"{\"attributes\":[\"riegl.id\",\"riegl.timestamp*\",\"riegl.wex_filter_valid\","
"\"riegl.wex_point_count\",\"riegl.wex_amplitude\",\"riegl.wex_amplitude_std"
"_dev\",\"riegl.wex_amplitude_min\",\"riegl.wex_amplitude_max\",\"riegl.wex_a"
"mplitude_offset\",\"riegl.wex_deviation\",\"riegl.wex_deviation_std_dev\",\""
"riegl.wex_deviation_min\",\"riegl.wex_deviation_max\",\"riegl.wex_range\",\""
"riegl.wex_range_std_dev\",\"riegl.wex_range_min\",\"riegl.wex_range_max\",\""
"riegl.wex_filter_range_min\",\"riegl.wex_filter_range_max\",\"riegl.wex_fi"
"lter_amplitude_max\"],\"extension\":\"wex\",\"identifier\":\"wex\",\"metadata\":["
"\"riegl.device\",\"riegl.notch_filter\",\"riegl.window_analysis\"]}"
)

# Table of all RDB file schema strings
RDB_SCHEMA_ARRAY = [
    RDB_SCHEMA_RIEGL_AVG_FWA,
    RDB_SCHEMA_RIEGL_AVG_SBX,
    RDB_SCHEMA_RIEGL_AVG_SIDX,
    RDB_SCHEMA_RIEGL_AVG_SPC,
    RDB_SCHEMA_RIEGL_CPX,
    RDB_SCHEMA_RIEGL_DOIX,
    RDB_SCHEMA_RIEGL_EIFX,
    RDB_SCHEMA_RIEGL_EPFX,
    RDB_SCHEMA_RIEGL_FWA,
    RDB_SCHEMA_RIEGL_LLHX,
    RDB_SCHEMA_RIEGL_MPX,
    RDB_SCHEMA_RIEGL_MTCH,
    RDB_SCHEMA_RIEGL_MVX,
    RDB_SCHEMA_RIEGL_OBSX,
    RDB_SCHEMA_RIEGL_OPEFX,
    RDB_SCHEMA_RIEGL_OPP,
    RDB_SCHEMA_RIEGL_OPX,
    RDB_SCHEMA_RIEGL_OWP,
    RDB_SCHEMA_RIEGL_PEFX,
    RDB_SCHEMA_RIEGL_PROJECT_POFX,
    RDB_SCHEMA_RIEGL_SCAN_POFX,
    RDB_SCHEMA_RIEGL_PROJECT_POQX,
    RDB_SCHEMA_RIEGL_SCAN_POQX,
    RDB_SCHEMA_RIEGL_PPX,
    RDB_SCHEMA_RIEGL_PROJECT_PTCH,
    RDB_SCHEMA_RIEGL_SCAN_PTCH,
    RDB_SCHEMA_RIEGL_SCANPOS_PTCH,
    RDB_SCHEMA_RIEGL_RDBX,
    RDB_SCHEMA_RIEGL_RMVX,
    RDB_SCHEMA_RIEGL_S10X,
    RDB_SCHEMA_RIEGL_SBX,
    RDB_SCHEMA_RIEGL_SDCX,
    RDB_SCHEMA_RIEGL_SIDX,
    RDB_SCHEMA_RIEGL_SODX,
    RDB_SCHEMA_RIEGL_SPC,
    RDB_SCHEMA_RIEGL_VTX,
    RDB_SCHEMA_RIEGL_VXLS,
    RDB_SCHEMA_RIEGL_WDCX,
    RDB_SCHEMA_RIEGL_WEX
]
