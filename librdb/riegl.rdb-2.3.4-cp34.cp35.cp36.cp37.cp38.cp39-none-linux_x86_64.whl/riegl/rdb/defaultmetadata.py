#
#*******************************************************************************
#
#  Copyright 2020 RIEGL Laser Measurement Systems
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
#  SPDX-License-Identifier: Apache-2.0
#
#*******************************************************************************
#
"""
*******************************************************************************
*
* \author  RIEGL LMS GmbH, Austria
* \brief   Description of RIEGL RDB 2 database meta data items.
* \version 2015-10-27/AW: Initial version
* \version 2015-11-25/AW: Item "Geo Tag" added
* \version 2016-10-27/AW: Item "Voxel Information" added
* \version 2016-11-17/AW: Item "Voxel Information" updated
* \version 2016-12-12/AW: Item "Range Statistics" added
* \version 2017-03-08/AW: Item "Plane Patch Statistics" added
* \version 2017-04-05/AW: Items "Atmosphere" and "Geometric Scale Factor" added
* \version 2017-08-22/AW: Items for waveform sample block and value files added
* \version 2017-10-24/AW: Item "Gaussian Decomposition" added
* \version 2017-11-13/AW: Item "riegl.scan_pattern" updated
* \version 2017-11-21/AW: Item "riegl.trajectory_info" added
* \version 2018-01-11/AW: Item "riegl.beam_geometry" added
* \version 2018-01-15/AW: Item "riegl.reflectance_calculation" added
* \version 2018-01-15/AW: Item "riegl.near_range_correction" added
* \version 2018-01-15/AW: Item "riegl.device_geometry" added
* \version 2018-02-13/AW: Item "riegl.notch_filter" added
* \version 2018-03-08/AW: Item "riegl.window_echo_correction" added
* \version 2018-03-15/AW: Item "riegl.pulse_position_modulation" added
* \version 2018-05-24/AW: Item "riegl.pixel_info" added
* \version 2018-06-08/AW: Item "riegl.shot_info" added
* \version 2018-06-08/AW: Item "riegl.echo_info" added
* \version 2018-06-14/AW: Item "riegl.mta_settings" added
* \version 2018-06-14/AW: Item "riegl.receiver_internals" added
* \version 2018-06-14/AW: Item "riegl.device_output_limits" added
* \version 2018-06-26/AW: Schema: replace "number" with "integer" if applicable
* \version 2018-07-09/AW: Item "riegl.pose_estimation" added
* \version 2018-07-09/AW: Item "riegl.pose_sensors" added
* \version 2018-09-20/AW: Item "riegl.pointcloud_info" added
* \version 2018-11-08/AW: Item "riegl.scan_pattern" updated
* \version 2018-11-13/AW: Item "riegl.receiver_internals" updated
* \version 2019-03-06/AW: Item "riegl.receiver_internals" updated
* \version 2019-03-21/AW: Item "riegl.device_geometry" updated
* \version 2019-04-15/AW: Item "riegl.point_attribute_groups" added
* \version 2019-04-30/AW: Item "riegl.waveform_settings" added
* \version 2019-10-03/AW: Item "riegl.angular_notch_filter" added
* \version 2019-10-03/AW: Item "riegl.noise_estimates" added
* \version 2019-10-25/AW: Item "riegl.window_analysis" added
* \version 2019-11-06/AW: Item "riegl.georeferencing_parameters" added
* \version 2019-11-27/AW: Item "riegl.plane_patch_matching" added
* \version 2019-12-13/AW: Items for tie-/control objects added
* \version 2019-12-19/AW: Items for tie-/control objects added
* \version 2020-02-04/AW: Item "riegl.detection_probability" added
* \version 2020-02-04/AW: Item "riegl.licenses" added
* \version 2020-04-27/AW: Item "riegl.waveform_info" updated (schema+example)
* \version 2020-09-03/AW: Item "riegl.reflectance_correction" added
* \version 2020-09-10/AW: Item "riegl.device_geometry_passive_channel" added
* \version 2020-09-25/AW: Item "riegl.georeferencing_parameters" updated
* \version 2020-09-25/AW: Item "riegl.trajectory_info" updated
* \version 2020-09-29/AW: Item "riegl.temperature_calculation" added
* \version 2020-10-23/AW: Item "riegl.exponential_decomposition" added (#3709)
* \version 2020-11-30/AW: Item "riegl.notch_filter" updated (schema)
* \version 2020-12-02/AW: Item "riegl.georeferencing_parameters" updated (schema)
* \version 2021-02-02/AW: Item "riegl.plane_slope_class_info" added (rdbplanes/#7)
* \version 2021-02-16/AW: Item "riegl.device_output_limits" updated (schema, #3811)
* \version 2021-03-03/AW: Item "riegl.exponential_decomposition" updated (schema, #3822)
* \version 2021-03-03/AW: Item "riegl.waveform_averaging_settings" added (#3821)
* \version 2021-04-01/AW: Item "riegl.voxel_info" updated (schema, #3854)
* \version 2021-04-16/AW: Item "riegl.voxel_info" updated (schema, #3866)
*
*******************************************************************************
"""

# Angular notch filter parameters for window glass echoes
RDB_RIEGL_ANGULAR_NOTCH_FILTER             = "riegl.angular_notch_filter"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_TITLE       = "Angular Notch Filter"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_DESCRIPTION = "Angular notch filter parameters for window glass echoes"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_STATUS      = "optional"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_SCHEMA = (
"{\"description\":\"Angular notch filter parameters for window glass echoe"
"s\",\"required\":[\"angle\",\"range_mean\",\"amplitude_mean\"],\"title\":\"Angular"
" Notch Filter\",\"properties\":{\"range_mean\":{\"description\":\"Mean range ["
"m]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"angle\":{\"description\":\""
"Angle [deg]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplitude_mean"
"\":{\"description\":\"Mean amplitude [dB]\",\"type\":\"array\",\"items\":{\"type\":"
"\"number\"}}},\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04"
"/schema#\"}"
)
RDB_RIEGL_ANGULAR_NOTCH_FILTER_EXAMPLE = (
"{\"range_mean\":[0.094,0.094,0.09075,0.08675,0.0815,0.0775,0.074,0.071,0"
".068,0.0675,0.06475],\"angle\":[14.0,15.0,16.0,17.0,18.0,19.0,20.0,21.0,"
"22.0,23.0,24.0],\"amplitude_mean\":[3.780913,3.780913,3.480913,3.120913,"
"2.850913,2.720913,2.680913,2.610913,2.530913,2.570913,2.570913]}"
)

# Atmospheric Parameters
RDB_RIEGL_ATMOSPHERE             = "riegl.atmosphere"
RDB_RIEGL_ATMOSPHERE_TITLE       = "Atmosphere"
RDB_RIEGL_ATMOSPHERE_DESCRIPTION = "Atmospheric Parameters"
RDB_RIEGL_ATMOSPHERE_STATUS      = "optional"
RDB_RIEGL_ATMOSPHERE_SCHEMA = (
"{\"description\":\"Atmospheric Parameters\",\"required\":[\"temperature\",\"pre"
"ssure\",\"rel_humidity\",\"pressure_sl\",\"amsl\",\"group_velocity\",\"attenuati"
"on\",\"wavelength\"],\"title\":\"Atmospheric "
"Parameters\",\"properties\":{\"temperature\":{\"description\":\"Temperature "
"along measurement path "
"[\\u00b0C]\",\"type\":\"number\"},\"wavelength\":{\"description\":\"Laser "
"wavelength [nm]\",\"type\":\"number\"},\"amsl\":{\"description\":\"Height above "
"mean sea level (AMSL) "
"[m]\",\"type\":\"number\"},\"rel_humidity\":{\"description\":\"Relative humidity"
" along measurement path "
"[%]\",\"type\":\"number\"},\"group_velocity\":{\"description\":\"Group velocity "
"of laser beam "
"[m/s]\",\"type\":\"number\"},\"pressure_sl\":{\"description\":\"Atmospheric "
"pressure at sea level "
"[mbar]\",\"type\":\"number\"},\"pressure\":{\"description\":\"Pressure along "
"measurment path "
"[mbar]\",\"type\":\"number\"},\"attenuation\":{\"description\":\"Atmospheric "
"attenuation [1/km]\",\"type\":\"number\"}},\"type\":\"object\",\"$schema\":\"http:"
"//json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_ATMOSPHERE_EXAMPLE = (
"{\"temperature\":7,\"wavelength\":1550,\"amsl\":0,\"rel_humidity\":63,\"group_v"
"elocity\":299711000.0,\"pressure_sl\":970,\"pressure\":970,\"attenuation\":0."
"028125}"
)

# Laser beam geometry details
RDB_RIEGL_BEAM_GEOMETRY             = "riegl.beam_geometry"
RDB_RIEGL_BEAM_GEOMETRY_TITLE       = "Beam Geometry"
RDB_RIEGL_BEAM_GEOMETRY_DESCRIPTION = "Laser beam geometry details"
RDB_RIEGL_BEAM_GEOMETRY_STATUS      = "optional"
RDB_RIEGL_BEAM_GEOMETRY_SCHEMA = (
"{\"description\":\"Laser beam geometry details\",\"required\":[\"beam_exit_di"
"ameter\",\"beam_divergence\"],\"title\":\"Beam "
"Geometry\",\"properties\":{\"beam_exit_diameter\":{\"description\":\"Beam "
"width at exit aperture [m]\",\"type\":\"number\",\"minimum\":0,\"exclusiveMini"
"mum\":false},\"beam_divergence\":{\"description\":\"Beam divergence in far "
"field [rad]\",\"type\":\"number\",\"minimum\":0,\"exclusiveMinimum\":false}},\"t"
"ype\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_BEAM_GEOMETRY_EXAMPLE = (
"{\"beam_exit_diameter\":0.0072,\"beam_divergence\":0.0003}"
)

# List of control object type definitions
RDB_RIEGL_CONTROL_OBJECT_CATALOG             = "riegl.control_object_catalog"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_TITLE       = "Control Object Catalog"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_DESCRIPTION = "List of control object type definitions"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_STATUS      = "optional"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_SCHEMA = (
"{\"description\":\"List of control object type "
"definitions\",\"required\":[\"types\"],\"title\":\"Control Object Catalog\",\"pr"
"operties\":{\"types\":{\"uniqueItems\":true,\"type\":\"array\",\"items\":{\"oneOf\""
":[{\"$ref\":\"#/definitions/rectangle\"},{\"$ref\":\"#/definitions/checkerboa"
"rd2x2\"},{\"$ref\":\"#/definitions/chevron\"},{\"$ref\":\"#/definitions/circul"
"ar_disk\"},{\"$ref\":\"#/definitions/cylinder\"},{\"$ref\":\"#/definitions/sph"
"ere\"},{\"$ref\":\"#/definitions/round_corner_cube_prism\"}],\"type\":\"object"
"\"}}},\"definitions\":{\"rectangle\":{\"description\":\"rectangle\",\"type\":\"obj"
"ect\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"description\":\"rectangl"
"e specific properties\",\"required\":[\"shape\",\"length\",\"width\"],\"type\":\"o"
"bject\",\"properties\":{\"width\":{\"description\":\"width in meters\",\"type\":\""
"number\",\"minimum\":0,\"exclusiveMinimum\":true},\"shape\":{\"type\":\"string\","
"\"enum\":[\"rectangle\"]},\"length\":{\"description\":\"length in meters\",\"type"
"\":\"number\",\"minimum\":0,\"exclusiveMinimum\":true}}}]},\"circular_disk\":{\""
"description\":\"circular disk\",\"type\":\"object\",\"allOf\":[{\"$ref\":\"#/defin"
"itions/common\"},{\"description\":\"circular disk specific properties\",\"re"
"quired\":[\"shape\",\"diameter\"],\"type\":\"object\",\"properties\":{\"diameter\":"
"{\"description\":\"diameter in meters\",\"type\":\"number\",\"minimum\":0,\"exclu"
"siveMinimum\":true},\"offset\":{\"description\":\"offset in meters, e.g. "
"reflector constant "
"(optional)\",\"type\":\"number\"},\"shape\":{\"description\":\"shape identifier\""
",\"type\":\"string\",\"enum\":[\"circular_disk\"]}}}]},\"sphere\":{\"description\""
":\"sphere\",\"type\":\"object\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"d"
"escription\":\"sphere specific properties\",\"required\":[\"shape\",\"diameter"
"\"],\"type\":\"object\",\"properties\":{\"diameter\":{\"description\":\"diameter "
"in meters\",\"type\":\"number\",\"minimum\":0,\"exclusiveMinimum\":true},\"shape"
"\":{\"description\":\"shape identifier\",\"type\":\"string\",\"enum\":[\"sphere\"]}"
"}}]},\"checkerboard2x2\":{\"description\":\"checkerboard 2 by 2\",\"type\":\"ob"
"ject\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"description\":\"checker"
"board specific properties\",\"required\":[\"shape\",\"square_length\"],\"type\""
":\"object\",\"properties\":{\"square_length\":{\"description\":\"length of a "
"square of the checkerboard in meters\",\"type\":\"number\",\"minimum\":0,\"exc"
"lusiveMinimum\":true},\"shape\":{\"description\":\"shape identifier\",\"type\":"
"\"string\",\"enum\":[\"checkerboard2x2\"]}}}]},\"common\":{\"description\":\"comm"
"on object properties\",\"required\":[\"name\",\"shape\"],\"type\":\"object\",\"pro"
"perties\":{\"description\":{\"description\":\"string describing the "
"object\",\"type\":\"string\"},\"surface_type\":{\"description\":\"surface "
"material type\",\"type\":\"string\",\"enum\":[\"retro_reflective_foil\",\"diffus"
"e\"]},\"shape\":{\"description\":\"shape identifier\",\"type\":\"string\",\"enum\":"
"[\"rectangle\",\"checkerboard2x2\",\"chevron\",\"circular_disk\",\"cylinder\",\"s"
"phere\",\"round_corner_cube_prism\"]},\"name\":{\"description\":\"unique type "
"identifier\",\"minLength\":3,\"type\":\"string\"}}},\"round_corner_cube_prism\""
":{\"description\":\"round corner cube prism\",\"type\":\"object\",\"allOf\":[{\"$"
"ref\":\"#/definitions/common\"},{\"description\":\"round corner cube prism "
"specific properties\",\"required\":[\"shape\",\"diameter\"],\"type\":\"object\",\""
"properties\":{\"diameter\":{\"description\":\"diameter in meters\",\"type\":\"nu"
"mber\",\"minimum\":0,\"exclusiveMinimum\":true},\"offset\":{\"description\":\"of"
"fset in meters, e.g. reflector constant "
"(optional)\",\"type\":\"number\"},\"shape\":{\"description\":\"shape identifier\""
",\"type\":\"string\",\"enum\":[\"round_corner_cube_prism\"]}}}]},\"chevron\":{\"d"
"escription\":\"chevron\",\"type\":\"object\",\"allOf\":[{\"$ref\":\"#/definitions/"
"common\"},{\"description\":\"chevron specific properties\",\"required\":[\"sha"
"pe\",\"outside_edge_length\",\"thickness\"],\"type\":\"object\",\"properties\":{\""
"outside_edge_length\":{\"description\":\"length of the two outer edges in "
"meters\",\"type\":\"number\",\"minimum\":0,\"exclusiveMinimum\":true},\"shape\":{"
"\"description\":\"shape identifier\",\"type\":\"string\",\"enum\":[\"chevron\"]},\""
"thickness\":{\"description\":\"thickness in meters\",\"type\":\"number\",\"minim"
"um\":0,\"exclusiveMinimum\":true}}}]},\"cylinder\":{\"description\":\"cylinder"
"\",\"type\":\"object\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"descripti"
"on\":\"cylinder specific properties\",\"required\":[\"shape\",\"diameter\",\"hei"
"ght\"],\"type\":\"object\",\"properties\":{\"diameter\":{\"description\":\"diamete"
"r in meters\",\"type\":\"number\",\"minimum\":0,\"exclusiveMinimum\":true},\"hei"
"ght\":{\"description\":\"height in meters\",\"type\":\"number\",\"minimum\":0,\"ex"
"clusiveMinimum\":true},\"shape\":{\"description\":\"shape identifier\",\"type\""
":\"string\",\"enum\":[\"cylinder\"]}}}]}},\"type\":\"object\",\"$schema\":\"http://"
"json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_CONTROL_OBJECT_CATALOG_EXAMPLE = (
"{\"types\":[{\"description\":\"Rectangle (60cm x "
"30cm)\",\"width\":0.3,\"shape\":\"rectangle\",\"length\":0.6,\"name\":\"Rectangle "
"60x30\"},{\"description\":\"Rectangle (80cm x "
"40cm)\",\"width\":0.4,\"shape\":\"rectangle\",\"length\":0.8,\"name\":\"Rectangle "
"80x40\"},{\"description\":\"Checkerboard (square length: 30cm)\",\"square_le"
"ngth\":0.3,\"shape\":\"checkerboard2x2\",\"name\":\"Checkerboard2x2 "
"30\"},{\"description\":\"Checkerboard (square length: 50cm)\",\"square_lengt"
"h\":0.5,\"shape\":\"checkerboard2x2\",\"name\":\"Checkerboard2x2 "
"50\"},{\"description\":\"Chevron (a=24''; b=4'')\",\"outside_edge_length\":0."
"6096,\"shape\":\"chevron\",\"thickness\":0.1016,\"name\":\"Chevron "
"24''/4''\"},{\"description\":\" Circular Disk (diameter: "
"50cm)\",\"diameter\":0.5,\"shape\":\"circular_disk\",\"name\":\"Circular Disk "
"50\",\"surface_type\":\"diffuse\"},{\"description\":\"flat circular reflector "
"from retro-reflective foil\",\"offset\":0.0,\"diameter\":0.05,\"surface_type"
"\":\"retro_reflective_foil\",\"shape\":\"circular_disk\",\"name\":\"RIEGL flat "
"reflector 50 mm\"},{\"description\":\"flat circular reflector from "
"retro-reflective foil\",\"offset\":0.0,\"diameter\":0.1,\"surface_type\":\"ret"
"ro_reflective_foil\",\"shape\":\"circular_disk\",\"name\":\"RIEGL flat "
"reflector 100 mm\"},{\"description\":\"flat circular reflector from "
"retro-reflective foil\",\"offset\":0.0,\"diameter\":0.15,\"surface_type\":\"re"
"tro_reflective_foil\",\"shape\":\"circular_disk\",\"name\":\"RIEGL flat "
"reflector 150 mm\"},{\"description\":\"cylindrical reflector from "
"retro-reflective foil\",\"height\":0.05,\"diameter\":0.05,\"surface_type\":\"r"
"etro_reflective_foil\",\"shape\":\"cylinder\",\"name\":\"RIEGL cylindrical "
"reflector 50 mm\"},{\"description\":\"cylindrical reflector from "
"retro-reflective foil\",\"height\":0.1,\"diameter\":0.1,\"surface_type\":\"ret"
"ro_reflective_foil\",\"shape\":\"cylinder\",\"name\":\"RIEGL cylindrical "
"reflector 100 mm\"},{\"description\":\"Sphere (diameter: 200 "
"mm)\",\"diameter\":0.2,\"shape\":\"sphere\",\"name\":\"Sphere 200 "
"mm\"},{\"description\":\"round corner cube prism\",\"diameter\":0.05,\"shape\":"
"\"round_corner_cube_prism\",\"name\":\"Corner Cube Prism 50 "
"mm\",\"offset\":0.0}],\"comments\":[\"This file contains a list of control "
"object types (aka. 'catalog').\",\"Each type is described by an "
"object,\",\"which must contain at least the following parameters:\",\"  - "
"name: unique identifier of the type\",\"  - shape: one of the following "
"supported shapes:\",\"      - rectangle\",\"      - checkerboard2x2\",\""
"      - chevron\",\"      - circular_disk\",\"      - cylinder\",\"      - "
"sphere\",\"      - round_corner_cube_prism\",\"Depending on 'shape', the "
"following parameters must/may be specified:\",\"  - rectangle:\",\"      -"
" length: length in meters\",\"      - width: width in meters\",\"  - "
"checkerboard2x2:\",\"      - square_length: length of a square of the "
"checkerboard in meters\",\"  - circular_disk:\",\"      - diameter: "
"diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
"constant (optional)\",\"  - chevron:\",\"      - outside_edge_length: "
"length of the two outer edges in meters\",\"      - thickness: thickness"
" in meters\",\"  - cylinder:\",\"      - diameter: diameter in meters\",\""
"      - height:  height in meters\",\"  - sphere:\",\"      - diameter: "
"diameter in meters\",\"  - round_corner_cube_prism:\",\"      - diameter: "
"diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
"constant (optional)\",\"Optional parameters:\",\"    - description: string"
" describing the object\",\"    - surface_type: surface material type "
"(either 'retro_reflective_foil' or 'diffuse')\"]}"
)

# Details about the control object reference file
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE             = "riegl.control_object_reference_file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_TITLE       = "Control Object Reference file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_DESCRIPTION = "Details about the control object reference file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_STATUS      = "optional"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_SCHEMA = (
"{\"description\":\"Details about the control object reference "
"file\",\"type\":\"object\",\"title\":\"Control Object Reference "
"file\",\"properties\":{\"reference_file\":{\"description\":\"Reference to a "
"control object file\",\"required\":[\"file_uuid\",\"file_path\"],\"type\":\"obje"
"ct\",\"properties\":{\"file_path\":{\"description\":\"Path of the control "
"object file relative to referring "
"file\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"Control object "
"file's Universally Unique Identifier (RFC 4122)\",\"type\":\"string\"}}}},\""
"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_EXAMPLE = (
"{\"reference_file\":{\"file_path\":\"../../../10_CONTROL_OBJECTS/ControlPoi"
"nts.cpx\",\"file_uuid\":\"810f5d57-eccf-49ed-b07a-0cdd109b4213\"}}"
)

# Detection probability as a function of amplitude
RDB_RIEGL_DETECTION_PROBABILITY             = "riegl.detection_probability"
RDB_RIEGL_DETECTION_PROBABILITY_TITLE       = "Detection Probability"
RDB_RIEGL_DETECTION_PROBABILITY_DESCRIPTION = "Detection probability as a function of amplitude"
RDB_RIEGL_DETECTION_PROBABILITY_STATUS      = "optional"
RDB_RIEGL_DETECTION_PROBABILITY_SCHEMA = (
"{\"description\":\"Detection probability as a function of amplitude\",\"req"
"uired\":[\"amplitude\",\"detection_probability\"],\"title\":\"Detection Probab"
"ility\",\"properties\":{\"detection_probability\":{\"description\":\"Detection"
" probability [0..1]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplit"
"ude\":{\"description\":\"Amplitude [dB]\",\"type\":\"array\",\"items\":{\"type\":\"n"
"umber\"}}},\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/s"
"chema#\"}"
)
RDB_RIEGL_DETECTION_PROBABILITY_EXAMPLE = (
"{\"detection_probability\":[0.0,0.5,0.8,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0]"
",\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0]}"
)

# Details about the device used to acquire the point cloud
RDB_RIEGL_DEVICE             = "riegl.device"
RDB_RIEGL_DEVICE_TITLE       = "Device Information"
RDB_RIEGL_DEVICE_DESCRIPTION = "Details about the device used to acquire the point cloud"
RDB_RIEGL_DEVICE_STATUS      = "optional"
RDB_RIEGL_DEVICE_SCHEMA = (
"{\"description\":\"Details about the device used to acquire the point "
"cloud\",\"required\":[\"device_type\",\"serial_number\"],\"title\":\"Device "
"Information\",\"properties\":{\"device_build\":{\"description\":\"Device build"
" variant\",\"type\":\"string\"},\"channel_number\":{\"description\":\"Laser "
"channel number (not defined or 0: single channel device)\",\"type\":\"inte"
"ger\",\"minimum\":0,\"exclusiveMinimum\":false},\"channel_text\":{\"descriptio"
"n\":\"Optional channel description (e.g. 'Green Channel' for "
"multi-channel "
"devices)\",\"type\":\"string\"},\"device_name\":{\"description\":\"Optional "
"device name (e.g. 'Scanner 1' for multi-scanner "
"systems)\",\"type\":\"string\"},\"device_type\":{\"description\":\"Device type "
"identifier (e.g. "
"VZ-400i)\",\"type\":\"string\"},\"serial_number\":{\"description\":\"Device "
"serial number (e.g. S2221234)\",\"type\":\"string\"}},\"type\":\"object\",\"$sch"
"ema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_DEVICE_EXAMPLE = (
"{\"device_build\":\"\",\"channel_number\":0,\"channel_text\":\"\",\"device_name\":"
"\"Scanner 1\",\"device_type\":\"VZ-400i\",\"serial_number\":\"S2221234\"}"
)

# Scanner device geometry details
RDB_RIEGL_DEVICE_GEOMETRY             = "riegl.device_geometry"
RDB_RIEGL_DEVICE_GEOMETRY_TITLE       = "Device Geometry"
RDB_RIEGL_DEVICE_GEOMETRY_DESCRIPTION = "Scanner device geometry details"
RDB_RIEGL_DEVICE_GEOMETRY_STATUS      = "optional"
RDB_RIEGL_DEVICE_GEOMETRY_SCHEMA = (
"{\"description\":\"Scanner device geometry "
"details\",\"required\":[\"primary\"],\"title\":\"Device "
"Geometry\",\"properties\":{\"primary\":{\"description\":\"Primary device "
"geometry structure (mandatory)\",\"required\":[\"ID\",\"content\"],\"type\":\"ob"
"ject\",\"properties\":{\"content\":{\"description\":\"Internal calibration val"
"ues\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"ID\":{\"description\":\"St"
"ructure identifier\",\"type\":\"array\",\"items\":{\"type\":\"integer\"},\"minItem"
"s\":2,\"maxItems\":2}}},\"secondary\":{\"description\":\"Additional device "
"geometry structure (optional)\",\"required\":[\"ID\",\"content\"],\"type\":\"obj"
"ect\",\"properties\":{\"content\":{\"description\":\"Internal calibration valu"
"es\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"ID\":{\"description\":\"Str"
"ucture identifier\",\"type\":\"array\",\"items\":{\"type\":\"integer\"},\"minItems"
"\":2,\"maxItems\":2}}},\"amu\":{\"description\":\"Angle Measurement "
"Unit\",\"type\":\"object\",\"properties\":{\"frameCC\":{\"description\":\"Frame "
"Circle Count (number of LSBs per full rotation about frame axis)\",\"typ"
"e\":\"number\",\"minimum\":0,\"exclusiveMinimum\":false},\"lineCC\":{\"descripti"
"on\":\"Line Circle Count (number of LSBs per full rotation about line ax"
"is)\",\"type\":\"number\",\"minimum\":0,\"exclusiveMinimum\":false}}}},\"type\":\""
"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_DEVICE_GEOMETRY_EXAMPLE = (
"{\"primary\":{\"content\":[0],\"ID\":[4,0]},\"secondary\":{\"content\":[0],\"ID\":"
"[91,0]},\"amu\":{\"frameCC\":124000,\"lineCC\":124000}}"
)

# Scanner passive channel device geometry details
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL             = "riegl.device_geometry_passive_channel"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_TITLE       = "Device Geometry Passive Channel"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_DESCRIPTION = "Scanner passive channel device geometry details"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_STATUS      = "optional"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_SCHEMA = (
"{\"description\":\"Scanner passive channel device geometry "
"details\",\"required\":[\"primary\"],\"title\":\"Device Geometry Passive "
"Channel\",\"properties\":{\"primary\":{\"description\":\"Primary device "
"geometry structure (mandatory)\",\"required\":[\"ID\",\"content\"],\"type\":\"ob"
"ject\",\"properties\":{\"content\":{\"description\":\"Internal calibration val"
"ues\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"ID\":{\"description\":\"St"
"ructure identifier\",\"type\":\"array\",\"items\":{\"type\":\"integer\"},\"minItem"
"s\":2,\"maxItems\":2}}}},\"type\":\"object\",\"$schema\":\"http://json-schema.or"
"g/draft-04/schema#\"}"
)
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_EXAMPLE = (
"{\"primary\":{\"content\":[0],\"ID\":[143,0]}}"
)

# Limits of the measured values output by the device
RDB_RIEGL_DEVICE_OUTPUT_LIMITS             = "riegl.device_output_limits"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_TITLE       = "Device Output Limits"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_DESCRIPTION = "Limits of the measured values output by the device"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_STATUS      = "optional"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_SCHEMA = (
"{\"description\":\"Limits of the measured values output by the device. "
"The limits depend on the device type, measurement program and/or scan "
"pattern.\",\"type\":\"object\",\"title\":\"Device Output "
"Limits\",\"properties\":{\"amplitude_maximum\":{\"description\":\"Maximum "
"possible amplitude in dB.\",\"type\":\"number\"},\"background_radiation_mini"
"mum\":{\"description\":\"Minimum possible background "
"radiation.\",\"type\":\"number\"},\"range_minimum\":{\"description\":\"Minimum "
"possible range in meters.\",\"type\":\"number\"},\"reflectance_minimum\":{\"de"
"scription\":\"Minimum possible reflectance in "
"dB.\",\"type\":\"number\"},\"deviation_maximum\":{\"description\":\"Maximum "
"possible pulse shape deviation.\",\"type\":\"number\"},\"background_radiatio"
"n_maximum\":{\"description\":\"Maximum possible background "
"radiation.\",\"type\":\"number\"},\"range_maximum\":{\"description\":\"Maximum "
"possible range in "
"meters.\",\"type\":\"number\"},\"deviation_minimum\":{\"description\":\"Minimum "
"possible pulse shape deviation.\",\"type\":\"number\"},\"mta_zone_count_maxi"
"mum\":{\"description\":\"Maximum number of MTA "
"zones.\",\"type\":\"number\"},\"reflectance_maximum\":{\"description\":\"Maximum"
" possible reflectance in "
"dB.\",\"type\":\"number\"},\"amplitude_minimum\":{\"description\":\"Minimum "
"possible amplitude in "
"dB.\",\"type\":\"number\"},\"echo_count_maximum\":{\"description\":\"Maximum "
"number of echoes a laser shot can have.\",\"type\":\"number\"}},\"$schema\":\""
"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_EXAMPLE = (
"{\"background_radiation_maximum\":0,\"range_maximum\":10000.0,\"amplitude_m"
"aximum\":100.0,\"deviation_minimum\":-1,\"background_radiation_minimum\":0,"
"\"mta_zone_count_maximum\":7,\"range_minimum\":2.9,\"reflectance_maximum\":1"
"00.0,\"amplitude_minimum\":0.0,\"reflectance_minimum\":-100.0,\"deviation_m"
"aximum\":32767}"
)

# Details about echo files
RDB_RIEGL_ECHO_INFO             = "riegl.echo_info"
RDB_RIEGL_ECHO_INFO_TITLE       = "Echo Information"
RDB_RIEGL_ECHO_INFO_DESCRIPTION = "Details about echo files"
RDB_RIEGL_ECHO_INFO_STATUS      = "optional"
RDB_RIEGL_ECHO_INFO_SCHEMA = (
"{\"description\":\"Details about echo "
"files\",\"required\":[\"echo_file\"],\"title\":\"Echo Information\",\"properties"
"\":{\"echo_file\":{\"required\":[\"file_extension\"],\"type\":\"object\",\"propert"
"ies\":{\"file_uuid\":{\"description\":\"File's Universally Unique Identifier"
" (RFC 4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Echo "
"file extension, without the leading dot\",\"type\":\"string\"}}}},\"type\":\"o"
"bject\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_ECHO_INFO_EXAMPLE = (
"{\"echo_file\":{\"file_uuid\":\"26a03615-67c0-4bea-8fe8-c577378fe661\",\"file"
"_extension\":\"owp\"}}"
)

# Details for exponential decomposition of full waveform data
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION             = "riegl.exponential_decomposition"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_TITLE       = "Exponential Decomposition"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_DESCRIPTION = "Details for exponential decomposition of full waveform data"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_STATUS      = "optional"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_SCHEMA = (
"{\"description\":\"Details for exponential decomposition of full waveform"
" data\",\"additionalProperties\":false,\"title\":\"Exponential "
"Decomposition\",\"patternProperties\":{\"^[0-9]+$\":{\"description\":\"one "
"field per channel, field name is channel index\",\"$ref\":\"#/definitions/"
"channel\"}},\"definitions\":{\"channel\":{\"required\":[\"delay\",\"scale\",\"para"
"meter\"],\"type\":\"object\",\"properties\":{\"parameter\":{\"description\":\"para"
"meters of the syswave exponential sum\",\"required\":[\"A\",\"B\",\"gamma\",\"om"
"ega\"],\"type\":\"object\",\"properties\":{\"omega\":{\"description\":\"angular "
"frequency in Hz\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"gamma\":{\"d"
"escription\":\"decay in 1/second\",\"type\":\"array\",\"items\":{\"type\":\"number"
"\"}},\"A\":{\"description\":\"real part of amplitude factor in units of full"
"-scale\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"B\":{\"description\":\""
"imaginary part of amplitude factor in units of full-scale\",\"type\":\"arr"
"ay\",\"items\":{\"type\":\"number\"}}}},\"delay\":{\"description\":\"delay "
"calibration in "
"seconds\",\"type\":\"number\"},\"scale\":{\"description\":\"amplitude "
"calibration\",\"type\":\"number\"},\"a_lin\":{\"description\":\"relative linear "
"amplitude range [0..1]\",\"exclusiveMaximum\":false,\"minimum\":0,\"maximum\""
":1,\"type\":\"number\",\"exclusiveMinimum\":false}}}},\"type\":\"object\",\"$sche"
"ma\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_EXAMPLE = (
"{\"1\":{\"parameter\":{\"omega\":[352020896.0,3647927552.0,-1977987072.0],\"g"
"amma\":[-1094726528.0,-769562752.0,-848000064.0],\"A\":[0.9,0.3,-1.3],\"B\""
":[-3.9,0.0,-0.3]},\"delay\":3.5e-09,\"scale\":1.0,\"a_lin\":0.9},\"0\":{\"param"
"eter\":{\"omega\":[352020896.0,3647927552.0,-1977987072.0],\"gamma\":[-1094"
"726528.0,-769562752.0,-848000064.0],\"A\":[0.9772450923919678,0.33543351"
"29261017,-1.312678575515747],\"B\":[-3.9813032150268555,0.08622030913829"
"803,-0.3152860999107361]},\"delay\":3.783458418887631e-09,\"scale\":1.0,\"a"
"_lin\":0.27}}"
)

# Details for Gaussian decomposition of full waveform data
RDB_RIEGL_GAUSSIAN_DECOMPOSITION             = "riegl.gaussian_decomposition"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_TITLE       = "Gaussian Decomposition"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_DESCRIPTION = "Details for Gaussian decomposition of full waveform data"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_STATUS      = "optional"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_SCHEMA = (
"{\"description\":\"riegl.gaussian_decomposition contains information "
"relevant for extracting calibrated amplitudes and calibrated ranges "
"from a Gaussian decomposition of full waveform data. This information "
"is contained in a table with five columns. Two columns are to be used "
"as input: amplitude_lsb_low_power and amplitude_lsb_high_power. The "
"other three columns provide the outputs. Amplitude_db gives the "
"calibrated amplitude in the optical regime in decibels. The range "
"offset columns provide additive range offsets, given in units of "
"seconds, for each channel.\",\"required\":[\"amplitude_lsb_low_power\",\"amp"
"litude_lsb_high_power\",\"amplitude_db\",\"range_offset_sec_low_power\",\"ra"
"nge_offset_sec_high_power\"],\"title\":\"Gaussian Decomposition\",\"properti"
"es\":{\"amplitude_lsb_low_power\":{\"type\":\"array\",\"items\":{\"type\":\"number"
"\"}},\"amplitude_db\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplitu"
"de_lsb_high_power\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"range_o"
"ffset_sec_low_power\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"range"
"_offset_sec_high_power\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}}},\"t"
"ype\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_EXAMPLE = (
"{\"amplitude_lsb_low_power\":[],\"amplitude_db\":[],\"amplitude_lsb_high_po"
"wer\":[],\"range_offset_sec_low_power\":[],\"range_offset_sec_high_power\":"
"[]}"
)

# Point cloud Georeferencing Information
RDB_RIEGL_GEO_TAG             = "riegl.geo_tag"
RDB_RIEGL_GEO_TAG_TITLE       = "Geo Tag"
RDB_RIEGL_GEO_TAG_DESCRIPTION = "Point cloud Georeferencing Information"
RDB_RIEGL_GEO_TAG_STATUS      = "optional"
RDB_RIEGL_GEO_TAG_SCHEMA = (
"{\"description\":\"Point cloud Georeferencing "
"Information\",\"type\":\"object\",\"title\":\"Geo "
"Tag\",\"properties\":{\"crs\":{\"description\":\"Global Coordinate Reference "
"System. Please note that only 3D Cartesian Coordinate Systems are "
"allowed.\",\"type\":\"object\",\"properties\":{\"epsg\":{\"description\":\"EPSG "
"code\",\"type\":\"integer\",\"minimum\":0},\"wkt\":{\"description\":\"\\\"Well-Known"
" Text\\\" string, OGC WKT dialect (see http://www.opengeospatial.org/sta"
"ndards/wkt-crs)\",\"type\":\"string\"},\"name\":{\"description\":\"Coordinate "
"reference system "
"name\",\"type\":\"string\"}}},\"pose\":{\"description\":\"Coordinate "
"Transformation Matrix to transform from File Coordinate System to "
"Global Coordinate Reference System. 4x4 matrix stored as two "
"dimensional array, row major order.\",\"type\":\"array\",\"items\":{\"descript"
"ion\":\"rows\",\"type\":\"array\",\"items\":{\"description\":\"columns\",\"type\":\"nu"
"mber\"},\"minItems\":4,\"maxItems\":4},\"minItems\":4,\"maxItems\":4}},\"$schema"
"\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_GEO_TAG_EXAMPLE = (
"{\"crs\":{\"epsg\":4978,\"wkt\":\"GEOCCS[\\\"WGS84 Geocentric\\\",DATUM[\\\"WGS84\\\""
",SPHEROID[\\\"WGS84\\\",6378137.000,298.257223563,AUTHORITY[\\\"EPSG\\\",\\\"703"
"0\\\"]],AUTHORITY[\\\"EPSG\\\",\\\"6326\\\"]],PRIMEM[\\\"Greenwich\\\",0.00000000000"
"00000,AUTHORITY[\\\"EPSG\\\",\\\"8901\\\"]],UNIT[\\\"Meter\\\",1.00000000000000000"
"000,AUTHORITY[\\\"EPSG\\\",\\\"9001\\\"]],AXIS[\\\"X\\\",OTHER],AXIS[\\\"Y\\\",EAST],A"
"XIS[\\\"Z\\\",NORTH],AUTHORITY[\\\"EPSG\\\",\\\"4978\\\"]]\",\"name\":\"WGS84 Geocentr"
"ic\"},\"pose\":[[-0.269827776749716,-0.723017716139738,0.635954678449952,"
"4063882.500831],[0.962908599449764,-0.20260517250352,0.178208229833847"
",1138787.607461],[0.0,0.660451759194338,0.7508684796801,4766084.550196"
"],[0.0,0.0,0.0,1.0]]}"
)

# Geometric Scale Factor applied to point coordinates
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR             = "riegl.geometric_scale_factor"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_TITLE       = "Geometric Scale Factor"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_DESCRIPTION = "Geometric Scale Factor applied to point coordinates"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_STATUS      = "optional"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_SCHEMA = (
"{\"description\":\"Geometric Scale Factor applied to point coordinates\",\""
"type\":\"number\",\"minimum\":0,\"$schema\":\"http://json-schema.org/draft-04/"
"schema#\",\"exclusiveMinimum\":true}"
)
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_EXAMPLE = (
"1.0"
)

# Parameters used for georeferencing of the point cloud
RDB_RIEGL_GEOREFERENCING_PARAMETERS             = "riegl.georeferencing_parameters"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_TITLE       = "Georeferencing Parameters"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_DESCRIPTION = "Parameters used for georeferencing of the point cloud"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_STATUS      = "optional"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_SCHEMA = (
"{\"description\":\"Parameters used for georeferencing of the point "
"cloud\",\"type\":\"object\",\"title\":\"Georeferencing Parameters\",\"properties"
"\":{\"trajectory_offsets\":{\"description\":\"Correction offsets applied to "
"the trajectory data\",\"type\":\"object\",\"properties\":{\"offset_pitch\":{\"de"
"scription\":\"[deg]\",\"type\":\"number\"},\"offset_east\":{\"description\":\"[m]\""
",\"type\":\"number\"},\"version\":{\"description\":\"Meaning of offset values "
"and how to apply them; version 0: "
"Rz(yaw+offset_yaw)*Ry(pitch+offset_pitch)*Rx(roll+offset_roll), "
"version 1: Rz(yaw)*Ry(pitch)*Rx(roll) * Rz(yaw_offset)*Ry(pitch_offset"
")*Rx(roll_offset)\",\"type\":\"integer\"},\"offset_north\":{\"description\":\"[m"
"]\",\"type\":\"number\"},\"offset_roll\":{\"description\":\"[deg]\",\"type\":\"numbe"
"r\"},\"offset_time\":{\"description\":\"[s]\",\"type\":\"number\"},\"offset_yaw\":{"
"\"description\":\"[deg]\",\"type\":\"number\"},\"offset_height\":{\"description\":"
"\"[m]\",\"type\":\"number\"}}},\"body_coordinate_system_type\":{\"description\":"
"\"BODY coordinate frame (NED: North-East-Down, ENU: East-North-Up), "
"default: NED\",\"type\":\"string\",\"enum\":[\"NED\",\"ENU\"]},\"socs_to_body_matr"
"ix\":{\"description\":\"Coordinate Transformation Matrix to transform from"
" Scanner's Own Coordinate System to Body Coordinate System. 4x4 matrix"
" stored as two dimensional array, row major order.\",\"type\":\"array\",\"it"
"ems\":{\"description\":\"rows\",\"type\":\"array\",\"items\":{\"description\":\"colu"
"mns\",\"type\":\"number\"},\"minItems\":4,\"maxItems\":4},\"minItems\":4,\"maxItem"
"s\":4},\"socs_to_rocs_matrix\":{\"description\":\"Coordinate Transformation "
"Matrix to transform from Scanner's Own Coordinate System to Record "
"Coordinate System. 4x4 matrix stored as two dimensional array, row "
"major order.\",\"type\":\"array\",\"items\":{\"description\":\"rows\",\"type\":\"arr"
"ay\",\"items\":{\"description\":\"columns\",\"type\":\"number\"},\"minItems\":4,\"ma"
"xItems\":4},\"minItems\":4,\"maxItems\":4},\"trajectory_file\":{\"description\""
":\"Trajectory data used for georeferencing of the point cloud\",\"require"
"d\":[\"file_extension\"],\"type\":\"object\",\"properties\":{\"file_uuid\":{\"desc"
"ription\":\"File's Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Trajectory "
"file extension, without the leading dot\",\"type\":\"string\"}}}},\"$schema\""
":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_GEOREFERENCING_PARAMETERS_EXAMPLE = (
"{\"trajectory_offsets\":{\"offset_pitch\":0.01,\"offset_east\":0.15,\"version"
"\":0,\"offset_north\":0.07,\"offset_roll\":0.03,\"offset_time\":18.007,\"offse"
"t_yaw\":-0.45,\"offset_height\":-0.2},\"body_coordinate_system_type\":\"NED\""
",\"socs_to_body_matrix\":[[-0.269827776749716,-0.723017716139738,0.63595"
"4678449952,0.0],[0.962908599449764,-0.20260517250352,0.178208229833847"
",0.0],[0.0,0.660451759194338,0.7508684796801,0.0],[0.0,0.0,0.0,1.0]],\""
"trajectory_file\":{\"file_uuid\":\"93a03615-66c0-4bea-8ff8-c577378fe660\",\""
"file_extension\":\"pofx\"}}"
)

# License keys for software features
RDB_RIEGL_LICENSES             = "riegl.licenses"
RDB_RIEGL_LICENSES_TITLE       = "Software License Keys"
RDB_RIEGL_LICENSES_DESCRIPTION = "License keys for software features"
RDB_RIEGL_LICENSES_STATUS      = "optional"
RDB_RIEGL_LICENSES_SCHEMA = (
"{\"description\":\"License keys for software "
"features\",\"additionalProperties\":false,\"title\":\"Software License "
"Keys\",\"patternProperties\":{\"^.*$\":{\"description\":\"Each field of the "
"object represents a feature and holds a list of license keys, where "
"the field name is the feature "
"name.\",\"type\":\"array\",\"items\":{\"description\":\"License key (example: "
"'46AE032A - 39882AC4 - 9EC0A184 - 6F163D73')\",\"type\":\"string\"},\"minIte"
"ms\":1}},\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/sch"
"ema#\"}"
)
RDB_RIEGL_LICENSES_EXAMPLE = (
"{\"Full Waveform Analysis Topography\":[\"0FD5FF07 - 011A1255 - 9F76CACA "
"- 8D2ED557\"],\"Georeferencing\":[\"46AE032A - 39882AC4 - 9EC0A184 - "
"6F163D73\"],\"MTA resolution\":[\"468E020A - 39A922E4 - B681A184 - "
"673E3D72\"],\"Full Waveform Analysis Topography with GPU "
"support\":[\"8AB44126 - 23B92250 - 16E2689F - 34EF7E7B\"]}"
)

# Parameters for MTA processing
RDB_RIEGL_MTA_SETTINGS             = "riegl.mta_settings"
RDB_RIEGL_MTA_SETTINGS_TITLE       = "MTA Settings"
RDB_RIEGL_MTA_SETTINGS_DESCRIPTION = "Parameters for MTA processing"
RDB_RIEGL_MTA_SETTINGS_STATUS      = "optional"
RDB_RIEGL_MTA_SETTINGS_SCHEMA = (
"{\"description\":\"Parameters for MTA "
"processing\",\"type\":\"object\",\"title\":\"MTA "
"Settings\",\"properties\":{\"modulation_depth\":{\"description\":\"Depth of "
"pulse position modulation in meter.\",\"type\":\"number\",\"minimum\":0},\"zon"
"e_width\":{\"description\":\"Width of a MTA zone in meter.\",\"type\":\"number"
"\",\"minimum\":0},\"zone_count\":{\"description\":\"Maximum number of MTA zone"
"s.\",\"maximum\":255,\"type\":\"integer\",\"minimum\":0}},\"$schema\":\"http://jso"
"n-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_MTA_SETTINGS_EXAMPLE = (
"{\"modulation_depth\":9.368514,\"zone_width\":149.896225,\"zone_count\":23}"
)

# Lookup table for range correction based on raw range
RDB_RIEGL_NEAR_RANGE_CORRECTION             = "riegl.near_range_correction"
RDB_RIEGL_NEAR_RANGE_CORRECTION_TITLE       = "Near Range Correction Table"
RDB_RIEGL_NEAR_RANGE_CORRECTION_DESCRIPTION = "Lookup table for range correction based on raw range"
RDB_RIEGL_NEAR_RANGE_CORRECTION_STATUS      = "optional"
RDB_RIEGL_NEAR_RANGE_CORRECTION_SCHEMA = (
"{\"description\":\"Lookup table for range correction based on raw "
"range\",\"required\":[\"delta\",\"content\"],\"title\":\"Near Range Correction "
"Table\",\"properties\":{\"content\":{\"description\":\"Correction value [m] to"
" be added to the raw range\",\"type\":\"array\",\"items\":{\"type\":\"number\"},\""
"minItems\":1,\"maxItems\":2000},\"delta\":{\"description\":\"Delta between "
"table entries [m], first entry is at range = 0 m\",\"type\":\"number\"}},\"t"
"ype\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_NEAR_RANGE_CORRECTION_EXAMPLE = (
"{\"content\":[0.0],\"delta\":0.512}"
)

# Standard deviation for range and amplitude as a function of amplitude
RDB_RIEGL_NOISE_ESTIMATES             = "riegl.noise_estimates"
RDB_RIEGL_NOISE_ESTIMATES_TITLE       = "Noise Estimates"
RDB_RIEGL_NOISE_ESTIMATES_DESCRIPTION = "Standard deviation for range and amplitude as a function of amplitude"
RDB_RIEGL_NOISE_ESTIMATES_STATUS      = "optional"
RDB_RIEGL_NOISE_ESTIMATES_SCHEMA = (
"{\"description\":\"Standard deviation for range and amplitude as a "
"function of amplitude\",\"required\":[\"amplitude\",\"range_sigma\",\"amplitud"
"e_sigma\"],\"title\":\"Noise "
"Estimates\",\"properties\":{\"range_sigma\":{\"description\":\"Sigma range [m]"
"\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplitude_sigma\":{\"descri"
"ption\":\"Sigma amplitude [dB]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}"
"},\"amplitude\":{\"description\":\"Amplitude [dB]\",\"type\":\"array\",\"items\":{"
"\"type\":\"number\"}}},\"type\":\"object\",\"$schema\":\"http://json-schema.org/d"
"raft-04/schema#\"}"
)
RDB_RIEGL_NOISE_ESTIMATES_EXAMPLE = (
"{\"range_sigma\":[0.065,0.056,0.046,0.038,0.032,0.027,0.024,0.021,0.018,"
"0.016,0.014],\"amplitude_sigma\":[0.988,0.988,0.875,0.774,0.686,0.608,0."
"54,0.482,0.432,0.39,0.354],\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7."
"0,8.0,9.0,10.0]}"
)

# Notch filter parameters for window glass echoes
RDB_RIEGL_NOTCH_FILTER             = "riegl.notch_filter"
RDB_RIEGL_NOTCH_FILTER_TITLE       = "Notch Filter"
RDB_RIEGL_NOTCH_FILTER_DESCRIPTION = "Notch filter parameters for window glass echoes"
RDB_RIEGL_NOTCH_FILTER_STATUS      = "optional"
RDB_RIEGL_NOTCH_FILTER_SCHEMA = (
"{\"description\":\"Notch filter parameters for window glass echoes\",\"requ"
"ired\":[\"range_minimum\",\"range_maximum\",\"amplitude_maximum\"],\"title\":\"N"
"otch Filter\",\"properties\":{\"range_minimum\":{\"description\":\"Minimum "
"range [m]\",\"type\":\"number\"},\"range_maximum\":{\"description\":\"Maximum "
"range "
"[m]\",\"type\":\"number\"},\"amplitude_maximum\":{\"description\":\"Maximum "
"amplitude [dB]\",\"type\":\"number\",\"minimum\":0}},\"type\":\"object\",\"$schema"
"\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_NOTCH_FILTER_EXAMPLE = (
"{\"range_minimum\":-0.5,\"range_maximum\":0.2,\"amplitude_maximum\":18.0}"
)

# Details about the pixels contained in the file
RDB_RIEGL_PIXEL_INFO             = "riegl.pixel_info"
RDB_RIEGL_PIXEL_INFO_TITLE       = "Pixel Information"
RDB_RIEGL_PIXEL_INFO_DESCRIPTION = "Details about the pixels contained in the file"
RDB_RIEGL_PIXEL_INFO_STATUS      = "optional"
RDB_RIEGL_PIXEL_INFO_SCHEMA = (
"{\"description\":\"Details about the pixels contained in the "
"file\",\"required\":[\"size\"],\"title\":\"Pixel "
"Information\",\"properties\":{\"size\":{\"description\":\"Size of pixels in "
"file coordinate system.\",\"$ref\":\"#/definitions/pixel_size\"},\"size_llcs"
"\":{\"description\":\"Size of pixels in a locally levelled cartesian "
"coordinate system (xy). This is only used for pixels based on a map pr"
"ojection.\",\"$ref\":\"#/definitions/pixel_size\"}},\"definitions\":{\"pixel_s"
"ize\":{\"description\":\"Size of "
"pixels.\",\"type\":\"array\",\"items\":{\"description\":\"Length of pixel edge ["
"m].\",\"type\":\"number\",\"minimum\":0},\"minItems\":2,\"maxItems\":2}},\"type\":\""
"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_PIXEL_INFO_EXAMPLE = (
"{\"size\":[0.5971642834779395,0.5971642834779395],\"size_llcs\":[0.5156575"
"252891171,0.5130835356683303]}"
)

# Details about the plane patch matching process
RDB_RIEGL_PLANE_PATCH_MATCHING             = "riegl.plane_patch_matching"
RDB_RIEGL_PLANE_PATCH_MATCHING_TITLE       = "Plane Patch Matching"
RDB_RIEGL_PLANE_PATCH_MATCHING_DESCRIPTION = "Details about the plane patch matching process"
RDB_RIEGL_PLANE_PATCH_MATCHING_STATUS      = "optional"
RDB_RIEGL_PLANE_PATCH_MATCHING_SCHEMA = (
"{\"description\":\"Details about the plane patch matching process\",\"requi"
"red\":[\"plane_patch_file_one\",\"plane_patch_file_two\"],\"title\":\"Plane "
"Patch Matching\",\"properties\":{\"plane_patch_file_two\":{\"description\":\"R"
"eference to the plane patch file two\",\"$ref\":\"#/definitions/file_refer"
"ence\"},\"plane_patch_file_one\":{\"description\":\"Reference to the plane "
"patch file one\",\"$ref\":\"#/definitions/file_reference\"}},\"definitions\":"
"{\"file_reference\":{\"description\":\"Reference to a plane patch file\",\"re"
"quired\":[\"file_uuid\",\"file_path\"],\"type\":\"object\",\"properties\":{\"file_"
"path\":{\"description\":\"Path of the plane patch file relative to the "
"match file\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"Plane patch "
"file's Universally Unique Identifier (RFC 4122)\",\"type\":\"string\"}}}},\""
"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_PLANE_PATCH_MATCHING_EXAMPLE = (
"{\"plane_patch_file_two\":{\"file_path\":\"project.ptch\",\"file_uuid\":\"fa47d"
"509-a64e-49ce-8b14-ff3130fbefa9\"},\"plane_patch_file_one\":{\"file_path\":"
"\"Record009_Line001/191025_121410_Scanner_1.ptch\",\"file_uuid\":\"810f5d57"
"-eccf-49ed-b07a-0cdd109b4213\"}}"
)

# Statistics about plane patches found by Plane Patch Extractor
RDB_RIEGL_PLANE_PATCH_STATISTICS             = "riegl.plane_patch_statistics"
RDB_RIEGL_PLANE_PATCH_STATISTICS_TITLE       = "Plane Patch Statistics"
RDB_RIEGL_PLANE_PATCH_STATISTICS_DESCRIPTION = "Statistics about plane patches found by Plane Patch Extractor"
RDB_RIEGL_PLANE_PATCH_STATISTICS_STATUS      = "optional"
RDB_RIEGL_PLANE_PATCH_STATISTICS_SCHEMA = (
"{\"description\":\"Statistics about plane patches found by Plane Patch "
"Extractor\",\"type\":\"object\",\"title\":\"Plane Patch "
"Statistics\",\"properties\":{\"total_area\":{\"description\":\"sum of all "
"plane patch areas [m\\u00b2]\",\"type\":\"number\"},\"total_horizontal_area\":"
"{\"description\":\"sum of all plane patch areas projected to horizontal "
"plane [m\\u00b2]\",\"type\":\"number\"}},\"$schema\":\"http://json-schema.org/d"
"raft-04/schema#\"}"
)
RDB_RIEGL_PLANE_PATCH_STATISTICS_EXAMPLE = (
"{\"total_area\":14007.965,\"total_horizontal_area\":13954.601}"
)

# Settings and classes for plane slope classification
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO             = "riegl.plane_slope_class_info"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_TITLE       = "Plane Slope Class Info"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_DESCRIPTION = "Settings and classes for plane slope classification"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_STATUS      = "optional"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_SCHEMA = (
"{\"description\":\"Settings and classes for plane slope "
"classification\",\"required\":[\"settings\",\"classes\"],\"title\":\"Plane Slope"
" Class Info\",\"properties\":{\"settings\":{\"description\":\"Classification "
"settings, details see documentation of rdbplanes\",\"oneOf\":[{\"$ref\":\"#/"
"definitions/method-1\"},{\"$ref\":\"#/definitions/method-2\"}],\"type\":\"obje"
"ct\"},\"classes\":{\"description\":\"Class definition table\",\"type\":\"object\""
",\"additionalProperties\":false,\"patternProperties\":{\"^[0-9]+$\":{\"descri"
"ption\":\"one field per class, field name is class number, field value "
"is class name\",\"type\":\"string\"}}}},\"definitions\":{\"method-1\":{\"descrip"
"tion\":\"Classification method 1\",\"required\":[\"plane_classification_meth"
"od\",\"maximum_inclination_angle_horizontal\"],\"type\":\"object\",\"propertie"
"s\":{\"maximum_inclination_angle_horizontal\":{\"description\":\"maximum "
"inclination angle of horizontal plane patches [deg]\",\"maximum\":360.0,\""
"type\":\"number\",\"minimum\":-360.0},\"plane_classification_method\":{\"descr"
"iption\":\"method ID (=1)\",\"maximum\":1,\"type\":\"integer\",\"minimum\":1}}},\""
"method-2\":{\"description\":\"Classification method 2\",\"required\":[\"plane_"
"classification_method\",\"sloping_plane_classes_minimum_angle\",\"sloping_"
"plane_classes_maximum_angle\"],\"type\":\"object\",\"properties\":{\"sloping_p"
"lane_classes_maximum_angle\":{\"description\":\"maximum inclination angle "
"of sloping plane patches [deg]\",\"maximum\":360.0,\"type\":\"number\",\"minim"
"um\":-360.0},\"sloping_plane_classes_minimum_angle\":{\"description\":\"mini"
"mum inclination angle of sloping plane patches [deg]\",\"maximum\":360.0,"
"\"type\":\"number\",\"minimum\":-360.0},\"plane_classification_method\":{\"desc"
"ription\":\"method ID (=2)\",\"maximum\":2,\"type\":\"integer\",\"minimum\":2}}}}"
",\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_EXAMPLE = (
"{\"settings\":{\"sloping_plane_classes_maximum_angle\":70.0,\"sloping_plane"
"_classes_minimum_angle\":10.0,\"plane_classification_method\":2},\"classes"
"\":{\"14\":\"horizontal, pointing down\",\"13\":\"sloping, pointing down and "
"west\",\"5\":\"sloping, pointing up and west\",\"4\":\"sloping, pointing up "
"and north\",\"11\":\"sloping, pointing down and south\",\"3\":\"sloping, "
"pointing up and south\",\"10\":\"sloping, pointing down and "
"east\",\"1\":\"horizontal, pointing up\",\"6\":\"vertical, pointing "
"east\",\"9\":\"vertical, pointing west\",\"2\":\"sloping, pointing up and "
"east\",\"8\":\"vertical, pointing north\",\"12\":\"sloping, pointing down and "
"north\",\"7\":\"vertical, pointing south\"}}"
)

# Grouping and sorting of point attributes for visualization purposes
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS             = "riegl.point_attribute_groups"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_TITLE       = "Point Attribute Groups"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_DESCRIPTION = "Grouping and sorting of point attributes for visualization purposes"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_STATUS      = "optional"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_SCHEMA = (
"{\"description\":\"Grouping and sorting of point attributes for "
"visualization purposes\",\"additionalProperties\":false,\"title\":\"Point "
"Attribute Groups\",\"patternProperties\":{\"^.*$\":{\"description\":\"Each "
"field of the object represents a point attribute group and holds a "
"list of point attributes, where the field name is the group "
"name.\",\"type\":\"array\",\"items\":{\"description\":\"Point attribute full "
"name or name pattern (perl regular expression syntax)\",\"type\":\"string\""
"},\"minItems\":1}},\"type\":\"object\",\"$schema\":\"http://json-schema.org/dra"
"ft-04/schema#\"}"
)
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_EXAMPLE = (
"{\"Coordinates/Vectors\":[\"riegl.xyz\",\"riegl.range\",\"riegl.theta\",\"riegl"
".phi\"],\"Other "
"Attributes\":[\"riegl.selected\",\"riegl.visible\"],\"Secondary Attributes\":"
"[\"riegl.mirror_facet\",\"riegl.waveform_available\"],\"Time\":[\"riegl.times"
"tamp\"],\"Primary "
"Attributes\":[\"riegl.reflectance\",\"riegl.amplitude\",\"riegl.deviation\"]}"
)

# Details about point cloud files
RDB_RIEGL_POINTCLOUD_INFO             = "riegl.pointcloud_info"
RDB_RIEGL_POINTCLOUD_INFO_TITLE       = "Point Cloud Information"
RDB_RIEGL_POINTCLOUD_INFO_DESCRIPTION = "Details about point cloud files"
RDB_RIEGL_POINTCLOUD_INFO_STATUS      = "optional"
RDB_RIEGL_POINTCLOUD_INFO_SCHEMA = (
"{\"description\":\"Details about point cloud "
"files\",\"type\":\"object\",\"title\":\"Point Cloud Information\",\"properties\":"
"{\"comments\":{\"description\":\"Comments\",\"type\":\"string\"},\"field_of_appli"
"cation\":{\"description\":\"Field of application\",\"type\":\"string\",\"enum\":["
"\"unknown\",\"SLS\",\"TLS\",\"KLS\",\"MLS\",\"ULS\",\"ALS\",\"BLS\",\"ILS\"]},\"project\":"
"{\"description\":\"Project name\",\"type\":\"string\"}},\"$schema\":\"http://json"
"-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_POINTCLOUD_INFO_EXAMPLE = (
"{\"comments\":\"Line 3\",\"field_of_application\":\"ALS\",\"project\":\"Campaign "
"4\"}"
)

# Estimated position and orientation information
RDB_RIEGL_POSE_ESTIMATION             = "riegl.pose_estimation"
RDB_RIEGL_POSE_ESTIMATION_TITLE       = "Pose Estimation"
RDB_RIEGL_POSE_ESTIMATION_DESCRIPTION = "Estimated position and orientation information"
RDB_RIEGL_POSE_ESTIMATION_STATUS      = "optional"
RDB_RIEGL_POSE_ESTIMATION_SCHEMA = (
"{\"description\":\"Estimated position and orientation information as "
"measured by GNSS, IMU or inclination "
"sensors\",\"required\":[\"orientation\"],\"title\":\"Pose "
"Estimation\",\"properties\":{\"orientation\":{\"description\":\"Orientation "
"values and orientation accuracies, measured with IMU or inclination se"
"nsors.\",\"required\":[\"roll\",\"pitch\",\"yaw\",\"roll_accuracy\",\"pitch_accura"
"cy\",\"yaw_accuracy\"],\"type\":\"object\",\"properties\":{\"yaw\":{\"description\""
":\"Yaw angle about scanner Z-axis [deg]\",\"maximum\":360,\"type\":\"number\","
"\"minimum\":-360},\"pitch\":{\"description\":\"Pitch angle about scanner "
"Y-axis [deg]\",\"maximum\":360,\"type\":\"number\",\"minimum\":-360},\"yaw_accur"
"acy\":{\"description\":\"Yaw angle accuracy [deg]\",\"type\":\"number\",\"minimu"
"m\":0,\"exclusiveMinimum\":true},\"roll_accuracy\":{\"description\":\"Roll "
"angle accuracy [deg]\",\"type\":\"number\",\"minimum\":0,\"exclusiveMinimum\":t"
"rue},\"pitch_accuracy\":{\"description\":\"Pitch angle accuracy [deg]\",\"typ"
"e\":\"number\",\"minimum\":0,\"exclusiveMinimum\":true},\"roll\":{\"description\""
":\"Roll angle about scanner X-axis [deg]\",\"maximum\":360,\"type\":\"number\""
",\"minimum\":-360}}},\"position\":{\"description\":\"Position coordinates and"
" position accuracy values as measured by GNSS in the specified "
"Coordinate Reference System (CRS)\",\"required\":[\"coordinate_1\",\"coordin"
"ate_2\",\"coordinate_3\",\"horizontal_accuracy\",\"vertical_accuracy\",\"crs\"]"
",\"type\":\"object\",\"properties\":{\"coordinate_1\":{\"description\":\"Coordina"
"te 1 as defined by axis 1 of the specified CRS (e.g., X, "
"Latitude)\",\"type\":\"number\"},\"coordinate_2\":{\"description\":\"Coordinate "
"2 as defined by axis 2 of the specified CRS (e.g., Y, Longitude)\",\"typ"
"e\":\"number\"},\"horizontal_accuracy\":{\"description\":\"Horizontal accuracy"
" [m]\",\"type\":\"number\",\"minimum\":0,\"exclusiveMinimum\":true},\"vertical_a"
"ccuracy\":{\"description\":\"Vertical accuracy [m]\",\"type\":\"number\",\"minim"
"um\":0,\"exclusiveMinimum\":true},\"crs\":{\"description\":\"Global Coordinate"
" Reference System\",\"required\":[\"epsg\"],\"type\":\"object\",\"properties\":{\""
"epsg\":{\"description\":\"EPSG "
"code\",\"type\":\"integer\",\"minimum\":0},\"wkt\":{\"description\":\"\\\"Well-Known"
" Text\\\" string, OGC WKT dialect (see http://www.opengeospatial.org/sta"
"ndards/wkt-crs)\",\"type\":\"string\"}}},\"coordinate_3\":{\"description\":\"Coo"
"rdinate 3 as defined by axis 3 of the specified CRS (e.g., Z, Altitude"
")\",\"type\":\"number\"}}},\"barometric_height_amsl\":{\"description\":\"Altitud"
"e determined based on the atmospheric pressure according to the "
"standard atmosphere laws [m].\",\"type\":\"number\"}},\"type\":\"object\",\"$sch"
"ema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_POSE_ESTIMATION_EXAMPLE = (
"{\"orientation\":{\"yaw\":101.87293630292045,\"pitch\":1.509153024827064,\"ya"
"w_accuracy\":1.0094337839368757,\"roll_accuracy\":0.009433783936875745,\"p"
"itch_accuracy\":0.009433783936875745,\"roll\":3.14743073066123},\"position"
"\":{\"coordinate_1\":48.655799473,\"coordinate_2\":15.645033406,\"horizontal"
"_accuracy\":0.810699999332428,\"vertical_accuracy\":1.3314999341964722,\"c"
"rs\":{\"epsg\":4979,\"wkt\":\"GEOGCS[\\\"WGS84 / Geographic\\\",DATUM[\\\"WGS84\\\","
"SPHEROID[\\\"WGS84\\\",6378137.000,298.257223563,AUTHORITY[\\\"EPSG\\\",\\\"7030"
"\\\"]],AUTHORITY[\\\"EPSG\\\",\\\"6326\\\"]],PRIMEM[\\\"Greenwich\\\",0.000000000000"
"0000,AUTHORITY[\\\"EPSG\\\",\\\"8901\\\"]],UNIT[\\\"Degree\\\",0.01745329251994329"
"547,AUTHORITY[\\\"EPSG\\\",\\\"9102\\\"]],AXIS[\\\"Latitude\\\",NORTH],AXIS[\\\"Long"
"itude\\\",EAST],AUTHORITY[\\\"EPSG\\\",\\\"4979\\\"]]\"},\"coordinate_3\":362.71249"
"38964844},\"barometric_height_amsl\":386.7457796227932}"
)

# Details on position and orientation sensors
RDB_RIEGL_POSE_SENSORS             = "riegl.pose_sensors"
RDB_RIEGL_POSE_SENSORS_TITLE       = "Pose Sensors"
RDB_RIEGL_POSE_SENSORS_DESCRIPTION = "Details on position and orientation sensors"
RDB_RIEGL_POSE_SENSORS_STATUS      = "optional"
RDB_RIEGL_POSE_SENSORS_SCHEMA = (
"{\"description\":\"Details on position and orientation sensors\",\"required"
"\":[\"gyroscope\",\"accelerometer\",\"magnetic_field_sensor\"],\"title\":\"Pose "
"Sensors\",\"properties\":{\"gyroscope\":{\"description\":\"Gyroscope details\","
"\"required\":[\"unit\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\",\"origin\",\"relat"
"ive_nonlinearity\"],\"type\":\"object\",\"properties\":{\"x_axis\":{\"descriptio"
"n\":\"Sensitive X axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":{\"description\":\"Sensitive Y"
" axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"origin\":{\"description\":\"Sensor "
"origin in SOCS [m] at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"offset\":{\"description\":\"Value to be"
" subtracted from raw measurement values\",\"$ref\":\"#/definitions/vector\""
"},\"z_axis\":{\"description\":\"Sensitive Z axis of sensor at frame angle ="
" 0\",\"$ref\":\"#/definitions/vector\"},\"unit\":{\"description\":\"Unit of raw "
"data and calibration values, 1 LSB in rad/s\",\"type\":\"number\",\"minimum\""
":0,\"exclusiveMinimum\":true},\"relative_nonlinearity\":{\"description\":\"Re"
"lative nonlinearity, dimensionless\",\"$ref\":\"#/definitions/vector\"}}},\""
"accelerometer\":{\"description\":\"Accelerometer details\",\"required\":[\"uni"
"t\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\",\"origin\",\"relative_nonlinearity"
"\"],\"type\":\"object\",\"properties\":{\"x_axis\":{\"description\":\"Sensitive X "
"axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":{\"description\":\"Sensitive Y"
" axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"origin\":{\"description\":\"Sensor "
"origin in SOCS [m] at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"offset\":{\"description\":\"Value to be"
" subtracted from raw measurement values\",\"$ref\":\"#/definitions/vector\""
"},\"z_axis\":{\"description\":\"Sensitive Z axis of sensor at frame angle ="
" 0\",\"$ref\":\"#/definitions/vector\"},\"unit\":{\"description\":\"Unit of raw "
"data and calibration values, 1 LSB in 9.81 m/s\\u00b2\",\"type\":\"number\","
"\"minimum\":0,\"exclusiveMinimum\":true},\"relative_nonlinearity\":{\"descrip"
"tion\":\"Relative nonlinearity, dimensionless\",\"$ref\":\"#/definitions/vec"
"tor\"}}},\"magnetic_field_sensor\":{\"description\":\"Magnetic Field Sensor "
"details\",\"required\":[\"unit\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\",\"fixed"
"\",\"relative_nonlinearity\"],\"type\":\"object\",\"properties\":{\"x_axis\":{\"de"
"scription\":\"Sensitive X axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":{\"description\":\"Sensitive Y"
" axis of sensor at frame angle = 0\",\"$ref\":\"#/definitions/vector\"},\"re"
"lative_nonlinearity\":{\"description\":\"Relative nonlinearity, dimensionl"
"ess\",\"$ref\":\"#/definitions/vector\"},\"offset\":{\"description\":\"Value to "
"be subtracted from raw measurement values\",\"$ref\":\"#/definitions/vecto"
"r\"},\"z_axis\":{\"description\":\"Sensitive Z axis of sensor at frame angle"
" = 0\",\"$ref\":\"#/definitions/vector\"},\"unit\":{\"description\":\"Unit of "
"raw data and calibration values, 1 LSB in nT\",\"type\":\"number\",\"minimum"
"\":0,\"exclusiveMinimum\":true},\"fixed\":{\"description\":\"Distortion of "
"magnetic field caused by non-rotating scanner part\",\"$ref\":\"#/definiti"
"ons/vector\"}}}},\"definitions\":{\"vector\":{\"type\":\"array\",\"items\":{\"desc"
"ription\":\"Index 0=X, 1=Y, 2=Z component\",\"type\":\"number\"},\"minItems\":3"
",\"maxItems\":3}},\"type\":\"object\",\"$schema\":\"http://json-schema.org/draf"
"t-04/schema#\"}"
)
RDB_RIEGL_POSE_SENSORS_EXAMPLE = (
"{\"gyroscope\":{\"x_axis\":[-121.195556640625,0.8219714164733887,0.2313031"
"703233719],\"y_axis\":[-0.440765917301178,-0.7897399663925171,119.589477"
"5390625],\"origin\":[0.026900000870227814,-0.03999999910593033,-0.089500"
"00256299973],\"offset\":[-50.92609786987305,146.15643310546875,62.432727"
"8137207],\"z_axis\":[0.555869996547699,119.22135162353516,0.467585027217"
"865],\"unit\":0.00014544410805683583,\"relative_nonlinearity\":[2.88817631"
"1444113e-07,1.06274164579645e-07,-1.7186295080634935e-39]},\"accelerome"
"ter\":{\"x_axis\":[-15008.123046875,56.956390380859375,-60.5175666809082]"
",\"y_axis\":[-7.027288913726807,-44.12333679199219,14952.3701171875],\"or"
"igin\":[0.026900000870227814,-0.03999999910593033,-0.08950000256299973]"
",\"offset\":[-733.3636474609375,58.969032287597656,1060.2550048828125],\""
"z_axis\":[1.639882206916809,15166.744140625,-116.99742889404297],\"unit\""
":6.666666740784422e-05,\"relative_nonlinearity\":[0.0,0.0,0.0]},\"magneti"
"c_field_sensor\":{\"x_axis\":[-0.011162743903696537,-2.315962774446234e-0"
"5,0.00016818844596855342],\"y_axis\":[0.00027888521435670555,-0.01142742"
"4848079681,-5.204829722060822e-05],\"relative_nonlinearity\":[0.0,0.0,0."
"0],\"offset\":[-23812.052734375,5606.57666015625,2493.28125],\"z_axis\":[0"
".00041987866279669106,7.876977906562388e-05,0.011407104320824146],\"uni"
"t\":91.74311828613281,\"fixed\":[-1576.010498046875,1596.081787109375,0.0"
"]}}"
)

# Laser pulse position modulation used for MTA resolution
RDB_RIEGL_PULSE_POSITION_MODULATION             = "riegl.pulse_position_modulation"
RDB_RIEGL_PULSE_POSITION_MODULATION_TITLE       = "Pulse Position Modulation"
RDB_RIEGL_PULSE_POSITION_MODULATION_DESCRIPTION = "Laser pulse position modulation used for MTA resolution"
RDB_RIEGL_PULSE_POSITION_MODULATION_STATUS      = "optional"
RDB_RIEGL_PULSE_POSITION_MODULATION_SCHEMA = (
"{\"description\":\"Laser pulse position modulation used for MTA resolutio"
"n\",\"required\":[\"length\",\"num_mod_ampl\",\"pulse_interval\"],\"title\":\"Puls"
"e Position Modulation\",\"properties\":{\"length\":{\"description\":\"Length "
"of code\",\"maximum\":255,\"type\":\"integer\",\"minimum\":0},\"pulse_interval\":"
"{\"description\":\"Explicit table of the pulse position modulation used "
"for MTA resolution. Table gives times between successive laser pulses "
"in seconds.\",\"type\":\"array\",\"items\":{\"type\":\"number\",\"minimum\":0}},\"co"
"de_phase_mode\":{\"description\":\"0: no synchronization, 1: toggle "
"between 2 phases, 2: increment with phase_increment\",\"maximum\":255,\"ty"
"pe\":\"integer\",\"minimum\":0},\"num_mod_ampl\":{\"description\":\"Number of "
"different modulation amplitudes (2: binary modulation)\",\"maximum\":255,"
"\"type\":\"integer\",\"minimum\":0},\"phase_step\":{\"description\":\"Step width "
"in phase of modulation code from line to line\",\"maximum\":255,\"type\":\"i"
"nteger\",\"minimum\":0}},\"type\":\"object\",\"$schema\":\"http://json-schema.or"
"g/draft-04/schema#\"}"
)
RDB_RIEGL_PULSE_POSITION_MODULATION_EXAMPLE = (
"{\"length\":31,\"pulse_interval\":[2.759375e-06,2.759375e-06,2.759375e-06,"
"2.759375e-06,2.821875e-06,2.759375e-06,2.759375e-06,2.821875e-06,2.759"
"375e-06,2.821875e-06,2.821875e-06,2.759375e-06,2.759375e-06,2.821875e-"
"06,2.821875e-06,2.821875e-06,2.821875e-06,2.821875e-06,2.759375e-06,2."
"759375e-06,2.759375e-06,2.821875e-06,2.821875e-06,2.759375e-06,2.82187"
"5e-06,2.821875e-06,2.821875e-06,2.759375e-06,2.821875e-06,2.759375e-06"
",2.821875e-06],\"code_phase_mode\":2,\"num_mod_ampl\":2,\"phase_step\":5}"
)

# Statistics about target distance wrt. SOCS origin
RDB_RIEGL_RANGE_STATISTICS             = "riegl.range_statistics"
RDB_RIEGL_RANGE_STATISTICS_TITLE       = "Range Statistics"
RDB_RIEGL_RANGE_STATISTICS_DESCRIPTION = "Statistics about target distance wrt. SOCS origin"
RDB_RIEGL_RANGE_STATISTICS_STATUS      = "optional"
RDB_RIEGL_RANGE_STATISTICS_SCHEMA = (
"{\"description\":\"Statistics about target distance wrt. SOCS origin\",\"re"
"quired\":[\"minimum\",\"average\",\"maximum\",\"std_dev\"],\"title\":\"Range "
"Statistics\",\"properties\":{\"maximum\":{\"description\":\"Maximum "
"value\",\"type\":\"number\"},\"average\":{\"description\":\"Average "
"value\",\"type\":\"number\"},\"minimum\":{\"description\":\"Minimum "
"value\",\"type\":\"number\"},\"std_dev\":{\"description\":\"Standard deviation\","
"\"type\":\"number\"}},\"type\":\"object\",\"$schema\":\"http://json-schema.org/dr"
"aft-04/schema#\"}"
)
RDB_RIEGL_RANGE_STATISTICS_EXAMPLE = (
"{\"maximum\":574.35,\"average\":15.49738,\"minimum\":0.919,\"std_dev\":24.349}"
)

# Receiver Internals
RDB_RIEGL_RECEIVER_INTERNALS             = "riegl.receiver_internals"
RDB_RIEGL_RECEIVER_INTERNALS_TITLE       = "Receiver Internals"
RDB_RIEGL_RECEIVER_INTERNALS_DESCRIPTION = "Receiver Internals"
RDB_RIEGL_RECEIVER_INTERNALS_STATUS      = "optional"
RDB_RIEGL_RECEIVER_INTERNALS_SCHEMA = (
"{\"description\":\"Receiver Internals\",\"title\":\"Receiver "
"Internals\",\"properties\":{\"sr\":{\"description\":\"Sample rate [Hz]\",\"type\""
":\"number\",\"minimum\":0,\"exclusiveMinimum\":true},\"t\":{\"type\":\"object\",\"a"
"dditionalProperties\":false,\"patternProperties\":{\"^[0-9]+$\":{\"descripti"
"on\":\"one field per channel, field name is channel "
"index\",\"$ref\":\"#/definitions/fp\"}}},\"si\":{\"description\":\"Start index ("
"hw_start)\",\"maximum\":255,\"type\":\"number\",\"minimum\":0},\"ex\":{\"descripti"
"on\":\"DEPRECATED, use 'riegl.exponential_decomposition' "
"instead\",\"type\":\"object\"},\"ns\":{\"description\":\"Number of samples\",\"max"
"imum\":4095,\"type\":\"integer\",\"minimum\":0},\"nt\":{\"description\":\"Number "
"of traces\",\"maximum\":255,\"type\":\"integer\",\"minimum\":0},\"a\":{\"descripti"
"on\":\"Amplitude [dB]\",\"type\":\"array\",\"items\":{\"type\":\"number\"},\"minItem"
"s\":1,\"maxItems\":256},\"tbl\":{\"description\":\"various internal data\",\"typ"
"e\":\"array\",\"items\":{\"$ref\":\"#/definitions/fp_table\"},\"minItems\":1},\"mw"
"\":{\"description\":\"Maximum weight\",\"maximum\":4095,\"type\":\"number\",\"mini"
"mum\":0,\"exclusiveMinimum\":true}},\"definitions\":{\"fp_table\":{\"required\""
":[\"ch\",\"tc\",\"nx\",\"ny\",\"tv\"],\"desription\":\"scanner internal "
"data\",\"type\":\"object\",\"properties\":{\"ch\":{\"description\":\"channel numbe"
"r\",\"type\":\"integer\",\"max\":255,\"min\":0},\"tv\":{\"type\":\"array\",\"items\":{\""
"oneOf\":[{\"$ref\":\"#/definitions/fp_table_row\"},{\"type\":\"number\"}]},\"min"
"Items\":1,\"maxItems\":2048},\"tc\":{\"description\":\"table data type "
"code\",\"type\":\"integer\",\"max\":255,\"min\":0},\"nx\":{\"description\":\"number "
"of x entries\",\"type\":\"integer\",\"max\":2048,\"min\":1},\"ny\":{\"description\""
":\"number of y entries\",\"type\":\"integer\",\"max\":2048,\"min\":1}}},\"fp_tabl"
"e_row\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"minItems\":1,\"maxItem"
"s\":2048},\"fp\":{\"description\":\"Fingerprint values\",\"required\":[\"s\",\"w\"]"
",\"type\":\"object\",\"properties\":{\"s\":{\"type\":\"array\",\"items\":{\"type\":\"ar"
"ray\",\"items\":{\"type\":\"number\"},\"minItems\":1,\"maxItems\":4096},\"minItems"
"\":1,\"maxItems\":256},\"w\":{\"type\":\"array\",\"items\":{\"type\":\"array\",\"items"
"\":{\"type\":\"number\"},\"minItems\":5,\"maxItems\":5},\"minItems\":1,\"maxItems\""
":256}}}},\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/sc"
"hema#\"}"
)
RDB_RIEGL_RECEIVER_INTERNALS_EXAMPLE = (
"{\"sr\":7959997000.0,\"t\":{\"1\":{\"s\":[[1.23,4.56],[7.89,0.12]],\"w\":[[78,86"
",126,134,31],[78,86,126,134,31]]},\"0\":{\"s\":[[1.23,4.56],[7.89,0.12]],\""
"w\":[[78,86,126,134,31],[78,86,126,134,31]]}},\"si\":48,\"ns\":400,\"nt\":128"
",\"a\":[-1.55],\"tbl\":[{\"ch\":0,\"tv\":[[1,2,3,4,5],[1.1,2.2,3.3,4.4,5.5]],\""
"tc\":1,\"nx\":5,\"ny\":2}],\"mw\":31}"
)

# List of names of the records
RDB_RIEGL_RECORD_NAMES             = "riegl.record_names"
RDB_RIEGL_RECORD_NAMES_TITLE       = "Record Names"
RDB_RIEGL_RECORD_NAMES_DESCRIPTION = "List of names of the records"
RDB_RIEGL_RECORD_NAMES_STATUS      = "optional"
RDB_RIEGL_RECORD_NAMES_SCHEMA = (
"{\"description\":\"List of names of the "
"records\",\"type\":\"object\",\"title\":\"Record "
"Names\",\"properties\":{\"names\":{\"description\":\"List of record names. The"
" name of a record is the {riegl.id}th element of this list. The number"
" of elements must correspond to the maximum riegl.id occurring in this"
" file.\",\"type\":\"array\",\"items\":{\"description\":\"Record name\",\"type\":\"st"
"ring\"}}},\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_RECORD_NAMES_EXAMPLE = (
"{\"names\":[\"Name of first record\",\"Name of second record\",\"Name of "
"third record\",\"Name of fourth record\"]}"
)

# Lookup table for reflectance calculation based on amplitude and range
RDB_RIEGL_REFLECTANCE_CALCULATION             = "riegl.reflectance_calculation"
RDB_RIEGL_REFLECTANCE_CALCULATION_TITLE       = "Reflectance Calculation Table"
RDB_RIEGL_REFLECTANCE_CALCULATION_DESCRIPTION = "Lookup table for reflectance calculation based on amplitude and range"
RDB_RIEGL_REFLECTANCE_CALCULATION_STATUS      = "optional"
RDB_RIEGL_REFLECTANCE_CALCULATION_SCHEMA = (
"{\"description\":\"Lookup table for reflectance calculation based on "
"amplitude and "
"range\",\"required\":[\"delta\",\"content\"],\"title\":\"Reflectance Calculation"
" Table\",\"properties\":{\"content\":{\"description\":\"Correction value [dB] "
"to be added to the amplitude\",\"type\":\"array\",\"items\":{\"type\":\"number\"}"
",\"minItems\":1,\"maxItems\":2000},\"delta\":{\"description\":\"Delta between "
"table entries [m], first entry is at range = 0 m\",\"type\":\"number\"}},\"t"
"ype\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_REFLECTANCE_CALCULATION_EXAMPLE = (
"{\"content\":[-33.01],\"delta\":0.150918}"
)

# Range-dependent and scan-angle-dependent correction of reflectance reading
RDB_RIEGL_REFLECTANCE_CORRECTION             = "riegl.reflectance_correction"
RDB_RIEGL_REFLECTANCE_CORRECTION_TITLE       = "Near-range reflectance correction"
RDB_RIEGL_REFLECTANCE_CORRECTION_DESCRIPTION = "Range-dependent and scan-angle-dependent correction of reflectance reading"
RDB_RIEGL_REFLECTANCE_CORRECTION_STATUS      = "optional"
RDB_RIEGL_REFLECTANCE_CORRECTION_SCHEMA = (
"{\"description\":\"Range-dependent and scan-angle-dependent correction of"
" reflectance reading\",\"required\":[\"ranges_m\",\"line_angles_deg\",\"reflec"
"tance_correction_db\"],\"title\":\"Near-range reflectance "
"correction\",\"properties\":{\"ranges_m\":{\"description\":\"Range [m]\",\"type\""
":\"array\",\"items\":{\"type\":\"number\"}},\"reflectance_correction_db\":{\"desc"
"ription\":\"Near range reflectance correction in dB as a function of "
"range over angle\",\"type\":\"array\",\"items\":{\"description\":\"rows (each "
"array corresponds to a "
"range)\",\"type\":\"array\",\"items\":{\"description\":\"columns (each value "
"corresponds to an "
"angle)\",\"type\":\"number\"}}},\"line_angles_deg\":{\"description\":\"Angle [de"
"g]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}}},\"type\":\"object\",\"$schem"
"a\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_REFLECTANCE_CORRECTION_EXAMPLE = (
"{\"ranges_m\":[0.0,1.0,2.0,3.0],\"reflectance_correction_db\":[[0.8,0.7,0."
"6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05"
",0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0."
"4,0.3,0.2,0.1,0.05,0.01]],\"line_angles_deg\":[0.0,0.5,1.0,1.5,1.0,2.0,2"
".5,3.0,3.5,4.0]}"
)

# Scan Pattern Description
RDB_RIEGL_SCAN_PATTERN             = "riegl.scan_pattern"
RDB_RIEGL_SCAN_PATTERN_TITLE       = "Scan Pattern"
RDB_RIEGL_SCAN_PATTERN_DESCRIPTION = "Scan Pattern Description"
RDB_RIEGL_SCAN_PATTERN_STATUS      = "optional"
RDB_RIEGL_SCAN_PATTERN_SCHEMA = (
"{\"description\":\"Scan Pattern "
"Description\",\"definitions\":{\"program\":{\"description\":\"Measurement prog"
"ram\",\"required\":[\"name\"],\"type\":\"object\",\"properties\":{\"laser_prr\":{\"d"
"escription\":\"Laser Pulse Repetition Rate [Hz]\",\"type\":\"number\",\"minimu"
"m\":0,\"exclusiveMinimum\":false},\"name\":{\"description\":\"Name of "
"measurement program\",\"type\":\"string\"}}}},\"title\":\"Scan "
"Pattern\",\"properties\":{\"rectangular\":{\"description\":\"Rectangular Field"
" Of View Scan Pattern\",\"required\":[\"phi_start\",\"phi_stop\",\"phi_increme"
"nt\",\"theta_start\",\"theta_stop\",\"theta_increment\"],\"type\":\"object\",\"pro"
"perties\":{\"theta_start\":{\"description\":\"Start theta angle in SOCS [deg"
"]\",\"maximum\":180.0,\"type\":\"number\",\"minimum\":0.0},\"phi_increment\":{\"de"
"scription\":\"Increment of phi angle in SOCS [deg]\",\"maximum\":90.0,\"type"
"\":\"number\",\"minimum\":0.0},\"phi_start\":{\"description\":\"Start phi angle "
"in SOCS [deg]\",\"maximum\":360.0,\"type\":\"number\",\"minimum\":0.0},\"phi_sto"
"p\":{\"description\":\"Stop phi angle in SOCS [deg]\",\"maximum\":720.0,\"type"
"\":\"number\",\"minimum\":0.0},\"program\":{\"$ref\":\"#/definitions/program\"},\""
"theta_increment\":{\"description\":\"Increment of theta angle in SOCS [deg"
"]\",\"maximum\":90.0,\"type\":\"number\",\"minimum\":0.0},\"theta_stop\":{\"descri"
"ption\":\"Stop theta angle in SOCS [deg]\",\"maximum\":180.0,\"type\":\"number"
"\",\"minimum\":0.0}}},\"line\":{\"description\":\"Line Scan Pattern\",\"required"
"\":[\"start\",\"stop\",\"increment\"],\"type\":\"object\",\"properties\":{\"start\":{"
"\"description\":\"Start angle in SOCS [deg]\",\"maximum\":360.0,\"type\":\"numb"
"er\",\"minimum\":0.0},\"increment\":{\"description\":\"Increment of angle in "
"SOCS [deg]\",\"maximum\":90.0,\"type\":\"number\",\"minimum\":0.0},\"program\":{\""
"$ref\":\"#/definitions/program\"},\"stop\":{\"description\":\"Stop angle in "
"SOCS [deg]\",\"maximum\":720.0,\"type\":\"number\",\"minimum\":0.0}}},\"segments"
"\":{\"description\":\"Segmented Line Scan Pattern\",\"required\":[\"list\"],\"ty"
"pe\":\"object\",\"properties\":{\"program\":{\"$ref\":\"#/definitions/program\"},"
"\"list\":{\"type\":\"array\",\"items\":{\"description\":\"Line Scan Segment\",\"req"
"uired\":[\"start\",\"stop\",\"increment\"],\"type\":\"object\",\"properties\":{\"sta"
"rt\":{\"description\":\"Start angle in SOCS [deg]\",\"maximum\":360.0,\"type\":"
"\"number\",\"minimum\":0.0},\"increment\":{\"description\":\"Increment of angle"
" in SOCS [deg]\",\"maximum\":90.0,\"type\":\"number\",\"minimum\":0.0},\"stop\":{"
"\"description\":\"Stop angle in SOCS [deg]\",\"maximum\":720.0,\"type\":\"numbe"
"r\",\"minimum\":0.0}}}}}}},\"$schema\":\"http://json-schema.org/draft-04/sch"
"ema#\"}"
)
RDB_RIEGL_SCAN_PATTERN_EXAMPLE = (
"{\"rectangular\":{\"theta_start\":30.0,\"phi_increment\":0.04,\"phi_start\":45"
".0,\"phi_stop\":270.0,\"program\":{\"laser_prr\":100000.0,\"name\":\"High "
"Speed\"},\"theta_increment\":0.04,\"theta_stop\":130.0}}"
)

# Details about laser shot files
RDB_RIEGL_SHOT_INFO             = "riegl.shot_info"
RDB_RIEGL_SHOT_INFO_TITLE       = "Shot Information"
RDB_RIEGL_SHOT_INFO_DESCRIPTION = "Details about laser shot files"
RDB_RIEGL_SHOT_INFO_STATUS      = "optional"
RDB_RIEGL_SHOT_INFO_SCHEMA = (
"{\"description\":\"Details about laser shot "
"files\",\"type\":\"object\",\"title\":\"Shot Information\",\"properties\":{\"shot_"
"file\":{\"required\":[\"file_extension\"],\"type\":\"object\",\"properties\":{\"fi"
"le_uuid\":{\"description\":\"File's Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Shot file "
"extension, without the leading dot\",\"type\":\"string\"}}}},\"$schema\":\"htt"
"p://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_SHOT_INFO_EXAMPLE = (
"{\"shot_file\":{\"file_uuid\":\"26a00815-67c0-4bff-8fe8-c577378fe663\",\"file"
"_extension\":\"sodx\"}}"
)

# Conversion of background radiation raw values to temperatures in °C
RDB_RIEGL_TEMPERATURE_CALCULATION             = "riegl.temperature_calculation"
RDB_RIEGL_TEMPERATURE_CALCULATION_TITLE       = "Temperature Calculation Table"
RDB_RIEGL_TEMPERATURE_CALCULATION_DESCRIPTION = "Conversion of background radiation raw values to temperatures in °C"
RDB_RIEGL_TEMPERATURE_CALCULATION_STATUS      = "optional"
RDB_RIEGL_TEMPERATURE_CALCULATION_SCHEMA = (
"{\"description\":\"Conversion of background radiation raw values to "
"temperatures in \\u00b0C\",\"title\":\"Temperature Calculation "
"Table\",\"properties\":{\"InGaAs\":{\"description\":\"Conversion table for "
"InGaAs channel\",\"$ref\":\"#/definitions/conversion_table\"},\"InGaAs_Si_Di"
"fference\":{\"description\":\"Conversion table for InGaAs - Si difference\""
",\"$ref\":\"#/definitions/conversion_table\"},\"Si\":{\"description\":\"Convers"
"ion table for Si channel\",\"$ref\":\"#/definitions/conversion_table\"}},\"d"
"efinitions\":{\"conversion_table\":{\"required\":[\"value\",\"temperature\"],\"t"
"ype\":\"object\",\"properties\":{\"temperature\":{\"description\":\"Temperature "
"[\\u00b0C]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"value\":{\"descrip"
"tion\":\"LSB [1]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}}}}},\"type\":\"o"
"bject\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_TEMPERATURE_CALCULATION_EXAMPLE = (
"{\"InGaAs\":{\"temperature\":[307.22196722535614,309.1153478247277,311.118"
"8086915047,313.10025350480055,315.2137946389828,317.2172555057597,319."
"2207163725366,321.2021611858325,323.3157023200148],\"value\":[0.0,64.000"
"97659230323,128.0019531846065,192.0029297769097,256.0039063692129,320."
"00488296151616,384.0058595538194,448.0068361461226,512.0078127384259]}"
",\"InGaAs_Si_Difference\":{\"temperature\":[1749.977111117893,1749.9771111"
"17893,1749.977111117893,1749.977111117893,1749.977111117893,1749.97711"
"1117893,1744.7813348796044,1681.9971312601092,1622.3944822534868],\"val"
"ue\":[1000.0,1100.090029602954,1200.04425183874,1300.1342814416948,1400"
".0885036774805,1500.0427259132668,1600.1327555162209,1700.086977752006"
"5,1800.0411999877924]},\"Si\":{\"temperature\":[546.300048828125,548.81640"
"51212026,551.3143938500972,554.0144257850053,556.604252334815,559.2124"
"464488079,561.8022729986177,564.4104671126105,567.0002936624203],\"valu"
"e\":[0.0,64.00097659230323,128.0019531846065,192.0029297769097,256.0039"
"063692129,320.00488296151616,384.0058595538194,448.0068361461226,512.0"
"078127384259]}}"
)

# Base of timestamps (epoch)
RDB_RIEGL_TIME_BASE             = "riegl.time_base"
RDB_RIEGL_TIME_BASE_TITLE       = "Time Base"
RDB_RIEGL_TIME_BASE_DESCRIPTION = "Base of timestamps (epoch)"
RDB_RIEGL_TIME_BASE_STATUS      = "optional"
RDB_RIEGL_TIME_BASE_SCHEMA = (
"{\"description\":\"Base of timestamps "
"(epoch)\",\"required\":[\"epoch\",\"source\"],\"title\":\"Time "
"Base\",\"properties\":{\"source\":{\"description\":\"Timestamp source\",\"type\":"
"\"string\",\"enum\":[\"unknown\",\"RTC\",\"GNSS\"]},\"system\":{\"description\":\"Tim"
"e system (time standard)\",\"type\":\"string\",\"enum\":[\"unknown\",\"UTC\",\"GPS"
"\"]},\"epoch\":{\"description\":\"Date and time of timestamp '0' as proposed"
" by RFC 3339 (e.g. 2015-10-27T00:00:00+01:00).\",\"type\":\"string\"}},\"typ"
"e\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_TIME_BASE_EXAMPLE = (
"{\"source\":\"GNSS\",\"system\":\"UTC\",\"epoch\":\"2015-10-27T00:00:00+00:00\"}"
)

# Details about position+orientation files
RDB_RIEGL_TRAJECTORY_INFO             = "riegl.trajectory_info"
RDB_RIEGL_TRAJECTORY_INFO_TITLE       = "Trajectory Information"
RDB_RIEGL_TRAJECTORY_INFO_DESCRIPTION = "Details about position+orientation files"
RDB_RIEGL_TRAJECTORY_INFO_STATUS      = "optional"
RDB_RIEGL_TRAJECTORY_INFO_SCHEMA = (
"{\"description\":\"Details about position+orientation files\",\"required\":["
"\"time_interval\",\"navigation_frame\"],\"title\":\"Trajectory "
"Information\",\"properties\":{\"settings\":{\"description\":\"Settings used to"
" calculate the trajectory (descriptive "
"text)\",\"type\":\"string\"},\"company\":{\"description\":\"Company "
"name\",\"type\":\"string\"},\"device\":{\"description\":\"Navigation device, "
"e.g. name/type/serial\",\"type\":\"string\"},\"field_of_application\":{\"descr"
"iption\":\"Field of application\",\"type\":\"string\",\"enum\":[\"unknown\",\"SLS\""
",\"TLS\",\"KLS\",\"MLS\",\"ULS\",\"ALS\",\"BLS\",\"ILS\"]},\"navigation_frame\":{\"desc"
"ription\":\"Navigation frame (NED: North-East-Down, ENU: East-North-Up)\""
",\"type\":\"string\",\"enum\":[\"unknown\",\"NED\",\"ENU\"]},\"software\":{\"descript"
"ion\":\"Software that calculated the trajectory (this may be the same or"
" different software than the one that created the "
"file)\",\"type\":\"string\"},\"time_interval\":{\"description\":\"Time interval "
"statistics\",\"required\":[\"minimum\",\"average\",\"maximum\",\"std_dev\"],\"type"
"\":\"object\",\"properties\":{\"maximum\":{\"description\":\"Maximum time "
"interval [s]\",\"type\":\"number\"},\"average\":{\"description\":\"Average time "
"interval [s]\",\"type\":\"number\"},\"minimum\":{\"description\":\"Minimum time "
"interval [s]\",\"type\":\"number\"},\"std_dev\":{\"description\":\"Standard "
"deviation of intervals "
"[s]\",\"type\":\"number\"}}},\"location\":{\"description\":\"Project location, "
"e.g. "
"city/state/country\",\"type\":\"string\"},\"project\":{\"description\":\"Project"
" name\",\"type\":\"string\"}},\"type\":\"object\",\"$schema\":\"http://json-schema"
".org/draft-04/schema#\"}"
)
RDB_RIEGL_TRAJECTORY_INFO_EXAMPLE = (
"{\"settings\":\"default\",\"company\":\"RIEGL LMS\",\"device\":\"IMU Model 12/1, "
"Serial# 12345\",\"field_of_application\":\"MLS\",\"navigation_frame\":\"NED\",\""
"software\":\"Navigation Software XYZ\",\"time_interval\":{\"maximum\":0.00500"
"4883,\"average\":0.00500053,\"minimum\":0.00500032,\"std_dev\":5.51e-07},\"lo"
"cation\":\"Horn\",\"project\":\"Campaign 3\"}"
)

# Details about vertex file
RDB_RIEGL_VERTEX_INFO             = "riegl.vertex_info"
RDB_RIEGL_VERTEX_INFO_TITLE       = "Vertex Information"
RDB_RIEGL_VERTEX_INFO_DESCRIPTION = "Details about vertex file"
RDB_RIEGL_VERTEX_INFO_STATUS      = "optional"
RDB_RIEGL_VERTEX_INFO_SCHEMA = (
"{\"description\":\"Details about vertex "
"file\",\"type\":\"object\",\"title\":\"Vertex Information\",\"properties\":{\"vert"
"ex_file\":{\"required\":[\"file_extension\"],\"type\":\"object\",\"properties\":{"
"\"file_uuid\":{\"description\":\"File's Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Vertex file "
"extension, without the leading dot\",\"type\":\"string\"}}}},\"$schema\":\"htt"
"p://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_VERTEX_INFO_EXAMPLE = (
"{\"vertex_file\":{\"file_uuid\":\"51534d95-d71f-4f36-ae1a-3e63a21fd1c7\",\"fi"
"le_extension\":\"vtx\"}}"
)

# Details about the voxels contained in the file
RDB_RIEGL_VOXEL_INFO             = "riegl.voxel_info"
RDB_RIEGL_VOXEL_INFO_TITLE       = "Voxel Information"
RDB_RIEGL_VOXEL_INFO_DESCRIPTION = "Details about the voxels contained in the file"
RDB_RIEGL_VOXEL_INFO_STATUS      = "optional"
RDB_RIEGL_VOXEL_INFO_SCHEMA = (
"{\"description\":\"Details about the voxels contained in the "
"file\",\"title\":\"Voxel Information\",\"oneOf\":[{\"required\":[\"size\",\"voxel_"
"origin\",\"voxel_type\"],\"additionalProperties\":false,\"properties\":{\"size"
"\":{\"description\":\"Size of voxels in file coordinate system.\",\"oneOf\":["
"{\"$ref\":\"#/definitions/voxel_size\"},{\"$ref\":\"#/definitions/voxel_size_"
"cubic\"}]},\"shape_thresholds\":{\"$ref\":\"#/definitions/shape_thresholds\"}"
",\"voxel_origin\":{\"$ref\":\"#/definitions/voxel_origin_enum\"},\"voxel_type"
"\":{\"$ref\":\"#/definitions/voxel_type\"}}},{\"required\":[\"reference_point\""
",\"size_llcs\",\"size\",\"voxel_origin\",\"voxel_type\"],\"additionalProperties"
"\":false,\"properties\":{\"size\":{\"description\":\"Size of voxels in file "
"coordinate system.\",\"$ref\":\"#/definitions/voxel_size\"},\"size_llcs\":{\"d"
"escription\":\"Size of voxels in a locally levelled cartesian coordinate"
" system (xyz). This is only used for voxels based on a map projection."
"\",\"$ref\":\"#/definitions/voxel_size\"},\"shape_thresholds\":{\"$ref\":\"#/def"
"initions/shape_thresholds\"},\"reference_point\":{\"description\":\"Point in"
" WGS84 geodetic decimal degree (EPSG:4326) that was used to compute "
"the projection distortion parameters. The coefficient order is "
"latitude, longitude. Only voxels with corresponding geo_tag, "
"voxel_size and reference_point can be reliably processed together. "
"This entry is available for voxel files in projected CRS only.\",\"type\""
":\"array\",\"items\":{\"maximum\":180,\"type\":\"number\",\"minimum\":-180},\"minIt"
"ems\":2,\"maxItems\":2},\"voxel_type\":{\"$ref\":\"#/definitions/voxel_type\"},"
"\"voxel_origin\":{\"oneOf\":[{\"$ref\":\"#/definitions/voxel_origin_enum\"},{\""
"description\":\"The base point of the voxel grid. Used together with "
"<tt>voxel_size</tt> and <tt>voxel_index</tt> to compute actual point c"
"oordinates.\",\"$ref\":\"#/definitions/voxel_origin_point\"}]}}}],\"type\":\"o"
"bject\",\"definitions\":{\"voxel_size_cubic\":{\"$ref\":\"#/definitions/edge_l"
"ength\",\"type\":\"number\"},\"shape_thresholds\":{\"description\":\"Thresholds "
"used to compute the voxel's shape_id value.\",\"type\":\"object\",\"required"
"\":[\"plane\",\"line\"],\"properties\":{\"plane\":{\"description\":\"If the "
"smallest eigenvalue is smaller than the median eigenvalue * "
"plane_threshold, the voxel is considered a plane.\",\"exclusiveMaximum\":"
"true,\"minimum\":0,\"maximum\":1,\"type\":\"number\",\"exclusiveMinimum\":true},"
"\"line\":{\"description\":\"If the biggest eigenvalue is bigger than the "
"median eigenvalue * line_threshold, the voxel is considered a line.\",\""
"type\":\"number\",\"exclusiveMinimum\":true,\"minimum\":1}}},\"voxel_size\":{\"d"
"escription\":\"Size of voxels.\",\"type\":\"array\",\"items\":{\"$ref\":\"#/defini"
"tions/edge_length\"},\"minItems\":3,\"maxItems\":3},\"voxel_origin_point\":{\""
"description\":\"Origin point for all voxel indices in voxel CRS.\",\"type\""
":\"array\",\"items\":{\"type\":\"number\"},\"minItems\":3,\"maxItems\":3},\"voxel_o"
"rigin_enum\":{\"description\":\"Defines whether the voxel's center or a "
"corner is placed on CRS origin <tt>(0/0/0)</tt>.\",\"default\":\"corner\",\""
"enum\":[\"center\",\"corner\"]},\"edge_length\":{\"description\":\"Length of "
"voxel edge [m].\",\"type\":\"number\",\"exclusiveMinimum\":true,\"minimum\":0},"
"\"voxel_type\":{\"description\":\"Whether a point in a voxel represents its"
" center or its centroid. If type is <tt>index</tt> there is no point "
"but only an integer voxel index.\",\"default\":\"centroid\",\"enum\":[\"center"
"\",\"centroid\",\"index\"]}},\"$schema\":\"http://json-schema.org/draft-04/sch"
"ema#\"}"
)
RDB_RIEGL_VOXEL_INFO_EXAMPLE = (
"{\"size\":[0.5971642834779395,0.5971642834779395,0.5143705304787237],\"sh"
"ape_thresholds\":{\"plane\":0.16,\"line\":6},\"size_llcs\":[0.515657525289117"
"1,0.5130835356683303,0.5143705304787237],\"reference_point\":[48,16],\"vo"
"xel_type\":\"centroid\",\"voxel_origin\":\"corner\"}"
)

# Settings for waveform averaging
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS             = "riegl.waveform_averaging_settings"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_TITLE       = "Waveform Averaging Settings"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_DESCRIPTION = "Settings for waveform averaging"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_SCHEMA = (
"{\"description\":\"Settings for waveform "
"averaging\",\"required\":[\"num_shots\",\"mta_zone\"],\"title\":\"Waveform "
"Averaging Settings\",\"properties\":{\"trim\":{\"description\":\"Percentage "
"for robust averaging.\",\"maximum\":0.5,\"type\":\"number\",\"minimum\":0,\"defa"
"ult\":0},\"mta_zone\":{\"description\":\"Fixed MTA zone for averaging.\",\"typ"
"e\":\"integer\",\"minimum\":1},\"num_shots\":{\"description\":\"Number of "
"consecutive shots to be used for averaging.\",\"type\":\"integer\",\"minimum"
"\":1}},\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schem"
"a#\"}"
)
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_EXAMPLE = (
"{\"trim\":0.05,\"mta_zone\":1,\"num_shots\":7}"
)

# Details about waveform files
RDB_RIEGL_WAVEFORM_INFO             = "riegl.waveform_info"
RDB_RIEGL_WAVEFORM_INFO_TITLE       = "Waveform Information"
RDB_RIEGL_WAVEFORM_INFO_DESCRIPTION = "Details about waveform files"
RDB_RIEGL_WAVEFORM_INFO_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_INFO_SCHEMA = (
"{\"description\":\"Details about waveform "
"files\",\"type\":\"object\",\"title\":\"Waveform Information\",\"properties\":{\"s"
"ample_data_files\":{\"type\":\"array\",\"items\":{\"required\":[\"channel\",\"chan"
"nel_name\",\"sample_interval\",\"sample_bits\",\"laser_wavelength\",\"delta_st"
"\",\"file_extension\"],\"type\":\"object\",\"properties\":{\"delta_st\":{\"descrip"
"tion\":\"reserved\",\"type\":\"number\"},\"channel\":{\"description\":\"Sample "
"block channel number (255 = invalid)\",\"exclusiveMaximum\":false,\"exclus"
"iveMinimum\":false,\"maximum\":255,\"type\":\"integer\",\"minimum\":0},\"sample_"
"bits\":{\"description\":\"Bitwidth of samples (e.g. 10 bit, 12 bit)\",\"excl"
"usiveMaximum\":false,\"exclusiveMinimum\":false,\"maximum\":32,\"type\":\"inte"
"ger\",\"minimum\":0},\"laser_wavelength\":{\"description\":\"Laser wavelength "
"in meters (0 = unknown)\",\"type\":\"number\",\"exclusiveMinimum\":false,\"min"
"imum\":0},\"file_extension\":{\"description\":\"Sample data file extension, "
"without the leading "
"dot\",\"type\":\"string\"},\"channel_name\":{\"description\":\"Sample block "
"channel name\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's "
"Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"sample_interval\":{\"description\":\"Sampling "
"interval in seconds\",\"type\":\"number\",\"exclusiveMinimum\":false,\"minimum"
"\":0}}}},\"range_offset_m\":{\"description\":\"Calibrated device specific "
"waveform data range offset in meters.\",\"type\":\"number\"},\"sample_block_"
"file\":{\"required\":[\"file_extension\"],\"type\":\"object\",\"properties\":{\"fi"
"le_uuid\":{\"description\":\"File's Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_extension\":{\"description\":\"Sample block "
"file extension, without the leading dot\",\"type\":\"string\"}}}},\"required"
"\":[\"sample_block_file\",\"sample_data_files\"],\"$schema\":\"http://json-sch"
"ema.org/draft-04/schema#\"}"
)
RDB_RIEGL_WAVEFORM_INFO_EXAMPLE = (
"{\"sample_data_files\":[{\"delta_st\":0,\"channel\":0,\"laser_wavelength\":0,\""
"sample_interval\":1.00503e-09,\"channel_name\":\"high_power\",\"file_extensi"
"on\":\"sp0\",\"sample_bits\":12,\"file_uuid\":\"da084413-e3e8-4655-a122-071de8"
"490d8e\"},{\"delta_st\":0,\"channel\":1,\"laser_wavelength\":0,\"sample_interv"
"al\":1.00503e-09,\"channel_name\":\"low_power\",\"file_extension\":\"sp1\",\"sam"
"ple_bits\":12,\"file_uuid\":\"93585b5e-5ea9-43a1-947b-e7ba3be642d2\"},{\"del"
"ta_st\":0,\"channel\":5,\"laser_wavelength\":0,\"sample_interval\":1.00503e-0"
"9,\"channel_name\":\"wwf\",\"file_extension\":\"sp5\",\"sample_bits\":12,\"file_u"
"uid\":\"9d2298c4-1036-464f-b5cb-1cf8e517f3a0\"}],\"range_offset_m\":3.1415,"
"\"sample_block_file\":{\"file_uuid\":\"93a03615-66c0-4bea-8ff8-c577378fe660"
"\",\"file_extension\":\"sbx\"}}"
)

# Scanner settings for waveform output
RDB_RIEGL_WAVEFORM_SETTINGS             = "riegl.waveform_settings"
RDB_RIEGL_WAVEFORM_SETTINGS_TITLE       = "Waveform Settings"
RDB_RIEGL_WAVEFORM_SETTINGS_DESCRIPTION = "Scanner settings for waveform output"
RDB_RIEGL_WAVEFORM_SETTINGS_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_SETTINGS_SCHEMA = (
"{\"description\":\"Scanner settings for waveform output\",\"items\":{\"requir"
"ed\":[\"sbl_name\",\"enabled\",\"channel_idx_mask\"],\"type\":\"object\",\"propert"
"ies\":{\"pass_rng_greater\":{\"description\":\"Threshold for range greater "
"than [m]\",\"type\":\"number\"},\"channel_idx_mask\":{\"description\":\"Bit mask"
" for channels which belong to sbl_name: Channel 0 = Bit0, Channel 1 = "
"Bit1, "
"...\",\"type\":\"integer\"},\"pass_dev_greater\":{\"description\":\"Threshold "
"for deviation greater than "
"[1]\",\"type\":\"integer\"},\"pass_ampl_less\":{\"description\":\"Threshold for "
"amplitude less than "
"[dB]\",\"type\":\"number\"},\"logic_expression\":{\"description\":\"Logic "
"expression of smart waveforms "
"filter\",\"type\":\"string\"},\"smart_enabled\":{\"description\":\"Smart "
"waveform output "
"enabled\",\"type\":\"boolean\"},\"sbl_name\":{\"description\":\"Name of sample "
"block, e.g.: wfm, "
"wwf\",\"type\":\"string\"},\"pass_ampl_greater\":{\"description\":\"Threshold "
"for amplitude greater than "
"[dB]\",\"type\":\"number\"},\"pass_rng_less\":{\"description\":\"Threshold for "
"range less than "
"[m]\",\"type\":\"number\"},\"enabled\":{\"description\":\"Waveform output "
"enabled\",\"type\":\"boolean\"},\"pass_dev_less\":{\"description\":\"Threshold "
"for deviation less than "
"[1]\",\"type\":\"integer\"}}},\"type\":\"array\",\"title\":\"Waveform "
"Settings\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_WAVEFORM_SETTINGS_EXAMPLE = (
"[{\"pass_rng_greater\":9.27,\"channel_idx_mask\":11,\"pass_ampl_less\":5.0,\""
"smart_enabled\":true,\"sbl_name\":\"wfm\",\"pass_ampl_greater\":1.0,\"pass_rng"
"_less\":13.11,\"enabled\":true},{\"sbl_name\":\"wwf\",\"channel_idx_mask\":32,\""
"enabled\":false}]"
)

# Window analysis data estimated from scandata and resulting filter parameters
RDB_RIEGL_WINDOW_ANALYSIS             = "riegl.window_analysis"
RDB_RIEGL_WINDOW_ANALYSIS_TITLE       = "Window Analysis"
RDB_RIEGL_WINDOW_ANALYSIS_DESCRIPTION = "Window analysis data estimated from scandata and resulting filter parameters"
RDB_RIEGL_WINDOW_ANALYSIS_STATUS      = "optional"
RDB_RIEGL_WINDOW_ANALYSIS_SCHEMA = (
"{\"description\":\"Window analysis data estimated from scandata and "
"resulting filter "
"parameters\",\"required\":[\"result\",\"filter\",\"settings\"],\"title\":\"Window "
"Analysis\",\"properties\":{\"filter\":{\"required\":[\"angle\",\"range_min\",\"ran"
"ge_max\",\"amplitude_max\"],\"type\":\"object\",\"properties\":{\"range_min\":{\"d"
"escription\":\"[m]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplitude"
"_max\":{\"description\":\"[dB]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},"
"\"angle\":{\"description\":\"[deg]\",\"type\":\"array\",\"items\":{\"type\":\"number\""
"}},\"range_max\":{\"description\":\"[m]\",\"type\":\"array\",\"items\":{\"type\":\"nu"
"mber\"}}}},\"result\":{\"required\":[\"angle\",\"range_mean\",\"range_sigma\",\"am"
"plitude_mean\",\"amplitude_sigma\",\"amplitude_offset\"],\"type\":\"object\",\"p"
"roperties\":{\"range_sigma\":{\"description\":\"[m]\",\"type\":\"array\",\"items\":"
"{\"type\":\"number\"}},\"amplitude_sigma\":{\"description\":\"[dB]\",\"type\":\"arr"
"ay\",\"items\":{\"type\":\"number\"}},\"amplitude_mean\":{\"description\":\"[dB]\","
"\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplitude_offset\":{\"descrip"
"tion\":\"[dB]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"range_mean\":{\""
"description\":\"[m]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"angle\":{"
"\"description\":\"[deg]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"times"
"tamp\":{\"description\":\"[s]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}}}}"
",\"settings\":{\"required\":[\"range\",\"amplitude\"],\"type\":\"object\",\"propert"
"ies\":{\"range\":{\"required\":[\"sigma_factor\",\"additive_value\"],\"type\":\"ob"
"ject\",\"properties\":{\"additive_value\":{\"type\":\"number\"},\"sigma_factor\":"
"{\"type\":\"number\"}}},\"amplitude\":{\"required\":[\"sigma_factor\",\"additive_"
"value\"],\"type\":\"object\",\"properties\":{\"additive_value\":{\"type\":\"number"
"\"},\"sigma_factor\":{\"type\":\"number\"}}}}}},\"type\":\"object\",\"$schema\":\"ht"
"tp://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_WINDOW_ANALYSIS_EXAMPLE = (
"{\"filter\":{\"range_min\":[-0.208,-0.21,-0.212,-0.214,-0.216,-0.218,-0.21"
"9,-0.221,-0.223,-0.225,-0.227],\"amplitude_max\":[8.04,8.01,7.99,7.96,7."
"93,7.9,7.88,7.85,7.83,7.8,7.78],\"angle\":[14.9,15.0,15.1,15.2,15.3,15.4"
",15.5,15.6,15.7,15.8,15.9],\"range_max\":[0.424,0.425,0.426,0.427,0.428,"
"0.428,0.429,0.43,0.431,0.431,0.432]},\"result\":{\"range_sigma\":[0.018696"
"52,0.02151435,0.01747969,0.01918765,0.01945776,0.01934862,0.01955329,0"
".02225589,0.02229977,0.01899122,0.02009433],\"amplitude_sigma\":[0.42728"
"44,0.4298479,0.4236816,0.4283583,0.4362353,0.4315141,0.4373984,0.44727"
"98,0.4346001,0.4345487,0.4540681],\"amplitude_mean\":[5.347396,5.263155,"
"5.224655,5.179926,5.097782,5.116479,5.051756,4.983473,5.007885,5.00244"
"1,4.982],\"amplitude_offset\":[1.9,1.9],\"range_mean\":[0.1105621,0.107956"
"4,0.1087088,0.1067261,0.1054582,0.1090412,0.102871,0.1019044,0.1051523"
",0.1058445,0.1031261],\"angle\":[14.9,15.0,15.1,15.2,15.3,15.4,15.5,15.6"
",15.7,15.8,15.9],\"timestamp\":[408.4441,411.4443]},\"settings\":{\"range\":"
"{\"additive_value\":0.1,\"sigma_factor\":8},\"amplitude\":{\"additive_value\":"
"1.0,\"sigma_factor\":4}}}"
)

# Correction parameters for window glass echoes
RDB_RIEGL_WINDOW_ECHO_CORRECTION             = "riegl.window_echo_correction"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_TITLE       = "Window Echo Correction"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_DESCRIPTION = "Correction parameters for window glass echoes"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_STATUS      = "optional"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_SCHEMA = (
"{\"description\":\"Correction parameters for window glass "
"echoes\",\"required\":[\"amplitude\",\"range\",\"slices\"],\"title\":\"Window Echo"
" Correction\",\"properties\":{\"range\":{\"description\":\"Range axis of "
"correction table\",\"required\":[\"minimum\",\"maximum\",\"entries\"],\"type\":\"o"
"bject\",\"properties\":{\"maximum\":{\"description\":\"Maximum range in m\",\"ma"
"ximum\":2.0,\"type\":\"number\",\"minimum\":-2.0},\"entries\":{\"description\":\"N"
"umber of range entries\",\"type\":\"integer\",\"minimum\":1},\"minimum\":{\"desc"
"ription\":\"Minimum range in m\",\"maximum\":2.0,\"type\":\"number\",\"minimum\":"
"-2.0}}},\"amplitude\":{\"description\":\"Amplitude axis of correction table"
"\",\"required\":[\"minimum\",\"maximum\",\"entries\"],\"type\":\"object\",\"properti"
"es\":{\"maximum\":{\"description\":\"Maximum amplitude in "
"dB\",\"type\":\"number\",\"minimum\":0.0},\"entries\":{\"description\":\"Number of"
" amplitude entries\",\"type\":\"integer\",\"minimum\":1},\"minimum\":{\"descript"
"ion\":\"Minimum amplitude in dB\",\"type\":\"number\",\"minimum\":0.0}}},\"slice"
"s\":{\"type\":\"array\",\"items\":{\"description\":\"Window echo correction "
"parameter slice\",\"required\":[\"amplitude\",\"table\"],\"type\":\"object\",\"pro"
"perties\":{\"table\":{\"description\":\"Correction table (dimension defined "
"by the 'amplitude' and 'range' "
"objects)\",\"type\":\"array\",\"items\":{\"description\":\"Table row (= "
"amplitude axis)\",\"type\":\"array\",\"items\":{\"description\":\"Table column "
"(= range axis)\",\"type\":\"array\",\"items\":{\"description\":\"Table cell "
"(item 0: amplitude in dB, 1: range in m, 2: flags)\",\"type\":\"number\"},\""
"minItems\":3,\"maxItems\":3},\"minItems\":1},\"minItems\":1},\"amplitude\":{\"de"
"scription\":\"Window echo amplitude of slice in dB\",\"type\":\"number\"}}}}}"
",\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_WINDOW_ECHO_CORRECTION_EXAMPLE = (
"{\"range\":{\"maximum\":1.5060822940732335,\"entries\":128,\"minimum\":-1.5060"
"822940732335},\"amplitude\":{\"maximum\":20,\"entries\":128,\"minimum\":2},\"sl"
"ices\":[{\"table\":[[[6.23,0.3535,1]],[[5.54,0.72375,1]]],\"amplitude\":1.5"
"},{\"table\":[[[6.23,0.3535,1]],[[5.54,0.72375,1]]],\"amplitude\":2.0}]}"
)
