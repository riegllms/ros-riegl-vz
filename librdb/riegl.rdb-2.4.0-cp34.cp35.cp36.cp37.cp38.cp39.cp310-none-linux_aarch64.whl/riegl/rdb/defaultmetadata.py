#
#*******************************************************************************
#
#  Copyright 2022 RIEGL Laser Measurement Systems
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
#  SPDX-License-Identifier: Apache-2.0
#
#*******************************************************************************
#
"""
*******************************************************************************
*
* \author  RIEGL LMS GmbH, Austria
* \brief   Description of RIEGL RDB 2 database meta data items.
* \version 2015-10-27/AW: Initial version
* \version 2015-11-25/AW: Item "Geo Tag" added
* \version 2016-10-27/AW: Item "Voxel Information" added
* \version 2016-11-17/AW: Item "Voxel Information" updated
* \version 2016-12-12/AW: Item "Range Statistics" added
* \version 2017-03-08/AW: Item "Plane Patch Statistics" added
* \version 2017-04-05/AW: Items "Atmosphere" and "Geometric Scale Factor" added
* \version 2017-08-22/AW: Items for waveform sample block and value files added
* \version 2017-10-24/AW: Item "Gaussian Decomposition" added
* \version 2017-11-13/AW: Item "riegl.scan_pattern" updated
* \version 2017-11-21/AW: Item "riegl.trajectory_info" added
* \version 2018-01-11/AW: Item "riegl.beam_geometry" added
* \version 2018-01-15/AW: Item "riegl.reflectance_calculation" added
* \version 2018-01-15/AW: Item "riegl.near_range_correction" added
* \version 2018-01-15/AW: Item "riegl.device_geometry" added
* \version 2018-02-13/AW: Item "riegl.notch_filter" added
* \version 2018-03-08/AW: Item "riegl.window_echo_correction" added
* \version 2018-03-15/AW: Item "riegl.pulse_position_modulation" added
* \version 2018-05-24/AW: Item "riegl.pixel_info" added
* \version 2018-06-08/AW: Item "riegl.shot_info" added
* \version 2018-06-08/AW: Item "riegl.echo_info" added
* \version 2018-06-14/AW: Item "riegl.mta_settings" added
* \version 2018-06-14/AW: Item "riegl.receiver_internals" added
* \version 2018-06-14/AW: Item "riegl.device_output_limits" added
* \version 2018-06-26/AW: Schema: replace "number" with "integer" if applicable
* \version 2018-07-09/AW: Item "riegl.pose_estimation" added
* \version 2018-07-09/AW: Item "riegl.pose_sensors" added
* \version 2018-09-20/AW: Item "riegl.pointcloud_info" added
* \version 2018-11-08/AW: Item "riegl.scan_pattern" updated
* \version 2018-11-13/AW: Item "riegl.receiver_internals" updated
* \version 2019-03-06/AW: Item "riegl.receiver_internals" updated
* \version 2019-03-21/AW: Item "riegl.device_geometry" updated
* \version 2019-04-15/AW: Item "riegl.point_attribute_groups" added
* \version 2019-04-30/AW: Item "riegl.waveform_settings" added
* \version 2019-10-03/AW: Item "riegl.angular_notch_filter" added
* \version 2019-10-03/AW: Item "riegl.noise_estimates" added
* \version 2019-10-25/AW: Item "riegl.window_analysis" added
* \version 2019-11-06/AW: Item "riegl.georeferencing_parameters" added
* \version 2019-11-27/AW: Item "riegl.plane_patch_matching" added
* \version 2019-12-13/AW: Items for tie-/control objects added
* \version 2019-12-19/AW: Items for tie-/control objects added
* \version 2020-02-04/AW: Item "riegl.detection_probability" added
* \version 2020-02-04/AW: Item "riegl.licenses" added
* \version 2020-04-27/AW: Item "riegl.waveform_info" updated (schema+example)
* \version 2020-09-03/AW: Item "riegl.reflectance_correction" added
* \version 2020-09-10/AW: Item "riegl.device_geometry_passive_channel" added
* \version 2020-09-25/AW: Item "riegl.georeferencing_parameters" updated
* \version 2020-09-25/AW: Item "riegl.trajectory_info" updated
* \version 2020-09-29/AW: Item "riegl.temperature_calculation" added
* \version 2020-10-23/AW: Item "riegl.exponential_decomposition" added (#3709)
* \version 2020-11-30/AW: Item "riegl.notch_filter" updated (schema)
* \version 2020-12-02/AW: Item "riegl.georeferencing_parameters" updated (schema)
* \version 2021-02-02/AW: Item "riegl.plane_slope_class_info" added (rdbplanes/#7)
* \version 2021-02-16/AW: Item "riegl.device_output_limits" updated (schema, #3811)
* \version 2021-03-03/AW: Item "riegl.exponential_decomposition" updated (schema, #3822)
* \version 2021-03-03/AW: Item "riegl.waveform_averaging_settings" added (#3821)
* \version 2021-04-01/AW: Item "riegl.voxel_info" updated (schema, #3854)
* \version 2021-04-16/AW: Item "riegl.voxel_info" updated (schema, #3866)
* \version 2021-09-30/AW: Item "riegl.waveform_info" updated (schema+example, #4016)
* \version 2021-10-04/AW: Improved spelling of the descriptions of some items
* \version 2021-11-04/AW: Rename "riegl.record_names" to "riegl.item_names" (#4034)
* \version 2022-03-11/AW: Item "riegl.devices" added (#4162)
* \version 2022-03-14/AW: Item "riegl.stored_filters" added (#4164)
*
*******************************************************************************
"""

# Angular notch filter parameters for window glass echoes
RDB_RIEGL_ANGULAR_NOTCH_FILTER             = "riegl.angular_notch_filter"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_TITLE       = "Angular Notch Filter"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_DESCRIPTION = "Angular notch filter parameters for window glass echoes"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_STATUS      = "optional"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_SCHEMA = (
"{\"required\":[\"angle\",\"range_mean\",\"amplitude_mean\"],\"$schema\":\"http://"
"json-schema.org/draft-04/schema#\",\"description\":\"Angular notch filter "
"parameters for window glass echoes\",\"title\":\"Angular Notch "
"Filter\",\"type\":\"object\",\"properties\":{\"angle\":{\"description\":\"Angle [d"
"eg]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplitude_mean\":{\"desc"
"ription\":\"Mean amplitude [dB]\",\"type\":\"array\",\"items\":{\"type\":\"number\""
"}},\"range_mean\":{\"description\":\"Mean range "
"[m]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}}}}"
)
RDB_RIEGL_ANGULAR_NOTCH_FILTER_EXAMPLE = (
"{\"angle\":[14.0,15.0,16.0,17.0,18.0,19.0,20.0,21.0,22.0,23.0,24.0],\"amp"
"litude_mean\":[3.780913,3.780913,3.480913,3.120913,2.850913,2.720913,2."
"680913,2.610913,2.530913,2.570913,2.570913],\"range_mean\":[0.094,0.094,"
"0.09075,0.08675,0.0815,0.0775,0.074,0.071,0.068,0.0675,0.06475]}"
)

# Atmospheric parameters
RDB_RIEGL_ATMOSPHERE             = "riegl.atmosphere"
RDB_RIEGL_ATMOSPHERE_TITLE       = "Atmosphere"
RDB_RIEGL_ATMOSPHERE_DESCRIPTION = "Atmospheric parameters"
RDB_RIEGL_ATMOSPHERE_STATUS      = "optional"
RDB_RIEGL_ATMOSPHERE_SCHEMA = (
"{\"required\":[\"temperature\",\"pressure\",\"rel_humidity\",\"pressure_sl\",\"am"
"sl\",\"group_velocity\",\"attenuation\",\"wavelength\"],\"$schema\":\"http://jso"
"n-schema.org/draft-04/schema#\",\"description\":\"Atmospheric "
"parameters\",\"title\":\"Atmospheric Parameters\",\"type\":\"object\",\"properti"
"es\":{\"wavelength\":{\"description\":\"Laser wavelength "
"[nm]\",\"type\":\"number\"},\"rel_humidity\":{\"description\":\"Relative "
"humidity along measurement path "
"[%]\",\"type\":\"number\"},\"group_velocity\":{\"description\":\"Group velocity "
"of laser beam "
"[m/s]\",\"type\":\"number\"},\"pressure\":{\"description\":\"Pressure along "
"measurment path "
"[mbar]\",\"type\":\"number\"},\"pressure_sl\":{\"description\":\"Atmospheric "
"pressure at sea level "
"[mbar]\",\"type\":\"number\"},\"attenuation\":{\"description\":\"Atmospheric "
"attenuation [1/km]\",\"type\":\"number\"},\"amsl\":{\"description\":\"Height "
"above mean sea level (AMSL) "
"[m]\",\"type\":\"number\"},\"temperature\":{\"description\":\"Temperature along "
"measurement path [\\u00b0C]\",\"type\":\"number\"}}}"
)
RDB_RIEGL_ATMOSPHERE_EXAMPLE = (
"{\"wavelength\":1550,\"rel_humidity\":63,\"group_velocity\":299711000.0,\"pre"
"ssure\":970,\"pressure_sl\":970,\"attenuation\":0.028125,\"amsl\":0,\"temperat"
"ure\":7}"
)

# Laser beam geometry details
RDB_RIEGL_BEAM_GEOMETRY             = "riegl.beam_geometry"
RDB_RIEGL_BEAM_GEOMETRY_TITLE       = "Beam Geometry"
RDB_RIEGL_BEAM_GEOMETRY_DESCRIPTION = "Laser beam geometry details"
RDB_RIEGL_BEAM_GEOMETRY_STATUS      = "optional"
RDB_RIEGL_BEAM_GEOMETRY_SCHEMA = (
"{\"required\":[\"beam_exit_diameter\",\"beam_divergence\"],\"$schema\":\"http:/"
"/json-schema.org/draft-04/schema#\",\"description\":\"Laser beam geometry "
"details\",\"title\":\"Beam Geometry\",\"type\":\"object\",\"properties\":{\"beam_d"
"ivergence\":{\"description\":\"Beam divergence in far field [rad]\",\"minimu"
"m\":0,\"exclusiveMinimum\":false,\"type\":\"number\"},\"beam_exit_diameter\":{\""
"description\":\"Beam width at exit aperture "
"[m]\",\"minimum\":0,\"exclusiveMinimum\":false,\"type\":\"number\"}}}"
)
RDB_RIEGL_BEAM_GEOMETRY_EXAMPLE = (
"{\"beam_divergence\":0.0003,\"beam_exit_diameter\":0.0072}"
)

# List of control object type definitions
RDB_RIEGL_CONTROL_OBJECT_CATALOG             = "riegl.control_object_catalog"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_TITLE       = "Control Object Catalog"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_DESCRIPTION = "List of control object type definitions"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_STATUS      = "optional"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_SCHEMA = (
"{\"required\":[\"types\"],\"definitions\":{\"round_corner_cube_prism\":{\"descr"
"iption\":\"round corner cube "
"prism\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"description\":\"round "
"corner cube prism specific properties\",\"required\":[\"shape\",\"diameter\"]"
",\"type\":\"object\",\"properties\":{\"shape\":{\"description\":\"shape identifie"
"r\",\"enum\":[\"round_corner_cube_prism\"],\"type\":\"string\"},\"diameter\":{\"de"
"scription\":\"diameter in meters\",\"minimum\":0,\"exclusiveMinimum\":true,\"t"
"ype\":\"number\"},\"offset\":{\"description\":\"offset in meters, e.g. "
"reflector constant (optional)\",\"type\":\"number\"}}}],\"type\":\"object\"},\"s"
"phere\":{\"description\":\"sphere\",\"allOf\":[{\"$ref\":\"#/definitions/common\""
"},{\"description\":\"sphere specific properties\",\"required\":[\"shape\",\"dia"
"meter\"],\"type\":\"object\",\"properties\":{\"shape\":{\"description\":\"shape id"
"entifier\",\"enum\":[\"sphere\"],\"type\":\"string\"},\"diameter\":{\"description\""
":\"diameter in meters\",\"minimum\":0,\"exclusiveMinimum\":true,\"type\":\"numb"
"er\"}}}],\"type\":\"object\"},\"common\":{\"description\":\"common object proper"
"ties\",\"required\":[\"name\",\"shape\"],\"type\":\"object\",\"properties\":{\"descr"
"iption\":{\"description\":\"string describing the "
"object\",\"type\":\"string\"},\"shape\":{\"description\":\"shape identifier\",\"en"
"um\":[\"rectangle\",\"checkerboard2x2\",\"chevron\",\"circular_disk\",\"cylinder"
"\",\"sphere\",\"round_corner_cube_prism\"],\"type\":\"string\"},\"surface_type\":"
"{\"description\":\"surface material type\",\"enum\":[\"retro_reflective_foil\""
",\"diffuse\"],\"type\":\"string\"},\"name\":{\"description\":\"unique type identi"
"fier\",\"type\":\"string\",\"minLength\":3}}},\"chevron\":{\"description\":\"chevr"
"on\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"description\":\"chevron "
"specific properties\",\"required\":[\"shape\",\"outside_edge_length\",\"thickn"
"ess\"],\"type\":\"object\",\"properties\":{\"shape\":{\"description\":\"shape iden"
"tifier\",\"enum\":[\"chevron\"],\"type\":\"string\"},\"thickness\":{\"description\""
":\"thickness in meters\",\"minimum\":0,\"exclusiveMinimum\":true,\"type\":\"num"
"ber\"},\"outside_edge_length\":{\"description\":\"length of the two outer "
"edges in meters\",\"minimum\":0,\"exclusiveMinimum\":true,\"type\":\"number\"}}"
"}],\"type\":\"object\"},\"cylinder\":{\"description\":\"cylinder\",\"allOf\":[{\"$r"
"ef\":\"#/definitions/common\"},{\"description\":\"cylinder specific properti"
"es\",\"required\":[\"shape\",\"diameter\",\"height\"],\"type\":\"object\",\"properti"
"es\":{\"shape\":{\"description\":\"shape identifier\",\"enum\":[\"cylinder\"],\"ty"
"pe\":\"string\"},\"diameter\":{\"description\":\"diameter in meters\",\"minimum\""
":0,\"exclusiveMinimum\":true,\"type\":\"number\"},\"height\":{\"description\":\"h"
"eight in meters\",\"minimum\":0,\"exclusiveMinimum\":true,\"type\":\"number\"}}"
"}],\"type\":\"object\"},\"rectangle\":{\"description\":\"rectangle\",\"allOf\":[{\""
"$ref\":\"#/definitions/common\"},{\"description\":\"rectangle specific prope"
"rties\",\"required\":[\"shape\",\"length\",\"width\"],\"type\":\"object\",\"properti"
"es\":{\"shape\":{\"enum\":[\"rectangle\"],\"type\":\"string\"},\"length\":{\"descrip"
"tion\":\"length in meters\",\"minimum\":0,\"exclusiveMinimum\":true,\"type\":\"n"
"umber\"},\"width\":{\"description\":\"width in meters\",\"minimum\":0,\"exclusiv"
"eMinimum\":true,\"type\":\"number\"}}}],\"type\":\"object\"},\"checkerboard2x2\":"
"{\"description\":\"checkerboard 2 by 2\",\"allOf\":[{\"$ref\":\"#/definitions/c"
"ommon\"},{\"description\":\"checkerboard specific properties\",\"required\":["
"\"shape\",\"square_length\"],\"type\":\"object\",\"properties\":{\"shape\":{\"descr"
"iption\":\"shape identifier\",\"enum\":[\"checkerboard2x2\"],\"type\":\"string\"}"
",\"square_length\":{\"description\":\"length of a square of the "
"checkerboard in meters\",\"minimum\":0,\"exclusiveMinimum\":true,\"type\":\"nu"
"mber\"}}}],\"type\":\"object\"},\"circular_disk\":{\"description\":\"circular di"
"sk\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"description\":\"circular "
"disk specific properties\",\"required\":[\"shape\",\"diameter\"],\"type\":\"obje"
"ct\",\"properties\":{\"shape\":{\"description\":\"shape identifier\",\"enum\":[\"c"
"ircular_disk\"],\"type\":\"string\"},\"diameter\":{\"description\":\"diameter in"
" meters\",\"minimum\":0,\"exclusiveMinimum\":true,\"type\":\"number\"},\"offset\""
":{\"description\":\"offset in meters, e.g. reflector constant (optional)\""
",\"type\":\"number\"}}}],\"type\":\"object\"}},\"$schema\":\"http://json-schema.o"
"rg/draft-04/schema#\",\"description\":\"List of control object type "
"definitions\",\"title\":\"Control Object Catalog\",\"type\":\"object\",\"propert"
"ies\":{\"types\":{\"uniqueItems\":true,\"type\":\"array\",\"items\":{\"oneOf\":[{\"$"
"ref\":\"#/definitions/rectangle\"},{\"$ref\":\"#/definitions/checkerboard2x2"
"\"},{\"$ref\":\"#/definitions/chevron\"},{\"$ref\":\"#/definitions/circular_di"
"sk\"},{\"$ref\":\"#/definitions/cylinder\"},{\"$ref\":\"#/definitions/sphere\"}"
",{\"$ref\":\"#/definitions/round_corner_cube_prism\"}],\"type\":\"object\"}}}}"
)
RDB_RIEGL_CONTROL_OBJECT_CATALOG_EXAMPLE = (
"{\"comments\":[\"This file contains a list of control object types (aka. "
"'catalog').\",\"Each type is described by an object,\",\"which must "
"contain at least the following parameters:\",\"  - name: unique "
"identifier of the type\",\"  - shape: one of the following supported "
"shapes:\",\"      - rectangle\",\"      - checkerboard2x2\",\"      - "
"chevron\",\"      - circular_disk\",\"      - cylinder\",\"      - sphere\",\""
"      - round_corner_cube_prism\",\"Depending on 'shape', the following "
"parameters must/may be specified:\",\"  - rectangle:\",\"      - length: "
"length in meters\",\"      - width: width in meters\",\"  - "
"checkerboard2x2:\",\"      - square_length: length of a square of the "
"checkerboard in meters\",\"  - circular_disk:\",\"      - diameter: "
"diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
"constant (optional)\",\"  - chevron:\",\"      - outside_edge_length: "
"length of the two outer edges in meters\",\"      - thickness: thickness"
" in meters\",\"  - cylinder:\",\"      - diameter: diameter in meters\",\""
"      - height:  height in meters\",\"  - sphere:\",\"      - diameter: "
"diameter in meters\",\"  - round_corner_cube_prism:\",\"      - diameter: "
"diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
"constant (optional)\",\"Optional parameters:\",\"    - description: string"
" describing the object\",\"    - surface_type: surface material type "
"(either 'retro_reflective_foil' or "
"'diffuse')\"],\"types\":[{\"description\":\"Rectangle (60cm x "
"30cm)\",\"shape\":\"rectangle\",\"length\":0.6,\"name\":\"Rectangle "
"60x30\",\"width\":0.3},{\"description\":\"Rectangle (80cm x "
"40cm)\",\"shape\":\"rectangle\",\"length\":0.8,\"name\":\"Rectangle "
"80x40\",\"width\":0.4},{\"description\":\"Checkerboard (square length: 30cm)"
"\",\"shape\":\"checkerboard2x2\",\"square_length\":0.3,\"name\":\"Checkerboard2x"
"2 30\"},{\"description\":\"Checkerboard (square length: 50cm)\",\"shape\":\"ch"
"eckerboard2x2\",\"square_length\":0.5,\"name\":\"Checkerboard2x2 "
"50\"},{\"description\":\"Chevron (a=24''; b=4'')\",\"shape\":\"chevron\",\"thick"
"ness\":0.1016,\"outside_edge_length\":0.6096,\"name\":\"Chevron "
"24''/4''\"},{\"description\":\" Circular Disk (diameter: "
"50cm)\",\"shape\":\"circular_disk\",\"diameter\":0.5,\"name\":\"Circular Disk 50"
"\",\"surface_type\":\"diffuse\"},{\"diameter\":0.05,\"offset\":0.0,\"name\":\"RIEG"
"L flat reflector 50 mm\",\"description\":\"flat circular reflector from "
"retro-reflective foil\",\"shape\":\"circular_disk\",\"surface_type\":\"retro_r"
"eflective_foil\"},{\"diameter\":0.1,\"offset\":0.0,\"name\":\"RIEGL flat "
"reflector 100 mm\",\"description\":\"flat circular reflector from "
"retro-reflective foil\",\"shape\":\"circular_disk\",\"surface_type\":\"retro_r"
"eflective_foil\"},{\"diameter\":0.15,\"offset\":0.0,\"name\":\"RIEGL flat "
"reflector 150 mm\",\"description\":\"flat circular reflector from "
"retro-reflective foil\",\"shape\":\"circular_disk\",\"surface_type\":\"retro_r"
"eflective_foil\"},{\"diameter\":0.05,\"name\":\"RIEGL cylindrical reflector "
"50 mm\",\"height\":0.05,\"description\":\"cylindrical reflector from "
"retro-reflective foil\",\"shape\":\"cylinder\",\"surface_type\":\"retro_reflec"
"tive_foil\"},{\"diameter\":0.1,\"name\":\"RIEGL cylindrical reflector 100 "
"mm\",\"height\":0.1,\"description\":\"cylindrical reflector from "
"retro-reflective foil\",\"shape\":\"cylinder\",\"surface_type\":\"retro_reflec"
"tive_foil\"},{\"description\":\"Sphere (diameter: 200 "
"mm)\",\"shape\":\"sphere\",\"diameter\":0.2,\"name\":\"Sphere 200 "
"mm\"},{\"description\":\"round corner cube prism\",\"shape\":\"round_corner_cu"
"be_prism\",\"diameter\":0.05,\"offset\":0.0,\"name\":\"Corner Cube Prism 50 "
"mm\"}]}"
)

# Details about the control object reference file
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE             = "riegl.control_object_reference_file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_TITLE       = "Control Object Reference file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_DESCRIPTION = "Details about the control object reference file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_STATUS      = "optional"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_SCHEMA = (
"{\"description\":\"Details about the control object reference "
"file\",\"title\":\"Control Object Reference file\",\"$schema\":\"http://json-s"
"chema.org/draft-04/schema#\",\"type\":\"object\",\"properties\":{\"reference_f"
"ile\":{\"description\":\"Reference to a control object file\",\"required\":[\""
"file_uuid\",\"file_path\"],\"type\":\"object\",\"properties\":{\"file_uuid\":{\"de"
"scription\":\"Control object file's Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_path\":{\"description\":\"Path of the "
"control object file relative to referring file\",\"type\":\"string\"}}}}}"
)
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_EXAMPLE = (
"{\"reference_file\":{\"file_uuid\":\"810f5d57-eccf-49ed-b07a-0cdd109b4213\","
"\"file_path\":\"../../../10_CONTROL_OBJECTS/ControlPoints.cpx\"}}"
)

# Detection probability as a function of amplitude
RDB_RIEGL_DETECTION_PROBABILITY             = "riegl.detection_probability"
RDB_RIEGL_DETECTION_PROBABILITY_TITLE       = "Detection Probability"
RDB_RIEGL_DETECTION_PROBABILITY_DESCRIPTION = "Detection probability as a function of amplitude"
RDB_RIEGL_DETECTION_PROBABILITY_STATUS      = "optional"
RDB_RIEGL_DETECTION_PROBABILITY_SCHEMA = (
"{\"required\":[\"amplitude\",\"detection_probability\"],\"$schema\":\"http://js"
"on-schema.org/draft-04/schema#\",\"description\":\"Detection probability "
"as a function of amplitude\",\"title\":\"Detection Probability\",\"type\":\"ob"
"ject\",\"properties\":{\"amplitude\":{\"description\":\"Amplitude [dB]\",\"type\""
":\"array\",\"items\":{\"type\":\"number\"}},\"detection_probability\":{\"descript"
"ion\":\"Detection probability "
"[0..1]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}}}}"
)
RDB_RIEGL_DETECTION_PROBABILITY_EXAMPLE = (
"{\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0],\"detection"
"_probability\":[0.0,0.5,0.8,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0]}"
)

# Details about the device used to acquire the point cloud
RDB_RIEGL_DEVICE             = "riegl.device"
RDB_RIEGL_DEVICE_TITLE       = "Device Information"
RDB_RIEGL_DEVICE_DESCRIPTION = "Details about the device used to acquire the point cloud"
RDB_RIEGL_DEVICE_STATUS      = "optional"
RDB_RIEGL_DEVICE_SCHEMA = (
"{\"required\":[\"device_type\",\"serial_number\"],\"$schema\":\"http://json-sch"
"ema.org/draft-04/schema#\",\"description\":\"Details about the device used"
" to acquire the point cloud\",\"title\":\"Device Information\",\"type\":\"obje"
"ct\",\"properties\":{\"channel_number\":{\"description\":\"Laser channel "
"number (not defined or 0: single channel device)\",\"minimum\":0,\"exclusi"
"veMinimum\":false,\"type\":\"integer\"},\"serial_number\":{\"description\":\"Dev"
"ice serial number (e.g. "
"S2221234)\",\"type\":\"string\"},\"device_type\":{\"description\":\"Device type "
"identifier (e.g. "
"VZ-400i)\",\"type\":\"string\"},\"device_build\":{\"description\":\"Device build"
" variant\",\"type\":\"string\"},\"device_name\":{\"description\":\"Optional "
"device name (e.g. 'Scanner 1' for multi-scanner "
"systems)\",\"type\":\"string\"},\"channel_text\":{\"description\":\"Optional "
"channel description (e.g. 'Green Channel' for multi-channel "
"devices)\",\"type\":\"string\"}}}"
)
RDB_RIEGL_DEVICE_EXAMPLE = (
"{\"channel_number\":0,\"serial_number\":\"S2221234\",\"device_type\":\"VZ-400i\""
",\"device_build\":\"\",\"device_name\":\"Scanner 1\",\"channel_text\":\"\"}"
)

# Scanner device geometry details
RDB_RIEGL_DEVICE_GEOMETRY             = "riegl.device_geometry"
RDB_RIEGL_DEVICE_GEOMETRY_TITLE       = "Device Geometry"
RDB_RIEGL_DEVICE_GEOMETRY_DESCRIPTION = "Scanner device geometry details"
RDB_RIEGL_DEVICE_GEOMETRY_STATUS      = "optional"
RDB_RIEGL_DEVICE_GEOMETRY_SCHEMA = (
"{\"required\":[\"primary\"],\"$schema\":\"http://json-schema.org/draft-04/sch"
"ema#\",\"description\":\"Scanner device geometry details\",\"title\":\"Device "
"Geometry\",\"type\":\"object\",\"properties\":{\"primary\":{\"description\":\"Prim"
"ary device geometry structure (mandatory)\",\"required\":[\"ID\",\"content\"]"
",\"type\":\"object\",\"properties\":{\"content\":{\"description\":\"Internal "
"calibration values\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"ID\":{\"d"
"escription\":\"Structure identifier\",\"minItems\":2,\"maxItems\":2,\"type\":\"a"
"rray\",\"items\":{\"type\":\"integer\"}}}},\"amu\":{\"description\":\"Angle "
"Measurement "
"Unit\",\"type\":\"object\",\"properties\":{\"frameCC\":{\"description\":\"Frame "
"Circle Count (number of LSBs per full rotation about frame axis)\",\"min"
"imum\":0,\"exclusiveMinimum\":false,\"type\":\"number\"},\"lineCC\":{\"descripti"
"on\":\"Line Circle Count (number of LSBs per full rotation about line ax"
"is)\",\"minimum\":0,\"exclusiveMinimum\":false,\"type\":\"number\"}}},\"secondar"
"y\":{\"description\":\"Additional device geometry structure (optional)\",\"r"
"equired\":[\"ID\",\"content\"],\"type\":\"object\",\"properties\":{\"content\":{\"de"
"scription\":\"Internal calibration values\",\"type\":\"array\",\"items\":{\"type"
"\":\"number\"}},\"ID\":{\"description\":\"Structure identifier\",\"minItems\":2,\""
"maxItems\":2,\"type\":\"array\",\"items\":{\"type\":\"integer\"}}}}}}"
)
RDB_RIEGL_DEVICE_GEOMETRY_EXAMPLE = (
"{\"primary\":{\"content\":[0],\"ID\":[4,0]},\"amu\":{\"frameCC\":124000,\"lineCC\""
":124000},\"secondary\":{\"content\":[0],\"ID\":[91,0]}}"
)

# Scanner passive channel device geometry details
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL             = "riegl.device_geometry_passive_channel"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_TITLE       = "Device Geometry Passive Channel"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_DESCRIPTION = "Scanner passive channel device geometry details"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_STATUS      = "optional"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_SCHEMA = (
"{\"required\":[\"primary\"],\"$schema\":\"http://json-schema.org/draft-04/sch"
"ema#\",\"description\":\"Scanner passive channel device geometry "
"details\",\"title\":\"Device Geometry Passive Channel\",\"type\":\"object\",\"pr"
"operties\":{\"primary\":{\"description\":\"Primary device geometry structure"
" (mandatory)\",\"required\":[\"ID\",\"content\"],\"type\":\"object\",\"properties\""
":{\"content\":{\"description\":\"Internal calibration values\",\"type\":\"array"
"\",\"items\":{\"type\":\"number\"}},\"ID\":{\"description\":\"Structure identifier"
"\",\"minItems\":2,\"maxItems\":2,\"type\":\"array\",\"items\":{\"type\":\"integer\"}}"
"}}}}"
)
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_EXAMPLE = (
"{\"primary\":{\"content\":[0],\"ID\":[143,0]}}"
)

# Limits of the measured values output by the device
RDB_RIEGL_DEVICE_OUTPUT_LIMITS             = "riegl.device_output_limits"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_TITLE       = "Device Output Limits"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_DESCRIPTION = "Limits of the measured values output by the device"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_STATUS      = "optional"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_SCHEMA = (
"{\"description\":\"Limits of the measured values output by the device. "
"The limits depend on the device type, measurement program and/or scan "
"pattern.\",\"title\":\"Device Output Limits\",\"$schema\":\"http://json-schema"
".org/draft-04/schema#\",\"type\":\"object\",\"properties\":{\"deviation_minimu"
"m\":{\"description\":\"Minimum possible pulse shape deviation.\",\"type\":\"nu"
"mber\"},\"amplitude_maximum\":{\"description\":\"Maximum possible amplitude "
"in dB.\",\"type\":\"number\"},\"reflectance_minimum\":{\"description\":\"Minimum"
" possible reflectance in "
"dB.\",\"type\":\"number\"},\"range_maximum\":{\"description\":\"Maximum possible"
" range in meters.\",\"type\":\"number\"},\"reflectance_maximum\":{\"descriptio"
"n\":\"Maximum possible reflectance in "
"dB.\",\"type\":\"number\"},\"echo_count_maximum\":{\"description\":\"Maximum "
"number of echoes a laser shot can have.\",\"type\":\"number\"},\"mta_zone_co"
"unt_maximum\":{\"description\":\"Maximum number of MTA zones.\",\"type\":\"num"
"ber\"},\"background_radiation_maximum\":{\"description\":\"Maximum possible "
"background radiation.\",\"type\":\"number\"},\"deviation_maximum\":{\"descript"
"ion\":\"Maximum possible pulse shape deviation.\",\"type\":\"number\"},\"ampli"
"tude_minimum\":{\"description\":\"Minimum possible amplitude in "
"dB.\",\"type\":\"number\"},\"range_minimum\":{\"description\":\"Minimum possible"
" range in meters.\",\"type\":\"number\"},\"background_radiation_minimum\":{\"d"
"escription\":\"Minimum possible background "
"radiation.\",\"type\":\"number\"}}}"
)
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_EXAMPLE = (
"{\"deviation_minimum\":-1,\"background_radiation_maximum\":0,\"mta_zone_cou"
"nt_maximum\":7,\"amplitude_minimum\":0.0,\"reflectance_minimum\":-100.0,\"de"
"viation_maximum\":32767,\"range_maximum\":10000.0,\"amplitude_maximum\":100"
".0,\"range_minimum\":2.9,\"background_radiation_minimum\":0,\"reflectance_m"
"aximum\":100.0}"
)

# Details about the devices used to acquire the point cloud
RDB_RIEGL_DEVICES             = "riegl.devices"
RDB_RIEGL_DEVICES_TITLE       = "Devices Information"
RDB_RIEGL_DEVICES_DESCRIPTION = "Details about the devices used to acquire the point cloud"
RDB_RIEGL_DEVICES_STATUS      = "optional"
RDB_RIEGL_DEVICES_SCHEMA = (
"{\"description\":\"Details about the devices used to acquire the point "
"cloud (e.g. when merging point clouds of different "
"devices)\",\"title\":\"Devices Information\",\"$schema\":\"http://json-schema."
"org/draft-04/schema#\",\"type\":\"array\",\"items\":{\"required\":[\"device_type"
"\",\"serial_number\"],\"type\":\"object\",\"properties\":{\"channel_number\":{\"de"
"scription\":\"Laser channel number (not defined or 0: single channel dev"
"ice)\",\"minimum\":0,\"exclusiveMinimum\":false,\"type\":\"integer\"},\"serial_n"
"umber\":{\"description\":\"Device serial number (e.g. "
"S2221234)\",\"type\":\"string\"},\"device_type\":{\"description\":\"Device type "
"identifier (e.g. "
"VZ-400i)\",\"type\":\"string\"},\"signed\":{\"description\":\"Flag that is set "
"when the original 'riegl.device' entry in the source file was "
"correctly "
"signed.\",\"type\":\"boolean\"},\"device_build\":{\"description\":\"Device build"
" variant\",\"type\":\"string\"},\"device_name\":{\"description\":\"Optional "
"device name (e.g. 'Scanner 1' for multi-scanner "
"systems)\",\"type\":\"string\"},\"channel_text\":{\"description\":\"Optional "
"channel description (e.g. 'Green Channel' for multi-channel "
"devices)\",\"type\":\"string\"}}}}"
)
RDB_RIEGL_DEVICES_EXAMPLE = (
"[{\"channel_number\":0,\"serial_number\":\"S2221234\",\"device_type\":\"VZ-400i"
"\",\"signed\":false,\"device_build\":\"\",\"device_name\":\"Scanner 1\",\"channel_"
"text\":\"\"},{\"channel_number\":1,\"serial_number\":\"S2222680\",\"device_type\""
":\"VQ-1560i-DW\",\"signed\":true,\"device_build\":\"\",\"device_name\":\"Scanner "
"2\",\"channel_text\":\"\"},{\"channel_number\":2,\"serial_number\":\"S2222680\",\""
"device_type\":\"VQ-1560i-DW\",\"signed\":true,\"device_build\":\"\",\"device_nam"
"e\":\"Scanner 3\",\"channel_text\":\"\"}]"
)

# Details about echo files
RDB_RIEGL_ECHO_INFO             = "riegl.echo_info"
RDB_RIEGL_ECHO_INFO_TITLE       = "Echo Information"
RDB_RIEGL_ECHO_INFO_DESCRIPTION = "Details about echo files"
RDB_RIEGL_ECHO_INFO_STATUS      = "optional"
RDB_RIEGL_ECHO_INFO_SCHEMA = (
"{\"required\":[\"echo_file\"],\"$schema\":\"http://json-schema.org/draft-04/s"
"chema#\",\"description\":\"Details about echo files\",\"title\":\"Echo Informa"
"tion\",\"type\":\"object\",\"properties\":{\"echo_file\":{\"required\":[\"file_ext"
"ension\"],\"type\":\"object\",\"properties\":{\"file_extension\":{\"description\""
":\"Echo file extension, without the leading "
"dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's Universally "
"Unique Identifier (RFC 4122)\",\"type\":\"string\"}}}}}"
)
RDB_RIEGL_ECHO_INFO_EXAMPLE = (
"{\"echo_file\":{\"file_extension\":\"owp\",\"file_uuid\":\"26a03615-67c0-4bea-8"
"fe8-c577378fe661\"}}"
)

# Details for exponential decomposition of full waveform data
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION             = "riegl.exponential_decomposition"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_TITLE       = "Exponential Decomposition"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_DESCRIPTION = "Details for exponential decomposition of full waveform data"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_STATUS      = "optional"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_SCHEMA = (
"{\"definitions\":{\"channel\":{\"required\":[\"delay\",\"scale\",\"parameter\"],\"t"
"ype\":\"object\",\"properties\":{\"parameter\":{\"description\":\"parameters of "
"the syswave exponential sum\",\"required\":[\"A\",\"B\",\"gamma\",\"omega\"],\"typ"
"e\":\"object\",\"properties\":{\"B\":{\"description\":\"imaginary part of "
"amplitude factor in units of full-scale\",\"type\":\"array\",\"items\":{\"type"
"\":\"number\"}},\"omega\":{\"description\":\"angular frequency in Hz\",\"type\":\""
"array\",\"items\":{\"type\":\"number\"}},\"gamma\":{\"description\":\"decay in 1/s"
"econd\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"A\":{\"description\":\"r"
"eal part of amplitude factor in units of full-scale\",\"type\":\"array\",\"i"
"tems\":{\"type\":\"number\"}}}},\"a_lin\":{\"exclusiveMaximum\":false,\"exclusiv"
"eMinimum\":false,\"maximum\":1,\"description\":\"relative linear amplitude "
"range "
"[0..1]\",\"minimum\":0,\"type\":\"number\"},\"scale\":{\"description\":\"amplitude"
" calibration\",\"type\":\"number\"},\"delay\":{\"description\":\"delay "
"calibration in seconds\",\"type\":\"number\"}}}},\"$schema\":\"http://json-sch"
"ema.org/draft-04/schema#\",\"description\":\"Details for exponential "
"decomposition of full waveform "
"data\",\"patternProperties\":{\"^[0-9]+$\":{\"description\":\"one field per "
"channel, field name is channel index\",\"$ref\":\"#/definitions/channel\"}}"
",\"additionalProperties\":false,\"title\":\"Exponential "
"Decomposition\",\"type\":\"object\"}"
)
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_EXAMPLE = (
"{\"1\":{\"parameter\":{\"B\":[-3.9,0.0,-0.3],\"omega\":[352020896.0,3647927552"
".0,-1977987072.0],\"gamma\":[-1094726528.0,-769562752.0,-848000064.0],\"A"
"\":[0.9,0.3,-1.3]},\"a_lin\":0.9,\"scale\":1.0,\"delay\":3.5e-09},\"0\":{\"param"
"eter\":{\"B\":[-3.9813032150268555,0.08622030913829803,-0.315286099910736"
"1],\"omega\":[352020896.0,3647927552.0,-1977987072.0],\"gamma\":[-10947265"
"28.0,-769562752.0,-848000064.0],\"A\":[0.9772450923919678,0.335433512926"
"1017,-1.312678575515747]},\"a_lin\":0.27,\"scale\":1.0,\"delay\":3.783458418"
"887631e-09}}"
)

# Details for Gaussian decomposition of full waveform data
RDB_RIEGL_GAUSSIAN_DECOMPOSITION             = "riegl.gaussian_decomposition"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_TITLE       = "Gaussian Decomposition"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_DESCRIPTION = "Details for Gaussian decomposition of full waveform data"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_STATUS      = "optional"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_SCHEMA = (
"{\"required\":[\"amplitude_lsb_low_power\",\"amplitude_lsb_high_power\",\"amp"
"litude_db\",\"range_offset_sec_low_power\",\"range_offset_sec_high_power\"]"
",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"description\":\"ri"
"egl.gaussian_decomposition contains information relevant for "
"extracting calibrated amplitudes and calibrated ranges from a Gaussian"
" decomposition of full waveform data. This information is contained in"
" a table with five columns. Two columns are to be used as input: "
"amplitude_lsb_low_power and amplitude_lsb_high_power. The other three "
"columns provide the outputs. Amplitude_db gives the calibrated "
"amplitude in the optical regime in decibels. The range offset columns "
"provide additive range offsets, given in units of seconds, for each "
"channel.\",\"title\":\"Gaussian Decomposition\",\"type\":\"object\",\"properties"
"\":{\"amplitude_lsb_high_power\":{\"type\":\"array\",\"items\":{\"type\":\"number\""
"}},\"range_offset_sec_low_power\":{\"type\":\"array\",\"items\":{\"type\":\"numbe"
"r\"}},\"amplitude_lsb_low_power\":{\"type\":\"array\",\"items\":{\"type\":\"number"
"\"}},\"amplitude_db\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"range_o"
"ffset_sec_high_power\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}}}}"
)
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_EXAMPLE = (
"{\"amplitude_lsb_high_power\":[],\"range_offset_sec_low_power\":[],\"amplit"
"ude_lsb_low_power\":[],\"amplitude_db\":[],\"range_offset_sec_high_power\":"
"[]}"
)

# Point cloud georeferencing information
RDB_RIEGL_GEO_TAG             = "riegl.geo_tag"
RDB_RIEGL_GEO_TAG_TITLE       = "Geo Tag"
RDB_RIEGL_GEO_TAG_DESCRIPTION = "Point cloud georeferencing information"
RDB_RIEGL_GEO_TAG_STATUS      = "optional"
RDB_RIEGL_GEO_TAG_SCHEMA = (
"{\"description\":\"Point cloud georeferencing information\",\"title\":\"Geo T"
"ag\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object"
"\",\"properties\":{\"crs\":{\"description\":\"Global Coordinate Reference "
"System. Please note that only 3D Cartesian Coordinate Systems are allo"
"wed.\",\"type\":\"object\",\"properties\":{\"wkt\":{\"description\":\"\\\"Well-Known"
" Text\\\" string, OGC WKT dialect (see http://www.opengeospatial.org/sta"
"ndards/wkt-crs)\",\"type\":\"string\"},\"name\":{\"description\":\"Coordinate "
"reference system name\",\"type\":\"string\"},\"epsg\":{\"description\":\"EPSG co"
"de\",\"minimum\":0,\"type\":\"integer\"}}},\"pose\":{\"description\":\"Coordinate "
"Transformation Matrix to transform from File Coordinate System to "
"Global Coordinate Reference System. 4x4 matrix stored as two "
"dimensional array, row major order.\",\"minItems\":4,\"maxItems\":4,\"type\":"
"\"array\",\"items\":{\"description\":\"rows\",\"minItems\":4,\"maxItems\":4,\"type\""
":\"array\",\"items\":{\"description\":\"columns\",\"type\":\"number\"}}}}}"
)
RDB_RIEGL_GEO_TAG_EXAMPLE = (
"{\"crs\":{\"wkt\":\"GEOCCS[\\\"WGS84 Geocentric\\\",DATUM[\\\"WGS84\\\",SPHEROID[\\\""
"WGS84\\\",6378137.000,298.257223563,AUTHORITY[\\\"EPSG\\\",\\\"7030\\\"]],AUTHOR"
"ITY[\\\"EPSG\\\",\\\"6326\\\"]],PRIMEM[\\\"Greenwich\\\",0.0000000000000000,AUTHOR"
"ITY[\\\"EPSG\\\",\\\"8901\\\"]],UNIT[\\\"Meter\\\",1.00000000000000000000,AUTHORIT"
"Y[\\\"EPSG\\\",\\\"9001\\\"]],AXIS[\\\"X\\\",OTHER],AXIS[\\\"Y\\\",EAST],AXIS[\\\"Z\\\",NO"
"RTH],AUTHORITY[\\\"EPSG\\\",\\\"4978\\\"]]\",\"name\":\"WGS84 Geocentric\",\"epsg\":4"
"978},\"pose\":[[-0.269827776749716,-0.723017716139738,0.635954678449952,"
"4063882.500831],[0.962908599449764,-0.20260517250352,0.178208229833847"
",1138787.607461],[0.0,0.660451759194338,0.7508684796801,4766084.550196"
"],[0.0,0.0,0.0,1.0]]}"
)

# Geometric scale factor applied to point coordinates
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR             = "riegl.geometric_scale_factor"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_TITLE       = "Geometric Scale Factor"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_DESCRIPTION = "Geometric scale factor applied to point coordinates"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_STATUS      = "optional"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_SCHEMA = (
"{\"description\":\"Geometric scale factor applied to point coordinates\",\""
"minimum\":0,\"exclusiveMinimum\":true,\"$schema\":\"http://json-schema.org/d"
"raft-04/schema#\",\"type\":\"number\"}"
)
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_EXAMPLE = (
"1.0"
)

# Parameters used for georeferencing of the point cloud
RDB_RIEGL_GEOREFERENCING_PARAMETERS             = "riegl.georeferencing_parameters"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_TITLE       = "Georeferencing Parameters"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_DESCRIPTION = "Parameters used for georeferencing of the point cloud"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_STATUS      = "optional"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_SCHEMA = (
"{\"description\":\"Parameters used for georeferencing of the point "
"cloud\",\"title\":\"Georeferencing Parameters\",\"$schema\":\"http://json-sche"
"ma.org/draft-04/schema#\",\"type\":\"object\",\"properties\":{\"socs_to_body_m"
"atrix\":{\"description\":\"Coordinate Transformation Matrix to transform "
"from Scanner's Own Coordinate System to Body Coordinate System. 4x4 "
"matrix stored as two dimensional array, row major order.\",\"minItems\":4"
",\"maxItems\":4,\"type\":\"array\",\"items\":{\"description\":\"rows\",\"minItems\":"
"4,\"maxItems\":4,\"type\":\"array\",\"items\":{\"description\":\"columns\",\"type\":"
"\"number\"}}},\"trajectory_offsets\":{\"description\":\"Correction offsets "
"applied to the trajectory data\",\"type\":\"object\",\"properties\":{\"offset_"
"time\":{\"description\":\"[s]\",\"type\":\"number\"},\"offset_height\":{\"descript"
"ion\":\"[m]\",\"type\":\"number\"},\"offset_east\":{\"description\":\"[m]\",\"type\":"
"\"number\"},\"offset_north\":{\"description\":\"[m]\",\"type\":\"number\"},\"offset"
"_roll\":{\"description\":\"[deg]\",\"type\":\"number\"},\"offset_yaw\":{\"descript"
"ion\":\"[deg]\",\"type\":\"number\"},\"version\":{\"description\":\"Meaning of "
"offset values and how to apply them; version 0: "
"Rz(yaw+offset_yaw)*Ry(pitch+offset_pitch)*Rx(roll+offset_roll), "
"version 1: Rz(yaw)*Ry(pitch)*Rx(roll) * Rz(yaw_offset)*Ry(pitch_offset"
")*Rx(roll_offset)\",\"type\":\"integer\"},\"offset_pitch\":{\"description\":\"[d"
"eg]\",\"type\":\"number\"}}},\"trajectory_file\":{\"description\":\"Trajectory "
"data used for georeferencing of the point cloud\",\"required\":[\"file_ext"
"ension\"],\"type\":\"object\",\"properties\":{\"file_extension\":{\"description\""
":\"Trajectory file extension, without the leading "
"dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's Universally "
"Unique Identifier (RFC 4122)\",\"type\":\"string\"}}},\"socs_to_rocs_matrix\""
":{\"description\":\"Coordinate Transformation Matrix to transform from "
"Scanner's Own Coordinate System to Record Coordinate System. 4x4 "
"matrix stored as two dimensional array, row major order.\",\"minItems\":4"
",\"maxItems\":4,\"type\":\"array\",\"items\":{\"description\":\"rows\",\"minItems\":"
"4,\"maxItems\":4,\"type\":\"array\",\"items\":{\"description\":\"columns\",\"type\":"
"\"number\"}}},\"body_coordinate_system_type\":{\"description\":\"BODY "
"coordinate frame (NED: North-East-Down, ENU: East-North-Up), default: "
"NED\",\"enum\":[\"NED\",\"ENU\"],\"type\":\"string\"}}}"
)
RDB_RIEGL_GEOREFERENCING_PARAMETERS_EXAMPLE = (
"{\"socs_to_body_matrix\":[[-0.269827776749716,-0.723017716139738,0.63595"
"4678449952,0.0],[0.962908599449764,-0.20260517250352,0.178208229833847"
",0.0],[0.0,0.660451759194338,0.7508684796801,0.0],[0.0,0.0,0.0,1.0]],\""
"trajectory_offsets\":{\"offset_time\":18.007,\"offset_height\":-0.2,\"offset"
"_east\":0.15,\"offset_north\":0.07,\"offset_roll\":0.03,\"offset_yaw\":-0.45,"
"\"version\":0,\"offset_pitch\":0.01},\"trajectory_file\":{\"file_extension\":\""
"pofx\",\"file_uuid\":\"93a03615-66c0-4bea-8ff8-c577378fe660\"},\"body_coordi"
"nate_system_type\":\"NED\"}"
)

# Map of item names
RDB_RIEGL_ITEM_NAMES             = "riegl.item_names"
RDB_RIEGL_ITEM_NAMES_TITLE       = "Item Names"
RDB_RIEGL_ITEM_NAMES_DESCRIPTION = "Map of item names"
RDB_RIEGL_ITEM_NAMES_STATUS      = "optional"
RDB_RIEGL_ITEM_NAMES_SCHEMA = (
"{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"description\":\"Ma"
"p of item names\",\"patternProperties\":{\"^-?[0-9]+$\":{\"description\":\"One"
" field per item, field name is item id, field value is item "
"name\",\"type\":\"string\"}},\"additionalProperties\":false,\"title\":\"Item "
"Names\",\"type\":\"object\"}"
)
RDB_RIEGL_ITEM_NAMES_EXAMPLE = (
"{\"-1\":\"Name of item with id -1\",\"1\":\"Name of item with id "
"1\",\"47\":\"Name of item with id 47\",\"2\":\"Name of item with id 2\"}"
)

# License keys for software features
RDB_RIEGL_LICENSES             = "riegl.licenses"
RDB_RIEGL_LICENSES_TITLE       = "Software License Keys"
RDB_RIEGL_LICENSES_DESCRIPTION = "License keys for software features"
RDB_RIEGL_LICENSES_STATUS      = "optional"
RDB_RIEGL_LICENSES_SCHEMA = (
"{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"description\":\"Li"
"cense keys for software "
"features\",\"patternProperties\":{\"^.*$\":{\"description\":\"Each field of "
"the object represents a feature and holds a list of license keys, "
"where the field name is the feature "
"name.\",\"minItems\":1,\"type\":\"array\",\"items\":{\"description\":\"License key"
" (example: '46AE032A - 39882AC4 - 9EC0A184 - 6F163D73')\",\"type\":\"strin"
"g\"}}},\"additionalProperties\":false,\"title\":\"Software License "
"Keys\",\"type\":\"object\"}"
)
RDB_RIEGL_LICENSES_EXAMPLE = (
"{\"Georeferencing\":[\"46AE032A - 39882AC4 - 9EC0A184 - 6F163D73\"],\"Full "
"Waveform Analysis Topography\":[\"0FD5FF07 - 011A1255 - 9F76CACA - "
"8D2ED557\"],\"Full Waveform Analysis Topography with GPU "
"support\":[\"8AB44126 - 23B92250 - 16E2689F - 34EF7E7B\"],\"MTA "
"resolution\":[\"468E020A - 39A922E4 - B681A184 - 673E3D72\"]}"
)

# Parameters for MTA processing
RDB_RIEGL_MTA_SETTINGS             = "riegl.mta_settings"
RDB_RIEGL_MTA_SETTINGS_TITLE       = "MTA Settings"
RDB_RIEGL_MTA_SETTINGS_DESCRIPTION = "Parameters for MTA processing"
RDB_RIEGL_MTA_SETTINGS_STATUS      = "optional"
RDB_RIEGL_MTA_SETTINGS_SCHEMA = (
"{\"description\":\"Parameters for MTA processing\",\"title\":\"MTA Settings\","
"\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\"p"
"roperties\":{\"modulation_depth\":{\"description\":\"Depth of pulse position"
" modulation in meter.\",\"minimum\":0,\"type\":\"number\"},\"zone_width\":{\"des"
"cription\":\"Width of a MTA zone in meter.\",\"minimum\":0,\"type\":\"number\"}"
",\"zone_count\":{\"description\":\"Maximum number of MTA "
"zones.\",\"minimum\":0,\"maximum\":255,\"type\":\"integer\"}}}"
)
RDB_RIEGL_MTA_SETTINGS_EXAMPLE = (
"{\"modulation_depth\":9.368514,\"zone_width\":149.896225,\"zone_count\":23}"
)

# Lookup table for range correction based on raw range
RDB_RIEGL_NEAR_RANGE_CORRECTION             = "riegl.near_range_correction"
RDB_RIEGL_NEAR_RANGE_CORRECTION_TITLE       = "Near Range Correction Table"
RDB_RIEGL_NEAR_RANGE_CORRECTION_DESCRIPTION = "Lookup table for range correction based on raw range"
RDB_RIEGL_NEAR_RANGE_CORRECTION_STATUS      = "optional"
RDB_RIEGL_NEAR_RANGE_CORRECTION_SCHEMA = (
"{\"required\":[\"delta\",\"content\"],\"$schema\":\"http://json-schema.org/draf"
"t-04/schema#\",\"description\":\"Lookup table for range correction based "
"on raw range\",\"title\":\"Near Range Correction Table\",\"type\":\"object\",\"p"
"roperties\":{\"content\":{\"description\":\"Correction value [m] to be added"
" to the raw range\",\"minItems\":1,\"maxItems\":2000,\"type\":\"array\",\"items\""
":{\"type\":\"number\"}},\"delta\":{\"description\":\"Delta between table "
"entries [m], first entry is at range = 0 m\",\"type\":\"number\"}}}"
)
RDB_RIEGL_NEAR_RANGE_CORRECTION_EXAMPLE = (
"{\"content\":[0.0],\"delta\":0.512}"
)

# Standard deviation for range and amplitude as a function of amplitude
RDB_RIEGL_NOISE_ESTIMATES             = "riegl.noise_estimates"
RDB_RIEGL_NOISE_ESTIMATES_TITLE       = "Noise Estimates"
RDB_RIEGL_NOISE_ESTIMATES_DESCRIPTION = "Standard deviation for range and amplitude as a function of amplitude"
RDB_RIEGL_NOISE_ESTIMATES_STATUS      = "optional"
RDB_RIEGL_NOISE_ESTIMATES_SCHEMA = (
"{\"required\":[\"amplitude\",\"range_sigma\",\"amplitude_sigma\"],\"$schema\":\"h"
"ttp://json-schema.org/draft-04/schema#\",\"description\":\"Standard "
"deviation for range and amplitude as a function of "
"amplitude\",\"title\":\"Noise Estimates\",\"type\":\"object\",\"properties\":{\"ra"
"nge_sigma\":{\"description\":\"Sigma range [m]\",\"type\":\"array\",\"items\":{\"t"
"ype\":\"number\"}},\"amplitude\":{\"description\":\"Amplitude [dB]\",\"type\":\"ar"
"ray\",\"items\":{\"type\":\"number\"}},\"amplitude_sigma\":{\"description\":\"Sigm"
"a amplitude [dB]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}}}}"
)
RDB_RIEGL_NOISE_ESTIMATES_EXAMPLE = (
"{\"range_sigma\":[0.065,0.056,0.046,0.038,0.032,0.027,0.024,0.021,0.018,"
"0.016,0.014],\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0"
"],\"amplitude_sigma\":[0.988,0.988,0.875,0.774,0.686,0.608,0.54,0.482,0."
"432,0.39,0.354]}"
)

# Notch filter parameters for window glass echoes
RDB_RIEGL_NOTCH_FILTER             = "riegl.notch_filter"
RDB_RIEGL_NOTCH_FILTER_TITLE       = "Notch Filter"
RDB_RIEGL_NOTCH_FILTER_DESCRIPTION = "Notch filter parameters for window glass echoes"
RDB_RIEGL_NOTCH_FILTER_STATUS      = "optional"
RDB_RIEGL_NOTCH_FILTER_SCHEMA = (
"{\"required\":[\"range_minimum\",\"range_maximum\",\"amplitude_maximum\"],\"$sc"
"hema\":\"http://json-schema.org/draft-04/schema#\",\"description\":\"Notch "
"filter parameters for window glass echoes\",\"title\":\"Notch Filter\",\"typ"
"e\":\"object\",\"properties\":{\"amplitude_maximum\":{\"description\":\"Maximum "
"amplitude [dB]\",\"minimum\":0,\"type\":\"number\"},\"range_minimum\":{\"descrip"
"tion\":\"Minimum range "
"[m]\",\"type\":\"number\"},\"range_maximum\":{\"description\":\"Maximum range "
"[m]\",\"type\":\"number\"}}}"
)
RDB_RIEGL_NOTCH_FILTER_EXAMPLE = (
"{\"amplitude_maximum\":18.0,\"range_minimum\":-0.5,\"range_maximum\":0.2}"
)

# Details about the pixels contained in the file
RDB_RIEGL_PIXEL_INFO             = "riegl.pixel_info"
RDB_RIEGL_PIXEL_INFO_TITLE       = "Pixel Information"
RDB_RIEGL_PIXEL_INFO_DESCRIPTION = "Details about the pixels contained in the file"
RDB_RIEGL_PIXEL_INFO_STATUS      = "optional"
RDB_RIEGL_PIXEL_INFO_SCHEMA = (
"{\"required\":[\"size\"],\"definitions\":{\"pixel_size\":{\"description\":\"Size "
"of pixels.\",\"minItems\":2,\"maxItems\":2,\"type\":\"array\",\"items\":{\"descrip"
"tion\":\"Length of pixel edge [m].\",\"minimum\":0,\"type\":\"number\"}}},\"$sch"
"ema\":\"http://json-schema.org/draft-04/schema#\",\"description\":\"Details "
"about the pixels contained in the file\",\"title\":\"Pixel Information\",\"t"
"ype\":\"object\",\"properties\":{\"size_llcs\":{\"description\":\"Size of pixels"
" in a locally levelled cartesian coordinate system (xy). This is only "
"used for pixels based on a map projection.\",\"$ref\":\"#/definitions/pixe"
"l_size\"},\"size\":{\"description\":\"Size of pixels in file coordinate "
"system.\",\"$ref\":\"#/definitions/pixel_size\"}}}"
)
RDB_RIEGL_PIXEL_INFO_EXAMPLE = (
"{\"size_llcs\":[0.5156575252891171,0.5130835356683303],\"size\":[0.5971642"
"834779395,0.5971642834779395]}"
)

# Details about the plane patch matching process
RDB_RIEGL_PLANE_PATCH_MATCHING             = "riegl.plane_patch_matching"
RDB_RIEGL_PLANE_PATCH_MATCHING_TITLE       = "Plane Patch Matching"
RDB_RIEGL_PLANE_PATCH_MATCHING_DESCRIPTION = "Details about the plane patch matching process"
RDB_RIEGL_PLANE_PATCH_MATCHING_STATUS      = "optional"
RDB_RIEGL_PLANE_PATCH_MATCHING_SCHEMA = (
"{\"required\":[\"plane_patch_file_one\",\"plane_patch_file_two\"],\"definitio"
"ns\":{\"file_reference\":{\"description\":\"Reference to a plane patch file\""
",\"required\":[\"file_uuid\",\"file_path\"],\"type\":\"object\",\"properties\":{\"f"
"ile_uuid\":{\"description\":\"Plane patch file's Universally Unique "
"Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_path\":{\"description\":\"Path of the plane "
"patch file relative to the match file\",\"type\":\"string\"}}}},\"$schema\":\""
"http://json-schema.org/draft-04/schema#\",\"description\":\"Details about "
"the plane patch matching process\",\"title\":\"Plane Patch Matching\",\"type"
"\":\"object\",\"properties\":{\"plane_patch_file_two\":{\"description\":\"Refere"
"nce to the plane patch file two\",\"$ref\":\"#/definitions/file_reference\""
"},\"plane_patch_file_one\":{\"description\":\"Reference to the plane patch "
"file one\",\"$ref\":\"#/definitions/file_reference\"}}}"
)
RDB_RIEGL_PLANE_PATCH_MATCHING_EXAMPLE = (
"{\"plane_patch_file_two\":{\"file_uuid\":\"fa47d509-a64e-49ce-8b14-ff3130fb"
"efa9\",\"file_path\":\"project.ptch\"},\"plane_patch_file_one\":{\"file_uuid\":"
"\"810f5d57-eccf-49ed-b07a-0cdd109b4213\",\"file_path\":\"Record009_Line001/"
"191025_121410_Scanner_1.ptch\"}}"
)

# Statistics about plane patches found by plane patch extractor
RDB_RIEGL_PLANE_PATCH_STATISTICS             = "riegl.plane_patch_statistics"
RDB_RIEGL_PLANE_PATCH_STATISTICS_TITLE       = "Plane Patch Statistics"
RDB_RIEGL_PLANE_PATCH_STATISTICS_DESCRIPTION = "Statistics about plane patches found by plane patch extractor"
RDB_RIEGL_PLANE_PATCH_STATISTICS_STATUS      = "optional"
RDB_RIEGL_PLANE_PATCH_STATISTICS_SCHEMA = (
"{\"description\":\"Statistics about plane patches found by plane patch "
"extractor\",\"title\":\"Plane Patch Statistics\",\"$schema\":\"http://json-sch"
"ema.org/draft-04/schema#\",\"type\":\"object\",\"properties\":{\"total_horizon"
"tal_area\":{\"description\":\"sum of all plane patch areas projected to "
"horizontal plane "
"[m\\u00b2]\",\"type\":\"number\"},\"total_area\":{\"description\":\"sum of all "
"plane patch areas [m\\u00b2]\",\"type\":\"number\"}}}"
)
RDB_RIEGL_PLANE_PATCH_STATISTICS_EXAMPLE = (
"{\"total_horizontal_area\":13954.601,\"total_area\":14007.965}"
)

# Settings and classes for plane slope classification
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO             = "riegl.plane_slope_class_info"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_TITLE       = "Plane Slope Class Info"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_DESCRIPTION = "Settings and classes for plane slope classification"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_STATUS      = "optional"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_SCHEMA = (
"{\"required\":[\"settings\",\"classes\"],\"definitions\":{\"method-1\":{\"descrip"
"tion\":\"Classification method 1\",\"required\":[\"plane_classification_meth"
"od\",\"maximum_inclination_angle_horizontal\"],\"type\":\"object\",\"propertie"
"s\":{\"maximum_inclination_angle_horizontal\":{\"description\":\"maximum "
"inclination angle of horizontal plane patches [deg]\",\"minimum\":-360.0,"
"\"maximum\":360.0,\"type\":\"number\"},\"plane_classification_method\":{\"descr"
"iption\":\"method ID (=1)\",\"minimum\":1,\"maximum\":1,\"type\":\"integer\"}}},\""
"method-2\":{\"description\":\"Classification method 2\",\"required\":[\"plane_"
"classification_method\",\"sloping_plane_classes_minimum_angle\",\"sloping_"
"plane_classes_maximum_angle\"],\"type\":\"object\",\"properties\":{\"sloping_p"
"lane_classes_minimum_angle\":{\"description\":\"minimum inclination angle "
"of sloping plane patches [deg]\",\"minimum\":-360.0,\"maximum\":360.0,\"type"
"\":\"number\"},\"sloping_plane_classes_maximum_angle\":{\"description\":\"maxi"
"mum inclination angle of sloping plane patches [deg]\",\"minimum\":-360.0"
",\"maximum\":360.0,\"type\":\"number\"},\"plane_classification_method\":{\"desc"
"ription\":\"method ID (=2)\",\"minimum\":2,\"maximum\":2,\"type\":\"integer\"}}}}"
",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"description\":\"Se"
"ttings and classes for plane slope classification\",\"title\":\"Plane "
"Slope Class "
"Info\",\"type\":\"object\",\"properties\":{\"classes\":{\"description\":\"Class "
"definition table\",\"patternProperties\":{\"^[0-9]+$\":{\"description\":\"one "
"field per class, field name is class number, field value is class name"
"\",\"type\":\"string\"}},\"additionalProperties\":false,\"type\":\"object\"},\"set"
"tings\":{\"description\":\"Classification settings, details see "
"documentation of rdbplanes\",\"oneOf\":[{\"$ref\":\"#/definitions/method-1\"}"
",{\"$ref\":\"#/definitions/method-2\"}],\"type\":\"object\"}}}"
)
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_EXAMPLE = (
"{\"classes\":{\"1\":\"horizontal, pointing up\",\"4\":\"sloping, pointing up "
"and north\",\"6\":\"vertical, pointing east\",\"9\":\"vertical, pointing "
"west\",\"5\":\"sloping, pointing up and west\",\"11\":\"sloping, pointing down"
" and south\",\"3\":\"sloping, pointing up and south\",\"10\":\"sloping, "
"pointing down and east\",\"14\":\"horizontal, pointing down\",\"2\":\"sloping,"
" pointing up and east\",\"13\":\"sloping, pointing down and "
"west\",\"7\":\"vertical, pointing south\",\"8\":\"vertical, pointing "
"north\",\"12\":\"sloping, pointing down and north\"},\"settings\":{\"sloping_p"
"lane_classes_minimum_angle\":10.0,\"sloping_plane_classes_maximum_angle\""
":70.0,\"plane_classification_method\":2}}"
)

# Grouping and sorting of point attributes for visualization purposes
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS             = "riegl.point_attribute_groups"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_TITLE       = "Point Attribute Groups"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_DESCRIPTION = "Grouping and sorting of point attributes for visualization purposes"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_STATUS      = "optional"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_SCHEMA = (
"{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"description\":\"Gr"
"ouping and sorting of point attributes for visualization "
"purposes\",\"patternProperties\":{\"^.*$\":{\"description\":\"Each field of "
"the object represents a point attribute group and holds a list of "
"point attributes, where the field name is the group "
"name.\",\"minItems\":1,\"type\":\"array\",\"items\":{\"description\":\"Point "
"attribute full name or name pattern (perl regular expression syntax)\","
"\"type\":\"string\"}}},\"additionalProperties\":false,\"title\":\"Point "
"Attribute Groups\",\"type\":\"object\"}"
)
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_EXAMPLE = (
"{\"Primary Attributes\":[\"riegl.reflectance\",\"riegl.amplitude\",\"riegl.de"
"viation\"],\"Time\":[\"riegl.timestamp\"],\"Coordinates/Vectors\":[\"riegl.xyz"
"\",\"riegl.range\",\"riegl.theta\",\"riegl.phi\"],\"Secondary "
"Attributes\":[\"riegl.mirror_facet\",\"riegl.waveform_available\"],\"Other "
"Attributes\":[\"riegl.selected\",\"riegl.visible\"]}"
)

# Details about point cloud files
RDB_RIEGL_POINTCLOUD_INFO             = "riegl.pointcloud_info"
RDB_RIEGL_POINTCLOUD_INFO_TITLE       = "Point Cloud Information"
RDB_RIEGL_POINTCLOUD_INFO_DESCRIPTION = "Details about point cloud files"
RDB_RIEGL_POINTCLOUD_INFO_STATUS      = "optional"
RDB_RIEGL_POINTCLOUD_INFO_SCHEMA = (
"{\"description\":\"Details about point cloud files\",\"title\":\"Point Cloud "
"Information\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type"
"\":\"object\",\"properties\":{\"field_of_application\":{\"description\":\"Field "
"of application\",\"enum\":[\"unknown\",\"SLS\",\"TLS\",\"KLS\",\"MLS\",\"ULS\",\"ALS\","
"\"BLS\",\"ILS\"],\"type\":\"string\"},\"comments\":{\"description\":\"Comments\",\"ty"
"pe\":\"string\"},\"project\":{\"description\":\"Project "
"name\",\"type\":\"string\"}}}"
)
RDB_RIEGL_POINTCLOUD_INFO_EXAMPLE = (
"{\"field_of_application\":\"ALS\",\"comments\":\"Line 3\",\"project\":\"Campaign "
"4\"}"
)

# Estimated position and orientation information
RDB_RIEGL_POSE_ESTIMATION             = "riegl.pose_estimation"
RDB_RIEGL_POSE_ESTIMATION_TITLE       = "Pose Estimation"
RDB_RIEGL_POSE_ESTIMATION_DESCRIPTION = "Estimated position and orientation information"
RDB_RIEGL_POSE_ESTIMATION_STATUS      = "optional"
RDB_RIEGL_POSE_ESTIMATION_SCHEMA = (
"{\"required\":[\"orientation\"],\"$schema\":\"http://json-schema.org/draft-04"
"/schema#\",\"description\":\"Estimated position and orientation "
"information as measured by GNSS, IMU or inclination "
"sensors\",\"title\":\"Pose Estimation\",\"type\":\"object\",\"properties\":{\"posi"
"tion\":{\"description\":\"Position coordinates and position accuracy "
"values as measured by GNSS in the specified Coordinate Reference "
"System (CRS)\",\"required\":[\"coordinate_1\",\"coordinate_2\",\"coordinate_3\""
",\"horizontal_accuracy\",\"vertical_accuracy\",\"crs\"],\"type\":\"object\",\"pro"
"perties\":{\"vertical_accuracy\":{\"description\":\"Vertical accuracy [m]\",\""
"minimum\":0,\"exclusiveMinimum\":true,\"type\":\"number\"},\"coordinate_2\":{\"d"
"escription\":\"Coordinate 2 as defined by axis 2 of the specified CRS "
"(e.g., Y, "
"Longitude)\",\"type\":\"number\"},\"coordinate_3\":{\"description\":\"Coordinate"
" 3 as defined by axis 3 of the specified CRS (e.g., Z, Altitude)\",\"typ"
"e\":\"number\"},\"horizontal_accuracy\":{\"description\":\"Horizontal accuracy"
" [m]\",\"minimum\":0,\"exclusiveMinimum\":true,\"type\":\"number\"},\"crs\":{\"des"
"cription\":\"Global Coordinate Reference System\",\"required\":[\"epsg\"],\"ty"
"pe\":\"object\",\"properties\":{\"wkt\":{\"description\":\"\\\"Well-Known Text\\\" "
"string, OGC WKT dialect (see http://www.opengeospatial.org/standards/w"
"kt-crs)\",\"type\":\"string\"},\"epsg\":{\"description\":\"EPSG code\",\"minimum\":"
"0,\"type\":\"integer\"}}},\"coordinate_1\":{\"description\":\"Coordinate 1 as "
"defined by axis 1 of the specified CRS (e.g., X, Latitude)\",\"type\":\"nu"
"mber\"}}},\"orientation\":{\"description\":\"Orientation values and "
"orientation accuracies, measured with IMU or inclination sensors.\",\"re"
"quired\":[\"roll\",\"pitch\",\"yaw\",\"roll_accuracy\",\"pitch_accuracy\",\"yaw_ac"
"curacy\"],\"type\":\"object\",\"properties\":{\"roll\":{\"description\":\"Roll "
"angle about scanner X-axis [deg]\",\"minimum\":-360,\"maximum\":360,\"type\":"
"\"number\"},\"yaw\":{\"description\":\"Yaw angle about scanner Z-axis [deg]\","
"\"minimum\":-360,\"maximum\":360,\"type\":\"number\"},\"roll_accuracy\":{\"descri"
"ption\":\"Roll angle accuracy [deg]\",\"minimum\":0,\"exclusiveMinimum\":true"
",\"type\":\"number\"},\"pitch\":{\"description\":\"Pitch angle about scanner "
"Y-axis [deg]\",\"minimum\":-360,\"maximum\":360,\"type\":\"number\"},\"pitch_acc"
"uracy\":{\"description\":\"Pitch angle accuracy [deg]\",\"minimum\":0,\"exclus"
"iveMinimum\":true,\"type\":\"number\"},\"yaw_accuracy\":{\"description\":\"Yaw "
"angle accuracy [deg]\",\"minimum\":0,\"exclusiveMinimum\":true,\"type\":\"numb"
"er\"}}},\"barometric_height_amsl\":{\"description\":\"Altitude determined "
"based on the atmospheric pressure according to the standard atmosphere"
" laws [m].\",\"type\":\"number\"}}}"
)
RDB_RIEGL_POSE_ESTIMATION_EXAMPLE = (
"{\"position\":{\"vertical_accuracy\":1.3314999341964722,\"coordinate_2\":15."
"645033406,\"coordinate_3\":362.7124938964844,\"horizontal_accuracy\":0.810"
"699999332428,\"crs\":{\"wkt\":\"GEOGCS[\\\"WGS84 / Geographic\\\",DATUM[\\\"WGS84"
"\\\",SPHEROID[\\\"WGS84\\\",6378137.000,298.257223563,AUTHORITY[\\\"EPSG\\\",\\\"7"
"030\\\"]],AUTHORITY[\\\"EPSG\\\",\\\"6326\\\"]],PRIMEM[\\\"Greenwich\\\",0.000000000"
"0000000,AUTHORITY[\\\"EPSG\\\",\\\"8901\\\"]],UNIT[\\\"Degree\\\",0.01745329251994"
"329547,AUTHORITY[\\\"EPSG\\\",\\\"9102\\\"]],AXIS[\\\"Latitude\\\",NORTH],AXIS[\\\"L"
"ongitude\\\",EAST],AUTHORITY[\\\"EPSG\\\",\\\"4979\\\"]]\",\"epsg\":4979},\"coordina"
"te_1\":48.655799473},\"orientation\":{\"roll\":3.14743073066123,\"yaw\":101.8"
"7293630292045,\"roll_accuracy\":0.009433783936875745,\"pitch\":1.509153024"
"827064,\"pitch_accuracy\":0.009433783936875745,\"yaw_accuracy\":1.00943378"
"39368757},\"barometric_height_amsl\":386.7457796227932}"
)

# Details on position and orientation sensors
RDB_RIEGL_POSE_SENSORS             = "riegl.pose_sensors"
RDB_RIEGL_POSE_SENSORS_TITLE       = "Pose Sensors"
RDB_RIEGL_POSE_SENSORS_DESCRIPTION = "Details on position and orientation sensors"
RDB_RIEGL_POSE_SENSORS_STATUS      = "optional"
RDB_RIEGL_POSE_SENSORS_SCHEMA = (
"{\"required\":[\"gyroscope\",\"accelerometer\",\"magnetic_field_sensor\"],\"def"
"initions\":{\"vector\":{\"minItems\":3,\"maxItems\":3,\"type\":\"array\",\"items\":"
"{\"description\":\"Index 0=X, 1=Y, 2=Z component\",\"type\":\"number\"}}},\"$sc"
"hema\":\"http://json-schema.org/draft-04/schema#\",\"description\":\"Details"
" on position and orientation sensors\",\"title\":\"Pose Sensors\",\"type\":\"o"
"bject\",\"properties\":{\"magnetic_field_sensor\":{\"description\":\"Magnetic "
"Field Sensor details\",\"required\":[\"unit\",\"x_axis\",\"y_axis\",\"z_axis\",\"o"
"ffset\",\"fixed\",\"relative_nonlinearity\"],\"type\":\"object\",\"properties\":{"
"\"z_axis\":{\"description\":\"Sensitive Z axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"unit\":{\"description\":\"Unit of raw "
"data and calibration values, 1 LSB in nT\",\"minimum\":0,\"exclusiveMinimu"
"m\":true,\"type\":\"number\"},\"offset\":{\"description\":\"Value to be "
"subtracted from raw measurement values\",\"$ref\":\"#/definitions/vector\"}"
",\"x_axis\":{\"description\":\"Sensitive X axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"relative_nonlinearity\":{\"descriptio"
"n\":\"Relative nonlinearity, dimensionless\",\"$ref\":\"#/definitions/vector"
"\"},\"y_axis\":{\"description\":\"Sensitive Y axis of sensor at frame angle "
"= 0\",\"$ref\":\"#/definitions/vector\"},\"fixed\":{\"description\":\"Distortion"
" of magnetic field caused by non-rotating scanner part\",\"$ref\":\"#/defi"
"nitions/vector\"}}},\"gyroscope\":{\"description\":\"Gyroscope details\",\"req"
"uired\":[\"unit\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\",\"origin\",\"relative_"
"nonlinearity\"],\"type\":\"object\",\"properties\":{\"z_axis\":{\"description\":\""
"Sensitive Z axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"unit\":{\"description\":\"Unit of raw "
"data and calibration values, 1 LSB in rad/s\",\"minimum\":0,\"exclusiveMin"
"imum\":true,\"type\":\"number\"},\"offset\":{\"description\":\"Value to be "
"subtracted from raw measurement values\",\"$ref\":\"#/definitions/vector\"}"
",\"x_axis\":{\"description\":\"Sensitive X axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"origin\":{\"description\":\"Sensor "
"origin in SOCS [m] at frame angle = 0\",\"$ref\":\"#/definitions/vector\"},"
"\"relative_nonlinearity\":{\"description\":\"Relative nonlinearity, dimensi"
"onless\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":{\"description\":\"Sensit"
"ive Y axis of sensor at frame angle = 0\",\"$ref\":\"#/definitions/vector\""
"}}},\"accelerometer\":{\"description\":\"Accelerometer details\",\"required\":"
"[\"unit\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\",\"origin\",\"relative_nonline"
"arity\"],\"type\":\"object\",\"properties\":{\"z_axis\":{\"description\":\"Sensiti"
"ve Z axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"unit\":{\"description\":\"Unit of raw "
"data and calibration values, 1 LSB in 9.81 m/s\\u00b2\",\"minimum\":0,\"exc"
"lusiveMinimum\":true,\"type\":\"number\"},\"offset\":{\"description\":\"Value to"
" be subtracted from raw measurement values\",\"$ref\":\"#/definitions/vect"
"or\"},\"x_axis\":{\"description\":\"Sensitive X axis of sensor at frame "
"angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"origin\":{\"description\":\"Sensor "
"origin in SOCS [m] at frame angle = 0\",\"$ref\":\"#/definitions/vector\"},"
"\"relative_nonlinearity\":{\"description\":\"Relative nonlinearity, dimensi"
"onless\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":{\"description\":\"Sensit"
"ive Y axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"}}}}}"
)
RDB_RIEGL_POSE_SENSORS_EXAMPLE = (
"{\"magnetic_field_sensor\":{\"z_axis\":[0.00041987866279669106,7.876977906"
"562388e-05,0.011407104320824146],\"unit\":91.74311828613281,\"offset\":[-2"
"3812.052734375,5606.57666015625,2493.28125],\"x_axis\":[-0.0111627439036"
"96537,-2.315962774446234e-05,0.00016818844596855342],\"relative_nonline"
"arity\":[0.0,0.0,0.0],\"y_axis\":[0.00027888521435670555,-0.0114274248480"
"79681,-5.204829722060822e-05],\"fixed\":[-1576.010498046875,1596.0817871"
"09375,0.0]},\"gyroscope\":{\"z_axis\":[0.555869996547699,119.2213516235351"
"6,0.467585027217865],\"unit\":0.00014544410805683583,\"offset\":[-50.92609"
"786987305,146.15643310546875,62.4327278137207],\"x_axis\":[-121.19555664"
"0625,0.8219714164733887,0.2313031703233719],\"origin\":[0.02690000087022"
"7814,-0.03999999910593033,-0.08950000256299973],\"relative_nonlinearity"
"\":[2.888176311444113e-07,1.06274164579645e-07,-1.7186295080634935e-39]"
",\"y_axis\":[-0.440765917301178,-0.7897399663925171,119.5894775390625]},"
"\"accelerometer\":{\"z_axis\":[1.639882206916809,15166.744140625,-116.9974"
"2889404297],\"unit\":6.666666740784422e-05,\"offset\":[-733.3636474609375,"
"58.969032287597656,1060.2550048828125],\"x_axis\":[-15008.123046875,56.9"
"56390380859375,-60.5175666809082],\"origin\":[0.026900000870227814,-0.03"
"999999910593033,-0.08950000256299973],\"relative_nonlinearity\":[0.0,0.0"
",0.0],\"y_axis\":[-7.027288913726807,-44.12333679199219,14952.3701171875"
"]}}"
)

# Laser pulse position modulation used for MTA resolution
RDB_RIEGL_PULSE_POSITION_MODULATION             = "riegl.pulse_position_modulation"
RDB_RIEGL_PULSE_POSITION_MODULATION_TITLE       = "Pulse Position Modulation"
RDB_RIEGL_PULSE_POSITION_MODULATION_DESCRIPTION = "Laser pulse position modulation used for MTA resolution"
RDB_RIEGL_PULSE_POSITION_MODULATION_STATUS      = "optional"
RDB_RIEGL_PULSE_POSITION_MODULATION_SCHEMA = (
"{\"required\":[\"length\",\"num_mod_ampl\",\"pulse_interval\"],\"$schema\":\"http"
"://json-schema.org/draft-04/schema#\",\"description\":\"Laser pulse "
"position modulation used for MTA resolution\",\"title\":\"Pulse Position M"
"odulation\",\"type\":\"object\",\"properties\":{\"length\":{\"description\":\"Leng"
"th of code\",\"minimum\":0,\"maximum\":255,\"type\":\"integer\"},\"phase_step\":{"
"\"description\":\"Step width in phase of modulation code from line to lin"
"e\",\"minimum\":0,\"maximum\":255,\"type\":\"integer\"},\"pulse_interval\":{\"desc"
"ription\":\"Explicit table of the pulse position modulation used for MTA"
" resolution. Table gives times between successive laser pulses in seco"
"nds.\",\"type\":\"array\",\"items\":{\"minimum\":0,\"type\":\"number\"}},\"num_mod_a"
"mpl\":{\"description\":\"Number of different modulation amplitudes (2: "
"binary modulation)\",\"minimum\":0,\"maximum\":255,\"type\":\"integer\"},\"code_"
"phase_mode\":{\"description\":\"0: no synchronization, 1: toggle between 2"
" phases, 2: increment with "
"phase_increment\",\"minimum\":0,\"maximum\":255,\"type\":\"integer\"}}}"
)
RDB_RIEGL_PULSE_POSITION_MODULATION_EXAMPLE = (
"{\"length\":31,\"phase_step\":5,\"pulse_interval\":[2.759375e-06,2.759375e-0"
"6,2.759375e-06,2.759375e-06,2.821875e-06,2.759375e-06,2.759375e-06,2.8"
"21875e-06,2.759375e-06,2.821875e-06,2.821875e-06,2.759375e-06,2.759375"
"e-06,2.821875e-06,2.821875e-06,2.821875e-06,2.821875e-06,2.821875e-06,"
"2.759375e-06,2.759375e-06,2.759375e-06,2.821875e-06,2.821875e-06,2.759"
"375e-06,2.821875e-06,2.821875e-06,2.821875e-06,2.759375e-06,2.821875e-"
"06,2.759375e-06,2.821875e-06],\"num_mod_ampl\":2,\"code_phase_mode\":2}"
)

# Statistics about target distance wrt. SOCS origin
RDB_RIEGL_RANGE_STATISTICS             = "riegl.range_statistics"
RDB_RIEGL_RANGE_STATISTICS_TITLE       = "Range Statistics"
RDB_RIEGL_RANGE_STATISTICS_DESCRIPTION = "Statistics about target distance wrt. SOCS origin"
RDB_RIEGL_RANGE_STATISTICS_STATUS      = "optional"
RDB_RIEGL_RANGE_STATISTICS_SCHEMA = (
"{\"required\":[\"minimum\",\"average\",\"maximum\",\"std_dev\"],\"$schema\":\"http:"
"//json-schema.org/draft-04/schema#\",\"description\":\"Statistics about "
"target distance wrt. SOCS origin\",\"title\":\"Range Statistics\",\"type\":\"o"
"bject\",\"properties\":{\"minimum\":{\"description\":\"Minimum "
"value\",\"type\":\"number\"},\"maximum\":{\"description\":\"Maximum "
"value\",\"type\":\"number\"},\"average\":{\"description\":\"Average "
"value\",\"type\":\"number\"},\"std_dev\":{\"description\":\"Standard "
"deviation\",\"type\":\"number\"}}}"
)
RDB_RIEGL_RANGE_STATISTICS_EXAMPLE = (
"{\"minimum\":0.919,\"maximum\":574.35,\"average\":15.49738,\"std_dev\":24.349}"
)

# Receiver Internals
RDB_RIEGL_RECEIVER_INTERNALS             = "riegl.receiver_internals"
RDB_RIEGL_RECEIVER_INTERNALS_TITLE       = "Receiver Internals"
RDB_RIEGL_RECEIVER_INTERNALS_DESCRIPTION = "Receiver Internals"
RDB_RIEGL_RECEIVER_INTERNALS_STATUS      = "optional"
RDB_RIEGL_RECEIVER_INTERNALS_SCHEMA = (
"{\"definitions\":{\"fp_table\":{\"required\":[\"ch\",\"tc\",\"nx\",\"ny\",\"tv\"],\"des"
"ription\":\"scanner internal "
"data\",\"type\":\"object\",\"properties\":{\"nx\":{\"description\":\"number of x e"
"ntries\",\"max\":2048,\"min\":1,\"type\":\"integer\"},\"ch\":{\"description\":\"chan"
"nel number\",\"max\":255,\"min\":0,\"type\":\"integer\"},\"tv\":{\"minItems\":1,\"ma"
"xItems\":2048,\"type\":\"array\",\"items\":{\"oneOf\":[{\"$ref\":\"#/definitions/f"
"p_table_row\"},{\"type\":\"number\"}]}},\"ny\":{\"description\":\"number of y en"
"tries\",\"max\":2048,\"min\":1,\"type\":\"integer\"},\"tc\":{\"description\":\"table"
" data type code\",\"max\":255,\"min\":0,\"type\":\"integer\"}}},\"fp_table_row\":"
"{\"minItems\":1,\"maxItems\":2048,\"type\":\"array\",\"items\":{\"type\":\"number\"}"
"},\"fp\":{\"description\":\"Fingerprint values\",\"required\":[\"s\",\"w\"],\"type\""
":\"object\",\"properties\":{\"s\":{\"minItems\":1,\"maxItems\":256,\"type\":\"array"
"\",\"items\":{\"minItems\":1,\"maxItems\":4096,\"type\":\"array\",\"items\":{\"type\""
":\"number\"}}},\"w\":{\"minItems\":1,\"maxItems\":256,\"type\":\"array\",\"items\":{"
"\"minItems\":5,\"maxItems\":5,\"type\":\"array\",\"items\":{\"type\":\"number\"}}}}}"
"},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"description\":\"R"
"eceiver Internals\",\"title\":\"Receiver Internals\",\"type\":\"object\",\"prope"
"rties\":{\"tbl\":{\"minItems\":1,\"description\":\"various internal data\",\"typ"
"e\":\"array\",\"items\":{\"$ref\":\"#/definitions/fp_table\"}},\"si\":{\"descripti"
"on\":\"Start index (hw_start)\",\"minimum\":0,\"maximum\":255,\"type\":\"number\""
"},\"sr\":{\"description\":\"Sample rate [Hz]\",\"minimum\":0,\"exclusiveMinimum"
"\":true,\"type\":\"number\"},\"t\":{\"patternProperties\":{\"^[0-9]+$\":{\"descrip"
"tion\":\"one field per channel, field name is channel index\",\"$ref\":\"#/d"
"efinitions/fp\"}},\"additionalProperties\":false,\"type\":\"object\"},\"ex\":{\""
"description\":\"DEPRECATED, use 'riegl.exponential_decomposition' "
"instead\",\"type\":\"object\"},\"a\":{\"minItems\":1,\"description\":\"Amplitude ["
"dB]\",\"maxItems\":256,\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"nt\":{\"d"
"escription\":\"Number of traces\",\"minimum\":0,\"maximum\":255,\"type\":\"integ"
"er\"},\"ns\":{\"description\":\"Number of samples\",\"minimum\":0,\"maximum\":409"
"5,\"type\":\"integer\"},\"mw\":{\"description\":\"Maximum weight\",\"minimum\":0,\""
"exclusiveMinimum\":true,\"maximum\":4095,\"type\":\"number\"}}}"
)
RDB_RIEGL_RECEIVER_INTERNALS_EXAMPLE = (
"{\"si\":48,\"sr\":7959997000.0,\"t\":{\"1\":{\"s\":[[1.23,4.56],[7.89,0.12]],\"w\""
":[[78,86,126,134,31],[78,86,126,134,31]]},\"0\":{\"s\":[[1.23,4.56],[7.89,"
"0.12]],\"w\":[[78,86,126,134,31],[78,86,126,134,31]]}},\"tbl\":[{\"nx\":5,\"c"
"h\":0,\"tv\":[[1,2,3,4,5],[1.1,2.2,3.3,4.4,5.5]],\"ny\":2,\"tc\":1}],\"a\":[-1."
"55],\"nt\":128,\"ns\":400,\"mw\":31}"
)

# Lookup table for reflectance calculation based on amplitude and range
RDB_RIEGL_REFLECTANCE_CALCULATION             = "riegl.reflectance_calculation"
RDB_RIEGL_REFLECTANCE_CALCULATION_TITLE       = "Reflectance Calculation Table"
RDB_RIEGL_REFLECTANCE_CALCULATION_DESCRIPTION = "Lookup table for reflectance calculation based on amplitude and range"
RDB_RIEGL_REFLECTANCE_CALCULATION_STATUS      = "optional"
RDB_RIEGL_REFLECTANCE_CALCULATION_SCHEMA = (
"{\"required\":[\"delta\",\"content\"],\"$schema\":\"http://json-schema.org/draf"
"t-04/schema#\",\"description\":\"Lookup table for reflectance calculation "
"based on amplitude and range\",\"title\":\"Reflectance Calculation Table\","
"\"type\":\"object\",\"properties\":{\"content\":{\"description\":\"Correction "
"value [dB] to be added to the amplitude\",\"minItems\":1,\"maxItems\":2000,"
"\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"delta\":{\"description\":\"Delt"
"a between table entries [m], first entry is at range = 0 "
"m\",\"type\":\"number\"}}}"
)
RDB_RIEGL_REFLECTANCE_CALCULATION_EXAMPLE = (
"{\"content\":[-33.01],\"delta\":0.150918}"
)

# Range-dependent and scan-angle-dependent correction of reflectance reading
RDB_RIEGL_REFLECTANCE_CORRECTION             = "riegl.reflectance_correction"
RDB_RIEGL_REFLECTANCE_CORRECTION_TITLE       = "Near-range reflectance correction"
RDB_RIEGL_REFLECTANCE_CORRECTION_DESCRIPTION = "Range-dependent and scan-angle-dependent correction of reflectance reading"
RDB_RIEGL_REFLECTANCE_CORRECTION_STATUS      = "optional"
RDB_RIEGL_REFLECTANCE_CORRECTION_SCHEMA = (
"{\"required\":[\"ranges_m\",\"line_angles_deg\",\"reflectance_correction_db\"]"
",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"description\":\"Ra"
"nge-dependent and scan-angle-dependent correction of reflectance "
"reading\",\"title\":\"Near-range reflectance correction\",\"type\":\"object\",\""
"properties\":{\"reflectance_correction_db\":{\"description\":\"Near range "
"reflectance correction in dB as a function of range over "
"angle\",\"type\":\"array\",\"items\":{\"description\":\"rows (each array "
"corresponds to a "
"range)\",\"type\":\"array\",\"items\":{\"description\":\"columns (each value "
"corresponds to an "
"angle)\",\"type\":\"number\"}}},\"ranges_m\":{\"description\":\"Range [m]\",\"type"
"\":\"array\",\"items\":{\"type\":\"number\"}},\"line_angles_deg\":{\"description\":"
"\"Angle [deg]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}}}}"
)
RDB_RIEGL_REFLECTANCE_CORRECTION_EXAMPLE = (
"{\"reflectance_correction_db\":[[0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05,0."
"01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0.4,0"
".3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05,0.01]],\"ra"
"nges_m\":[0.0,1.0,2.0,3.0],\"line_angles_deg\":[0.0,0.5,1.0,1.5,1.0,2.0,2"
".5,3.0,3.5,4.0]}"
)

# Scan pattern description
RDB_RIEGL_SCAN_PATTERN             = "riegl.scan_pattern"
RDB_RIEGL_SCAN_PATTERN_TITLE       = "Scan Pattern"
RDB_RIEGL_SCAN_PATTERN_DESCRIPTION = "Scan pattern description"
RDB_RIEGL_SCAN_PATTERN_STATUS      = "optional"
RDB_RIEGL_SCAN_PATTERN_SCHEMA = (
"{\"description\":\"Scan pattern "
"description\",\"properties\":{\"line\":{\"description\":\"Line Scan Pattern\",\""
"required\":[\"start\",\"stop\",\"increment\"],\"type\":\"object\",\"properties\":{\""
"program\":{\"$ref\":\"#/definitions/program\"},\"stop\":{\"description\":\"Stop "
"angle in SOCS [deg]\",\"minimum\":0.0,\"maximum\":720.0,\"type\":\"number\"},\"s"
"tart\":{\"description\":\"Start angle in SOCS [deg]\",\"minimum\":0.0,\"maximu"
"m\":360.0,\"type\":\"number\"},\"increment\":{\"description\":\"Increment of "
"angle in SOCS [deg]\",\"minimum\":0.0,\"maximum\":90.0,\"type\":\"number\"}}},\""
"segments\":{\"description\":\"Segmented Line Scan Pattern\",\"required\":[\"li"
"st\"],\"type\":\"object\",\"properties\":{\"program\":{\"$ref\":\"#/definitions/pr"
"ogram\"},\"list\":{\"type\":\"array\",\"items\":{\"description\":\"Line Scan Segme"
"nt\",\"required\":[\"start\",\"stop\",\"increment\"],\"type\":\"object\",\"propertie"
"s\":{\"stop\":{\"description\":\"Stop angle in SOCS [deg]\",\"minimum\":0.0,\"ma"
"ximum\":720.0,\"type\":\"number\"},\"start\":{\"description\":\"Start angle in "
"SOCS [deg]\",\"minimum\":0.0,\"maximum\":360.0,\"type\":\"number\"},\"increment\""
":{\"description\":\"Increment of angle in SOCS [deg]\",\"minimum\":0.0,\"maxi"
"mum\":90.0,\"type\":\"number\"}}}}}},\"rectangular\":{\"description\":\"Rectangu"
"lar Field Of View Scan Pattern\",\"required\":[\"phi_start\",\"phi_stop\",\"ph"
"i_increment\",\"theta_start\",\"theta_stop\",\"theta_increment\"],\"type\":\"obj"
"ect\",\"properties\":{\"program\":{\"$ref\":\"#/definitions/program\"},\"theta_s"
"top\":{\"description\":\"Stop theta angle in SOCS [deg]\",\"minimum\":0.0,\"ma"
"ximum\":180.0,\"type\":\"number\"},\"phi_stop\":{\"description\":\"Stop phi "
"angle in SOCS [deg]\",\"minimum\":0.0,\"maximum\":720.0,\"type\":\"number\"},\"t"
"heta_increment\":{\"description\":\"Increment of theta angle in SOCS [deg]"
"\",\"minimum\":0.0,\"maximum\":90.0,\"type\":\"number\"},\"phi_increment\":{\"desc"
"ription\":\"Increment of phi angle in SOCS [deg]\",\"minimum\":0.0,\"maximum"
"\":90.0,\"type\":\"number\"},\"phi_start\":{\"description\":\"Start phi angle in"
" SOCS [deg]\",\"minimum\":0.0,\"maximum\":360.0,\"type\":\"number\"},\"theta_sta"
"rt\":{\"description\":\"Start theta angle in SOCS "
"[deg]\",\"minimum\":0.0,\"maximum\":180.0,\"type\":\"number\"}}}},\"title\":\"Scan"
" Pattern\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"definit"
"ions\":{\"program\":{\"description\":\"Measurement program\",\"required\":[\"nam"
"e\"],\"type\":\"object\",\"properties\":{\"laser_prr\":{\"description\":\"Laser "
"Pulse Repetition Rate [Hz]\",\"minimum\":0,\"exclusiveMinimum\":false,\"type"
"\":\"number\"},\"name\":{\"description\":\"Name of measurement "
"program\",\"type\":\"string\"}}}}}"
)
RDB_RIEGL_SCAN_PATTERN_EXAMPLE = (
"{\"rectangular\":{\"program\":{\"laser_prr\":100000.0,\"name\":\"High Speed\"},\""
"theta_stop\":130.0,\"phi_stop\":270.0,\"theta_increment\":0.04,\"phi_increme"
"nt\":0.04,\"phi_start\":45.0,\"theta_start\":30.0}}"
)

# Details about laser shot files
RDB_RIEGL_SHOT_INFO             = "riegl.shot_info"
RDB_RIEGL_SHOT_INFO_TITLE       = "Shot Information"
RDB_RIEGL_SHOT_INFO_DESCRIPTION = "Details about laser shot files"
RDB_RIEGL_SHOT_INFO_STATUS      = "optional"
RDB_RIEGL_SHOT_INFO_SCHEMA = (
"{\"description\":\"Details about laser shot files\",\"title\":\"Shot Informat"
"ion\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"objec"
"t\",\"properties\":{\"shot_file\":{\"required\":[\"file_extension\"],\"type\":\"ob"
"ject\",\"properties\":{\"file_extension\":{\"description\":\"Shot file "
"extension, without the leading "
"dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's Universally "
"Unique Identifier (RFC 4122)\",\"type\":\"string\"}}}}}"
)
RDB_RIEGL_SHOT_INFO_EXAMPLE = (
"{\"shot_file\":{\"file_extension\":\"sodx\",\"file_uuid\":\"26a00815-67c0-4bff-"
"8fe8-c577378fe663\"}}"
)

# Point filters applied in addition to the application-defined filters
RDB_RIEGL_STORED_FILTERS             = "riegl.stored_filters"
RDB_RIEGL_STORED_FILTERS_TITLE       = "Stored filters"
RDB_RIEGL_STORED_FILTERS_DESCRIPTION = "Point filters applied in addition to the application-defined filters"
RDB_RIEGL_STORED_FILTERS_STATUS      = "optional"
RDB_RIEGL_STORED_FILTERS_SCHEMA = (
"{\"required\":[\"activated\",\"filters\"],\"$schema\":\"http://json-schema.org/"
"draft-04/schema#\",\"description\":\"Point filters applied in addition to "
"the application-defined filters\",\"title\":\"Stored filters\",\"type\":\"obje"
"ct\",\"properties\":{\"activated\":{\"description\":\"Apply ('true') or ignore"
" ('false') all "
"filters\",\"type\":\"boolean\"},\"filters\":{\"description\":\"List of point "
"filters\",\"type\":\"array\",\"items\":{\"description\":\"Point filter definitio"
"n\",\"required\":[\"activated\",\"title\",\"description\",\"filter\"],\"type\":\"obj"
"ect\",\"properties\":{\"description\":{\"description\":\"A brief description "
"of the filter (e.g. for display in a "
"tooltip)\",\"type\":\"string\"},\"title\":{\"description\":\"A short filter "
"title (e.g. for display in a selection "
"list)\",\"type\":\"string\"},\"activated\":{\"description\":\"Apply ('true') or "
"ignore ('false') this "
"filter\",\"type\":\"boolean\"},\"filter\":{\"description\":\"The RDB filter "
"string to apply (e.g. when reading points or index), details see "
"documentation of function select()\",\"type\":\"string\"}}}}}}"
)
RDB_RIEGL_STORED_FILTERS_EXAMPLE = (
"{\"activated\":true,\"filters\":[{\"description\":\"Ignore points with "
"uncertain MTA zone assignment\",\"title\":\"MTA Zone "
"Resolved/Unresolved\",\"activated\":true,\"filter\":\"riegl.mta_unresolved "
"== 0\"},{\"description\":\"Ignore points with invalid pulse shape deviatio"
"n\",\"title\":\"Deviation\",\"activated\":true,\"filter\":\"riegl.deviation != "
"-1\"}]}"
)

# Conversion of background radiation raw values to temperatures in °C
RDB_RIEGL_TEMPERATURE_CALCULATION             = "riegl.temperature_calculation"
RDB_RIEGL_TEMPERATURE_CALCULATION_TITLE       = "Temperature Calculation Table"
RDB_RIEGL_TEMPERATURE_CALCULATION_DESCRIPTION = "Conversion of background radiation raw values to temperatures in °C"
RDB_RIEGL_TEMPERATURE_CALCULATION_STATUS      = "optional"
RDB_RIEGL_TEMPERATURE_CALCULATION_SCHEMA = (
"{\"definitions\":{\"conversion_table\":{\"required\":[\"value\",\"temperature\"]"
",\"type\":\"object\",\"properties\":{\"value\":{\"description\":\"LSB [1]\",\"type\""
":\"array\",\"items\":{\"type\":\"number\"}},\"temperature\":{\"description\":\"Temp"
"erature [\\u00b0C]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}}}}},\"$sche"
"ma\":\"http://json-schema.org/draft-04/schema#\",\"description\":\"Conversio"
"n of background radiation raw values to temperatures in "
"\\u00b0C\",\"title\":\"Temperature Calculation Table\",\"type\":\"object\",\"prop"
"erties\":{\"InGaAs_Si_Difference\":{\"description\":\"Conversion table for "
"InGaAs - Si difference\",\"$ref\":\"#/definitions/conversion_table\"},\"InGa"
"As\":{\"description\":\"Conversion table for InGaAs channel\",\"$ref\":\"#/def"
"initions/conversion_table\"},\"Si\":{\"description\":\"Conversion table for "
"Si channel\",\"$ref\":\"#/definitions/conversion_table\"}}}"
)
RDB_RIEGL_TEMPERATURE_CALCULATION_EXAMPLE = (
"{\"InGaAs_Si_Difference\":{\"value\":[1000.0,1100.090029602954,1200.044251"
"83874,1300.1342814416948,1400.0885036774805,1500.0427259132668,1600.13"
"27555162209,1700.0869777520065,1800.0411999877924],\"temperature\":[1749"
".977111117893,1749.977111117893,1749.977111117893,1749.977111117893,17"
"49.977111117893,1749.977111117893,1744.7813348796044,1681.997131260109"
"2,1622.3944822534868]},\"InGaAs\":{\"value\":[0.0,64.00097659230323,128.00"
"19531846065,192.0029297769097,256.0039063692129,320.00488296151616,384"
".0058595538194,448.0068361461226,512.0078127384259],\"temperature\":[307"
".22196722535614,309.1153478247277,311.1188086915047,313.10025350480055"
",315.2137946389828,317.2172555057597,319.2207163725366,321.20216118583"
"25,323.3157023200148]},\"Si\":{\"value\":[0.0,64.00097659230323,128.001953"
"1846065,192.0029297769097,256.0039063692129,320.00488296151616,384.005"
"8595538194,448.0068361461226,512.0078127384259],\"temperature\":[546.300"
"048828125,548.8164051212026,551.3143938500972,554.0144257850053,556.60"
"4252334815,559.2124464488079,561.8022729986177,564.4104671126105,567.0"
"002936624203]}}"
)

# Base of timestamps (epoch)
RDB_RIEGL_TIME_BASE             = "riegl.time_base"
RDB_RIEGL_TIME_BASE_TITLE       = "Time Base"
RDB_RIEGL_TIME_BASE_DESCRIPTION = "Base of timestamps (epoch)"
RDB_RIEGL_TIME_BASE_STATUS      = "optional"
RDB_RIEGL_TIME_BASE_SCHEMA = (
"{\"required\":[\"epoch\",\"source\"],\"$schema\":\"http://json-schema.org/draft"
"-04/schema#\",\"description\":\"Base of timestamps (epoch)\",\"title\":\"Time "
"Base\",\"type\":\"object\",\"properties\":{\"epoch\":{\"description\":\"Date and "
"time of timestamp '0' as proposed by RFC 3339 (e.g. 2015-10-27T00:00:0"
"0+01:00).\",\"type\":\"string\"},\"source\":{\"description\":\"Timestamp source\""
",\"enum\":[\"unknown\",\"RTC\",\"GNSS\"],\"type\":\"string\"},\"system\":{\"descripti"
"on\":\"Time system (time "
"standard)\",\"enum\":[\"unknown\",\"UTC\",\"GPS\"],\"type\":\"string\"}}}"
)
RDB_RIEGL_TIME_BASE_EXAMPLE = (
"{\"epoch\":\"2015-10-27T00:00:00+00:00\",\"source\":\"GNSS\",\"system\":\"UTC\"}"
)

# Details about position+orientation files
RDB_RIEGL_TRAJECTORY_INFO             = "riegl.trajectory_info"
RDB_RIEGL_TRAJECTORY_INFO_TITLE       = "Trajectory Information"
RDB_RIEGL_TRAJECTORY_INFO_DESCRIPTION = "Details about position+orientation files"
RDB_RIEGL_TRAJECTORY_INFO_STATUS      = "optional"
RDB_RIEGL_TRAJECTORY_INFO_SCHEMA = (
"{\"required\":[\"time_interval\",\"navigation_frame\"],\"$schema\":\"http://jso"
"n-schema.org/draft-04/schema#\",\"description\":\"Details about "
"position+orientation files\",\"title\":\"Trajectory Information\",\"type\":\"o"
"bject\",\"properties\":{\"navigation_frame\":{\"description\":\"Navigation "
"frame (NED: North-East-Down, ENU: East-North-Up)\",\"enum\":[\"unknown\",\"N"
"ED\",\"ENU\"],\"type\":\"string\"},\"company\":{\"description\":\"Company "
"name\",\"type\":\"string\"},\"settings\":{\"description\":\"Settings used to "
"calculate the trajectory (descriptive "
"text)\",\"type\":\"string\"},\"location\":{\"description\":\"Project location, "
"e.g. city/state/country\",\"type\":\"string\"},\"time_interval\":{\"descriptio"
"n\":\"Time interval statistics\",\"required\":[\"minimum\",\"average\",\"maximum"
"\",\"std_dev\"],\"type\":\"object\",\"properties\":{\"minimum\":{\"description\":\"M"
"inimum time interval "
"[s]\",\"type\":\"number\"},\"maximum\":{\"description\":\"Maximum time interval "
"[s]\",\"type\":\"number\"},\"average\":{\"description\":\"Average time interval "
"[s]\",\"type\":\"number\"},\"std_dev\":{\"description\":\"Standard deviation of "
"intervals "
"[s]\",\"type\":\"number\"}}},\"field_of_application\":{\"description\":\"Field "
"of application\",\"enum\":[\"unknown\",\"SLS\",\"TLS\",\"KLS\",\"MLS\",\"ULS\",\"ALS\","
"\"BLS\",\"ILS\"],\"type\":\"string\"},\"device\":{\"description\":\"Navigation "
"device, e.g. "
"name/type/serial\",\"type\":\"string\"},\"software\":{\"description\":\"Software"
" that calculated the trajectory (this may be the same or different "
"software than the one that created the "
"file)\",\"type\":\"string\"},\"project\":{\"description\":\"Project "
"name\",\"type\":\"string\"}}}"
)
RDB_RIEGL_TRAJECTORY_INFO_EXAMPLE = (
"{\"navigation_frame\":\"NED\",\"company\":\"RIEGL LMS\",\"settings\":\"default\",\""
"location\":\"Horn\",\"time_interval\":{\"minimum\":0.00500032,\"maximum\":0.005"
"004883,\"average\":0.00500053,\"std_dev\":5.51e-07},\"field_of_application\""
":\"MLS\",\"device\":\"IMU Model 12/1, Serial# 12345\",\"software\":\"Navigation"
" Software XYZ\",\"project\":\"Campaign 3\"}"
)

# Details about vertex file
RDB_RIEGL_VERTEX_INFO             = "riegl.vertex_info"
RDB_RIEGL_VERTEX_INFO_TITLE       = "Vertex Information"
RDB_RIEGL_VERTEX_INFO_DESCRIPTION = "Details about vertex file"
RDB_RIEGL_VERTEX_INFO_STATUS      = "optional"
RDB_RIEGL_VERTEX_INFO_SCHEMA = (
"{\"description\":\"Details about vertex file\",\"title\":\"Vertex Information"
"\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\","
"\"properties\":{\"vertex_file\":{\"required\":[\"file_extension\"],\"type\":\"obj"
"ect\",\"properties\":{\"file_extension\":{\"description\":\"Vertex file "
"extension, without the leading "
"dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's Universally "
"Unique Identifier (RFC 4122)\",\"type\":\"string\"}}}}}"
)
RDB_RIEGL_VERTEX_INFO_EXAMPLE = (
"{\"vertex_file\":{\"file_extension\":\"vtx\",\"file_uuid\":\"51534d95-d71f-4f36"
"-ae1a-3e63a21fd1c7\"}}"
)

# Details about the voxels contained in the file
RDB_RIEGL_VOXEL_INFO             = "riegl.voxel_info"
RDB_RIEGL_VOXEL_INFO_TITLE       = "Voxel Information"
RDB_RIEGL_VOXEL_INFO_DESCRIPTION = "Details about the voxels contained in the file"
RDB_RIEGL_VOXEL_INFO_STATUS      = "optional"
RDB_RIEGL_VOXEL_INFO_SCHEMA = (
"{\"definitions\":{\"voxel_origin_enum\":{\"description\":\"Defines whether "
"the voxel's center or a corner is placed on CRS origin <tt>(0/0/0)</tt"
">.\",\"enum\":[\"center\",\"corner\"],\"default\":\"corner\"},\"shape_thresholds\":"
"{\"description\":\"Thresholds used to compute the voxel's shape_id value."
"\",\"required\":[\"plane\",\"line\"],\"type\":\"object\",\"properties\":{\"line\":{\"d"
"escription\":\"If the biggest eigenvalue is bigger than the median "
"eigenvalue * line_threshold, the voxel is considered a line.\",\"minimum"
"\":1,\"exclusiveMinimum\":true,\"type\":\"number\"},\"plane\":{\"exclusiveMaximu"
"m\":true,\"exclusiveMinimum\":true,\"maximum\":1,\"description\":\"If the "
"smallest eigenvalue is smaller than the median eigenvalue * "
"plane_threshold, the voxel is considered a plane.\",\"minimum\":0,\"type\":"
"\"number\"}}},\"voxel_size\":{\"description\":\"Size of voxels.\",\"minItems\":3"
",\"maxItems\":3,\"type\":\"array\",\"items\":{\"$ref\":\"#/definitions/edge_lengt"
"h\"}},\"edge_length\":{\"description\":\"Length of voxel edge [m].\",\"minimum"
"\":0,\"exclusiveMinimum\":true,\"type\":\"number\"},\"voxel_type\":{\"descriptio"
"n\":\"Whether a point in a voxel represents its center or its centroid. "
"If type is <tt>index</tt> there is no point but only an integer voxel "
"index.\",\"enum\":[\"center\",\"centroid\",\"index\"],\"default\":\"centroid\"},\"vo"
"xel_origin_point\":{\"description\":\"Origin point for all voxel indices "
"in voxel CRS.\",\"minItems\":3,\"maxItems\":3,\"type\":\"array\",\"items\":{\"type"
"\":\"number\"}},\"voxel_size_cubic\":{\"$ref\":\"#/definitions/edge_length\",\"t"
"ype\":\"number\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"o"
"neOf\":[{\"additionalProperties\":false,\"required\":[\"size\",\"voxel_origin\""
",\"voxel_type\"],\"properties\":{\"voxel_type\":{\"$ref\":\"#/definitions/voxel"
"_type\"},\"voxel_origin\":{\"$ref\":\"#/definitions/voxel_origin_enum\"},\"sha"
"pe_thresholds\":{\"$ref\":\"#/definitions/shape_thresholds\"},\"size\":{\"desc"
"ription\":\"Size of voxels in file coordinate system.\",\"oneOf\":[{\"$ref\":"
"\"#/definitions/voxel_size\"},{\"$ref\":\"#/definitions/voxel_size_cubic\"}]"
"}}},{\"additionalProperties\":false,\"required\":[\"reference_point\",\"size_"
"llcs\",\"size\",\"voxel_origin\",\"voxel_type\"],\"properties\":{\"voxel_origin\""
":{\"oneOf\":[{\"$ref\":\"#/definitions/voxel_origin_enum\"},{\"description\":\""
"The base point of the voxel grid. Used together with "
"<tt>voxel_size</tt> and <tt>voxel_index</tt> to compute actual point c"
"oordinates.\",\"$ref\":\"#/definitions/voxel_origin_point\"}]},\"shape_thres"
"holds\":{\"$ref\":\"#/definitions/shape_thresholds\"},\"size\":{\"description\""
":\"Size of voxels in file coordinate system.\",\"$ref\":\"#/definitions/vox"
"el_size\"},\"voxel_type\":{\"$ref\":\"#/definitions/voxel_type\"},\"reference_"
"point\":{\"description\":\"Point in WGS84 geodetic decimal degree "
"(EPSG:4326) that was used to compute the projection distortion "
"parameters. The coefficient order is latitude, longitude. Only voxels "
"with corresponding geo_tag, voxel_size and reference_point can be "
"reliably processed together. This entry is available for voxel files "
"in projected CRS only.\",\"minItems\":2,\"maxItems\":2,\"type\":\"array\",\"item"
"s\":{\"minimum\":-180,\"maximum\":180,\"type\":\"number\"}},\"size_llcs\":{\"descr"
"iption\":\"Size of voxels in a locally levelled cartesian coordinate "
"system (xyz). This is only used for voxels based on a map projection.\""
",\"$ref\":\"#/definitions/voxel_size\"}}}],\"description\":\"Details about "
"the voxels contained in the file\",\"title\":\"Voxel "
"Information\",\"type\":\"object\"}"
)
RDB_RIEGL_VOXEL_INFO_EXAMPLE = (
"{\"voxel_origin\":\"corner\",\"shape_thresholds\":{\"line\":6,\"plane\":0.16},\"s"
"ize\":[0.5971642834779395,0.5971642834779395,0.5143705304787237],\"voxel"
"_type\":\"centroid\",\"reference_point\":[48,16],\"size_llcs\":[0.51565752528"
"91171,0.5130835356683303,0.5143705304787237]}"
)

# Settings for waveform averaging
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS             = "riegl.waveform_averaging_settings"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_TITLE       = "Waveform Averaging Settings"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_DESCRIPTION = "Settings for waveform averaging"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_SCHEMA = (
"{\"required\":[\"num_shots\",\"mta_zone\"],\"$schema\":\"http://json-schema.org"
"/draft-04/schema#\",\"description\":\"Settings for waveform "
"averaging\",\"title\":\"Waveform Averaging Settings\",\"type\":\"object\",\"prop"
"erties\":{\"num_shots\":{\"description\":\"Number of consecutive shots to be"
" used for averaging.\",\"minimum\":1,\"type\":\"integer\"},\"mta_zone\":{\"descr"
"iption\":\"Fixed MTA zone for averaging.\",\"minimum\":1,\"type\":\"integer\"},"
"\"trim\":{\"description\":\"Percentage for robust "
"averaging.\",\"minimum\":0,\"default\":0,\"maximum\":0.5,\"type\":\"number\"}}}"
)
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_EXAMPLE = (
"{\"num_shots\":7,\"mta_zone\":1,\"trim\":0.05}"
)

# Details about waveform files
RDB_RIEGL_WAVEFORM_INFO             = "riegl.waveform_info"
RDB_RIEGL_WAVEFORM_INFO_TITLE       = "Waveform Information"
RDB_RIEGL_WAVEFORM_INFO_DESCRIPTION = "Details about waveform files"
RDB_RIEGL_WAVEFORM_INFO_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_INFO_SCHEMA = (
"{\"required\":[\"sample_block_file\",\"sample_data_files\"],\"$schema\":\"http:"
"//json-schema.org/draft-04/schema#\",\"description\":\"Details about "
"waveform files\",\"title\":\"Waveform Information\",\"type\":\"object\",\"proper"
"ties\":{\"sample_block_file\":{\"required\":[\"file_extension\"],\"type\":\"obje"
"ct\",\"properties\":{\"file_extension\":{\"description\":\"Sample block file "
"extension, without the leading "
"dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's Universally "
"Unique Identifier (RFC 4122)\",\"type\":\"string\"}}},\"sample_data_files\":{"
"\"type\":\"array\",\"items\":{\"required\":[\"channel\",\"channel_name\",\"sample_i"
"nterval\",\"sample_bits\",\"laser_wavelength\",\"delta_st\",\"file_extension\"]"
",\"type\":\"object\",\"properties\":{\"file_extension\":{\"description\":\"Sample"
" data file extension, without the leading "
"dot\",\"type\":\"string\"},\"sample_interval\":{\"description\":\"Sampling "
"interval in seconds\",\"minimum\":0,\"exclusiveMinimum\":false,\"type\":\"numb"
"er\"},\"laser_wavelength\":{\"description\":\"Laser wavelength in meters (0 "
"= unknown)\",\"minimum\":0,\"exclusiveMinimum\":false,\"type\":\"number\"},\"cha"
"nnel_name\":{\"description\":\"Sample block channel name\",\"type\":\"string\"}"
",\"sample_bits\":{\"exclusiveMaximum\":false,\"exclusiveMinimum\":false,\"max"
"imum\":32,\"description\":\"Bitwidth of samples (e.g. 10 bit, 12 bit)\",\"mi"
"nimum\":0,\"type\":\"integer\"},\"delta_st\":{\"description\":\"reserved\",\"type\""
":\"number\"},\"channel\":{\"exclusiveMaximum\":false,\"exclusiveMinimum\":fals"
"e,\"maximum\":255,\"description\":\"Sample block channel number (255 = inva"
"lid)\",\"minimum\":0,\"type\":\"integer\"},\"file_uuid\":{\"description\":\"File's"
" Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"}}}},\"range_offset_m\":{\"description\":\"Calibrated"
" device specific range offset for waveform analysis by system response"
" fitting in meters.\",\"type\":\"number\"},\"range_offset_waveform_samples_m"
"\":{\"description\":\"Calibrated device specific range offset for waveform"
" samples in meters.\",\"type\":\"number\"}}}"
)
RDB_RIEGL_WAVEFORM_INFO_EXAMPLE = (
"{\"range_offset_waveform_samples_m \":7.283,\"sample_block_file\":{\"file_e"
"xtension\":\"sbx\",\"file_uuid\":\"93a03615-66c0-4bea-8ff8-c577378fe660\"},\"s"
"ample_data_files\":[{\"laser_wavelength\":0,\"file_extension\":\"sp0\",\"sampl"
"e_interval\":1.00503e-09,\"channel_name\":\"high_power\",\"sample_bits\":12,\""
"delta_st\":0,\"channel\":0,\"file_uuid\":\"da084413-e3e8-4655-a122-071de8490"
"d8e\"},{\"laser_wavelength\":0,\"file_extension\":\"sp1\",\"sample_interval\":1"
".00503e-09,\"channel_name\":\"low_power\",\"sample_bits\":12,\"delta_st\":0,\"c"
"hannel\":1,\"file_uuid\":\"93585b5e-5ea9-43a1-947b-e7ba3be642d2\"},{\"laser_"
"wavelength\":0,\"file_extension\":\"sp5\",\"sample_interval\":1.00503e-09,\"ch"
"annel_name\":\"wwf\",\"sample_bits\":12,\"delta_st\":0,\"channel\":5,\"file_uuid"
"\":\"9d2298c4-1036-464f-b5cb-1cf8e517f3a0\"}],\"range_offset_m\":3.1415}"
)

# Scanner settings for waveform output
RDB_RIEGL_WAVEFORM_SETTINGS             = "riegl.waveform_settings"
RDB_RIEGL_WAVEFORM_SETTINGS_TITLE       = "Waveform Settings"
RDB_RIEGL_WAVEFORM_SETTINGS_DESCRIPTION = "Scanner settings for waveform output"
RDB_RIEGL_WAVEFORM_SETTINGS_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_SETTINGS_SCHEMA = (
"{\"description\":\"Scanner settings for waveform "
"output\",\"title\":\"Waveform Settings\",\"$schema\":\"http://json-schema.org/"
"draft-04/schema#\",\"type\":\"array\",\"items\":{\"required\":[\"sbl_name\",\"enab"
"led\",\"channel_idx_mask\"],\"type\":\"object\",\"properties\":{\"pass_rng_great"
"er\":{\"description\":\"Threshold for range greater than "
"[m]\",\"type\":\"number\"},\"sbl_name\":{\"description\":\"Name of sample block,"
" e.g.: wfm, "
"wwf\",\"type\":\"string\"},\"pass_ampl_greater\":{\"description\":\"Threshold "
"for amplitude greater than "
"[dB]\",\"type\":\"number\"},\"enabled\":{\"description\":\"Waveform output "
"enabled\",\"type\":\"boolean\"},\"smart_enabled\":{\"description\":\"Smart "
"waveform output "
"enabled\",\"type\":\"boolean\"},\"pass_ampl_less\":{\"description\":\"Threshold "
"for amplitude less than "
"[dB]\",\"type\":\"number\"},\"channel_idx_mask\":{\"description\":\"Bit mask for"
" channels which belong to sbl_name: Channel 0 = Bit0, Channel 1 = "
"Bit1, ...\",\"type\":\"integer\"},\"pass_rng_less\":{\"description\":\"Threshold"
" for range less than "
"[m]\",\"type\":\"number\"},\"pass_dev_less\":{\"description\":\"Threshold for "
"deviation less than "
"[1]\",\"type\":\"integer\"},\"pass_dev_greater\":{\"description\":\"Threshold "
"for deviation greater than "
"[1]\",\"type\":\"integer\"},\"logic_expression\":{\"description\":\"Logic "
"expression of smart waveforms filter\",\"type\":\"string\"}}}}"
)
RDB_RIEGL_WAVEFORM_SETTINGS_EXAMPLE = (
"[{\"pass_rng_greater\":9.27,\"sbl_name\":\"wfm\",\"pass_ampl_greater\":1.0,\"en"
"abled\":true,\"smart_enabled\":true,\"pass_ampl_less\":5.0,\"pass_rng_less\":"
"13.11,\"channel_idx_mask\":11},{\"sbl_name\":\"wwf\",\"channel_idx_mask\":32,\""
"enabled\":false}]"
)

# Window analysis data estimated from scandata and resulting filter parameters
RDB_RIEGL_WINDOW_ANALYSIS             = "riegl.window_analysis"
RDB_RIEGL_WINDOW_ANALYSIS_TITLE       = "Window Analysis"
RDB_RIEGL_WINDOW_ANALYSIS_DESCRIPTION = "Window analysis data estimated from scandata and resulting filter parameters"
RDB_RIEGL_WINDOW_ANALYSIS_STATUS      = "optional"
RDB_RIEGL_WINDOW_ANALYSIS_SCHEMA = (
"{\"required\":[\"result\",\"filter\",\"settings\"],\"$schema\":\"http://json-sche"
"ma.org/draft-04/schema#\",\"description\":\"Window analysis data estimated"
" from scandata and resulting filter parameters\",\"title\":\"Window Analys"
"is\",\"type\":\"object\",\"properties\":{\"result\":{\"required\":[\"angle\",\"range"
"_mean\",\"range_sigma\",\"amplitude_mean\",\"amplitude_sigma\",\"amplitude_off"
"set\"],\"type\":\"object\",\"properties\":{\"range_sigma\":{\"description\":\"[m]\""
",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"angle\":{\"description\":\"[de"
"g]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"range_mean\":{\"descripti"
"on\":\"[m]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplitude_offset\""
":{\"description\":\"[dB]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"ampl"
"itude_sigma\":{\"description\":\"[dB]\",\"type\":\"array\",\"items\":{\"type\":\"num"
"ber\"}},\"timestamp\":{\"description\":\"[s]\",\"type\":\"array\",\"items\":{\"type\""
":\"number\"}},\"amplitude_mean\":{\"description\":\"[dB]\",\"type\":\"array\",\"ite"
"ms\":{\"type\":\"number\"}}}},\"filter\":{\"required\":[\"angle\",\"range_min\",\"ra"
"nge_max\",\"amplitude_max\"],\"type\":\"object\",\"properties\":{\"range_min\":{\""
"description\":\"[m]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"angle\":{"
"\"description\":\"[deg]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"range"
"_max\":{\"description\":\"[m]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\""
"amplitude_max\":{\"description\":\"[dB]\",\"type\":\"array\",\"items\":{\"type\":\"n"
"umber\"}}}},\"settings\":{\"required\":[\"range\",\"amplitude\"],\"type\":\"object"
"\",\"properties\":{\"range\":{\"required\":[\"sigma_factor\",\"additive_value\"],"
"\"type\":\"object\",\"properties\":{\"additive_value\":{\"type\":\"number\"},\"sigm"
"a_factor\":{\"type\":\"number\"}}},\"amplitude\":{\"required\":[\"sigma_factor\","
"\"additive_value\"],\"type\":\"object\",\"properties\":{\"additive_value\":{\"typ"
"e\":\"number\"},\"sigma_factor\":{\"type\":\"number\"}}}}}}}"
)
RDB_RIEGL_WINDOW_ANALYSIS_EXAMPLE = (
"{\"result\":{\"range_sigma\":[0.01869652,0.02151435,0.01747969,0.01918765,"
"0.01945776,0.01934862,0.01955329,0.02225589,0.02229977,0.01899122,0.02"
"009433],\"angle\":[14.9,15.0,15.1,15.2,15.3,15.4,15.5,15.6,15.7,15.8,15."
"9],\"range_mean\":[0.1105621,0.1079564,0.1087088,0.1067261,0.1054582,0.1"
"090412,0.102871,0.1019044,0.1051523,0.1058445,0.1031261],\"amplitude_of"
"fset\":[1.9,1.9],\"amplitude_sigma\":[0.4272844,0.4298479,0.4236816,0.428"
"3583,0.4362353,0.4315141,0.4373984,0.4472798,0.4346001,0.4345487,0.454"
"0681],\"timestamp\":[408.4441,411.4443],\"amplitude_mean\":[5.347396,5.263"
"155,5.224655,5.179926,5.097782,5.116479,5.051756,4.983473,5.007885,5.0"
"02441,4.982]},\"filter\":{\"range_min\":[-0.208,-0.21,-0.212,-0.214,-0.216"
",-0.218,-0.219,-0.221,-0.223,-0.225,-0.227],\"angle\":[14.9,15.0,15.1,15"
".2,15.3,15.4,15.5,15.6,15.7,15.8,15.9],\"range_max\":[0.424,0.425,0.426,"
"0.427,0.428,0.428,0.429,0.43,0.431,0.431,0.432],\"amplitude_max\":[8.04,"
"8.01,7.99,7.96,7.93,7.9,7.88,7.85,7.83,7.8,7.78]},\"settings\":{\"range\":"
"{\"additive_value\":0.1,\"sigma_factor\":8},\"amplitude\":{\"additive_value\":"
"1.0,\"sigma_factor\":4}}}"
)

# Correction parameters for window glass echoes
RDB_RIEGL_WINDOW_ECHO_CORRECTION             = "riegl.window_echo_correction"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_TITLE       = "Window Echo Correction"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_DESCRIPTION = "Correction parameters for window glass echoes"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_STATUS      = "optional"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_SCHEMA = (
"{\"required\":[\"amplitude\",\"range\",\"slices\"],\"$schema\":\"http://json-sche"
"ma.org/draft-04/schema#\",\"description\":\"Correction parameters for "
"window glass echoes\",\"title\":\"Window Echo Correction\",\"type\":\"object\","
"\"properties\":{\"range\":{\"description\":\"Range axis of correction table\","
"\"required\":[\"minimum\",\"maximum\",\"entries\"],\"type\":\"object\",\"properties"
"\":{\"entries\":{\"description\":\"Number of range entries\",\"minimum\":1,\"typ"
"e\":\"integer\"},\"minimum\":{\"description\":\"Minimum range in m\",\"minimum\":"
"-2.0,\"maximum\":2.0,\"type\":\"number\"},\"maximum\":{\"description\":\"Maximum "
"range in m\",\"minimum\":-2.0,\"maximum\":2.0,\"type\":\"number\"}}},\"slices\":{"
"\"type\":\"array\",\"items\":{\"description\":\"Window echo correction "
"parameter slice\",\"required\":[\"amplitude\",\"table\"],\"type\":\"object\",\"pro"
"perties\":{\"amplitude\":{\"description\":\"Window echo amplitude of slice "
"in dB\",\"type\":\"number\"},\"table\":{\"description\":\"Correction table "
"(dimension defined by the 'amplitude' and 'range' "
"objects)\",\"minItems\":1,\"type\":\"array\",\"items\":{\"description\":\"Table "
"row (= amplitude "
"axis)\",\"minItems\":1,\"type\":\"array\",\"items\":{\"description\":\"Table "
"column (= range axis)\",\"minItems\":3,\"maxItems\":3,\"type\":\"array\",\"items"
"\":{\"description\":\"Table cell (item 0: amplitude in dB, 1: range in m, "
"2: "
"flags)\",\"type\":\"number\"}}}}}}},\"amplitude\":{\"description\":\"Amplitude "
"axis of correction table\",\"required\":[\"minimum\",\"maximum\",\"entries\"],\""
"type\":\"object\",\"properties\":{\"entries\":{\"description\":\"Number of "
"amplitude entries\",\"minimum\":1,\"type\":\"integer\"},\"minimum\":{\"descripti"
"on\":\"Minimum amplitude in "
"dB\",\"minimum\":0.0,\"type\":\"number\"},\"maximum\":{\"description\":\"Maximum "
"amplitude in dB\",\"minimum\":0.0,\"type\":\"number\"}}}}}"
)
RDB_RIEGL_WINDOW_ECHO_CORRECTION_EXAMPLE = (
"{\"range\":{\"entries\":128,\"minimum\":-1.5060822940732335,\"maximum\":1.5060"
"822940732335},\"slices\":[{\"amplitude\":1.5,\"table\":[[[6.23,0.3535,1]],[["
"5.54,0.72375,1]]]},{\"amplitude\":2.0,\"table\":[[[6.23,0.3535,1]],[[5.54,"
"0.72375,1]]]}],\"amplitude\":{\"entries\":128,\"minimum\":2,\"maximum\":20}}"
)
