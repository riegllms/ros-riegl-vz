#
#*******************************************************************************
#
#  Copyright 2022 RIEGL Laser Measurement Systems
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
#  SPDX-License-Identifier: Apache-2.0
#
#*******************************************************************************
#
"""
*******************************************************************************
*
* \author RIEGL LMS GmbH, Austria
* \brief  Description of RIEGL RDB 2 database file contents
*
*  NOTE: All information in this file is preliminary, since the
*        definition of the database schemas is not yet complete.
*
*******************************************************************************
"""

# File schema version
RDB_SCHEMA_VERSION = "ab4e0cc0"
RDB_SCHEMA_DATE = "2021-05-03"

# Schema for ".avg.fwa" files
RDB_SCHEMA_RIEGL_AVG_FWA = (
"{\"identifier\":\"avg.fwa\",\"attributes\":[\"riegl.id*\",\"riegl.amplitude\",\"r"
"iegl.gain\",\"riegl.raw_range\",\"riegl.wfm_echo_time_offset\",\"riegl.wfm_s"
"bl_id\",\"riegl.deviation?\",\"riegl.pulse_width?\"],\"metadata\":[],\"extensi"
"on\":\"avg.fwa\"}"
)

# Schema for ".avg.sbx" files
RDB_SCHEMA_RIEGL_AVG_SBX = (
"{\"identifier\":\"avg.sbx\",\"attributes\":[\"riegl.id*\",\"riegl.wfm_sbl_chann"
"el\",\"riegl.wfm_sbl_mean\",\"riegl.wfm_sbl_std_dev\",\"riegl.wfm_sbl_time_o"
"ffset\",\"riegl.wfm_sda_first\",\"riegl.wfm_sda_count\"],\"metadata\":[],\"ext"
"ension\":\"avg.sbx\"}"
)

# Schema for ".avg.sidx" files
RDB_SCHEMA_RIEGL_AVG_SIDX = (
"{\"identifier\":\"avg.sidx\",\"attributes\":[\"riegl.id\",\"riegl.shot_timestam"
"p_hr*\",\"riegl.wfm_sbl_first\",\"riegl.wfm_sbl_count\",\"riegl.echo_first?\""
",\"riegl.echo_count?\"],\"metadata\":[\"riegl.shot_info\",\"riegl.waveform_in"
"fo\",\"riegl.echo_info?\",\"riegl.waveform_averaging_settings\"],\"extension"
"\":\"avg.sidx\"}"
)

# Schema for ".avg.sp{C}" files
RDB_SCHEMA_RIEGL_AVG_SPC = (
"{\"identifier\":\"avg.sp{C}\",\"attributes\":[\"riegl.id*\",\"riegl.wfm_sample_"
"value\"],\"metadata\":[],\"extension\":\"avg.sp{C}\"}"
)

# Schema for ".cpx" files
RDB_SCHEMA_RIEGL_CPX = (
"{\"identifier\":\"cpx\",\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_a"
"ccuracies\",\"riegl.control_object_type\",\"riegl.zenith_vector\",\"riegl.us"
"ed_for_adjustment\",\"riegl.acquisition_date?\",\"riegl.cp_surface_inclina"
"tion_angle\",\"riegl.cp_surface_inclination_tolerance_angle\",\"riegl.impo"
"rt_line_number\"],\"metadata\":[\"riegl.geo_tag\",\"riegl.control_object_cat"
"alog\",\"riegl.record_names\",\"riegl.imported_files\"],\"extension\":\"cpx\"}"
)

# Schema for ".fwa" files
RDB_SCHEMA_RIEGL_FWA = (
"{\"identifier\":\"fwa\",\"attributes\":[\"riegl.id*\",\"riegl.amplitude\",\"riegl"
".gain\",\"riegl.raw_range\",\"riegl.wfm_echo_time_offset\",\"riegl.wfm_sbl_i"
"d\",\"riegl.deviation?\",\"riegl.pulse_width?\"],\"metadata\":[],\"extension\":"
"\"fwa\"}"
)

# Schema for ".mpx" files
RDB_SCHEMA_RIEGL_MPX = (
"{\"identifier\":\"mpx\",\"attributes\":[\"riegl.id\",\"riegl.xy_map*\",\"riegl.am"
"plitude\",\"riegl.reflectance\",\"riegl.deviation\",\"riegl.timestamp_min?\","
"\"riegl.timestamp_max?\",\"riegl.point_count\",\"riegl.point_count_grid_cel"
"l\",\"riegl.pixel_linear_sums?\",\"riegl.pixel_square_sums?\",\"riegl.height"
"_min\",\"riegl.height_max\",\"riegl.height_mean\",\"riegl.height_center\",\"ri"
"egl.surface_normal\",\"riegl.pca_thickness\",\"riegl.std_dev\",\"riegl.voxel"
"_count\"],\"metadata\":[\"riegl.geo_tag\",\"riegl.pixel_info\",\"riegl.time_ba"
"se?\"],\"extension\":\"mpx\"}"
)

# Schema for ".mtch" files
RDB_SCHEMA_RIEGL_MTCH = (
"{\"identifier\":\"mtch\",\"attributes\":[\"riegl.xyz*\",\"riegl.plane_reference"
"s\",\"riegl.plane_patch_distance\",\"riegl.plane_patch_lateral_distance\",\""
"riegl.plane_patch_link_vector\",\"riegl.id\"],\"metadata\":[\"riegl.plane_pa"
"tch_matching\"],\"extension\":\"mtch\"}"
)

# Schema for ".mvx" files
RDB_SCHEMA_RIEGL_MVX = (
"{\"identifier\":\"mvx\",\"attributes\":[\"riegl.id\",\"riegl.xyz_map*\",\"riegl.a"
"mplitude\",\"riegl.reflectance\",\"riegl.deviation\",\"riegl.timestamp_min?\""
",\"riegl.timestamp_max?\",\"riegl.point_count\",\"riegl.shape_id\",\"riegl.co"
"variances?\",\"riegl.pca_axis_min\",\"riegl.pca_axis_max\",\"riegl.pca_exten"
"ts\",\"riegl.std_dev\",\"riegl.voxel_collapsed\"],\"metadata\":[\"riegl.geo_ta"
"g\",\"riegl.time_base?\",\"riegl.voxel_info\"],\"extension\":\"mvx\"}"
)

# Schema for ".obsx" files
RDB_SCHEMA_RIEGL_OBSX = (
"{\"identifier\":\"obsx\",\"attributes\":[\"riegl.xyz\",\"riegl.surface_normal\","
"\"riegl.plane_slope_class?\",\"riegl.id*\",\"riegl.sda1_plane_patch_one\",\"r"
"iegl.sda1_plane_patch_two\",\"riegl.sda1_source_file_one\",\"riegl.sda1_so"
"urce_file_two\"],\"metadata\":[\"riegl.geo_tag\",\"riegl.plane_slope_class_i"
"nfo?\",\"riegl.pointcloud_info\",\"riegl.sda1_source_files\"],\"extension\":\""
"obsx\"}"
)

# Schema for ".opefx" files
RDB_SCHEMA_RIEGL_OPEFX = (
"{\"identifier\":\"opefx\",\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz"
"_accuracies?\",\"riegl.surface_normal\",\"riegl.plane_up\",\"riegl.point_cou"
"nt\",\"riegl.std_dev\",\"riegl.plane_width\",\"riegl.plane_height\",\"riegl.pl"
"ane_confidence_normal\",\"riegl.model_fit_quality?\",\"riegl.used_for_adju"
"stment\",\"riegl.xyz_socs\",\"riegl.timestamp\",\"riegl.mirror_facet\",\"riegl"
".platform_rpy_ROCS_NED\",\"riegl.platform_drpy_ROCS_NED\",\"riegl.platform"
"_xyz_ROCS_ENU\",\"riegl.platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_vector\""
",\"riegl.raw_range\",\"riegl.raw_frame_angle\",\"riegl.raw_line_angle\",\"rie"
"gl.reference_object_id\"],\"metadata\":[\"riegl.device\",\"riegl.device_geom"
"etry\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"riegl.scan_pa"
"ttern?\",\"riegl.time_base\",\"riegl.record_names\",\"riegl.control_object_r"
"eference_file\"],\"extension\":\"opefx\"}"
)

# Schema for ".opp" files
RDB_SCHEMA_RIEGL_OPP = (
"{\"identifier\":\"opp\",\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_a"
"ccuracies?\",\"riegl.surface_normal\",\"riegl.plane_up\",\"riegl.point_count"
"\",\"riegl.std_dev\",\"riegl.plane_width\",\"riegl.plane_height\",\"riegl.plan"
"e_confidence_normal\",\"riegl.model_fit_quality?\",\"riegl.used_for_adjust"
"ment\",\"riegl.xyz_socs\",\"riegl.timestamp\",\"riegl.mirror_facet\",\"riegl.p"
"latform_rpy_ROCS_NED\",\"riegl.platform_drpy_ROCS_NED\",\"riegl.platform_x"
"yz_ROCS_ENU\",\"riegl.platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_vector\",\""
"riegl.raw_range\",\"riegl.raw_frame_angle\",\"riegl.raw_line_angle\",\"riegl"
".reference_object_id\"],\"metadata\":[\"riegl.device\",\"riegl.device_geomet"
"ry\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"riegl.scan_patt"
"ern?\",\"riegl.time_base\",\"riegl.record_names\",\"riegl.control_object_ref"
"erence_file\"],\"extension\":\"opp\"}"
)

# Schema for ".opx" files
RDB_SCHEMA_RIEGL_OPX = (
"{\"identifier\":\"opx\",\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.contr"
"ol_object_type\",\"riegl.model_cs_axis_x?\",\"riegl.model_cs_axis_y?\",\"rie"
"gl.model_cs_axis_z?\",\"riegl.model_fit_quality?\",\"riegl.obs_confidence_"
"xy?\",\"riegl.obs_confidence_z?\",\"riegl.obs_signal_confidence_rot?\",\"rie"
"gl.used_for_adjustment\",\"riegl.xyz_socs\",\"riegl.timestamp\",\"riegl.mirr"
"or_facet\",\"riegl.platform_rpy_ROCS_NED\",\"riegl.platform_drpy_ROCS_NED\""
",\"riegl.platform_xyz_ROCS_ENU\",\"riegl.platform_dxyz_ROCS_ENU\",\"riegl.s"
"da.shift_vector\",\"riegl.raw_range\",\"riegl.raw_frame_angle\",\"riegl.raw_"
"line_angle\",\"riegl.reference_object_id\"],\"metadata\":[\"riegl.device\",\"r"
"iegl.device_geometry\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters"
"\",\"riegl.scan_pattern?\",\"riegl.time_base\",\"riegl.control_object_catalo"
"g\",\"riegl.record_names\",\"riegl.control_object_reference_file\"],\"extens"
"ion\":\"opx\"}"
)

# Schema for ".owp" files
RDB_SCHEMA_RIEGL_OWP = (
"{\"identifier\":\"owp\",\"attributes\":[\"riegl.id*\",\"riegl.raw_range\",\"riegl"
".amplitude\",\"riegl.deviation\",\"riegl.gain\"],\"metadata\":[],\"extension\":"
"\"owp\"}"
)

# Schema for ".pefx" files
RDB_SCHEMA_RIEGL_PEFX = (
"{\"identifier\":\"pefx\",\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_"
"accuracies?\",\"riegl.surface_normal\",\"riegl.plane_up\",\"riegl.std_dev\",\""
"riegl.plane_confidence_normal\",\"riegl.plane_width\",\"riegl.plane_height"
"\",\"riegl.vertex_first\",\"riegl.vertex_count\",\"riegl.used_for_adjustment"
"\",\"riegl.acquisition_date?\",\"riegl.import_line_number\",\"riegl.import_l"
"ine_count\"],\"metadata\":[\"riegl.geo_tag\",\"riegl.vertex_info\",\"riegl.rec"
"ord_names\",\"riegl.imported_files\"],\"extension\":\"pefx\"}"
)

# Schema for ".pofx" files
RDB_SCHEMA_RIEGL_PROJECT_POFX = (
"{\"identifier\":\"project.pofx\",\"attributes\":[\"riegl.id\",\"riegl.pof_times"
"tamp*\",\"riegl.pof_latitude\",\"riegl.pof_longitude\",\"riegl.pof_height\",\""
"riegl.pof_roll\",\"riegl.pof_pitch\",\"riegl.pof_yaw\",\"riegl.pof_path_leng"
"th\"],\"metadata\":[\"riegl.time_base\",\"riegl.trajectory_info\"],\"extension"
"\":\"pofx\"}"
)

# Schema for ".pofx" files
RDB_SCHEMA_RIEGL_SCAN_POFX = (
"{\"identifier\":\"scan.pofx\",\"attributes\":[\"riegl.id\",\"riegl.pof_timestam"
"p*\",\"riegl.pof_latitude\",\"riegl.pof_longitude\",\"riegl.pof_height\",\"rie"
"gl.pof_roll\",\"riegl.pof_pitch\",\"riegl.pof_yaw\",\"riegl.pof_path_length\""
",\"riegl.pof_xyz\",\"riegl.pof_roll_ned\",\"riegl.pof_pitch_ned\",\"riegl.pof"
"_yaw_ned\"],\"metadata\":[\"riegl.time_base\",\"riegl.geo_tag\",\"riegl.trajec"
"tory_info\"],\"extension\":\"pofx\"}"
)

# Schema for ".poqx" files
RDB_SCHEMA_RIEGL_PROJECT_POQX = (
"{\"identifier\":\"project.poqx\",\"attributes\":[\"riegl.id\",\"riegl.pof_times"
"tamp*\",\"riegl.pof_accuracy_north\",\"riegl.pof_accuracy_east\",\"riegl.pof"
"_accuracy_down\",\"riegl.pof_accuracy_roll\",\"riegl.pof_accuracy_pitch\",\""
"riegl.pof_accuracy_yaw\",\"riegl.pof_path_length\",\"riegl.pof_pdop\",\"rieg"
"l.pof_satellites_gnss?\",\"riegl.pof_satellites_gps?\",\"riegl.pof_satelli"
"tes_glonass?\",\"riegl.pof_satellites_beidou?\",\"riegl.pof_satellites_gal"
"ileo?\",\"riegl.pof_satellites_qzss?\"],\"metadata\":[\"riegl.time_base\",\"ri"
"egl.trajectory_info\"],\"extension\":\"poqx\"}"
)

# Schema for ".poqx" files
RDB_SCHEMA_RIEGL_SCAN_POQX = (
"{\"identifier\":\"scan.poqx\",\"attributes\":[\"riegl.id\",\"riegl.pof_timestam"
"p*\",\"riegl.pof_accuracy_north\",\"riegl.pof_accuracy_east\",\"riegl.pof_ac"
"curacy_down\",\"riegl.pof_accuracy_roll\",\"riegl.pof_accuracy_pitch\",\"rie"
"gl.pof_accuracy_yaw\",\"riegl.pof_path_length\",\"riegl.pof_pdop\",\"riegl.p"
"of_satellites_gnss?\",\"riegl.pof_satellites_gps?\",\"riegl.pof_satellites"
"_glonass?\",\"riegl.pof_satellites_beidou?\",\"riegl.pof_satellites_galile"
"o?\",\"riegl.pof_satellites_qzss?\"],\"metadata\":[\"riegl.time_base\",\"riegl"
".trajectory_info\"],\"extension\":\"poqx\"}"
)

# Schema for ".ppx" files
RDB_SCHEMA_RIEGL_PPX = (
"{\"identifier\":\"ppx\",\"attributes\":[\"riegl.id\",\"riegl.pps_timestamp_inte"
"rn*\",\"riegl.pps_timestamp_extern\"],\"metadata\":[\"riegl.device\",\"riegl.t"
"ime_base\"],\"extension\":\"ppx\"}"
)

# Schema for ".ptch" files
RDB_SCHEMA_RIEGL_PROJECT_PTCH = (
"{\"identifier\":\"project.ptch\",\"attributes\":[\"riegl.xyz*\",\"riegl.surface"
"_normal\",\"riegl.plane_up\",\"riegl.reflectance?\",\"riegl.point_count\",\"ri"
"egl.std_dev\",\"riegl.plane_width\",\"riegl.plane_height\",\"riegl.plane_cou"
"nt\",\"riegl.covariances\",\"riegl.id\"],\"metadata\":[\"riegl.device\",\"riegl."
"geo_tag?\",\"riegl.scan_pattern?\",\"riegl.time_base?\",\"riegl.plane_patch_"
"statistics?\"],\"extension\":\"ptch\"}"
)

# Schema for ".ptch" files
RDB_SCHEMA_RIEGL_SCAN_PTCH = (
"{\"identifier\":\"scan.ptch\",\"attributes\":[\"riegl.xyz*\",\"riegl.xyz_socs\","
"\"riegl.direction?\",\"riegl.direction_medium?\",\"riegl.direction_coarse?\""
",\"riegl.surface_normal\",\"riegl.plane_up\",\"riegl.timestamp\",\"riegl.refl"
"ectance?\",\"riegl.point_count\",\"riegl.std_dev\",\"riegl.plane_width\",\"rie"
"gl.plane_height\",\"riegl.plane_count\",\"riegl.mirror_facet\",\"riegl.covar"
"iances\",\"riegl.id\",\"riegl.plane_slope_class?\",\"riegl.plane_occupancy\","
"\"riegl.plane_confidence_normal\",\"riegl.plane_cog_link\",\"riegl.match_co"
"unt\",\"riegl.platform_rpy_ROCS_NED\",\"riegl.platform_xyz_ROCS_ENU\",\"rieg"
"l.platform_drpy_ROCS_NED\",\"riegl.platform_dxyz_ROCS_ENU\",\"riegl.sda.sh"
"ift_vector\",\"riegl.raw_range\",\"riegl.raw_frame_angle\",\"riegl.raw_line_"
"angle\"],\"metadata\":[\"riegl.device\",\"riegl.device_geometry\",\"riegl.geo_"
"tag\",\"riegl.georeferencing_parameters\",\"riegl.scan_pattern?\",\"riegl.ti"
"me_base\",\"riegl.plane_patch_statistics?\",\"riegl.plane_slope_class_info"
"?\"],\"extension\":\"ptch\"}"
)

# Schema for ".ptch" files
RDB_SCHEMA_RIEGL_SCANPOS_PTCH = (
"{\"identifier\":\"scanpos.ptch\",\"attributes\":[\"riegl.xyz*\",\"riegl.surface"
"_normal\",\"riegl.plane_up\",\"riegl.reflectance?\",\"riegl.point_count\",\"ri"
"egl.std_dev\",\"riegl.plane_width\",\"riegl.plane_height\",\"riegl.plane_cou"
"nt\",\"riegl.covariances\",\"riegl.id\"],\"metadata\":[\"riegl.device\",\"riegl."
"geo_tag?\",\"riegl.scan_pattern?\",\"riegl.time_base?\",\"riegl.plane_patch_"
"statistics?\"],\"extension\":\"ptch\"}"
)

# Schema for ".rdbx" files
RDB_SCHEMA_RIEGL_RDBX = (
"{\"identifier\":\"rdbx\",\"attributes\":[\"riegl.id\",\"riegl.timestamp\",\"riegl"
".xyz*\",\"riegl.xyz_socs\",\"riegl.direction_medium\",\"riegl.amplitude\",\"ri"
"egl.reflectance?\",\"riegl.deviation?\",\"riegl.pulse_width?\",\"riegl.targe"
"t_index\",\"riegl.target_count\",\"riegl.mirror_facet?\",\"riegl.scan_segmen"
"t?\",\"riegl.mta_unresolved?\",\"riegl.mta_zone?\",\"riegl.window_echo_impac"
"t_corrected?\",\"riegl.rgba?\",\"riegl.class?\",\"riegl.start_of_scan_line?\""
",\"riegl.end_of_scan_line?\",\"riegl.source_indicator?\",\"riegl.fwa?\",\"rie"
"gl.waveform_available?\",\"riegl.wfm_sbl_id?\",\"riegl.wfm_echo_time_offse"
"t?\",\"riegl.scan_angle\",\"riegl.scan_direction\",\"riegl.source_index?\",\"r"
"iegl.hydro_intersection_point?\",\"riegl.hydro_intersection_normal?\"],\"m"
"etadata\":[\"riegl.atmosphere\",\"riegl.beam_geometry\",\"riegl.device_geome"
"try\",\"riegl.device\",\"riegl.gaussian_decomposition?\",\"riegl.exponential"
"_decomposition?\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"ri"
"egl.mta_settings?\",\"riegl.near_range_correction?\",\"riegl.noise_estimat"
"es?\",\"riegl.angular_notch_filter?\",\"riegl.notch_filter?\",\"riegl.pointc"
"loud_info?\",\"riegl.pulse_position_modulation?\",\"riegl.range_statistics"
"?\",\"riegl.receiver_internals?\",\"riegl.reflectance_calculation?\",\"riegl"
".reflectance_correction?\",\"riegl.scan_pattern\",\"riegl.time_base\",\"rieg"
"l.waveform_settings?\",\"riegl.window_analysis?\",\"riegl.window_echo_corr"
"ection?\"],\"extension\":\"rdbx\"}"
)

# Schema for ".rmvx" files
RDB_SCHEMA_RIEGL_RMVX = (
"{\"identifier\":\"rmvx\",\"attributes\":[\"riegl.id\",\"riegl.voxel_index*\",\"ri"
"egl.amplitude\",\"riegl.reflectance\",\"riegl.deviation\",\"riegl.direction_"
"medium\",\"riegl.point_count\",\"riegl.voxel_linear_sums\",\"riegl.voxel_squ"
"are_sums\",\"riegl.timestamp_min?\",\"riegl.timestamp_max?\"],\"metadata\":[\""
"riegl.geo_tag\",\"riegl.voxel_info\",\"riegl.time_base?\"],\"extension\":\"rmv"
"x\"}"
)

# Schema for ".s10x" files
RDB_SCHEMA_RIEGL_S10X = (
"{\"identifier\":\"s10x\",\"attributes\":[\"riegl.id\",\"riegl.timestamp*\",\"rieg"
"l.frame_angle_coarse\",\"riegl.gyroscope_raw\",\"riegl.accelerometer_raw\","
"\"riegl.magnetic_field_sensor_raw\",\"riegl.gyroscope\",\"riegl.acceleromet"
"er\",\"riegl.magnetic_field_sensor\",\"riegl.barometric_height_amsl\",\"rieg"
"l.temperature\",\"riegl.line_scan_active\",\"riegl.frame_scan_active\",\"rie"
"gl.data_acquisition_active\"],\"metadata\":[\"riegl.time_base\",\"riegl.pose"
"_sensors\"],\"extension\":\"s10x\"}"
)

# Schema for ".sbx" files
RDB_SCHEMA_RIEGL_SBX = (
"{\"identifier\":\"sbx\",\"attributes\":[\"riegl.id*\",\"riegl.wfm_sbl_channel\","
"\"riegl.wfm_sbl_mean\",\"riegl.wfm_sbl_std_dev\",\"riegl.wfm_sbl_time_offse"
"t\",\"riegl.wfm_sda_first\",\"riegl.wfm_sda_count\"],\"metadata\":[],\"extensi"
"on\":\"sbx\"}"
)

# Schema for ".sdcx" files
RDB_SCHEMA_RIEGL_SDCX = (
"{\"identifier\":\"sdcx\",\"attributes\":[\"riegl.id\",\"riegl.timestamp*\",\"rieg"
"l.xyz\",\"riegl.amplitude\",\"riegl.reflectance?\",\"riegl.deviation?\",\"rieg"
"l.pulse_width?\",\"riegl.target_index\",\"riegl.target_count\",\"riegl.mirro"
"r_facet?\",\"riegl.scan_segment?\",\"riegl.mta_unresolved?\",\"riegl.mta_zon"
"e?\",\"riegl.window_echo_impact_corrected?\",\"riegl.class?\",\"riegl.start_"
"of_scan_line?\",\"riegl.end_of_scan_line?\",\"riegl.source_indicator?\",\"ri"
"egl.fwa?\",\"riegl.waveform_available?\",\"riegl.wfm_sbl_id?\",\"riegl.wfm_e"
"cho_time_offset?\"],\"metadata\":[\"riegl.atmosphere\",\"riegl.beam_geometry"
"\",\"riegl.device_geometry\",\"riegl.device\",\"riegl.gaussian_decomposition"
"?\",\"riegl.exponential_decomposition?\",\"riegl.mta_settings?\",\"riegl.nea"
"r_range_correction?\",\"riegl.noise_estimates?\",\"riegl.angular_notch_fil"
"ter?\",\"riegl.notch_filter?\",\"riegl.pointcloud_info?\",\"riegl.pulse_posi"
"tion_modulation?\",\"riegl.range_statistics?\",\"riegl.receiver_internals?"
"\",\"riegl.reflectance_calculation?\",\"riegl.reflectance_correction?\",\"ri"
"egl.scan_pattern\",\"riegl.time_base\",\"riegl.window_analysis?\",\"riegl.wi"
"ndow_echo_correction?\"],\"extension\":\"sdcx\"}"
)

# Schema for ".sidx" files
RDB_SCHEMA_RIEGL_SIDX = (
"{\"identifier\":\"sidx\",\"attributes\":[\"riegl.id\",\"riegl.shot_timestamp_hr"
"*\",\"riegl.echo_first\",\"riegl.echo_count\"],\"metadata\":[\"riegl.shot_info"
"\",\"riegl.echo_info\"],\"extension\":\"sidx\"}"
)

# Schema for ".sodx" files
RDB_SCHEMA_RIEGL_SODX = (
"{\"identifier\":\"sodx\",\"attributes\":[\"riegl.id\",\"riegl.shot_timestamp_hr"
"*\",\"riegl.mirror_facet\",\"riegl.scan_segment\",\"riegl.start_of_scan_line"
"\",\"riegl.line_angle_coarse\",\"riegl.shot_origin\",\"riegl.shot_direction\""
",\"riegl.shot_direction_levelled?\",\"riegl.wfm_sbl_first?\",\"riegl.wfm_sb"
"l_count?\",\"riegl.echo_first?\",\"riegl.echo_count?\"],\"metadata\":[\"riegl."
"atmosphere\",\"riegl.device\",\"riegl.device_geometry\",\"riegl.device_outpu"
"t_limits\",\"riegl.beam_geometry\",\"riegl.near_range_correction?\",\"riegl."
"window_echo_correction?\",\"riegl.receiver_internals?\",\"riegl.gaussian_d"
"ecomposition?\",\"riegl.exponential_decomposition?\",\"riegl.mta_settings?"
"\",\"riegl.pulse_position_modulation?\",\"riegl.notch_filter?\",\"riegl.refl"
"ectance_calculation?\",\"riegl.scan_pattern\",\"riegl.time_base\",\"riegl.wa"
"veform_info?\",\"riegl.echo_info?\"],\"extension\":\"sodx\"}"
)

# Schema for ".sp{C}" files
RDB_SCHEMA_RIEGL_SPC = (
"{\"identifier\":\"sp{C}\",\"attributes\":[\"riegl.id*\",\"riegl.wfm_sample_valu"
"e\"],\"metadata\":[],\"extension\":\"sp{C}\"}"
)

# Schema for ".vtx" files
RDB_SCHEMA_RIEGL_VTX = (
"{\"identifier\":\"vtx\",\"attributes\":[\"riegl.id*\",\"riegl.xyz\",\"riegl.xyz_a"
"ccuracies?\"],\"metadata\":[\"riegl.geo_tag\"],\"extension\":\"vtx\"}"
)

# Schema for ".vxls" files
RDB_SCHEMA_RIEGL_VXLS = (
"{\"identifier\":\"vxls\",\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.cova"
"riances\",\"riegl.pca_axis_max\",\"riegl.pca_axis_min\",\"riegl.pca_extents\""
",\"riegl.point_count\",\"riegl.reflectance\",\"riegl.shape_id\",\"riegl.voxel"
"_collapsed\",\"riegl.std_dev?\"],\"metadata\":[\"riegl.voxel_info\",\"riegl.ge"
"o_tag?\"],\"extension\":\"vxls\"}"
)

# Schema for ".wdcx" files
RDB_SCHEMA_RIEGL_WDCX = (
"{\"identifier\":\"wdcx\",\"attributes\":[\"riegl.id\",\"riegl.timestamp\",\"riegl"
".xyz*\",\"riegl.xyz_socs\",\"riegl.direction_medium\",\"riegl.amplitude\",\"ri"
"egl.reflectance?\",\"riegl.deviation?\",\"riegl.pulse_width?\",\"riegl.targe"
"t_index\",\"riegl.target_count\",\"riegl.mirror_facet?\",\"riegl.scan_segmen"
"t?\",\"riegl.mta_unresolved?\",\"riegl.mta_zone?\",\"riegl.window_echo_impac"
"t_corrected?\",\"riegl.rgba?\",\"riegl.class?\",\"riegl.start_of_scan_line?\""
",\"riegl.end_of_scan_line?\",\"riegl.source_indicator?\",\"riegl.fwa?\",\"rie"
"gl.waveform_available?\",\"riegl.wfm_sbl_id?\",\"riegl.wfm_echo_time_offse"
"t?\",\"riegl.scan_angle\",\"riegl.scan_direction\",\"riegl.source_index?\",\"r"
"iegl.hydro_intersection_point?\",\"riegl.hydro_intersection_normal?\"],\"m"
"etadata\":[\"riegl.atmosphere\",\"riegl.beam_geometry\",\"riegl.device_geome"
"try\",\"riegl.device\",\"riegl.gaussian_decomposition?\",\"riegl.exponential"
"_decomposition?\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"ri"
"egl.mta_settings?\",\"riegl.near_range_correction?\",\"riegl.noise_estimat"
"es?\",\"riegl.angular_notch_filter?\",\"riegl.notch_filter?\",\"riegl.pointc"
"loud_info?\",\"riegl.pulse_position_modulation?\",\"riegl.range_statistics"
"?\",\"riegl.receiver_internals?\",\"riegl.reflectance_calculation?\",\"riegl"
".reflectance_correction?\",\"riegl.scan_pattern\",\"riegl.time_base\",\"rieg"
"l.waveform_settings?\",\"riegl.window_analysis?\",\"riegl.window_echo_corr"
"ection?\"],\"extension\":\"wdcx\"}"
)

# Schema for ".wex" files
RDB_SCHEMA_RIEGL_WEX = (
"{\"identifier\":\"wex\",\"attributes\":[\"riegl.id\",\"riegl.timestamp*\",\"riegl"
".wex_filter_valid\",\"riegl.wex_point_count\",\"riegl.wex_amplitude\",\"rieg"
"l.wex_amplitude_std_dev\",\"riegl.wex_amplitude_min\",\"riegl.wex_amplitud"
"e_max\",\"riegl.wex_amplitude_offset\",\"riegl.wex_deviation\",\"riegl.wex_d"
"eviation_std_dev\",\"riegl.wex_deviation_min\",\"riegl.wex_deviation_max\","
"\"riegl.wex_range\",\"riegl.wex_range_std_dev\",\"riegl.wex_range_min\",\"rie"
"gl.wex_range_max\",\"riegl.wex_filter_range_min\",\"riegl.wex_filter_range"
"_max\",\"riegl.wex_filter_amplitude_max\"],\"metadata\":[\"riegl.device\",\"ri"
"egl.notch_filter\",\"riegl.window_analysis\"],\"extension\":\"wex\"}"
)

# Table of all RDB file schema strings
RDB_SCHEMA_ARRAY = [
    RDB_SCHEMA_RIEGL_AVG_FWA,
    RDB_SCHEMA_RIEGL_AVG_SBX,
    RDB_SCHEMA_RIEGL_AVG_SIDX,
    RDB_SCHEMA_RIEGL_AVG_SPC,
    RDB_SCHEMA_RIEGL_CPX,
    RDB_SCHEMA_RIEGL_FWA,
    RDB_SCHEMA_RIEGL_MPX,
    RDB_SCHEMA_RIEGL_MTCH,
    RDB_SCHEMA_RIEGL_MVX,
    RDB_SCHEMA_RIEGL_OBSX,
    RDB_SCHEMA_RIEGL_OPEFX,
    RDB_SCHEMA_RIEGL_OPP,
    RDB_SCHEMA_RIEGL_OPX,
    RDB_SCHEMA_RIEGL_OWP,
    RDB_SCHEMA_RIEGL_PEFX,
    RDB_SCHEMA_RIEGL_PROJECT_POFX,
    RDB_SCHEMA_RIEGL_SCAN_POFX,
    RDB_SCHEMA_RIEGL_PROJECT_POQX,
    RDB_SCHEMA_RIEGL_SCAN_POQX,
    RDB_SCHEMA_RIEGL_PPX,
    RDB_SCHEMA_RIEGL_PROJECT_PTCH,
    RDB_SCHEMA_RIEGL_SCAN_PTCH,
    RDB_SCHEMA_RIEGL_SCANPOS_PTCH,
    RDB_SCHEMA_RIEGL_RDBX,
    RDB_SCHEMA_RIEGL_RMVX,
    RDB_SCHEMA_RIEGL_S10X,
    RDB_SCHEMA_RIEGL_SBX,
    RDB_SCHEMA_RIEGL_SDCX,
    RDB_SCHEMA_RIEGL_SIDX,
    RDB_SCHEMA_RIEGL_SODX,
    RDB_SCHEMA_RIEGL_SPC,
    RDB_SCHEMA_RIEGL_VTX,
    RDB_SCHEMA_RIEGL_VXLS,
    RDB_SCHEMA_RIEGL_WDCX,
    RDB_SCHEMA_RIEGL_WEX
]
