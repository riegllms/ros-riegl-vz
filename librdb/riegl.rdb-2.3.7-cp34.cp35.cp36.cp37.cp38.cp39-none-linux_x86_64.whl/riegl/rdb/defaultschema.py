#
#*******************************************************************************
#
#  Copyright 2020 RIEGL Laser Measurement Systems
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
#  SPDX-License-Identifier: Apache-2.0
#
#*******************************************************************************
#
"""
*******************************************************************************
*
* \author RIEGL LMS GmbH, Austria
* \brief  Description of RIEGL RDB 2 database file contents
*
*  NOTE: All information in this file is preliminary, since the
*        definition of the database schemas is not yet complete.
*
*******************************************************************************
"""

# File schema version
RDB_SCHEMA_VERSION = "ab4e0cc0"
RDB_SCHEMA_DATE = "2021-05-03"

# Schema for ".avg.fwa" files
RDB_SCHEMA_RIEGL_AVG_FWA = (
"{\"attributes\":[\"riegl.id*\",\"riegl.amplitude\",\"riegl.gain\",\"riegl.raw_r"
"ange\",\"riegl.wfm_echo_time_offset\",\"riegl.wfm_sbl_id\",\"riegl.deviation"
"?\",\"riegl.pulse_width?\"],\"extension\":\"avg.fwa\",\"metadata\":[],\"identifi"
"er\":\"avg.fwa\"}"
)

# Schema for ".avg.sbx" files
RDB_SCHEMA_RIEGL_AVG_SBX = (
"{\"attributes\":[\"riegl.id*\",\"riegl.wfm_sbl_channel\",\"riegl.wfm_sbl_mean"
"\",\"riegl.wfm_sbl_std_dev\",\"riegl.wfm_sbl_time_offset\",\"riegl.wfm_sda_f"
"irst\",\"riegl.wfm_sda_count\"],\"extension\":\"avg.sbx\",\"metadata\":[],\"iden"
"tifier\":\"avg.sbx\"}"
)

# Schema for ".avg.sidx" files
RDB_SCHEMA_RIEGL_AVG_SIDX = (
"{\"attributes\":[\"riegl.id\",\"riegl.shot_timestamp_hr*\",\"riegl.wfm_sbl_fi"
"rst\",\"riegl.wfm_sbl_count\",\"riegl.echo_first?\",\"riegl.echo_count?\"],\"e"
"xtension\":\"avg.sidx\",\"metadata\":[\"riegl.shot_info\",\"riegl.waveform_inf"
"o\",\"riegl.echo_info?\",\"riegl.waveform_averaging_settings\"],\"identifier"
"\":\"avg.sidx\"}"
)

# Schema for ".avg.sp{C}" files
RDB_SCHEMA_RIEGL_AVG_SPC = (
"{\"attributes\":[\"riegl.id*\",\"riegl.wfm_sample_value\"],\"extension\":\"avg."
"sp{C}\",\"metadata\":[],\"identifier\":\"avg.sp{C}\"}"
)

# Schema for ".cpx" files
RDB_SCHEMA_RIEGL_CPX = (
"{\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_accuracies\",\"riegl.c"
"ontrol_object_type\",\"riegl.zenith_vector\",\"riegl.used_for_adjustment\","
"\"riegl.acquisition_date?\",\"riegl.cp_surface_inclination_angle\",\"riegl."
"cp_surface_inclination_tolerance_angle\",\"riegl.import_line_number\"],\"e"
"xtension\":\"cpx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.control_object_cata"
"log\",\"riegl.record_names\",\"riegl.imported_files\"],\"identifier\":\"cpx\"}"
)

# Schema for ".fwa" files
RDB_SCHEMA_RIEGL_FWA = (
"{\"attributes\":[\"riegl.id*\",\"riegl.amplitude\",\"riegl.gain\",\"riegl.raw_r"
"ange\",\"riegl.wfm_echo_time_offset\",\"riegl.wfm_sbl_id\",\"riegl.deviation"
"?\",\"riegl.pulse_width?\"],\"extension\":\"fwa\",\"metadata\":[],\"identifier\":"
"\"fwa\"}"
)

# Schema for ".mpx" files
RDB_SCHEMA_RIEGL_MPX = (
"{\"attributes\":[\"riegl.id\",\"riegl.xy_map*\",\"riegl.amplitude\",\"riegl.ref"
"lectance\",\"riegl.deviation\",\"riegl.timestamp_min?\",\"riegl.timestamp_ma"
"x?\",\"riegl.point_count\",\"riegl.point_count_grid_cell\",\"riegl.pixel_lin"
"ear_sums?\",\"riegl.pixel_square_sums?\",\"riegl.height_min\",\"riegl.height"
"_max\",\"riegl.height_mean\",\"riegl.height_center\",\"riegl.surface_normal\""
",\"riegl.pca_thickness\",\"riegl.std_dev\",\"riegl.voxel_count\"],\"extension"
"\":\"mpx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.pixel_info\",\"riegl.time_bas"
"e?\"],\"identifier\":\"mpx\"}"
)

# Schema for ".mtch" files
RDB_SCHEMA_RIEGL_MTCH = (
"{\"attributes\":[\"riegl.xyz*\",\"riegl.plane_references\",\"riegl.plane_patc"
"h_distance\",\"riegl.plane_patch_lateral_distance\",\"riegl.plane_patch_li"
"nk_vector\",\"riegl.id\"],\"extension\":\"mtch\",\"metadata\":[\"riegl.plane_pat"
"ch_matching\"],\"identifier\":\"mtch\"}"
)

# Schema for ".mvx" files
RDB_SCHEMA_RIEGL_MVX = (
"{\"attributes\":[\"riegl.id\",\"riegl.xyz_map*\",\"riegl.amplitude\",\"riegl.re"
"flectance\",\"riegl.deviation\",\"riegl.timestamp_min?\",\"riegl.timestamp_m"
"ax?\",\"riegl.point_count\",\"riegl.shape_id\",\"riegl.covariances?\",\"riegl."
"pca_axis_min\",\"riegl.pca_axis_max\",\"riegl.pca_extents\",\"riegl.std_dev\""
",\"riegl.voxel_collapsed\"],\"extension\":\"mvx\",\"metadata\":[\"riegl.geo_tag"
"\",\"riegl.time_base?\",\"riegl.voxel_info\"],\"identifier\":\"mvx\"}"
)

# Schema for ".obsx" files
RDB_SCHEMA_RIEGL_OBSX = (
"{\"attributes\":[\"riegl.xyz\",\"riegl.surface_normal\",\"riegl.plane_slope_c"
"lass?\",\"riegl.id*\",\"riegl.sda1_plane_patch_one\",\"riegl.sda1_plane_patc"
"h_two\",\"riegl.sda1_source_file_one\",\"riegl.sda1_source_file_two\"],\"ext"
"ension\":\"obsx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.plane_slope_class_in"
"fo?\",\"riegl.pointcloud_info\",\"riegl.sda1_source_files\"],\"identifier\":\""
"obsx\"}"
)

# Schema for ".opefx" files
RDB_SCHEMA_RIEGL_OPEFX = (
"{\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_accuracies?\",\"riegl."
"surface_normal\",\"riegl.plane_up\",\"riegl.point_count\",\"riegl.std_dev\",\""
"riegl.plane_width\",\"riegl.plane_height\",\"riegl.plane_confidence_normal"
"\",\"riegl.model_fit_quality?\",\"riegl.used_for_adjustment\",\"riegl.xyz_so"
"cs\",\"riegl.timestamp\",\"riegl.mirror_facet\",\"riegl.platform_rpy_ROCS_NE"
"D\",\"riegl.platform_drpy_ROCS_NED\",\"riegl.platform_xyz_ROCS_ENU\",\"riegl"
".platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_vector\",\"riegl.raw_range\",\"r"
"iegl.raw_frame_angle\",\"riegl.raw_line_angle\",\"riegl.reference_object_i"
"d\"],\"extension\":\"opefx\",\"metadata\":[\"riegl.device\",\"riegl.device_geome"
"try\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"riegl.scan_pat"
"tern?\",\"riegl.time_base\",\"riegl.record_names\",\"riegl.control_object_re"
"ference_file\"],\"identifier\":\"opefx\"}"
)

# Schema for ".opp" files
RDB_SCHEMA_RIEGL_OPP = (
"{\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_accuracies?\",\"riegl."
"surface_normal\",\"riegl.plane_up\",\"riegl.point_count\",\"riegl.std_dev\",\""
"riegl.plane_width\",\"riegl.plane_height\",\"riegl.plane_confidence_normal"
"\",\"riegl.model_fit_quality?\",\"riegl.used_for_adjustment\",\"riegl.xyz_so"
"cs\",\"riegl.timestamp\",\"riegl.mirror_facet\",\"riegl.platform_rpy_ROCS_NE"
"D\",\"riegl.platform_drpy_ROCS_NED\",\"riegl.platform_xyz_ROCS_ENU\",\"riegl"
".platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_vector\",\"riegl.raw_range\",\"r"
"iegl.raw_frame_angle\",\"riegl.raw_line_angle\",\"riegl.reference_object_i"
"d\"],\"extension\":\"opp\",\"metadata\":[\"riegl.device\",\"riegl.device_geometr"
"y\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"riegl.scan_patte"
"rn?\",\"riegl.time_base\",\"riegl.record_names\",\"riegl.control_object_refe"
"rence_file\"],\"identifier\":\"opp\"}"
)

# Schema for ".opx" files
RDB_SCHEMA_RIEGL_OPX = (
"{\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.control_object_type\",\"ri"
"egl.model_cs_axis_x?\",\"riegl.model_cs_axis_y?\",\"riegl.model_cs_axis_z?"
"\",\"riegl.model_fit_quality?\",\"riegl.obs_confidence_xy?\",\"riegl.obs_con"
"fidence_z?\",\"riegl.obs_signal_confidence_rot?\",\"riegl.used_for_adjustm"
"ent\",\"riegl.xyz_socs\",\"riegl.timestamp\",\"riegl.mirror_facet\",\"riegl.pl"
"atform_rpy_ROCS_NED\",\"riegl.platform_drpy_ROCS_NED\",\"riegl.platform_xy"
"z_ROCS_ENU\",\"riegl.platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_vector\",\"r"
"iegl.raw_range\",\"riegl.raw_frame_angle\",\"riegl.raw_line_angle\",\"riegl."
"reference_object_id\"],\"extension\":\"opx\",\"metadata\":[\"riegl.device\",\"ri"
"egl.device_geometry\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\""
",\"riegl.scan_pattern?\",\"riegl.time_base\",\"riegl.control_object_catalog"
"\",\"riegl.record_names\",\"riegl.control_object_reference_file\"],\"identif"
"ier\":\"opx\"}"
)

# Schema for ".owp" files
RDB_SCHEMA_RIEGL_OWP = (
"{\"attributes\":[\"riegl.id*\",\"riegl.raw_range\",\"riegl.amplitude\",\"riegl."
"deviation\",\"riegl.gain\"],\"extension\":\"owp\",\"metadata\":[],\"identifier\":"
"\"owp\"}"
)

# Schema for ".pefx" files
RDB_SCHEMA_RIEGL_PEFX = (
"{\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_accuracies?\",\"riegl."
"surface_normal\",\"riegl.plane_up\",\"riegl.std_dev\",\"riegl.plane_confiden"
"ce_normal\",\"riegl.plane_width\",\"riegl.plane_height\",\"riegl.vertex_firs"
"t\",\"riegl.vertex_count\",\"riegl.used_for_adjustment\",\"riegl.acquisition"
"_date?\",\"riegl.import_line_number\",\"riegl.import_line_count\"],\"extensi"
"on\":\"pefx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.vertex_info\",\"riegl.reco"
"rd_names\",\"riegl.imported_files\"],\"identifier\":\"pefx\"}"
)

# Schema for ".pofx" files
RDB_SCHEMA_RIEGL_PROJECT_POFX = (
"{\"attributes\":[\"riegl.id\",\"riegl.pof_timestamp*\",\"riegl.pof_latitude\","
"\"riegl.pof_longitude\",\"riegl.pof_height\",\"riegl.pof_roll\",\"riegl.pof_p"
"itch\",\"riegl.pof_yaw\",\"riegl.pof_path_length\"],\"extension\":\"pofx\",\"met"
"adata\":[\"riegl.time_base\",\"riegl.trajectory_info\"],\"identifier\":\"proje"
"ct.pofx\"}"
)

# Schema for ".pofx" files
RDB_SCHEMA_RIEGL_SCAN_POFX = (
"{\"attributes\":[\"riegl.id\",\"riegl.pof_timestamp*\",\"riegl.pof_latitude\","
"\"riegl.pof_longitude\",\"riegl.pof_height\",\"riegl.pof_roll\",\"riegl.pof_p"
"itch\",\"riegl.pof_yaw\",\"riegl.pof_path_length\",\"riegl.pof_xyz\",\"riegl.p"
"of_roll_ned\",\"riegl.pof_pitch_ned\",\"riegl.pof_yaw_ned\"],\"extension\":\"p"
"ofx\",\"metadata\":[\"riegl.time_base\",\"riegl.geo_tag\",\"riegl.trajectory_i"
"nfo\"],\"identifier\":\"scan.pofx\"}"
)

# Schema for ".poqx" files
RDB_SCHEMA_RIEGL_PROJECT_POQX = (
"{\"attributes\":[\"riegl.id\",\"riegl.pof_timestamp*\",\"riegl.pof_accuracy_n"
"orth\",\"riegl.pof_accuracy_east\",\"riegl.pof_accuracy_down\",\"riegl.pof_a"
"ccuracy_roll\",\"riegl.pof_accuracy_pitch\",\"riegl.pof_accuracy_yaw\",\"rie"
"gl.pof_path_length\",\"riegl.pof_pdop\",\"riegl.pof_satellites_gnss?\",\"rie"
"gl.pof_satellites_gps?\",\"riegl.pof_satellites_glonass?\",\"riegl.pof_sat"
"ellites_beidou?\",\"riegl.pof_satellites_galileo?\",\"riegl.pof_satellites"
"_qzss?\"],\"extension\":\"poqx\",\"metadata\":[\"riegl.time_base\",\"riegl.traje"
"ctory_info\"],\"identifier\":\"project.poqx\"}"
)

# Schema for ".poqx" files
RDB_SCHEMA_RIEGL_SCAN_POQX = (
"{\"attributes\":[\"riegl.id\",\"riegl.pof_timestamp*\",\"riegl.pof_accuracy_n"
"orth\",\"riegl.pof_accuracy_east\",\"riegl.pof_accuracy_down\",\"riegl.pof_a"
"ccuracy_roll\",\"riegl.pof_accuracy_pitch\",\"riegl.pof_accuracy_yaw\",\"rie"
"gl.pof_path_length\",\"riegl.pof_pdop\",\"riegl.pof_satellites_gnss?\",\"rie"
"gl.pof_satellites_gps?\",\"riegl.pof_satellites_glonass?\",\"riegl.pof_sat"
"ellites_beidou?\",\"riegl.pof_satellites_galileo?\",\"riegl.pof_satellites"
"_qzss?\"],\"extension\":\"poqx\",\"metadata\":[\"riegl.time_base\",\"riegl.traje"
"ctory_info\"],\"identifier\":\"scan.poqx\"}"
)

# Schema for ".ppx" files
RDB_SCHEMA_RIEGL_PPX = (
"{\"attributes\":[\"riegl.id\",\"riegl.pps_timestamp_intern*\",\"riegl.pps_tim"
"estamp_extern\"],\"extension\":\"ppx\",\"metadata\":[\"riegl.device\",\"riegl.ti"
"me_base\"],\"identifier\":\"ppx\"}"
)

# Schema for ".ptch" files
RDB_SCHEMA_RIEGL_PROJECT_PTCH = (
"{\"attributes\":[\"riegl.xyz*\",\"riegl.surface_normal\",\"riegl.plane_up\",\"r"
"iegl.reflectance?\",\"riegl.point_count\",\"riegl.std_dev\",\"riegl.plane_wi"
"dth\",\"riegl.plane_height\",\"riegl.plane_count\",\"riegl.covariances\",\"rie"
"gl.id\"],\"extension\":\"ptch\",\"metadata\":[\"riegl.device\",\"riegl.geo_tag?\""
",\"riegl.scan_pattern?\",\"riegl.time_base?\",\"riegl.plane_patch_statistic"
"s?\"],\"identifier\":\"project.ptch\"}"
)

# Schema for ".ptch" files
RDB_SCHEMA_RIEGL_SCAN_PTCH = (
"{\"attributes\":[\"riegl.xyz*\",\"riegl.xyz_socs\",\"riegl.direction?\",\"riegl"
".direction_medium?\",\"riegl.direction_coarse?\",\"riegl.surface_normal\",\""
"riegl.plane_up\",\"riegl.timestamp\",\"riegl.reflectance?\",\"riegl.point_co"
"unt\",\"riegl.std_dev\",\"riegl.plane_width\",\"riegl.plane_height\",\"riegl.p"
"lane_count\",\"riegl.mirror_facet\",\"riegl.covariances\",\"riegl.id\",\"riegl"
".plane_slope_class?\",\"riegl.plane_occupancy\",\"riegl.plane_confidence_n"
"ormal\",\"riegl.plane_cog_link\",\"riegl.match_count\",\"riegl.platform_rpy_"
"ROCS_NED\",\"riegl.platform_xyz_ROCS_ENU\",\"riegl.platform_drpy_ROCS_NED\""
",\"riegl.platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_vector\",\"riegl.raw_ra"
"nge\",\"riegl.raw_frame_angle\",\"riegl.raw_line_angle\"],\"extension\":\"ptch"
"\",\"metadata\":[\"riegl.device\",\"riegl.device_geometry\",\"riegl.geo_tag\",\""
"riegl.georeferencing_parameters\",\"riegl.scan_pattern?\",\"riegl.time_bas"
"e\",\"riegl.plane_patch_statistics?\",\"riegl.plane_slope_class_info?\"],\"i"
"dentifier\":\"scan.ptch\"}"
)

# Schema for ".ptch" files
RDB_SCHEMA_RIEGL_SCANPOS_PTCH = (
"{\"attributes\":[\"riegl.xyz*\",\"riegl.surface_normal\",\"riegl.plane_up\",\"r"
"iegl.reflectance?\",\"riegl.point_count\",\"riegl.std_dev\",\"riegl.plane_wi"
"dth\",\"riegl.plane_height\",\"riegl.plane_count\",\"riegl.covariances\",\"rie"
"gl.id\"],\"extension\":\"ptch\",\"metadata\":[\"riegl.device\",\"riegl.geo_tag?\""
",\"riegl.scan_pattern?\",\"riegl.time_base?\",\"riegl.plane_patch_statistic"
"s?\"],\"identifier\":\"scanpos.ptch\"}"
)

# Schema for ".rdbx" files
RDB_SCHEMA_RIEGL_RDBX = (
"{\"attributes\":[\"riegl.id\",\"riegl.timestamp\",\"riegl.xyz*\",\"riegl.xyz_so"
"cs\",\"riegl.direction_medium\",\"riegl.amplitude\",\"riegl.reflectance?\",\"r"
"iegl.deviation?\",\"riegl.pulse_width?\",\"riegl.target_index\",\"riegl.targ"
"et_count\",\"riegl.mirror_facet?\",\"riegl.scan_segment?\",\"riegl.mta_unres"
"olved?\",\"riegl.mta_zone?\",\"riegl.window_echo_impact_corrected?\",\"riegl"
".rgba?\",\"riegl.class?\",\"riegl.start_of_scan_line?\",\"riegl.end_of_scan_"
"line?\",\"riegl.source_indicator?\",\"riegl.fwa?\",\"riegl.waveform_availabl"
"e?\",\"riegl.wfm_sbl_id?\",\"riegl.wfm_echo_time_offset?\",\"riegl.scan_angl"
"e\",\"riegl.scan_direction\",\"riegl.source_index?\",\"riegl.hydro_intersect"
"ion_point?\",\"riegl.hydro_intersection_normal?\"],\"extension\":\"rdbx\",\"me"
"tadata\":[\"riegl.atmosphere\",\"riegl.beam_geometry\",\"riegl.device_geomet"
"ry\",\"riegl.device\",\"riegl.gaussian_decomposition?\",\"riegl.exponential_"
"decomposition?\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"rie"
"gl.mta_settings?\",\"riegl.near_range_correction?\",\"riegl.noise_estimate"
"s?\",\"riegl.angular_notch_filter?\",\"riegl.notch_filter?\",\"riegl.pointcl"
"oud_info?\",\"riegl.pulse_position_modulation?\",\"riegl.range_statistics?"
"\",\"riegl.receiver_internals?\",\"riegl.reflectance_calculation?\",\"riegl."
"reflectance_correction?\",\"riegl.scan_pattern\",\"riegl.time_base\",\"riegl"
".waveform_settings?\",\"riegl.window_analysis?\",\"riegl.window_echo_corre"
"ction?\"],\"identifier\":\"rdbx\"}"
)

# Schema for ".rmvx" files
RDB_SCHEMA_RIEGL_RMVX = (
"{\"attributes\":[\"riegl.id\",\"riegl.voxel_index*\",\"riegl.amplitude\",\"rieg"
"l.reflectance\",\"riegl.deviation\",\"riegl.direction_medium\",\"riegl.point"
"_count\",\"riegl.voxel_linear_sums\",\"riegl.voxel_square_sums\",\"riegl.tim"
"estamp_min?\",\"riegl.timestamp_max?\"],\"extension\":\"rmvx\",\"metadata\":[\"r"
"iegl.geo_tag\",\"riegl.voxel_info\",\"riegl.time_base?\"],\"identifier\":\"rmv"
"x\"}"
)

# Schema for ".s10x" files
RDB_SCHEMA_RIEGL_S10X = (
"{\"attributes\":[\"riegl.id\",\"riegl.timestamp*\",\"riegl.frame_angle_coarse"
"\",\"riegl.gyroscope_raw\",\"riegl.accelerometer_raw\",\"riegl.magnetic_fiel"
"d_sensor_raw\",\"riegl.gyroscope\",\"riegl.accelerometer\",\"riegl.magnetic_"
"field_sensor\",\"riegl.barometric_height_amsl\",\"riegl.temperature\",\"rieg"
"l.line_scan_active\",\"riegl.frame_scan_active\",\"riegl.data_acquisition_"
"active\"],\"extension\":\"s10x\",\"metadata\":[\"riegl.time_base\",\"riegl.pose_"
"sensors\"],\"identifier\":\"s10x\"}"
)

# Schema for ".sbx" files
RDB_SCHEMA_RIEGL_SBX = (
"{\"attributes\":[\"riegl.id*\",\"riegl.wfm_sbl_channel\",\"riegl.wfm_sbl_mean"
"\",\"riegl.wfm_sbl_std_dev\",\"riegl.wfm_sbl_time_offset\",\"riegl.wfm_sda_f"
"irst\",\"riegl.wfm_sda_count\"],\"extension\":\"sbx\",\"metadata\":[],\"identifi"
"er\":\"sbx\"}"
)

# Schema for ".sdcx" files
RDB_SCHEMA_RIEGL_SDCX = (
"{\"attributes\":[\"riegl.id\",\"riegl.timestamp*\",\"riegl.xyz\",\"riegl.amplit"
"ude\",\"riegl.reflectance?\",\"riegl.deviation?\",\"riegl.pulse_width?\",\"rie"
"gl.target_index\",\"riegl.target_count\",\"riegl.mirror_facet?\",\"riegl.sca"
"n_segment?\",\"riegl.mta_unresolved?\",\"riegl.mta_zone?\",\"riegl.window_ec"
"ho_impact_corrected?\",\"riegl.class?\",\"riegl.start_of_scan_line?\",\"rieg"
"l.end_of_scan_line?\",\"riegl.source_indicator?\",\"riegl.fwa?\",\"riegl.wav"
"eform_available?\",\"riegl.wfm_sbl_id?\",\"riegl.wfm_echo_time_offset?\"],\""
"extension\":\"sdcx\",\"metadata\":[\"riegl.atmosphere\",\"riegl.beam_geometry\""
",\"riegl.device_geometry\",\"riegl.device\",\"riegl.gaussian_decomposition?"
"\",\"riegl.exponential_decomposition?\",\"riegl.mta_settings?\",\"riegl.near"
"_range_correction?\",\"riegl.noise_estimates?\",\"riegl.angular_notch_filt"
"er?\",\"riegl.notch_filter?\",\"riegl.pointcloud_info?\",\"riegl.pulse_posit"
"ion_modulation?\",\"riegl.range_statistics?\",\"riegl.receiver_internals?\""
",\"riegl.reflectance_calculation?\",\"riegl.reflectance_correction?\",\"rie"
"gl.scan_pattern\",\"riegl.time_base\",\"riegl.window_analysis?\",\"riegl.win"
"dow_echo_correction?\"],\"identifier\":\"sdcx\"}"
)

# Schema for ".sidx" files
RDB_SCHEMA_RIEGL_SIDX = (
"{\"attributes\":[\"riegl.id\",\"riegl.shot_timestamp_hr*\",\"riegl.echo_first"
"\",\"riegl.echo_count\"],\"extension\":\"sidx\",\"metadata\":[\"riegl.shot_info\""
",\"riegl.echo_info\"],\"identifier\":\"sidx\"}"
)

# Schema for ".sodx" files
RDB_SCHEMA_RIEGL_SODX = (
"{\"attributes\":[\"riegl.id\",\"riegl.shot_timestamp_hr*\",\"riegl.mirror_fac"
"et\",\"riegl.scan_segment\",\"riegl.start_of_scan_line\",\"riegl.line_angle_"
"coarse\",\"riegl.shot_origin\",\"riegl.shot_direction\",\"riegl.shot_directi"
"on_levelled?\",\"riegl.wfm_sbl_first?\",\"riegl.wfm_sbl_count?\",\"riegl.ech"
"o_first?\",\"riegl.echo_count?\"],\"extension\":\"sodx\",\"metadata\":[\"riegl.a"
"tmosphere\",\"riegl.device\",\"riegl.device_geometry\",\"riegl.device_output"
"_limits\",\"riegl.beam_geometry\",\"riegl.near_range_correction?\",\"riegl.w"
"indow_echo_correction?\",\"riegl.receiver_internals?\",\"riegl.gaussian_de"
"composition?\",\"riegl.exponential_decomposition?\",\"riegl.mta_settings?\""
",\"riegl.pulse_position_modulation?\",\"riegl.notch_filter?\",\"riegl.refle"
"ctance_calculation?\",\"riegl.scan_pattern\",\"riegl.time_base\",\"riegl.wav"
"eform_info?\",\"riegl.echo_info?\"],\"identifier\":\"sodx\"}"
)

# Schema for ".sp{C}" files
RDB_SCHEMA_RIEGL_SPC = (
"{\"attributes\":[\"riegl.id*\",\"riegl.wfm_sample_value\"],\"extension\":\"sp{C"
"}\",\"metadata\":[],\"identifier\":\"sp{C}\"}"
)

# Schema for ".vtx" files
RDB_SCHEMA_RIEGL_VTX = (
"{\"attributes\":[\"riegl.id*\",\"riegl.xyz\",\"riegl.xyz_accuracies?\"],\"exten"
"sion\":\"vtx\",\"metadata\":[\"riegl.geo_tag\"],\"identifier\":\"vtx\"}"
)

# Schema for ".vxls" files
RDB_SCHEMA_RIEGL_VXLS = (
"{\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.covariances\",\"riegl.pca_"
"axis_max\",\"riegl.pca_axis_min\",\"riegl.pca_extents\",\"riegl.point_count\""
",\"riegl.reflectance\",\"riegl.shape_id\",\"riegl.voxel_collapsed\",\"riegl.s"
"td_dev?\"],\"extension\":\"vxls\",\"metadata\":[\"riegl.voxel_info\",\"riegl.geo"
"_tag?\"],\"identifier\":\"vxls\"}"
)

# Schema for ".wdcx" files
RDB_SCHEMA_RIEGL_WDCX = (
"{\"attributes\":[\"riegl.id\",\"riegl.timestamp\",\"riegl.xyz*\",\"riegl.xyz_so"
"cs\",\"riegl.direction_medium\",\"riegl.amplitude\",\"riegl.reflectance?\",\"r"
"iegl.deviation?\",\"riegl.pulse_width?\",\"riegl.target_index\",\"riegl.targ"
"et_count\",\"riegl.mirror_facet?\",\"riegl.scan_segment?\",\"riegl.mta_unres"
"olved?\",\"riegl.mta_zone?\",\"riegl.window_echo_impact_corrected?\",\"riegl"
".rgba?\",\"riegl.class?\",\"riegl.start_of_scan_line?\",\"riegl.end_of_scan_"
"line?\",\"riegl.source_indicator?\",\"riegl.fwa?\",\"riegl.waveform_availabl"
"e?\",\"riegl.wfm_sbl_id?\",\"riegl.wfm_echo_time_offset?\",\"riegl.scan_angl"
"e\",\"riegl.scan_direction\",\"riegl.source_index?\",\"riegl.hydro_intersect"
"ion_point?\",\"riegl.hydro_intersection_normal?\"],\"extension\":\"wdcx\",\"me"
"tadata\":[\"riegl.atmosphere\",\"riegl.beam_geometry\",\"riegl.device_geomet"
"ry\",\"riegl.device\",\"riegl.gaussian_decomposition?\",\"riegl.exponential_"
"decomposition?\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"rie"
"gl.mta_settings?\",\"riegl.near_range_correction?\",\"riegl.noise_estimate"
"s?\",\"riegl.angular_notch_filter?\",\"riegl.notch_filter?\",\"riegl.pointcl"
"oud_info?\",\"riegl.pulse_position_modulation?\",\"riegl.range_statistics?"
"\",\"riegl.receiver_internals?\",\"riegl.reflectance_calculation?\",\"riegl."
"reflectance_correction?\",\"riegl.scan_pattern\",\"riegl.time_base\",\"riegl"
".waveform_settings?\",\"riegl.window_analysis?\",\"riegl.window_echo_corre"
"ction?\"],\"identifier\":\"wdcx\"}"
)

# Schema for ".wex" files
RDB_SCHEMA_RIEGL_WEX = (
"{\"attributes\":[\"riegl.id\",\"riegl.timestamp*\",\"riegl.wex_filter_valid\","
"\"riegl.wex_point_count\",\"riegl.wex_amplitude\",\"riegl.wex_amplitude_std"
"_dev\",\"riegl.wex_amplitude_min\",\"riegl.wex_amplitude_max\",\"riegl.wex_a"
"mplitude_offset\",\"riegl.wex_deviation\",\"riegl.wex_deviation_std_dev\",\""
"riegl.wex_deviation_min\",\"riegl.wex_deviation_max\",\"riegl.wex_range\",\""
"riegl.wex_range_std_dev\",\"riegl.wex_range_min\",\"riegl.wex_range_max\",\""
"riegl.wex_filter_range_min\",\"riegl.wex_filter_range_max\",\"riegl.wex_fi"
"lter_amplitude_max\"],\"extension\":\"wex\",\"metadata\":[\"riegl.device\",\"rie"
"gl.notch_filter\",\"riegl.window_analysis\"],\"identifier\":\"wex\"}"
)

# Table of all RDB file schema strings
RDB_SCHEMA_ARRAY = [
    RDB_SCHEMA_RIEGL_AVG_FWA,
    RDB_SCHEMA_RIEGL_AVG_SBX,
    RDB_SCHEMA_RIEGL_AVG_SIDX,
    RDB_SCHEMA_RIEGL_AVG_SPC,
    RDB_SCHEMA_RIEGL_CPX,
    RDB_SCHEMA_RIEGL_FWA,
    RDB_SCHEMA_RIEGL_MPX,
    RDB_SCHEMA_RIEGL_MTCH,
    RDB_SCHEMA_RIEGL_MVX,
    RDB_SCHEMA_RIEGL_OBSX,
    RDB_SCHEMA_RIEGL_OPEFX,
    RDB_SCHEMA_RIEGL_OPP,
    RDB_SCHEMA_RIEGL_OPX,
    RDB_SCHEMA_RIEGL_OWP,
    RDB_SCHEMA_RIEGL_PEFX,
    RDB_SCHEMA_RIEGL_PROJECT_POFX,
    RDB_SCHEMA_RIEGL_SCAN_POFX,
    RDB_SCHEMA_RIEGL_PROJECT_POQX,
    RDB_SCHEMA_RIEGL_SCAN_POQX,
    RDB_SCHEMA_RIEGL_PPX,
    RDB_SCHEMA_RIEGL_PROJECT_PTCH,
    RDB_SCHEMA_RIEGL_SCAN_PTCH,
    RDB_SCHEMA_RIEGL_SCANPOS_PTCH,
    RDB_SCHEMA_RIEGL_RDBX,
    RDB_SCHEMA_RIEGL_RMVX,
    RDB_SCHEMA_RIEGL_S10X,
    RDB_SCHEMA_RIEGL_SBX,
    RDB_SCHEMA_RIEGL_SDCX,
    RDB_SCHEMA_RIEGL_SIDX,
    RDB_SCHEMA_RIEGL_SODX,
    RDB_SCHEMA_RIEGL_SPC,
    RDB_SCHEMA_RIEGL_VTX,
    RDB_SCHEMA_RIEGL_VXLS,
    RDB_SCHEMA_RIEGL_WDCX,
    RDB_SCHEMA_RIEGL_WEX
]
