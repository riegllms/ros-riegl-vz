#
#*******************************************************************************
#
#  Copyright 2020 RIEGL Laser Measurement Systems
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
#  SPDX-License-Identifier: Apache-2.0
#
#*******************************************************************************
#
"""
*******************************************************************************
*
* \author  RIEGL LMS GmbH, Austria
* \brief   Description of RIEGL RDB 2 database meta data items.
* \version 2015-10-27/AW: Initial version
* \version 2015-11-25/AW: Item "Geo Tag" added
* \version 2016-10-27/AW: Item "Voxel Information" added
* \version 2016-11-17/AW: Item "Voxel Information" updated
* \version 2016-12-12/AW: Item "Range Statistics" added
* \version 2017-03-08/AW: Item "Plane Patch Statistics" added
* \version 2017-04-05/AW: Items "Atmosphere" and "Geometric Scale Factor" added
* \version 2017-08-22/AW: Items for waveform sample block and value files added
* \version 2017-10-24/AW: Item "Gaussian Decomposition" added
* \version 2017-11-13/AW: Item "riegl.scan_pattern" updated
* \version 2017-11-21/AW: Item "riegl.trajectory_info" added
* \version 2018-01-11/AW: Item "riegl.beam_geometry" added
* \version 2018-01-15/AW: Item "riegl.reflectance_calculation" added
* \version 2018-01-15/AW: Item "riegl.near_range_correction" added
* \version 2018-01-15/AW: Item "riegl.device_geometry" added
* \version 2018-02-13/AW: Item "riegl.notch_filter" added
* \version 2018-03-08/AW: Item "riegl.window_echo_correction" added
* \version 2018-03-15/AW: Item "riegl.pulse_position_modulation" added
* \version 2018-05-24/AW: Item "riegl.pixel_info" added
* \version 2018-06-08/AW: Item "riegl.shot_info" added
* \version 2018-06-08/AW: Item "riegl.echo_info" added
* \version 2018-06-14/AW: Item "riegl.mta_settings" added
* \version 2018-06-14/AW: Item "riegl.receiver_internals" added
* \version 2018-06-14/AW: Item "riegl.device_output_limits" added
* \version 2018-06-26/AW: Schema: replace "number" with "integer" if applicable
* \version 2018-07-09/AW: Item "riegl.pose_estimation" added
* \version 2018-07-09/AW: Item "riegl.pose_sensors" added
* \version 2018-09-20/AW: Item "riegl.pointcloud_info" added
* \version 2018-11-08/AW: Item "riegl.scan_pattern" updated
* \version 2018-11-13/AW: Item "riegl.receiver_internals" updated
* \version 2019-03-06/AW: Item "riegl.receiver_internals" updated
* \version 2019-03-21/AW: Item "riegl.device_geometry" updated
* \version 2019-04-15/AW: Item "riegl.point_attribute_groups" added
* \version 2019-04-30/AW: Item "riegl.waveform_settings" added
* \version 2019-10-03/AW: Item "riegl.angular_notch_filter" added
* \version 2019-10-03/AW: Item "riegl.noise_estimates" added
* \version 2019-10-25/AW: Item "riegl.window_analysis" added
* \version 2019-11-06/AW: Item "riegl.georeferencing_parameters" added
* \version 2019-11-27/AW: Item "riegl.plane_patch_matching" added
* \version 2019-12-13/AW: Items for tie-/control objects added
* \version 2019-12-19/AW: Items for tie-/control objects added
* \version 2020-02-04/AW: Item "riegl.detection_probability" added
* \version 2020-02-04/AW: Item "riegl.licenses" added
* \version 2020-04-27/AW: Item "riegl.waveform_info" updated (schema+example)
* \version 2020-09-03/AW: Item "riegl.reflectance_correction" added
* \version 2020-09-10/AW: Item "riegl.device_geometry_passive_channel" added
* \version 2020-09-25/AW: Item "riegl.georeferencing_parameters" updated
* \version 2020-09-25/AW: Item "riegl.trajectory_info" updated
* \version 2020-09-29/AW: Item "riegl.temperature_calculation" added
* \version 2020-10-23/AW: Item "riegl.exponential_decomposition" added (#3709)
* \version 2020-11-30/AW: Item "riegl.notch_filter" updated (schema)
* \version 2020-12-02/AW: Item "riegl.georeferencing_parameters" updated (schema)
* \version 2021-02-02/AW: Item "riegl.plane_slope_class_info" added (rdbplanes/#7)
* \version 2021-02-16/AW: Item "riegl.device_output_limits" updated (schema, #3811)
* \version 2021-03-03/AW: Item "riegl.exponential_decomposition" updated (schema, #3822)
* \version 2021-03-03/AW: Item "riegl.waveform_averaging_settings" added (#3821)
* \version 2021-04-01/AW: Item "riegl.voxel_info" updated (schema, #3854)
* \version 2021-04-16/AW: Item "riegl.voxel_info" updated (schema, #3866)
* \version 2021-09-30/AW: Item "riegl.waveform_info" updated (schema+example, #4016)
* \version 2021-10-04/AW: Improved spelling of the descriptions of some items
*
*******************************************************************************
"""

# Angular notch filter parameters for window glass echoes
RDB_RIEGL_ANGULAR_NOTCH_FILTER             = "riegl.angular_notch_filter"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_TITLE       = "Angular Notch Filter"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_DESCRIPTION = "Angular notch filter parameters for window glass echoes"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_STATUS      = "optional"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_SCHEMA = (
"{\"description\":\"Angular notch filter parameters for window glass echoe"
"s\",\"required\":[\"angle\",\"range_mean\",\"amplitude_mean\"],\"properties\":{\"a"
"ngle\":{\"description\":\"Angle [deg]\",\"type\":\"array\",\"items\":{\"type\":\"num"
"ber\"}},\"range_mean\":{\"description\":\"Mean range [m]\",\"type\":\"array\",\"it"
"ems\":{\"type\":\"number\"}},\"amplitude_mean\":{\"description\":\"Mean "
"amplitude [dB]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}}},\"$schema\":\""
"http://json-schema.org/draft-04/schema#\",\"title\":\"Angular Notch "
"Filter\",\"type\":\"object\"}"
)
RDB_RIEGL_ANGULAR_NOTCH_FILTER_EXAMPLE = (
"{\"angle\":[14.0,15.0,16.0,17.0,18.0,19.0,20.0,21.0,22.0,23.0,24.0],\"ran"
"ge_mean\":[0.094,0.094,0.09075,0.08675,0.0815,0.0775,0.074,0.071,0.068,"
"0.0675,0.06475],\"amplitude_mean\":[3.780913,3.780913,3.480913,3.120913,"
"2.850913,2.720913,2.680913,2.610913,2.530913,2.570913,2.570913]}"
)

# Atmospheric parameters
RDB_RIEGL_ATMOSPHERE             = "riegl.atmosphere"
RDB_RIEGL_ATMOSPHERE_TITLE       = "Atmosphere"
RDB_RIEGL_ATMOSPHERE_DESCRIPTION = "Atmospheric parameters"
RDB_RIEGL_ATMOSPHERE_STATUS      = "optional"
RDB_RIEGL_ATMOSPHERE_SCHEMA = (
"{\"description\":\"Atmospheric parameters\",\"required\":[\"temperature\",\"pre"
"ssure\",\"rel_humidity\",\"pressure_sl\",\"amsl\",\"group_velocity\",\"attenuati"
"on\",\"wavelength\"],\"properties\":{\"pressure\":{\"description\":\"Pressure "
"along measurment path "
"[mbar]\",\"type\":\"number\"},\"wavelength\":{\"description\":\"Laser wavelength"
" [nm]\",\"type\":\"number\"},\"temperature\":{\"description\":\"Temperature "
"along measurement path "
"[\\u00b0C]\",\"type\":\"number\"},\"amsl\":{\"description\":\"Height above mean "
"sea level (AMSL) "
"[m]\",\"type\":\"number\"},\"attenuation\":{\"description\":\"Atmospheric "
"attenuation "
"[1/km]\",\"type\":\"number\"},\"rel_humidity\":{\"description\":\"Relative "
"humidity along measurement path "
"[%]\",\"type\":\"number\"},\"pressure_sl\":{\"description\":\"Atmospheric "
"pressure at sea level "
"[mbar]\",\"type\":\"number\"},\"group_velocity\":{\"description\":\"Group "
"velocity of laser beam [m/s]\",\"type\":\"number\"}},\"$schema\":\"http://json"
"-schema.org/draft-04/schema#\",\"title\":\"Atmospheric "
"Parameters\",\"type\":\"object\"}"
)
RDB_RIEGL_ATMOSPHERE_EXAMPLE = (
"{\"pressure\":970,\"wavelength\":1550,\"temperature\":7,\"amsl\":0,\"attenuatio"
"n\":0.028125,\"rel_humidity\":63,\"pressure_sl\":970,\"group_velocity\":29971"
"1000.0}"
)

# Laser beam geometry details
RDB_RIEGL_BEAM_GEOMETRY             = "riegl.beam_geometry"
RDB_RIEGL_BEAM_GEOMETRY_TITLE       = "Beam Geometry"
RDB_RIEGL_BEAM_GEOMETRY_DESCRIPTION = "Laser beam geometry details"
RDB_RIEGL_BEAM_GEOMETRY_STATUS      = "optional"
RDB_RIEGL_BEAM_GEOMETRY_SCHEMA = (
"{\"description\":\"Laser beam geometry details\",\"required\":[\"beam_exit_di"
"ameter\",\"beam_divergence\"],\"properties\":{\"beam_exit_diameter\":{\"minimu"
"m\":0,\"description\":\"Beam width at exit aperture [m]\",\"exclusiveMinimum"
"\":false,\"type\":\"number\"},\"beam_divergence\":{\"minimum\":0,\"description\":"
"\"Beam divergence in far field [rad]\",\"exclusiveMinimum\":false,\"type\":\""
"number\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":"
"\"Beam Geometry\",\"type\":\"object\"}"
)
RDB_RIEGL_BEAM_GEOMETRY_EXAMPLE = (
"{\"beam_exit_diameter\":0.0072,\"beam_divergence\":0.0003}"
)

# List of control object type definitions
RDB_RIEGL_CONTROL_OBJECT_CATALOG             = "riegl.control_object_catalog"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_TITLE       = "Control Object Catalog"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_DESCRIPTION = "List of control object type definitions"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_STATUS      = "optional"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_SCHEMA = (
"{\"definitions\":{\"common\":{\"description\":\"common object properties\",\"re"
"quired\":[\"name\",\"shape\"],\"properties\":{\"description\":{\"description\":\"s"
"tring describing the "
"object\",\"type\":\"string\"},\"shape\":{\"description\":\"shape identifier\",\"en"
"um\":[\"rectangle\",\"checkerboard2x2\",\"chevron\",\"circular_disk\",\"cylinder"
"\",\"sphere\",\"round_corner_cube_prism\"],\"type\":\"string\"},\"name\":{\"descri"
"ption\":\"unique type identifier\",\"minLength\":3,\"type\":\"string\"},\"surfac"
"e_type\":{\"description\":\"surface material type\",\"enum\":[\"retro_reflecti"
"ve_foil\",\"diffuse\"],\"type\":\"string\"}},\"type\":\"object\"},\"sphere\":{\"desc"
"ription\":\"sphere\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"descripti"
"on\":\"sphere specific properties\",\"required\":[\"shape\",\"diameter\"],\"prop"
"erties\":{\"diameter\":{\"minimum\":0,\"description\":\"diameter in meters\",\"e"
"xclusiveMinimum\":true,\"type\":\"number\"},\"shape\":{\"description\":\"shape i"
"dentifier\",\"enum\":[\"sphere\"],\"type\":\"string\"}},\"type\":\"object\"}],\"type"
"\":\"object\"},\"chevron\":{\"description\":\"chevron\",\"allOf\":[{\"$ref\":\"#/def"
"initions/common\"},{\"description\":\"chevron specific properties\",\"requir"
"ed\":[\"shape\",\"outside_edge_length\",\"thickness\"],\"properties\":{\"outside"
"_edge_length\":{\"minimum\":0,\"description\":\"length of the two outer "
"edges in meters\",\"exclusiveMinimum\":true,\"type\":\"number\"},\"thickness\":"
"{\"minimum\":0,\"description\":\"thickness in meters\",\"exclusiveMinimum\":tr"
"ue,\"type\":\"number\"},\"shape\":{\"description\":\"shape identifier\",\"enum\":["
"\"chevron\"],\"type\":\"string\"}},\"type\":\"object\"}],\"type\":\"object\"},\"round"
"_corner_cube_prism\":{\"description\":\"round corner cube "
"prism\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"description\":\"round "
"corner cube prism specific properties\",\"required\":[\"shape\",\"diameter\"]"
",\"properties\":{\"offset\":{\"description\":\"offset in meters, e.g. "
"reflector constant (optional)\",\"type\":\"number\"},\"diameter\":{\"minimum\":"
"0,\"description\":\"diameter in meters\",\"exclusiveMinimum\":true,\"type\":\"n"
"umber\"},\"shape\":{\"description\":\"shape identifier\",\"enum\":[\"round_corne"
"r_cube_prism\"],\"type\":\"string\"}},\"type\":\"object\"}],\"type\":\"object\"},\"c"
"ylinder\":{\"description\":\"cylinder\",\"allOf\":[{\"$ref\":\"#/definitions/com"
"mon\"},{\"description\":\"cylinder specific properties\",\"required\":[\"shape"
"\",\"diameter\",\"height\"],\"properties\":{\"height\":{\"minimum\":0,\"descriptio"
"n\":\"height in meters\",\"exclusiveMinimum\":true,\"type\":\"number\"},\"diamet"
"er\":{\"minimum\":0,\"description\":\"diameter in meters\",\"exclusiveMinimum\""
":true,\"type\":\"number\"},\"shape\":{\"description\":\"shape identifier\",\"enum"
"\":[\"cylinder\"],\"type\":\"string\"}},\"type\":\"object\"}],\"type\":\"object\"},\"c"
"ircular_disk\":{\"description\":\"circular disk\",\"allOf\":[{\"$ref\":\"#/defin"
"itions/common\"},{\"description\":\"circular disk specific properties\",\"re"
"quired\":[\"shape\",\"diameter\"],\"properties\":{\"offset\":{\"description\":\"of"
"fset in meters, e.g. reflector constant (optional)\",\"type\":\"number\"},\""
"diameter\":{\"minimum\":0,\"description\":\"diameter in meters\",\"exclusiveMi"
"nimum\":true,\"type\":\"number\"},\"shape\":{\"description\":\"shape identifier\""
",\"enum\":[\"circular_disk\"],\"type\":\"string\"}},\"type\":\"object\"}],\"type\":\""
"object\"},\"rectangle\":{\"description\":\"rectangle\",\"allOf\":[{\"$ref\":\"#/de"
"finitions/common\"},{\"description\":\"rectangle specific properties\",\"req"
"uired\":[\"shape\",\"length\",\"width\"],\"properties\":{\"width\":{\"minimum\":0,\""
"description\":\"width in meters\",\"exclusiveMinimum\":true,\"type\":\"number\""
"},\"length\":{\"minimum\":0,\"description\":\"length in meters\",\"exclusiveMin"
"imum\":true,\"type\":\"number\"},\"shape\":{\"enum\":[\"rectangle\"],\"type\":\"stri"
"ng\"}},\"type\":\"object\"}],\"type\":\"object\"},\"checkerboard2x2\":{\"descripti"
"on\":\"checkerboard 2 by 2\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"d"
"escription\":\"checkerboard specific properties\",\"required\":[\"shape\",\"sq"
"uare_length\"],\"properties\":{\"square_length\":{\"minimum\":0,\"description\""
":\"length of a square of the checkerboard in meters\",\"exclusiveMinimum\""
":true,\"type\":\"number\"},\"shape\":{\"description\":\"shape identifier\",\"enum"
"\":[\"checkerboard2x2\"],\"type\":\"string\"}},\"type\":\"object\"}],\"type\":\"obje"
"ct\"}},\"description\":\"List of control object type definitions\",\"require"
"d\":[\"types\"],\"properties\":{\"types\":{\"uniqueItems\":true,\"type\":\"array\","
"\"items\":{\"oneOf\":[{\"$ref\":\"#/definitions/rectangle\"},{\"$ref\":\"#/defini"
"tions/checkerboard2x2\"},{\"$ref\":\"#/definitions/chevron\"},{\"$ref\":\"#/de"
"finitions/circular_disk\"},{\"$ref\":\"#/definitions/cylinder\"},{\"$ref\":\"#"
"/definitions/sphere\"},{\"$ref\":\"#/definitions/round_corner_cube_prism\"}"
"],\"type\":\"object\"}}},\"$schema\":\"http://json-schema.org/draft-04/schema"
"#\",\"title\":\"Control Object Catalog\",\"type\":\"object\"}"
)
RDB_RIEGL_CONTROL_OBJECT_CATALOG_EXAMPLE = (
"{\"types\":[{\"width\":0.3,\"description\":\"Rectangle (60cm x "
"30cm)\",\"length\":0.6,\"shape\":\"rectangle\",\"name\":\"Rectangle "
"60x30\"},{\"width\":0.4,\"description\":\"Rectangle (80cm x "
"40cm)\",\"length\":0.8,\"shape\":\"rectangle\",\"name\":\"Rectangle "
"80x40\"},{\"description\":\"Checkerboard (square length: "
"30cm)\",\"shape\":\"checkerboard2x2\",\"name\":\"Checkerboard2x2 "
"30\",\"square_length\":0.3},{\"description\":\"Checkerboard (square length: "
"50cm)\",\"shape\":\"checkerboard2x2\",\"name\":\"Checkerboard2x2 50\",\"square_l"
"ength\":0.5},{\"outside_edge_length\":0.6096,\"description\":\"Chevron "
"(a=24''; b=4'')\",\"shape\":\"chevron\",\"name\":\"Chevron "
"24''/4''\",\"thickness\":0.1016},{\"description\":\" Circular Disk "
"(diameter: "
"50cm)\",\"diameter\":0.5,\"shape\":\"circular_disk\",\"name\":\"Circular Disk "
"50\",\"surface_type\":\"diffuse\"},{\"description\":\"flat circular reflector "
"from retro-reflective "
"foil\",\"offset\":0.0,\"shape\":\"circular_disk\",\"name\":\"RIEGL flat "
"reflector 50 mm\",\"surface_type\":\"retro_reflective_foil\",\"diameter\":0.0"
"5},{\"description\":\"flat circular reflector from retro-reflective "
"foil\",\"offset\":0.0,\"shape\":\"circular_disk\",\"name\":\"RIEGL flat "
"reflector 100 mm\",\"surface_type\":\"retro_reflective_foil\",\"diameter\":0."
"1},{\"description\":\"flat circular reflector from retro-reflective "
"foil\",\"offset\":0.0,\"shape\":\"circular_disk\",\"name\":\"RIEGL flat "
"reflector 150 mm\",\"surface_type\":\"retro_reflective_foil\",\"diameter\":0."
"15},{\"description\":\"cylindrical reflector from retro-reflective "
"foil\",\"height\":0.05,\"shape\":\"cylinder\",\"name\":\"RIEGL cylindrical "
"reflector 50 mm\",\"surface_type\":\"retro_reflective_foil\",\"diameter\":0.0"
"5},{\"description\":\"cylindrical reflector from retro-reflective "
"foil\",\"height\":0.1,\"shape\":\"cylinder\",\"name\":\"RIEGL cylindrical "
"reflector 100 mm\",\"surface_type\":\"retro_reflective_foil\",\"diameter\":0."
"1},{\"description\":\"Sphere (diameter: 200 "
"mm)\",\"diameter\":0.2,\"shape\":\"sphere\",\"name\":\"Sphere 200 "
"mm\"},{\"description\":\"round corner cube prism\",\"offset\":0.0,\"diameter\":"
"0.05,\"shape\":\"round_corner_cube_prism\",\"name\":\"Corner Cube Prism 50 "
"mm\"}],\"comments\":[\"This file contains a list of control object types "
"(aka. 'catalog').\",\"Each type is described by an object,\",\"which must "
"contain at least the following parameters:\",\"  - name: unique "
"identifier of the type\",\"  - shape: one of the following supported "
"shapes:\",\"      - rectangle\",\"      - checkerboard2x2\",\"      - "
"chevron\",\"      - circular_disk\",\"      - cylinder\",\"      - sphere\",\""
"      - round_corner_cube_prism\",\"Depending on 'shape', the following "
"parameters must/may be specified:\",\"  - rectangle:\",\"      - length: "
"length in meters\",\"      - width: width in meters\",\"  - "
"checkerboard2x2:\",\"      - square_length: length of a square of the "
"checkerboard in meters\",\"  - circular_disk:\",\"      - diameter: "
"diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
"constant (optional)\",\"  - chevron:\",\"      - outside_edge_length: "
"length of the two outer edges in meters\",\"      - thickness: thickness"
" in meters\",\"  - cylinder:\",\"      - diameter: diameter in meters\",\""
"      - height:  height in meters\",\"  - sphere:\",\"      - diameter: "
"diameter in meters\",\"  - round_corner_cube_prism:\",\"      - diameter: "
"diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
"constant (optional)\",\"Optional parameters:\",\"    - description: string"
" describing the object\",\"    - surface_type: surface material type "
"(either 'retro_reflective_foil' or 'diffuse')\"]}"
)

# Details about the control object reference file
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE             = "riegl.control_object_reference_file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_TITLE       = "Control Object Reference file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_DESCRIPTION = "Details about the control object reference file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_STATUS      = "optional"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_SCHEMA = (
"{\"description\":\"Details about the control object reference "
"file\",\"title\":\"Control Object Reference file\",\"type\":\"object\",\"$schema"
"\":\"http://json-schema.org/draft-04/schema#\",\"properties\":{\"reference_f"
"ile\":{\"description\":\"Reference to a control object file\",\"required\":[\""
"file_uuid\",\"file_path\"],\"properties\":{\"file_uuid\":{\"description\":\"Cont"
"rol object file's Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"file_path\":{\"description\":\"Path of the "
"control object file relative to referring "
"file\",\"type\":\"string\"}},\"type\":\"object\"}}}"
)
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_EXAMPLE = (
"{\"reference_file\":{\"file_uuid\":\"810f5d57-eccf-49ed-b07a-0cdd109b4213\","
"\"file_path\":\"../../../10_CONTROL_OBJECTS/ControlPoints.cpx\"}}"
)

# Detection probability as a function of amplitude
RDB_RIEGL_DETECTION_PROBABILITY             = "riegl.detection_probability"
RDB_RIEGL_DETECTION_PROBABILITY_TITLE       = "Detection Probability"
RDB_RIEGL_DETECTION_PROBABILITY_DESCRIPTION = "Detection probability as a function of amplitude"
RDB_RIEGL_DETECTION_PROBABILITY_STATUS      = "optional"
RDB_RIEGL_DETECTION_PROBABILITY_SCHEMA = (
"{\"description\":\"Detection probability as a function of amplitude\",\"req"
"uired\":[\"amplitude\",\"detection_probability\"],\"properties\":{\"detection_"
"probability\":{\"description\":\"Detection probability [0..1]\",\"type\":\"arr"
"ay\",\"items\":{\"type\":\"number\"}},\"amplitude\":{\"description\":\"Amplitude ["
"dB]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}}},\"$schema\":\"http://json"
"-schema.org/draft-04/schema#\",\"title\":\"Detection "
"Probability\",\"type\":\"object\"}"
)
RDB_RIEGL_DETECTION_PROBABILITY_EXAMPLE = (
"{\"detection_probability\":[0.0,0.5,0.8,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0]"
",\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0]}"
)

# Details about the device used to acquire the point cloud
RDB_RIEGL_DEVICE             = "riegl.device"
RDB_RIEGL_DEVICE_TITLE       = "Device Information"
RDB_RIEGL_DEVICE_DESCRIPTION = "Details about the device used to acquire the point cloud"
RDB_RIEGL_DEVICE_STATUS      = "optional"
RDB_RIEGL_DEVICE_SCHEMA = (
"{\"description\":\"Details about the device used to acquire the point clo"
"ud\",\"required\":[\"device_type\",\"serial_number\"],\"properties\":{\"device_b"
"uild\":{\"description\":\"Device build variant\",\"type\":\"string\"},\"channel_"
"number\":{\"minimum\":0,\"description\":\"Laser channel number (not defined "
"or 0: single channel device)\",\"exclusiveMinimum\":false,\"type\":\"integer"
"\"},\"device_type\":{\"description\":\"Device type identifier (e.g. "
"VZ-400i)\",\"type\":\"string\"},\"channel_text\":{\"description\":\"Optional "
"channel description (e.g. 'Green Channel' for multi-channel "
"devices)\",\"type\":\"string\"},\"serial_number\":{\"description\":\"Device "
"serial number (e.g. "
"S2221234)\",\"type\":\"string\"},\"device_name\":{\"description\":\"Optional "
"device name (e.g. 'Scanner 1' for multi-scanner systems)\",\"type\":\"stri"
"ng\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Dev"
"ice Information\",\"type\":\"object\"}"
)
RDB_RIEGL_DEVICE_EXAMPLE = (
"{\"device_build\":\"\",\"channel_number\":0,\"device_type\":\"VZ-400i\",\"channel"
"_text\":\"\",\"serial_number\":\"S2221234\",\"device_name\":\"Scanner 1\"}"
)

# Scanner device geometry details
RDB_RIEGL_DEVICE_GEOMETRY             = "riegl.device_geometry"
RDB_RIEGL_DEVICE_GEOMETRY_TITLE       = "Device Geometry"
RDB_RIEGL_DEVICE_GEOMETRY_DESCRIPTION = "Scanner device geometry details"
RDB_RIEGL_DEVICE_GEOMETRY_STATUS      = "optional"
RDB_RIEGL_DEVICE_GEOMETRY_SCHEMA = (
"{\"description\":\"Scanner device geometry details\",\"required\":[\"primary\""
"],\"properties\":{\"secondary\":{\"description\":\"Additional device geometry"
" structure (optional)\",\"required\":[\"ID\",\"content\"],\"properties\":{\"cont"
"ent\":{\"description\":\"Internal calibration values\",\"type\":\"array\",\"item"
"s\":{\"type\":\"number\"}},\"ID\":{\"description\":\"Structure identifier\",\"minI"
"tems\":2,\"maxItems\":2,\"type\":\"array\",\"items\":{\"type\":\"integer\"}}},\"type"
"\":\"object\"},\"amu\":{\"description\":\"Angle Measurement "
"Unit\",\"properties\":{\"lineCC\":{\"minimum\":0,\"description\":\"Line Circle "
"Count (number of LSBs per full rotation about line axis)\",\"exclusiveMi"
"nimum\":false,\"type\":\"number\"},\"frameCC\":{\"minimum\":0,\"description\":\"Fr"
"ame Circle Count (number of LSBs per full rotation about frame axis)\","
"\"exclusiveMinimum\":false,\"type\":\"number\"}},\"type\":\"object\"},\"primary\":"
"{\"description\":\"Primary device geometry structure (mandatory)\",\"requir"
"ed\":[\"ID\",\"content\"],\"properties\":{\"content\":{\"description\":\"Internal "
"calibration values\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"ID\":{\"d"
"escription\":\"Structure identifier\",\"minItems\":2,\"maxItems\":2,\"type\":\"a"
"rray\",\"items\":{\"type\":\"integer\"}}},\"type\":\"object\"}},\"$schema\":\"http:/"
"/json-schema.org/draft-04/schema#\",\"title\":\"Device "
"Geometry\",\"type\":\"object\"}"
)
RDB_RIEGL_DEVICE_GEOMETRY_EXAMPLE = (
"{\"secondary\":{\"content\":[0],\"ID\":[91,0]},\"amu\":{\"lineCC\":124000,\"frame"
"CC\":124000},\"primary\":{\"content\":[0],\"ID\":[4,0]}}"
)

# Scanner passive channel device geometry details
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL             = "riegl.device_geometry_passive_channel"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_TITLE       = "Device Geometry Passive Channel"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_DESCRIPTION = "Scanner passive channel device geometry details"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_STATUS      = "optional"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_SCHEMA = (
"{\"description\":\"Scanner passive channel device geometry details\",\"requ"
"ired\":[\"primary\"],\"properties\":{\"primary\":{\"description\":\"Primary "
"device geometry structure (mandatory)\",\"required\":[\"ID\",\"content\"],\"pr"
"operties\":{\"content\":{\"description\":\"Internal calibration values\",\"typ"
"e\":\"array\",\"items\":{\"type\":\"number\"}},\"ID\":{\"description\":\"Structure i"
"dentifier\",\"minItems\":2,\"maxItems\":2,\"type\":\"array\",\"items\":{\"type\":\"i"
"nteger\"}}},\"type\":\"object\"}},\"$schema\":\"http://json-schema.org/draft-0"
"4/schema#\",\"title\":\"Device Geometry Passive Channel\",\"type\":\"object\"}"
)
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_EXAMPLE = (
"{\"primary\":{\"content\":[0],\"ID\":[143,0]}}"
)

# Limits of the measured values output by the device
RDB_RIEGL_DEVICE_OUTPUT_LIMITS             = "riegl.device_output_limits"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_TITLE       = "Device Output Limits"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_DESCRIPTION = "Limits of the measured values output by the device"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_STATUS      = "optional"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_SCHEMA = (
"{\"description\":\"Limits of the measured values output by the device. "
"The limits depend on the device type, measurement program and/or scan "
"pattern.\",\"title\":\"Device Output Limits\",\"type\":\"object\",\"$schema\":\"ht"
"tp://json-schema.org/draft-04/schema#\",\"properties\":{\"reflectance_maxi"
"mum\":{\"description\":\"Maximum possible reflectance in dB.\",\"type\":\"numb"
"er\"},\"background_radiation_minimum\":{\"description\":\"Minimum possible "
"background radiation.\",\"type\":\"number\"},\"amplitude_minimum\":{\"descript"
"ion\":\"Minimum possible amplitude in "
"dB.\",\"type\":\"number\"},\"reflectance_minimum\":{\"description\":\"Minimum "
"possible reflectance in "
"dB.\",\"type\":\"number\"},\"mta_zone_count_maximum\":{\"description\":\"Maximum"
" number of MTA "
"zones.\",\"type\":\"number\"},\"range_maximum\":{\"description\":\"Maximum "
"possible range in "
"meters.\",\"type\":\"number\"},\"amplitude_maximum\":{\"description\":\"Maximum "
"possible amplitude in "
"dB.\",\"type\":\"number\"},\"echo_count_maximum\":{\"description\":\"Maximum "
"number of echoes a laser shot can "
"have.\",\"type\":\"number\"},\"range_minimum\":{\"description\":\"Minimum "
"possible range in "
"meters.\",\"type\":\"number\"},\"deviation_minimum\":{\"description\":\"Minimum "
"possible pulse shape deviation.\",\"type\":\"number\"},\"deviation_maximum\":"
"{\"description\":\"Maximum possible pulse shape deviation.\",\"type\":\"numbe"
"r\"},\"background_radiation_maximum\":{\"description\":\"Maximum possible "
"background radiation.\",\"type\":\"number\"}}}"
)
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_EXAMPLE = (
"{\"amplitude_maximum\":100.0,\"reflectance_maximum\":100.0,\"amplitude_mini"
"mum\":0.0,\"mta_zone_count_maximum\":7,\"range_minimum\":2.9,\"reflectance_m"
"inimum\":-100.0,\"deviation_minimum\":-1,\"background_radiation_maximum\":0"
",\"range_maximum\":10000.0,\"deviation_maximum\":32767,\"background_radiati"
"on_minimum\":0}"
)

# Details about echo files
RDB_RIEGL_ECHO_INFO             = "riegl.echo_info"
RDB_RIEGL_ECHO_INFO_TITLE       = "Echo Information"
RDB_RIEGL_ECHO_INFO_DESCRIPTION = "Details about echo files"
RDB_RIEGL_ECHO_INFO_STATUS      = "optional"
RDB_RIEGL_ECHO_INFO_SCHEMA = (
"{\"description\":\"Details about echo files\",\"required\":[\"echo_file\"],\"pr"
"operties\":{\"echo_file\":{\"required\":[\"file_extension\"],\"properties\":{\"f"
"ile_extension\":{\"description\":\"Echo file extension, without the "
"leading dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's "
"Universally Unique Identifier (RFC 4122)\",\"type\":\"string\"}},\"type\":\"ob"
"ject\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"E"
"cho Information\",\"type\":\"object\"}"
)
RDB_RIEGL_ECHO_INFO_EXAMPLE = (
"{\"echo_file\":{\"file_extension\":\"owp\",\"file_uuid\":\"26a03615-67c0-4bea-8"
"fe8-c577378fe661\"}}"
)

# Details for exponential decomposition of full waveform data
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION             = "riegl.exponential_decomposition"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_TITLE       = "Exponential Decomposition"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_DESCRIPTION = "Details for exponential decomposition of full waveform data"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_STATUS      = "optional"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_SCHEMA = (
"{\"definitions\":{\"channel\":{\"required\":[\"delay\",\"scale\",\"parameter\"],\"p"
"roperties\":{\"scale\":{\"description\":\"amplitude "
"calibration\",\"type\":\"number\"},\"delay\":{\"description\":\"delay "
"calibration in "
"seconds\",\"type\":\"number\"},\"parameter\":{\"description\":\"parameters of "
"the syswave exponential sum\",\"required\":[\"A\",\"B\",\"gamma\",\"omega\"],\"pro"
"perties\":{\"omega\":{\"description\":\"angular frequency in "
"Hz\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"A\":{\"description\":\"real"
" part of amplitude factor in units of full-scale\",\"type\":\"array\",\"item"
"s\":{\"type\":\"number\"}},\"gamma\":{\"description\":\"decay in 1/second\",\"type"
"\":\"array\",\"items\":{\"type\":\"number\"}},\"B\":{\"description\":\"imaginary "
"part of amplitude factor in units of full-scale\",\"type\":\"array\",\"items"
"\":{\"type\":\"number\"}}},\"type\":\"object\"},\"a_lin\":{\"maximum\":1,\"descripti"
"on\":\"relative linear amplitude range [0..1]\",\"exclusiveMaximum\":false,"
"\"exclusiveMinimum\":false,\"minimum\":0,\"type\":\"number\"}},\"type\":\"object\""
"}},\"description\":\"Details for exponential decomposition of full "
"waveform data\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"ti"
"tle\":\"Exponential "
"Decomposition\",\"patternProperties\":{\"^[0-9]+$\":{\"description\":\"one "
"field per channel, field name is channel index\",\"$ref\":\"#/definitions/"
"channel\"}},\"type\":\"object\",\"additionalProperties\":false}"
)
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_EXAMPLE = (
"{\"0\":{\"scale\":1.0,\"delay\":3.783458418887631e-09,\"parameter\":{\"omega\":["
"352020896.0,3647927552.0,-1977987072.0],\"A\":[0.9772450923919678,0.3354"
"335129261017,-1.312678575515747],\"gamma\":[-1094726528.0,-769562752.0,-"
"848000064.0],\"B\":[-3.9813032150268555,0.08622030913829803,-0.315286099"
"9107361]},\"a_lin\":0.27},\"1\":{\"scale\":1.0,\"delay\":3.5e-09,\"parameter\":{"
"\"omega\":[352020896.0,3647927552.0,-1977987072.0],\"A\":[0.9,0.3,-1.3],\"g"
"amma\":[-1094726528.0,-769562752.0,-848000064.0],\"B\":[-3.9,0.0,-0.3]},\""
"a_lin\":0.9}}"
)

# Details for Gaussian decomposition of full waveform data
RDB_RIEGL_GAUSSIAN_DECOMPOSITION             = "riegl.gaussian_decomposition"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_TITLE       = "Gaussian Decomposition"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_DESCRIPTION = "Details for Gaussian decomposition of full waveform data"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_STATUS      = "optional"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_SCHEMA = (
"{\"description\":\"riegl.gaussian_decomposition contains information "
"relevant for extracting calibrated amplitudes and calibrated ranges "
"from a Gaussian decomposition of full waveform data. This information "
"is contained in a table with five columns. Two columns are to be used "
"as input: amplitude_lsb_low_power and amplitude_lsb_high_power. The "
"other three columns provide the outputs. Amplitude_db gives the "
"calibrated amplitude in the optical regime in decibels. The range "
"offset columns provide additive range offsets, given in units of "
"seconds, for each channel.\",\"required\":[\"amplitude_lsb_low_power\",\"amp"
"litude_lsb_high_power\",\"amplitude_db\",\"range_offset_sec_low_power\",\"ra"
"nge_offset_sec_high_power\"],\"properties\":{\"amplitude_lsb_high_power\":{"
"\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"range_offset_sec_low_power\""
":{\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"range_offset_sec_high_pow"
"er\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplitude_db\":{\"type\":"
"\"array\",\"items\":{\"type\":\"number\"}},\"amplitude_lsb_low_power\":{\"type\":\""
"array\",\"items\":{\"type\":\"number\"}}},\"$schema\":\"http://json-schema.org/d"
"raft-04/schema#\",\"title\":\"Gaussian Decomposition\",\"type\":\"object\"}"
)
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_EXAMPLE = (
"{\"amplitude_lsb_high_power\":[],\"range_offset_sec_low_power\":[],\"range_"
"offset_sec_high_power\":[],\"amplitude_db\":[],\"amplitude_lsb_low_power\":"
"[]}"
)

# Point cloud georeferencing information
RDB_RIEGL_GEO_TAG             = "riegl.geo_tag"
RDB_RIEGL_GEO_TAG_TITLE       = "Geo Tag"
RDB_RIEGL_GEO_TAG_DESCRIPTION = "Point cloud georeferencing information"
RDB_RIEGL_GEO_TAG_STATUS      = "optional"
RDB_RIEGL_GEO_TAG_SCHEMA = (
"{\"description\":\"Point cloud georeferencing information\",\"title\":\"Geo T"
"ag\",\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#"
"\",\"properties\":{\"crs\":{\"description\":\"Global Coordinate Reference "
"System. Please note that only 3D Cartesian Coordinate Systems are "
"allowed.\",\"properties\":{\"wkt\":{\"description\":\"\\\"Well-Known Text\\\" "
"string, OGC WKT dialect (see http://www.opengeospatial.org/standards/w"
"kt-crs)\",\"type\":\"string\"},\"epsg\":{\"minimum\":0,\"description\":\"EPSG "
"code\",\"type\":\"integer\"},\"name\":{\"description\":\"Coordinate reference "
"system name\",\"type\":\"string\"}},\"type\":\"object\"},\"pose\":{\"description\":"
"\"Coordinate Transformation Matrix to transform from File Coordinate "
"System to Global Coordinate Reference System. 4x4 matrix stored as two"
" dimensional array, row major order.\",\"minItems\":4,\"maxItems\":4,\"type\""
":\"array\",\"items\":{\"description\":\"rows\",\"minItems\":4,\"maxItems\":4,\"type"
"\":\"array\",\"items\":{\"description\":\"columns\",\"type\":\"number\"}}}}}"
)
RDB_RIEGL_GEO_TAG_EXAMPLE = (
"{\"crs\":{\"wkt\":\"GEOCCS[\\\"WGS84 Geocentric\\\",DATUM[\\\"WGS84\\\",SPHEROID[\\\""
"WGS84\\\",6378137.000,298.257223563,AUTHORITY[\\\"EPSG\\\",\\\"7030\\\"]],AUTHOR"
"ITY[\\\"EPSG\\\",\\\"6326\\\"]],PRIMEM[\\\"Greenwich\\\",0.0000000000000000,AUTHOR"
"ITY[\\\"EPSG\\\",\\\"8901\\\"]],UNIT[\\\"Meter\\\",1.00000000000000000000,AUTHORIT"
"Y[\\\"EPSG\\\",\\\"9001\\\"]],AXIS[\\\"X\\\",OTHER],AXIS[\\\"Y\\\",EAST],AXIS[\\\"Z\\\",NO"
"RTH],AUTHORITY[\\\"EPSG\\\",\\\"4978\\\"]]\",\"epsg\":4978,\"name\":\"WGS84 Geocentr"
"ic\"},\"pose\":[[-0.269827776749716,-0.723017716139738,0.635954678449952,"
"4063882.500831],[0.962908599449764,-0.20260517250352,0.178208229833847"
",1138787.607461],[0.0,0.660451759194338,0.7508684796801,4766084.550196"
"],[0.0,0.0,0.0,1.0]]}"
)

# Geometric scale factor applied to point coordinates
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR             = "riegl.geometric_scale_factor"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_TITLE       = "Geometric Scale Factor"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_DESCRIPTION = "Geometric scale factor applied to point coordinates"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_STATUS      = "optional"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_SCHEMA = (
"{\"minimum\":0,\"description\":\"Geometric scale factor applied to point co"
"ordinates\",\"type\":\"number\",\"$schema\":\"http://json-schema.org/draft-04/"
"schema#\",\"exclusiveMinimum\":true}"
)
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_EXAMPLE = (
"1.0"
)

# Parameters used for georeferencing of the point cloud
RDB_RIEGL_GEOREFERENCING_PARAMETERS             = "riegl.georeferencing_parameters"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_TITLE       = "Georeferencing Parameters"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_DESCRIPTION = "Parameters used for georeferencing of the point cloud"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_STATUS      = "optional"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_SCHEMA = (
"{\"description\":\"Parameters used for georeferencing of the point "
"cloud\",\"title\":\"Georeferencing Parameters\",\"type\":\"object\",\"$schema\":\""
"http://json-schema.org/draft-04/schema#\",\"properties\":{\"trajectory_fil"
"e\":{\"description\":\"Trajectory data used for georeferencing of the "
"point cloud\",\"required\":[\"file_extension\"],\"properties\":{\"file_extensi"
"on\":{\"description\":\"Trajectory file extension, without the leading "
"dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's Universally "
"Unique Identifier (RFC 4122)\",\"type\":\"string\"}},\"type\":\"object\"},\"socs"
"_to_rocs_matrix\":{\"description\":\"Coordinate Transformation Matrix to "
"transform from Scanner's Own Coordinate System to Record Coordinate "
"System. 4x4 matrix stored as two dimensional array, row major order.\","
"\"minItems\":4,\"maxItems\":4,\"type\":\"array\",\"items\":{\"description\":\"rows\""
",\"minItems\":4,\"maxItems\":4,\"type\":\"array\",\"items\":{\"description\":\"colu"
"mns\",\"type\":\"number\"}}},\"trajectory_offsets\":{\"description\":\"Correctio"
"n offsets applied to the trajectory data\",\"properties\":{\"offset_east\":"
"{\"description\":\"[m]\",\"type\":\"number\"},\"offset_height\":{\"description\":\""
"[m]\",\"type\":\"number\"},\"offset_time\":{\"description\":\"[s]\",\"type\":\"numbe"
"r\"},\"offset_north\":{\"description\":\"[m]\",\"type\":\"number\"},\"offset_roll\""
":{\"description\":\"[deg]\",\"type\":\"number\"},\"version\":{\"description\":\"Mea"
"ning of offset values and how to apply them; version 0: "
"Rz(yaw+offset_yaw)*Ry(pitch+offset_pitch)*Rx(roll+offset_roll), "
"version 1: Rz(yaw)*Ry(pitch)*Rx(roll) * Rz(yaw_offset)*Ry(pitch_offset"
")*Rx(roll_offset)\",\"type\":\"integer\"},\"offset_yaw\":{\"description\":\"[deg"
"]\",\"type\":\"number\"},\"offset_pitch\":{\"description\":\"[deg]\",\"type\":\"numb"
"er\"}},\"type\":\"object\"},\"socs_to_body_matrix\":{\"description\":\"Coordinat"
"e Transformation Matrix to transform from Scanner's Own Coordinate "
"System to Body Coordinate System. 4x4 matrix stored as two dimensional"
" array, row major order.\",\"minItems\":4,\"maxItems\":4,\"type\":\"array\",\"it"
"ems\":{\"description\":\"rows\",\"minItems\":4,\"maxItems\":4,\"type\":\"array\",\"i"
"tems\":{\"description\":\"columns\",\"type\":\"number\"}}},\"body_coordinate_sys"
"tem_type\":{\"description\":\"BODY coordinate frame (NED: North-East-Down,"
" ENU: East-North-Up), default: "
"NED\",\"enum\":[\"NED\",\"ENU\"],\"type\":\"string\"}}}"
)
RDB_RIEGL_GEOREFERENCING_PARAMETERS_EXAMPLE = (
"{\"trajectory_file\":{\"file_extension\":\"pofx\",\"file_uuid\":\"93a03615-66c0"
"-4bea-8ff8-c577378fe660\"},\"trajectory_offsets\":{\"offset_east\":0.15,\"of"
"fset_height\":-0.2,\"offset_time\":18.007,\"offset_north\":0.07,\"offset_rol"
"l\":0.03,\"version\":0,\"offset_yaw\":-0.45,\"offset_pitch\":0.01},\"socs_to_b"
"ody_matrix\":[[-0.269827776749716,-0.723017716139738,0.635954678449952,"
"0.0],[0.962908599449764,-0.20260517250352,0.178208229833847,0.0],[0.0,"
"0.660451759194338,0.7508684796801,0.0],[0.0,0.0,0.0,1.0]],\"body_coordi"
"nate_system_type\":\"NED\"}"
)

# License keys for software features
RDB_RIEGL_LICENSES             = "riegl.licenses"
RDB_RIEGL_LICENSES_TITLE       = "Software License Keys"
RDB_RIEGL_LICENSES_DESCRIPTION = "License keys for software features"
RDB_RIEGL_LICENSES_STATUS      = "optional"
RDB_RIEGL_LICENSES_SCHEMA = (
"{\"description\":\"License keys for software features\",\"$schema\":\"http://"
"json-schema.org/draft-04/schema#\",\"title\":\"Software License "
"Keys\",\"patternProperties\":{\"^.*$\":{\"description\":\"Each field of the "
"object represents a feature and holds a list of license keys, where "
"the field name is the feature "
"name.\",\"minItems\":1,\"type\":\"array\",\"items\":{\"description\":\"License key"
" (example: '46AE032A - 39882AC4 - 9EC0A184 - 6F163D73')\",\"type\":\"strin"
"g\"}}},\"type\":\"object\",\"additionalProperties\":false}"
)
RDB_RIEGL_LICENSES_EXAMPLE = (
"{\"MTA resolution\":[\"468E020A - 39A922E4 - B681A184 - 673E3D72\"],\"Full "
"Waveform Analysis Topography with GPU support\":[\"8AB44126 - 23B92250 -"
" 16E2689F - 34EF7E7B\"],\"Georeferencing\":[\"46AE032A - 39882AC4 - "
"9EC0A184 - 6F163D73\"],\"Full Waveform Analysis Topography\":[\"0FD5FF07 -"
" 011A1255 - 9F76CACA - 8D2ED557\"]}"
)

# Parameters for MTA processing
RDB_RIEGL_MTA_SETTINGS             = "riegl.mta_settings"
RDB_RIEGL_MTA_SETTINGS_TITLE       = "MTA Settings"
RDB_RIEGL_MTA_SETTINGS_DESCRIPTION = "Parameters for MTA processing"
RDB_RIEGL_MTA_SETTINGS_STATUS      = "optional"
RDB_RIEGL_MTA_SETTINGS_SCHEMA = (
"{\"description\":\"Parameters for MTA processing\",\"title\":\"MTA Settings\","
"\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"p"
"roperties\":{\"zone_width\":{\"minimum\":0,\"description\":\"Width of a MTA "
"zone in meter.\",\"type\":\"number\"},\"zone_count\":{\"minimum\":0,\"descriptio"
"n\":\"Maximum number of MTA zones.\",\"type\":\"integer\",\"maximum\":255},\"mod"
"ulation_depth\":{\"minimum\":0,\"description\":\"Depth of pulse position "
"modulation in meter.\",\"type\":\"number\"}}}"
)
RDB_RIEGL_MTA_SETTINGS_EXAMPLE = (
"{\"zone_width\":149.896225,\"zone_count\":23,\"modulation_depth\":9.368514}"
)

# Lookup table for range correction based on raw range
RDB_RIEGL_NEAR_RANGE_CORRECTION             = "riegl.near_range_correction"
RDB_RIEGL_NEAR_RANGE_CORRECTION_TITLE       = "Near Range Correction Table"
RDB_RIEGL_NEAR_RANGE_CORRECTION_DESCRIPTION = "Lookup table for range correction based on raw range"
RDB_RIEGL_NEAR_RANGE_CORRECTION_STATUS      = "optional"
RDB_RIEGL_NEAR_RANGE_CORRECTION_SCHEMA = (
"{\"description\":\"Lookup table for range correction based on raw range\","
"\"required\":[\"delta\",\"content\"],\"properties\":{\"content\":{\"description\":"
"\"Correction value [m] to be added to the raw range\",\"minItems\":1,\"maxI"
"tems\":2000,\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"delta\":{\"descrip"
"tion\":\"Delta between table entries [m], first entry is at range = 0 m\""
",\"type\":\"number\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\""
",\"title\":\"Near Range Correction Table\",\"type\":\"object\"}"
)
RDB_RIEGL_NEAR_RANGE_CORRECTION_EXAMPLE = (
"{\"content\":[0.0],\"delta\":0.512}"
)

# Standard deviation for range and amplitude as a function of amplitude
RDB_RIEGL_NOISE_ESTIMATES             = "riegl.noise_estimates"
RDB_RIEGL_NOISE_ESTIMATES_TITLE       = "Noise Estimates"
RDB_RIEGL_NOISE_ESTIMATES_DESCRIPTION = "Standard deviation for range and amplitude as a function of amplitude"
RDB_RIEGL_NOISE_ESTIMATES_STATUS      = "optional"
RDB_RIEGL_NOISE_ESTIMATES_SCHEMA = (
"{\"description\":\"Standard deviation for range and amplitude as a "
"function of amplitude\",\"required\":[\"amplitude\",\"range_sigma\",\"amplitud"
"e_sigma\"],\"properties\":{\"amplitude_sigma\":{\"description\":\"Sigma "
"amplitude [dB]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"range_sigma"
"\":{\"description\":\"Sigma range [m]\",\"type\":\"array\",\"items\":{\"type\":\"num"
"ber\"}},\"amplitude\":{\"description\":\"Amplitude [dB]\",\"type\":\"array\",\"ite"
"ms\":{\"type\":\"number\"}}},\"$schema\":\"http://json-schema.org/draft-04/sch"
"ema#\",\"title\":\"Noise Estimates\",\"type\":\"object\"}"
)
RDB_RIEGL_NOISE_ESTIMATES_EXAMPLE = (
"{\"amplitude_sigma\":[0.988,0.988,0.875,0.774,0.686,0.608,0.54,0.482,0.4"
"32,0.39,0.354],\"range_sigma\":[0.065,0.056,0.046,0.038,0.032,0.027,0.02"
"4,0.021,0.018,0.016,0.014],\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7."
"0,8.0,9.0,10.0]}"
)

# Notch filter parameters for window glass echoes
RDB_RIEGL_NOTCH_FILTER             = "riegl.notch_filter"
RDB_RIEGL_NOTCH_FILTER_TITLE       = "Notch Filter"
RDB_RIEGL_NOTCH_FILTER_DESCRIPTION = "Notch filter parameters for window glass echoes"
RDB_RIEGL_NOTCH_FILTER_STATUS      = "optional"
RDB_RIEGL_NOTCH_FILTER_SCHEMA = (
"{\"description\":\"Notch filter parameters for window glass echoes\",\"requ"
"ired\":[\"range_minimum\",\"range_maximum\",\"amplitude_maximum\"],\"propertie"
"s\":{\"amplitude_maximum\":{\"minimum\":0,\"description\":\"Maximum amplitude "
"[dB]\",\"type\":\"number\"},\"range_maximum\":{\"description\":\"Maximum range "
"[m]\",\"type\":\"number\"},\"range_minimum\":{\"description\":\"Minimum range [m"
"]\",\"type\":\"number\"}},\"$schema\":\"http://json-schema.org/draft-04/schema"
"#\",\"title\":\"Notch Filter\",\"type\":\"object\"}"
)
RDB_RIEGL_NOTCH_FILTER_EXAMPLE = (
"{\"amplitude_maximum\":18.0,\"range_maximum\":0.2,\"range_minimum\":-0.5}"
)

# Details about the pixels contained in the file
RDB_RIEGL_PIXEL_INFO             = "riegl.pixel_info"
RDB_RIEGL_PIXEL_INFO_TITLE       = "Pixel Information"
RDB_RIEGL_PIXEL_INFO_DESCRIPTION = "Details about the pixels contained in the file"
RDB_RIEGL_PIXEL_INFO_STATUS      = "optional"
RDB_RIEGL_PIXEL_INFO_SCHEMA = (
"{\"definitions\":{\"pixel_size\":{\"description\":\"Size of pixels.\",\"minItem"
"s\":2,\"maxItems\":2,\"type\":\"array\",\"items\":{\"minimum\":0,\"description\":\"L"
"ength of pixel edge [m].\",\"type\":\"number\"}}},\"description\":\"Details "
"about the pixels contained in the "
"file\",\"required\":[\"size\"],\"properties\":{\"size\":{\"description\":\"Size of"
" pixels in file coordinate system.\",\"$ref\":\"#/definitions/pixel_size\"}"
",\"size_llcs\":{\"description\":\"Size of pixels in a locally levelled "
"cartesian coordinate system (xy). This is only used for pixels based "
"on a map projection.\",\"$ref\":\"#/definitions/pixel_size\"}},\"$schema\":\"h"
"ttp://json-schema.org/draft-04/schema#\",\"title\":\"Pixel "
"Information\",\"type\":\"object\"}"
)
RDB_RIEGL_PIXEL_INFO_EXAMPLE = (
"{\"size\":[0.5971642834779395,0.5971642834779395],\"size_llcs\":[0.5156575"
"252891171,0.5130835356683303]}"
)

# Details about the plane patch matching process
RDB_RIEGL_PLANE_PATCH_MATCHING             = "riegl.plane_patch_matching"
RDB_RIEGL_PLANE_PATCH_MATCHING_TITLE       = "Plane Patch Matching"
RDB_RIEGL_PLANE_PATCH_MATCHING_DESCRIPTION = "Details about the plane patch matching process"
RDB_RIEGL_PLANE_PATCH_MATCHING_STATUS      = "optional"
RDB_RIEGL_PLANE_PATCH_MATCHING_SCHEMA = (
"{\"definitions\":{\"file_reference\":{\"description\":\"Reference to a plane "
"patch file\",\"required\":[\"file_uuid\",\"file_path\"],\"properties\":{\"file_u"
"uid\":{\"description\":\"Plane patch file's Universally Unique Identifier "
"(RFC 4122)\",\"type\":\"string\"},\"file_path\":{\"description\":\"Path of the "
"plane patch file relative to the match "
"file\",\"type\":\"string\"}},\"type\":\"object\"}},\"description\":\"Details about"
" the plane patch matching process\",\"required\":[\"plane_patch_file_one\","
"\"plane_patch_file_two\"],\"properties\":{\"plane_patch_file_one\":{\"descrip"
"tion\":\"Reference to the plane patch file one\",\"$ref\":\"#/definitions/fi"
"le_reference\"},\"plane_patch_file_two\":{\"description\":\"Reference to the"
" plane patch file two\",\"$ref\":\"#/definitions/file_reference\"}},\"$schem"
"a\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Plane Patch "
"Matching\",\"type\":\"object\"}"
)
RDB_RIEGL_PLANE_PATCH_MATCHING_EXAMPLE = (
"{\"plane_patch_file_one\":{\"file_uuid\":\"810f5d57-eccf-49ed-b07a-0cdd109b"
"4213\",\"file_path\":\"Record009_Line001/191025_121410_Scanner_1.ptch\"},\"p"
"lane_patch_file_two\":{\"file_uuid\":\"fa47d509-a64e-49ce-8b14-ff3130fbefa"
"9\",\"file_path\":\"project.ptch\"}}"
)

# Statistics about plane patches found by plane patch extractor
RDB_RIEGL_PLANE_PATCH_STATISTICS             = "riegl.plane_patch_statistics"
RDB_RIEGL_PLANE_PATCH_STATISTICS_TITLE       = "Plane Patch Statistics"
RDB_RIEGL_PLANE_PATCH_STATISTICS_DESCRIPTION = "Statistics about plane patches found by plane patch extractor"
RDB_RIEGL_PLANE_PATCH_STATISTICS_STATUS      = "optional"
RDB_RIEGL_PLANE_PATCH_STATISTICS_SCHEMA = (
"{\"description\":\"Statistics about plane patches found by plane patch "
"extractor\",\"title\":\"Plane Patch Statistics\",\"type\":\"object\",\"$schema\":"
"\"http://json-schema.org/draft-04/schema#\",\"properties\":{\"total_area\":{"
"\"description\":\"sum of all plane patch areas [m\\u00b2]\",\"type\":\"number\""
"},\"total_horizontal_area\":{\"description\":\"sum of all plane patch areas"
" projected to horizontal plane [m\\u00b2]\",\"type\":\"number\"}}}"
)
RDB_RIEGL_PLANE_PATCH_STATISTICS_EXAMPLE = (
"{\"total_area\":14007.965,\"total_horizontal_area\":13954.601}"
)

# Settings and classes for plane slope classification
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO             = "riegl.plane_slope_class_info"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_TITLE       = "Plane Slope Class Info"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_DESCRIPTION = "Settings and classes for plane slope classification"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_STATUS      = "optional"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_SCHEMA = (
"{\"definitions\":{\"method-2\":{\"description\":\"Classification method 2\",\"r"
"equired\":[\"plane_classification_method\",\"sloping_plane_classes_minimum"
"_angle\",\"sloping_plane_classes_maximum_angle\"],\"properties\":{\"sloping_"
"plane_classes_maximum_angle\":{\"minimum\":-360.0,\"description\":\"maximum "
"inclination angle of sloping plane patches [deg]\",\"type\":\"number\",\"max"
"imum\":360.0},\"plane_classification_method\":{\"minimum\":2,\"description\":"
"\"method ID (=2)\",\"type\":\"integer\",\"maximum\":2},\"sloping_plane_classes_"
"minimum_angle\":{\"minimum\":-360.0,\"description\":\"minimum inclination "
"angle of sloping plane patches [deg]\",\"type\":\"number\",\"maximum\":360.0}"
"},\"type\":\"object\"},\"method-1\":{\"description\":\"Classification method 1\""
",\"required\":[\"plane_classification_method\",\"maximum_inclination_angle_"
"horizontal\"],\"properties\":{\"plane_classification_method\":{\"minimum\":1,"
"\"description\":\"method ID (=1)\",\"type\":\"integer\",\"maximum\":1},\"maximum_"
"inclination_angle_horizontal\":{\"minimum\":-360.0,\"description\":\"maximum"
" inclination angle of horizontal plane patches [deg]\",\"type\":\"number\","
"\"maximum\":360.0}},\"type\":\"object\"}},\"description\":\"Settings and "
"classes for plane slope classification\",\"required\":[\"settings\",\"classe"
"s\"],\"properties\":{\"classes\":{\"description\":\"Class definition "
"table\",\"patternProperties\":{\"^[0-9]+$\":{\"description\":\"one field per "
"class, field name is class number, field value is class name\",\"type\":\""
"string\"}},\"type\":\"object\",\"additionalProperties\":false},\"settings\":{\"d"
"escription\":\"Classification settings, details see documentation of rdb"
"planes\",\"oneOf\":[{\"$ref\":\"#/definitions/method-1\"},{\"$ref\":\"#/definiti"
"ons/method-2\"}],\"type\":\"object\"}},\"$schema\":\"http://json-schema.org/dr"
"aft-04/schema#\",\"title\":\"Plane Slope Class Info\",\"type\":\"object\"}"
)
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_EXAMPLE = (
"{\"classes\":{\"11\":\"sloping, pointing down and south\",\"6\":\"vertical, "
"pointing east\",\"10\":\"sloping, pointing down and east\",\"9\":\"vertical, "
"pointing west\",\"14\":\"horizontal, pointing down\",\"13\":\"sloping, "
"pointing down and west\",\"1\":\"horizontal, pointing up\",\"7\":\"vertical, "
"pointing south\",\"2\":\"sloping, pointing up and east\",\"4\":\"sloping, "
"pointing up and north\",\"8\":\"vertical, pointing north\",\"3\":\"sloping, "
"pointing up and south\",\"5\":\"sloping, pointing up and "
"west\",\"12\":\"sloping, pointing down and north\"},\"settings\":{\"sloping_pl"
"ane_classes_maximum_angle\":70.0,\"plane_classification_method\":2,\"slopi"
"ng_plane_classes_minimum_angle\":10.0}}"
)

# Grouping and sorting of point attributes for visualization purposes
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS             = "riegl.point_attribute_groups"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_TITLE       = "Point Attribute Groups"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_DESCRIPTION = "Grouping and sorting of point attributes for visualization purposes"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_STATUS      = "optional"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_SCHEMA = (
"{\"description\":\"Grouping and sorting of point attributes for "
"visualization purposes\",\"$schema\":\"http://json-schema.org/draft-04/sch"
"ema#\",\"title\":\"Point Attribute "
"Groups\",\"patternProperties\":{\"^.*$\":{\"description\":\"Each field of the "
"object represents a point attribute group and holds a list of point "
"attributes, where the field name is the group "
"name.\",\"minItems\":1,\"type\":\"array\",\"items\":{\"description\":\"Point "
"attribute full name or name pattern (perl regular expression syntax)\","
"\"type\":\"string\"}}},\"type\":\"object\",\"additionalProperties\":false}"
)
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_EXAMPLE = (
"{\"Coordinates/Vectors\":[\"riegl.xyz\",\"riegl.range\",\"riegl.theta\",\"riegl"
".phi\"],\"Primary Attributes\":[\"riegl.reflectance\",\"riegl.amplitude\",\"ri"
"egl.deviation\"],\"Time\":[\"riegl.timestamp\"],\"Other "
"Attributes\":[\"riegl.selected\",\"riegl.visible\"],\"Secondary "
"Attributes\":[\"riegl.mirror_facet\",\"riegl.waveform_available\"]}"
)

# Details about point cloud files
RDB_RIEGL_POINTCLOUD_INFO             = "riegl.pointcloud_info"
RDB_RIEGL_POINTCLOUD_INFO_TITLE       = "Point Cloud Information"
RDB_RIEGL_POINTCLOUD_INFO_DESCRIPTION = "Details about point cloud files"
RDB_RIEGL_POINTCLOUD_INFO_STATUS      = "optional"
RDB_RIEGL_POINTCLOUD_INFO_SCHEMA = (
"{\"description\":\"Details about point cloud files\",\"title\":\"Point Cloud "
"Information\",\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-0"
"4/schema#\",\"properties\":{\"project\":{\"description\":\"Project "
"name\",\"type\":\"string\"},\"field_of_application\":{\"description\":\"Field of"
" application\",\"enum\":[\"unknown\",\"SLS\",\"TLS\",\"KLS\",\"MLS\",\"ULS\",\"ALS\",\"B"
"LS\",\"ILS\"],\"type\":\"string\"},\"comments\":{\"description\":\"Comments\",\"type"
"\":\"string\"}}}"
)
RDB_RIEGL_POINTCLOUD_INFO_EXAMPLE = (
"{\"project\":\"Campaign 4\",\"field_of_application\":\"ALS\",\"comments\":\"Line "
"3\"}"
)

# Estimated position and orientation information
RDB_RIEGL_POSE_ESTIMATION             = "riegl.pose_estimation"
RDB_RIEGL_POSE_ESTIMATION_TITLE       = "Pose Estimation"
RDB_RIEGL_POSE_ESTIMATION_DESCRIPTION = "Estimated position and orientation information"
RDB_RIEGL_POSE_ESTIMATION_STATUS      = "optional"
RDB_RIEGL_POSE_ESTIMATION_SCHEMA = (
"{\"description\":\"Estimated position and orientation information as "
"measured by GNSS, IMU or inclination sensors\",\"required\":[\"orientation"
"\"],\"properties\":{\"barometric_height_amsl\":{\"description\":\"Altitude "
"determined based on the atmospheric pressure according to the standard"
" atmosphere laws "
"[m].\",\"type\":\"number\"},\"position\":{\"description\":\"Position coordinates"
" and position accuracy values as measured by GNSS in the specified "
"Coordinate Reference System (CRS)\",\"required\":[\"coordinate_1\",\"coordin"
"ate_2\",\"coordinate_3\",\"horizontal_accuracy\",\"vertical_accuracy\",\"crs\"]"
",\"properties\":{\"horizontal_accuracy\":{\"minimum\":0,\"description\":\"Horiz"
"ontal accuracy [m]\",\"exclusiveMinimum\":true,\"type\":\"number\"},\"coordina"
"te_3\":{\"description\":\"Coordinate 3 as defined by axis 3 of the "
"specified CRS (e.g., Z, "
"Altitude)\",\"type\":\"number\"},\"crs\":{\"description\":\"Global Coordinate "
"Reference System\",\"required\":[\"epsg\"],\"properties\":{\"wkt\":{\"descriptio"
"n\":\"\\\"Well-Known Text\\\" string, OGC WKT dialect (see http://www.openge"
"ospatial.org/standards/wkt-crs)\",\"type\":\"string\"},\"epsg\":{\"minimum\":0,"
"\"description\":\"EPSG code\",\"type\":\"integer\"}},\"type\":\"object\"},\"coordin"
"ate_1\":{\"description\":\"Coordinate 1 as defined by axis 1 of the "
"specified CRS (e.g., X, Latitude)\",\"type\":\"number\"},\"vertical_accuracy"
"\":{\"minimum\":0,\"description\":\"Vertical accuracy [m]\",\"exclusiveMinimum"
"\":true,\"type\":\"number\"},\"coordinate_2\":{\"description\":\"Coordinate 2 as"
" defined by axis 2 of the specified CRS (e.g., Y, Longitude)\",\"type\":\""
"number\"}},\"type\":\"object\"},\"orientation\":{\"description\":\"Orientation "
"values and orientation accuracies, measured with IMU or inclination se"
"nsors.\",\"required\":[\"roll\",\"pitch\",\"yaw\",\"roll_accuracy\",\"pitch_accura"
"cy\",\"yaw_accuracy\"],\"properties\":{\"yaw_accuracy\":{\"minimum\":0,\"descrip"
"tion\":\"Yaw angle accuracy [deg]\",\"exclusiveMinimum\":true,\"type\":\"numbe"
"r\"},\"roll_accuracy\":{\"minimum\":0,\"description\":\"Roll angle accuracy [d"
"eg]\",\"exclusiveMinimum\":true,\"type\":\"number\"},\"pitch_accuracy\":{\"minim"
"um\":0,\"description\":\"Pitch angle accuracy [deg]\",\"exclusiveMinimum\":tr"
"ue,\"type\":\"number\"},\"yaw\":{\"minimum\":-360,\"description\":\"Yaw angle "
"about scanner Z-axis [deg]\",\"type\":\"number\",\"maximum\":360},\"roll\":{\"mi"
"nimum\":-360,\"description\":\"Roll angle about scanner X-axis [deg]\",\"typ"
"e\":\"number\",\"maximum\":360},\"pitch\":{\"minimum\":-360,\"description\":\"Pitc"
"h angle about scanner Y-axis [deg]\",\"type\":\"number\",\"maximum\":360}},\"t"
"ype\":\"object\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"t"
"itle\":\"Pose Estimation\",\"type\":\"object\"}"
)
RDB_RIEGL_POSE_ESTIMATION_EXAMPLE = (
"{\"barometric_height_amsl\":386.7457796227932,\"position\":{\"horizontal_ac"
"curacy\":0.810699999332428,\"coordinate_3\":362.7124938964844,\"crs\":{\"wkt"
"\":\"GEOGCS[\\\"WGS84 / Geographic\\\",DATUM[\\\"WGS84\\\",SPHEROID[\\\"WGS84\\\",63"
"78137.000,298.257223563,AUTHORITY[\\\"EPSG\\\",\\\"7030\\\"]],AUTHORITY[\\\"EPSG"
"\\\",\\\"6326\\\"]],PRIMEM[\\\"Greenwich\\\",0.0000000000000000,AUTHORITY[\\\"EPSG"
"\\\",\\\"8901\\\"]],UNIT[\\\"Degree\\\",0.01745329251994329547,AUTHORITY[\\\"EPSG\\"
"\",\\\"9102\\\"]],AXIS[\\\"Latitude\\\",NORTH],AXIS[\\\"Longitude\\\",EAST],AUTHORI"
"TY[\\\"EPSG\\\",\\\"4979\\\"]]\",\"epsg\":4979},\"coordinate_1\":48.655799473,\"vert"
"ical_accuracy\":1.3314999341964722,\"coordinate_2\":15.645033406},\"orient"
"ation\":{\"yaw_accuracy\":1.0094337839368757,\"roll_accuracy\":0.0094337839"
"36875745,\"pitch_accuracy\":0.009433783936875745,\"yaw\":101.8729363029204"
"5,\"roll\":3.14743073066123,\"pitch\":1.509153024827064}}"
)

# Details on position and orientation sensors
RDB_RIEGL_POSE_SENSORS             = "riegl.pose_sensors"
RDB_RIEGL_POSE_SENSORS_TITLE       = "Pose Sensors"
RDB_RIEGL_POSE_SENSORS_DESCRIPTION = "Details on position and orientation sensors"
RDB_RIEGL_POSE_SENSORS_STATUS      = "optional"
RDB_RIEGL_POSE_SENSORS_SCHEMA = (
"{\"definitions\":{\"vector\":{\"minItems\":3,\"maxItems\":3,\"type\":\"array\",\"it"
"ems\":{\"description\":\"Index 0=X, 1=Y, 2=Z "
"component\",\"type\":\"number\"}}},\"description\":\"Details on position and "
"orientation sensors\",\"required\":[\"gyroscope\",\"accelerometer\",\"magnetic"
"_field_sensor\"],\"properties\":{\"magnetic_field_sensor\":{\"description\":\""
"Magnetic Field Sensor details\",\"required\":[\"unit\",\"x_axis\",\"y_axis\",\"z"
"_axis\",\"offset\",\"fixed\",\"relative_nonlinearity\"],\"properties\":{\"fixed\""
":{\"description\":\"Distortion of magnetic field caused by non-rotating "
"scanner part\",\"$ref\":\"#/definitions/vector\"},\"x_axis\":{\"description\":\""
"Sensitive X axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"offset\":{\"description\":\"Value to be"
" subtracted from raw measurement values\",\"$ref\":\"#/definitions/vector\""
"},\"y_axis\":{\"description\":\"Sensitive Y axis of sensor at frame angle ="
" 0\",\"$ref\":\"#/definitions/vector\"},\"z_axis\":{\"description\":\"Sensitive "
"Z axis of sensor at frame angle = 0\",\"$ref\":\"#/definitions/vector\"},\"u"
"nit\":{\"minimum\":0,\"description\":\"Unit of raw data and calibration "
"values, 1 LSB in nT\",\"exclusiveMinimum\":true,\"type\":\"number\"},\"relativ"
"e_nonlinearity\":{\"description\":\"Relative nonlinearity, dimensionless\","
"\"$ref\":\"#/definitions/vector\"}},\"type\":\"object\"},\"gyroscope\":{\"descrip"
"tion\":\"Gyroscope details\",\"required\":[\"unit\",\"x_axis\",\"y_axis\",\"z_axis"
"\",\"offset\",\"origin\",\"relative_nonlinearity\"],\"properties\":{\"x_axis\":{\""
"description\":\"Sensitive X axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"offset\":{\"description\":\"Value to be"
" subtracted from raw measurement "
"values\",\"$ref\":\"#/definitions/vector\"},\"origin\":{\"description\":\"Sensor"
" origin in SOCS [m] at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":{\"description\":\"Sensitive Y"
" axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"z_axis\":{\"description\":\"Sensitive Z"
" axis of sensor at frame angle = 0\",\"$ref\":\"#/definitions/vector\"},\"un"
"it\":{\"minimum\":0,\"description\":\"Unit of raw data and calibration "
"values, 1 LSB in rad/s\",\"exclusiveMinimum\":true,\"type\":\"number\"},\"rela"
"tive_nonlinearity\":{\"description\":\"Relative nonlinearity, dimensionles"
"s\",\"$ref\":\"#/definitions/vector\"}},\"type\":\"object\"},\"accelerometer\":{\""
"description\":\"Accelerometer details\",\"required\":[\"unit\",\"x_axis\",\"y_ax"
"is\",\"z_axis\",\"offset\",\"origin\",\"relative_nonlinearity\"],\"properties\":{"
"\"x_axis\":{\"description\":\"Sensitive X axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"offset\":{\"description\":\"Value to be"
" subtracted from raw measurement "
"values\",\"$ref\":\"#/definitions/vector\"},\"origin\":{\"description\":\"Sensor"
" origin in SOCS [m] at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":{\"description\":\"Sensitive Y"
" axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"z_axis\":{\"description\":\"Sensitive Z"
" axis of sensor at frame angle = 0\",\"$ref\":\"#/definitions/vector\"},\"un"
"it\":{\"minimum\":0,\"description\":\"Unit of raw data and calibration "
"values, 1 LSB in 9.81 m/s\\u00b2\",\"exclusiveMinimum\":true,\"type\":\"numbe"
"r\"},\"relative_nonlinearity\":{\"description\":\"Relative nonlinearity, dim"
"ensionless\",\"$ref\":\"#/definitions/vector\"}},\"type\":\"object\"}},\"$schema"
"\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Pose "
"Sensors\",\"type\":\"object\"}"
)
RDB_RIEGL_POSE_SENSORS_EXAMPLE = (
"{\"magnetic_field_sensor\":{\"fixed\":[-1576.010498046875,1596.08178710937"
"5,0.0],\"x_axis\":[-0.011162743903696537,-2.315962774446234e-05,0.000168"
"18844596855342],\"offset\":[-23812.052734375,5606.57666015625,2493.28125"
"],\"y_axis\":[0.00027888521435670555,-0.011427424848079681,-5.2048297220"
"60822e-05],\"z_axis\":[0.00041987866279669106,7.876977906562388e-05,0.01"
"1407104320824146],\"unit\":91.74311828613281,\"relative_nonlinearity\":[0."
"0,0.0,0.0]},\"gyroscope\":{\"x_axis\":[-121.195556640625,0.821971416473388"
"7,0.2313031703233719],\"offset\":[-50.92609786987305,146.15643310546875,"
"62.4327278137207],\"origin\":[0.026900000870227814,-0.03999999910593033,"
"-0.08950000256299973],\"y_axis\":[-0.440765917301178,-0.7897399663925171"
",119.5894775390625],\"z_axis\":[0.555869996547699,119.22135162353516,0.4"
"67585027217865],\"unit\":0.00014544410805683583,\"relative_nonlinearity\":"
"[2.888176311444113e-07,1.06274164579645e-07,-1.7186295080634935e-39]},"
"\"accelerometer\":{\"x_axis\":[-15008.123046875,56.956390380859375,-60.517"
"5666809082],\"offset\":[-733.3636474609375,58.969032287597656,1060.25500"
"48828125],\"origin\":[0.026900000870227814,-0.03999999910593033,-0.08950"
"000256299973],\"y_axis\":[-7.027288913726807,-44.12333679199219,14952.37"
"01171875],\"z_axis\":[1.639882206916809,15166.744140625,-116.99742889404"
"297],\"unit\":6.666666740784422e-05,\"relative_nonlinearity\":[0.0,0.0,0.0"
"]}}"
)

# Laser pulse position modulation used for MTA resolution
RDB_RIEGL_PULSE_POSITION_MODULATION             = "riegl.pulse_position_modulation"
RDB_RIEGL_PULSE_POSITION_MODULATION_TITLE       = "Pulse Position Modulation"
RDB_RIEGL_PULSE_POSITION_MODULATION_DESCRIPTION = "Laser pulse position modulation used for MTA resolution"
RDB_RIEGL_PULSE_POSITION_MODULATION_STATUS      = "optional"
RDB_RIEGL_PULSE_POSITION_MODULATION_SCHEMA = (
"{\"description\":\"Laser pulse position modulation used for MTA resolutio"
"n\",\"required\":[\"length\",\"num_mod_ampl\",\"pulse_interval\"],\"properties\":"
"{\"num_mod_ampl\":{\"minimum\":0,\"description\":\"Number of different "
"modulation amplitudes (2: binary modulation)\",\"type\":\"integer\",\"maximu"
"m\":255},\"code_phase_mode\":{\"minimum\":0,\"description\":\"0: no "
"synchronization, 1: toggle between 2 phases, 2: increment with phase_i"
"ncrement\",\"type\":\"integer\",\"maximum\":255},\"length\":{\"minimum\":0,\"descr"
"iption\":\"Length of code\",\"type\":\"integer\",\"maximum\":255},\"pulse_interv"
"al\":{\"description\":\"Explicit table of the pulse position modulation "
"used for MTA resolution. Table gives times between successive laser "
"pulses in seconds.\",\"type\":\"array\",\"items\":{\"minimum\":0,\"type\":\"number"
"\"}},\"phase_step\":{\"minimum\":0,\"description\":\"Step width in phase of "
"modulation code from line to line\",\"type\":\"integer\",\"maximum\":255}},\"$"
"schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Pulse "
"Position Modulation\",\"type\":\"object\"}"
)
RDB_RIEGL_PULSE_POSITION_MODULATION_EXAMPLE = (
"{\"num_mod_ampl\":2,\"code_phase_mode\":2,\"length\":31,\"pulse_interval\":[2."
"759375e-06,2.759375e-06,2.759375e-06,2.759375e-06,2.821875e-06,2.75937"
"5e-06,2.759375e-06,2.821875e-06,2.759375e-06,2.821875e-06,2.821875e-06"
",2.759375e-06,2.759375e-06,2.821875e-06,2.821875e-06,2.821875e-06,2.82"
"1875e-06,2.821875e-06,2.759375e-06,2.759375e-06,2.759375e-06,2.821875e"
"-06,2.821875e-06,2.759375e-06,2.821875e-06,2.821875e-06,2.821875e-06,2"
".759375e-06,2.821875e-06,2.759375e-06,2.821875e-06],\"phase_step\":5}"
)

# Statistics about target distance wrt. SOCS origin
RDB_RIEGL_RANGE_STATISTICS             = "riegl.range_statistics"
RDB_RIEGL_RANGE_STATISTICS_TITLE       = "Range Statistics"
RDB_RIEGL_RANGE_STATISTICS_DESCRIPTION = "Statistics about target distance wrt. SOCS origin"
RDB_RIEGL_RANGE_STATISTICS_STATUS      = "optional"
RDB_RIEGL_RANGE_STATISTICS_SCHEMA = (
"{\"description\":\"Statistics about target distance wrt. SOCS origin\",\"re"
"quired\":[\"minimum\",\"average\",\"maximum\",\"std_dev\"],\"properties\":{\"minim"
"um\":{\"description\":\"Minimum "
"value\",\"type\":\"number\"},\"maximum\":{\"description\":\"Maximum "
"value\",\"type\":\"number\"},\"average\":{\"description\":\"Average "
"value\",\"type\":\"number\"},\"std_dev\":{\"description\":\"Standard deviation\","
"\"type\":\"number\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\","
"\"title\":\"Range Statistics\",\"type\":\"object\"}"
)
RDB_RIEGL_RANGE_STATISTICS_EXAMPLE = (
"{\"minimum\":0.919,\"maximum\":574.35,\"average\":15.49738,\"std_dev\":24.349}"
)

# Receiver Internals
RDB_RIEGL_RECEIVER_INTERNALS             = "riegl.receiver_internals"
RDB_RIEGL_RECEIVER_INTERNALS_TITLE       = "Receiver Internals"
RDB_RIEGL_RECEIVER_INTERNALS_DESCRIPTION = "Receiver Internals"
RDB_RIEGL_RECEIVER_INTERNALS_STATUS      = "optional"
RDB_RIEGL_RECEIVER_INTERNALS_SCHEMA = (
"{\"definitions\":{\"fp_table\":{\"required\":[\"ch\",\"tc\",\"nx\",\"ny\",\"tv\"],\"pro"
"perties\":{\"tv\":{\"items\":{\"oneOf\":[{\"$ref\":\"#/definitions/fp_table_row\""
"},{\"type\":\"number\"}]},\"maxItems\":2048,\"type\":\"array\",\"minItems\":1},\"tc"
"\":{\"min\":0,\"max\":255,\"type\":\"integer\",\"description\":\"table data type "
"code\"},\"ch\":{\"min\":0,\"max\":255,\"type\":\"integer\",\"description\":\"channel"
" number\"},\"nx\":{\"min\":1,\"max\":2048,\"type\":\"integer\",\"description\":\"num"
"ber of x entries\"},\"ny\":{\"min\":1,\"max\":2048,\"type\":\"integer\",\"descript"
"ion\":\"number of y entries\"}},\"type\":\"object\",\"desription\":\"scanner "
"internal data\"},\"fp_table_row\":{\"items\":{\"type\":\"number\"},\"maxItems\":2"
"048,\"type\":\"array\",\"minItems\":1},\"fp\":{\"description\":\"Fingerprint valu"
"es\",\"required\":[\"s\",\"w\"],\"properties\":{\"s\":{\"minItems\":1,\"maxItems\":25"
"6,\"type\":\"array\",\"items\":{\"minItems\":1,\"maxItems\":4096,\"type\":\"array\","
"\"items\":{\"type\":\"number\"}}},\"w\":{\"minItems\":1,\"maxItems\":256,\"type\":\"a"
"rray\",\"items\":{\"minItems\":5,\"maxItems\":5,\"type\":\"array\",\"items\":{\"type"
"\":\"number\"}}}},\"type\":\"object\"}},\"description\":\"Receiver Internals\",\"p"
"roperties\":{\"si\":{\"minimum\":0,\"maximum\":255,\"type\":\"number\",\"descripti"
"on\":\"Start index (hw_start)\"},\"ns\":{\"minimum\":0,\"maximum\":4095,\"type\":"
"\"integer\",\"description\":\"Number of "
"samples\"},\"ex\":{\"description\":\"DEPRECATED, use "
"'riegl.exponential_decomposition' instead\",\"type\":\"object\"},\"t\":{\"patt"
"ernProperties\":{\"^[0-9]+$\":{\"description\":\"one field per channel, "
"field name is channel index\",\"$ref\":\"#/definitions/fp\"}},\"type\":\"objec"
"t\",\"additionalProperties\":false},\"sr\":{\"minimum\":0,\"description\":\"Samp"
"le rate [Hz]\",\"exclusiveMinimum\":true,\"type\":\"number\"},\"mw\":{\"minimum\""
":0,\"maximum\":4095,\"exclusiveMinimum\":true,\"type\":\"number\",\"description"
"\":\"Maximum weight\"},\"nt\":{\"minimum\":0,\"maximum\":255,\"type\":\"integer\",\""
"description\":\"Number of traces\"},\"tbl\":{\"description\":\"various "
"internal data\",\"minItems\":1,\"type\":\"array\",\"items\":{\"$ref\":\"#/definiti"
"ons/fp_table\"}},\"a\":{\"description\":\"Amplitude [dB]\",\"minItems\":1,\"maxI"
"tems\":256,\"type\":\"array\",\"items\":{\"type\":\"number\"}}},\"$schema\":\"http:/"
"/json-schema.org/draft-04/schema#\",\"title\":\"Receiver "
"Internals\",\"type\":\"object\"}"
)
RDB_RIEGL_RECEIVER_INTERNALS_EXAMPLE = (
"{\"si\":48,\"ns\":400,\"t\":{\"0\":{\"s\":[[1.23,4.56],[7.89,0.12]],\"w\":[[78,86,"
"126,134,31],[78,86,126,134,31]]},\"1\":{\"s\":[[1.23,4.56],[7.89,0.12]],\"w"
"\":[[78,86,126,134,31],[78,86,126,134,31]]}},\"sr\":7959997000.0,\"mw\":31,"
"\"nt\":128,\"tbl\":[{\"tv\":[[1,2,3,4,5],[1.1,2.2,3.3,4.4,5.5]],\"tc\":1,\"ch\":"
"0,\"nx\":5,\"ny\":2}],\"a\":[-1.55]}"
)

# List of names of the records
RDB_RIEGL_RECORD_NAMES             = "riegl.record_names"
RDB_RIEGL_RECORD_NAMES_TITLE       = "Record Names"
RDB_RIEGL_RECORD_NAMES_DESCRIPTION = "List of names of the records"
RDB_RIEGL_RECORD_NAMES_STATUS      = "optional"
RDB_RIEGL_RECORD_NAMES_SCHEMA = (
"{\"description\":\"List of names of the records\",\"title\":\"Record Names\",\""
"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"pr"
"operties\":{\"names\":{\"description\":\"List of record names. The name of a"
" record is the {riegl.id}th element of this list. The number of "
"elements must correspond to the maximum riegl.id occurring in this "
"file.\",\"type\":\"array\",\"items\":{\"description\":\"Record "
"name\",\"type\":\"string\"}}}}"
)
RDB_RIEGL_RECORD_NAMES_EXAMPLE = (
"{\"names\":[\"Name of first record\",\"Name of second record\",\"Name of "
"third record\",\"Name of fourth record\"]}"
)

# Lookup table for reflectance calculation based on amplitude and range
RDB_RIEGL_REFLECTANCE_CALCULATION             = "riegl.reflectance_calculation"
RDB_RIEGL_REFLECTANCE_CALCULATION_TITLE       = "Reflectance Calculation Table"
RDB_RIEGL_REFLECTANCE_CALCULATION_DESCRIPTION = "Lookup table for reflectance calculation based on amplitude and range"
RDB_RIEGL_REFLECTANCE_CALCULATION_STATUS      = "optional"
RDB_RIEGL_REFLECTANCE_CALCULATION_SCHEMA = (
"{\"description\":\"Lookup table for reflectance calculation based on "
"amplitude and range\",\"required\":[\"delta\",\"content\"],\"properties\":{\"con"
"tent\":{\"description\":\"Correction value [dB] to be added to the amplitu"
"de\",\"minItems\":1,\"maxItems\":2000,\"type\":\"array\",\"items\":{\"type\":\"numbe"
"r\"}},\"delta\":{\"description\":\"Delta between table entries [m], first "
"entry is at range = 0 m\",\"type\":\"number\"}},\"$schema\":\"http://json-sche"
"ma.org/draft-04/schema#\",\"title\":\"Reflectance Calculation "
"Table\",\"type\":\"object\"}"
)
RDB_RIEGL_REFLECTANCE_CALCULATION_EXAMPLE = (
"{\"content\":[-33.01],\"delta\":0.150918}"
)

# Range-dependent and scan-angle-dependent correction of reflectance reading
RDB_RIEGL_REFLECTANCE_CORRECTION             = "riegl.reflectance_correction"
RDB_RIEGL_REFLECTANCE_CORRECTION_TITLE       = "Near-range reflectance correction"
RDB_RIEGL_REFLECTANCE_CORRECTION_DESCRIPTION = "Range-dependent and scan-angle-dependent correction of reflectance reading"
RDB_RIEGL_REFLECTANCE_CORRECTION_STATUS      = "optional"
RDB_RIEGL_REFLECTANCE_CORRECTION_SCHEMA = (
"{\"description\":\"Range-dependent and scan-angle-dependent correction of"
" reflectance reading\",\"required\":[\"ranges_m\",\"line_angles_deg\",\"reflec"
"tance_correction_db\"],\"properties\":{\"line_angles_deg\":{\"description\":\""
"Angle [deg]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"ranges_m\":{\"de"
"scription\":\"Range [m]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"refl"
"ectance_correction_db\":{\"description\":\"Near range reflectance "
"correction in dB as a function of range over "
"angle\",\"type\":\"array\",\"items\":{\"description\":\"rows (each array "
"corresponds to a "
"range)\",\"type\":\"array\",\"items\":{\"description\":\"columns (each value "
"corresponds to an angle)\",\"type\":\"number\"}}}},\"$schema\":\"http://json-s"
"chema.org/draft-04/schema#\",\"title\":\"Near-range reflectance "
"correction\",\"type\":\"object\"}"
)
RDB_RIEGL_REFLECTANCE_CORRECTION_EXAMPLE = (
"{\"line_angles_deg\":[0.0,0.5,1.0,1.5,1.0,2.0,2.5,3.0,3.5,4.0],\"ranges_m"
"\":[0.0,1.0,2.0,3.0],\"reflectance_correction_db\":[[0.8,0.7,0.6,0.5,0.4,"
"0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0."
"8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,"
"0.1,0.05,0.01]]}"
)

# Scan pattern description
RDB_RIEGL_SCAN_PATTERN             = "riegl.scan_pattern"
RDB_RIEGL_SCAN_PATTERN_TITLE       = "Scan Pattern"
RDB_RIEGL_SCAN_PATTERN_DESCRIPTION = "Scan pattern description"
RDB_RIEGL_SCAN_PATTERN_STATUS      = "optional"
RDB_RIEGL_SCAN_PATTERN_SCHEMA = (
"{\"definitions\":{\"program\":{\"description\":\"Measurement "
"program\",\"required\":[\"name\"],\"properties\":{\"name\":{\"description\":\"Name"
" of measurement program\",\"type\":\"string\"},\"laser_prr\":{\"minimum\":0,\"de"
"scription\":\"Laser Pulse Repetition Rate [Hz]\",\"exclusiveMinimum\":false"
",\"type\":\"number\"}},\"type\":\"object\"}},\"description\":\"Scan pattern "
"description\",\"title\":\"Scan "
"Pattern\",\"properties\":{\"rectangular\":{\"description\":\"Rectangular Field"
" Of View Scan Pattern\",\"required\":[\"phi_start\",\"phi_stop\",\"phi_increme"
"nt\",\"theta_start\",\"theta_stop\",\"theta_increment\"],\"properties\":{\"phi_i"
"ncrement\":{\"minimum\":0.0,\"description\":\"Increment of phi angle in SOCS"
" [deg]\",\"type\":\"number\",\"maximum\":90.0},\"theta_start\":{\"minimum\":0.0,\""
"description\":\"Start theta angle in SOCS [deg]\",\"type\":\"number\",\"maximu"
"m\":180.0},\"phi_stop\":{\"minimum\":0.0,\"description\":\"Stop phi angle in "
"SOCS [deg]\",\"type\":\"number\",\"maximum\":720.0},\"phi_start\":{\"minimum\":0."
"0,\"description\":\"Start phi angle in SOCS [deg]\",\"type\":\"number\",\"maxim"
"um\":360.0},\"theta_stop\":{\"minimum\":0.0,\"description\":\"Stop theta angle"
" in SOCS [deg]\",\"type\":\"number\",\"maximum\":180.0},\"program\":{\"$ref\":\"#/"
"definitions/program\"},\"theta_increment\":{\"minimum\":0.0,\"description\":\""
"Increment of theta angle in SOCS [deg]\",\"type\":\"number\",\"maximum\":90.0"
"}},\"type\":\"object\"},\"segments\":{\"description\":\"Segmented Line Scan Pat"
"tern\",\"required\":[\"list\"],\"properties\":{\"list\":{\"type\":\"array\",\"items\""
":{\"description\":\"Line Scan Segment\",\"required\":[\"start\",\"stop\",\"increm"
"ent\"],\"properties\":{\"stop\":{\"minimum\":0.0,\"description\":\"Stop angle in"
" SOCS [deg]\",\"type\":\"number\",\"maximum\":720.0},\"increment\":{\"minimum\":0"
".0,\"description\":\"Increment of angle in SOCS [deg]\",\"type\":\"number\",\"m"
"aximum\":90.0},\"start\":{\"minimum\":0.0,\"description\":\"Start angle in "
"SOCS [deg]\",\"type\":\"number\",\"maximum\":360.0}},\"type\":\"object\"}},\"progr"
"am\":{\"$ref\":\"#/definitions/program\"}},\"type\":\"object\"},\"line\":{\"descri"
"ption\":\"Line Scan Pattern\",\"required\":[\"start\",\"stop\",\"increment\"],\"pr"
"operties\":{\"stop\":{\"minimum\":0.0,\"description\":\"Stop angle in SOCS [de"
"g]\",\"type\":\"number\",\"maximum\":720.0},\"increment\":{\"minimum\":0.0,\"descr"
"iption\":\"Increment of angle in SOCS [deg]\",\"type\":\"number\",\"maximum\":9"
"0.0},\"start\":{\"minimum\":0.0,\"description\":\"Start angle in SOCS [deg]\","
"\"type\":\"number\",\"maximum\":360.0},\"program\":{\"$ref\":\"#/definitions/prog"
"ram\"}},\"type\":\"object\"}},\"$schema\":\"http://json-schema.org/draft-04/sc"
"hema#\"}"
)
RDB_RIEGL_SCAN_PATTERN_EXAMPLE = (
"{\"rectangular\":{\"phi_increment\":0.04,\"theta_start\":30.0,\"phi_stop\":270"
".0,\"phi_start\":45.0,\"theta_stop\":130.0,\"program\":{\"name\":\"High "
"Speed\",\"laser_prr\":100000.0},\"theta_increment\":0.04}}"
)

# Details about laser shot files
RDB_RIEGL_SHOT_INFO             = "riegl.shot_info"
RDB_RIEGL_SHOT_INFO_TITLE       = "Shot Information"
RDB_RIEGL_SHOT_INFO_DESCRIPTION = "Details about laser shot files"
RDB_RIEGL_SHOT_INFO_STATUS      = "optional"
RDB_RIEGL_SHOT_INFO_SCHEMA = (
"{\"description\":\"Details about laser shot files\",\"title\":\"Shot Informat"
"ion\",\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema"
"#\",\"properties\":{\"shot_file\":{\"required\":[\"file_extension\"],\"propertie"
"s\":{\"file_extension\":{\"description\":\"Shot file extension, without the "
"leading dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's "
"Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"}},\"type\":\"object\"}}}"
)
RDB_RIEGL_SHOT_INFO_EXAMPLE = (
"{\"shot_file\":{\"file_extension\":\"sodx\",\"file_uuid\":\"26a00815-67c0-4bff-"
"8fe8-c577378fe663\"}}"
)

# Conversion of background radiation raw values to temperatures in °C
RDB_RIEGL_TEMPERATURE_CALCULATION             = "riegl.temperature_calculation"
RDB_RIEGL_TEMPERATURE_CALCULATION_TITLE       = "Temperature Calculation Table"
RDB_RIEGL_TEMPERATURE_CALCULATION_DESCRIPTION = "Conversion of background radiation raw values to temperatures in °C"
RDB_RIEGL_TEMPERATURE_CALCULATION_STATUS      = "optional"
RDB_RIEGL_TEMPERATURE_CALCULATION_SCHEMA = (
"{\"definitions\":{\"conversion_table\":{\"required\":[\"value\",\"temperature\"]"
",\"properties\":{\"temperature\":{\"description\":\"Temperature [\\u00b0C]\",\"t"
"ype\":\"array\",\"items\":{\"type\":\"number\"}},\"value\":{\"description\":\"LSB [1"
"]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}}},\"type\":\"object\"}},\"descr"
"iption\":\"Conversion of background radiation raw values to temperatures"
" in \\u00b0C\",\"properties\":{\"Si\":{\"description\":\"Conversion table for "
"Si channel\",\"$ref\":\"#/definitions/conversion_table\"},\"InGaAs_Si_Differ"
"ence\":{\"description\":\"Conversion table for InGaAs - Si difference\",\"$r"
"ef\":\"#/definitions/conversion_table\"},\"InGaAs\":{\"description\":\"Convers"
"ion table for InGaAs channel\",\"$ref\":\"#/definitions/conversion_table\"}"
"},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Tempera"
"ture Calculation Table\",\"type\":\"object\"}"
)
RDB_RIEGL_TEMPERATURE_CALCULATION_EXAMPLE = (
"{\"Si\":{\"temperature\":[546.300048828125,548.8164051212026,551.314393850"
"0972,554.0144257850053,556.604252334815,559.2124464488079,561.80227299"
"86177,564.4104671126105,567.0002936624203],\"value\":[0.0,64.00097659230"
"323,128.0019531846065,192.0029297769097,256.0039063692129,320.00488296"
"151616,384.0058595538194,448.0068361461226,512.0078127384259]},\"InGaAs"
"_Si_Difference\":{\"temperature\":[1749.977111117893,1749.977111117893,17"
"49.977111117893,1749.977111117893,1749.977111117893,1749.977111117893,"
"1744.7813348796044,1681.9971312601092,1622.3944822534868],\"value\":[100"
"0.0,1100.090029602954,1200.04425183874,1300.1342814416948,1400.0885036"
"774805,1500.0427259132668,1600.1327555162209,1700.0869777520065,1800.0"
"411999877924]},\"InGaAs\":{\"temperature\":[307.22196722535614,309.1153478"
"247277,311.1188086915047,313.10025350480055,315.2137946389828,317.2172"
"555057597,319.2207163725366,321.2021611858325,323.3157023200148],\"valu"
"e\":[0.0,64.00097659230323,128.0019531846065,192.0029297769097,256.0039"
"063692129,320.00488296151616,384.0058595538194,448.0068361461226,512.0"
"078127384259]}}"
)

# Base of timestamps (epoch)
RDB_RIEGL_TIME_BASE             = "riegl.time_base"
RDB_RIEGL_TIME_BASE_TITLE       = "Time Base"
RDB_RIEGL_TIME_BASE_DESCRIPTION = "Base of timestamps (epoch)"
RDB_RIEGL_TIME_BASE_STATUS      = "optional"
RDB_RIEGL_TIME_BASE_SCHEMA = (
"{\"description\":\"Base of timestamps (epoch)\",\"required\":[\"epoch\",\"sourc"
"e\"],\"properties\":{\"source\":{\"description\":\"Timestamp source\",\"enum\":[\""
"unknown\",\"RTC\",\"GNSS\"],\"type\":\"string\"},\"system\":{\"description\":\"Time "
"system (time standard)\",\"enum\":[\"unknown\",\"UTC\",\"GPS\"],\"type\":\"string\""
"},\"epoch\":{\"description\":\"Date and time of timestamp '0' as proposed "
"by RFC 3339 (e.g. 2015-10-27T00:00:00+01:00).\",\"type\":\"string\"}},\"$sch"
"ema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Time "
"Base\",\"type\":\"object\"}"
)
RDB_RIEGL_TIME_BASE_EXAMPLE = (
"{\"source\":\"GNSS\",\"system\":\"UTC\",\"epoch\":\"2015-10-27T00:00:00+00:00\"}"
)

# Details about position+orientation files
RDB_RIEGL_TRAJECTORY_INFO             = "riegl.trajectory_info"
RDB_RIEGL_TRAJECTORY_INFO_TITLE       = "Trajectory Information"
RDB_RIEGL_TRAJECTORY_INFO_DESCRIPTION = "Details about position+orientation files"
RDB_RIEGL_TRAJECTORY_INFO_STATUS      = "optional"
RDB_RIEGL_TRAJECTORY_INFO_SCHEMA = (
"{\"description\":\"Details about position+orientation files\",\"required\":["
"\"time_interval\",\"navigation_frame\"],\"properties\":{\"navigation_frame\":{"
"\"description\":\"Navigation frame (NED: North-East-Down, ENU: East-North"
"-Up)\",\"enum\":[\"unknown\",\"NED\",\"ENU\"],\"type\":\"string\"},\"field_of_applic"
"ation\":{\"description\":\"Field of application\",\"enum\":[\"unknown\",\"SLS\",\""
"TLS\",\"KLS\",\"MLS\",\"ULS\",\"ALS\",\"BLS\",\"ILS\"],\"type\":\"string\"},\"time_inter"
"val\":{\"description\":\"Time interval statistics\",\"required\":[\"minimum\",\""
"average\",\"maximum\",\"std_dev\"],\"properties\":{\"minimum\":{\"description\":\""
"Minimum time interval "
"[s]\",\"type\":\"number\"},\"maximum\":{\"description\":\"Maximum time interval "
"[s]\",\"type\":\"number\"},\"average\":{\"description\":\"Average time interval "
"[s]\",\"type\":\"number\"},\"std_dev\":{\"description\":\"Standard deviation of "
"intervals [s]\",\"type\":\"number\"}},\"type\":\"object\"},\"device\":{\"descripti"
"on\":\"Navigation device, e.g. "
"name/type/serial\",\"type\":\"string\"},\"project\":{\"description\":\"Project "
"name\",\"type\":\"string\"},\"location\":{\"description\":\"Project location, "
"e.g. city/state/country\",\"type\":\"string\"},\"software\":{\"description\":\"S"
"oftware that calculated the trajectory (this may be the same or "
"different software than the one that created the "
"file)\",\"type\":\"string\"},\"company\":{\"description\":\"Company "
"name\",\"type\":\"string\"},\"settings\":{\"description\":\"Settings used to "
"calculate the trajectory (descriptive text)\",\"type\":\"string\"}},\"$schem"
"a\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Trajectory "
"Information\",\"type\":\"object\"}"
)
RDB_RIEGL_TRAJECTORY_INFO_EXAMPLE = (
"{\"navigation_frame\":\"NED\",\"field_of_application\":\"MLS\",\"time_interval\""
":{\"minimum\":0.00500032,\"maximum\":0.005004883,\"average\":0.00500053,\"std"
"_dev\":5.51e-07},\"device\":\"IMU Model 12/1, Serial# "
"12345\",\"project\":\"Campaign 3\",\"location\":\"Horn\",\"software\":\"Navigation"
" Software XYZ\",\"company\":\"RIEGL LMS\",\"settings\":\"default\"}"
)

# Details about vertex file
RDB_RIEGL_VERTEX_INFO             = "riegl.vertex_info"
RDB_RIEGL_VERTEX_INFO_TITLE       = "Vertex Information"
RDB_RIEGL_VERTEX_INFO_DESCRIPTION = "Details about vertex file"
RDB_RIEGL_VERTEX_INFO_STATUS      = "optional"
RDB_RIEGL_VERTEX_INFO_SCHEMA = (
"{\"description\":\"Details about vertex file\",\"title\":\"Vertex Information"
"\",\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\","
"\"properties\":{\"vertex_file\":{\"required\":[\"file_extension\"],\"properties"
"\":{\"file_extension\":{\"description\":\"Vertex file extension, without the"
" leading dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's "
"Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"}},\"type\":\"object\"}}}"
)
RDB_RIEGL_VERTEX_INFO_EXAMPLE = (
"{\"vertex_file\":{\"file_extension\":\"vtx\",\"file_uuid\":\"51534d95-d71f-4f36"
"-ae1a-3e63a21fd1c7\"}}"
)

# Details about the voxels contained in the file
RDB_RIEGL_VOXEL_INFO             = "riegl.voxel_info"
RDB_RIEGL_VOXEL_INFO_TITLE       = "Voxel Information"
RDB_RIEGL_VOXEL_INFO_DESCRIPTION = "Details about the voxels contained in the file"
RDB_RIEGL_VOXEL_INFO_STATUS      = "optional"
RDB_RIEGL_VOXEL_INFO_SCHEMA = (
"{\"definitions\":{\"voxel_origin_enum\":{\"description\":\"Defines whether "
"the voxel's center or a corner is placed on CRS origin <tt>(0/0/0)</tt"
">.\",\"default\":\"corner\",\"enum\":[\"center\",\"corner\"]},\"voxel_origin_point"
"\":{\"description\":\"Origin point for all voxel indices in voxel CRS.\",\"m"
"inItems\":3,\"maxItems\":3,\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"sha"
"pe_thresholds\":{\"description\":\"Thresholds used to compute the voxel's "
"shape_id value.\",\"required\":[\"plane\",\"line\"],\"properties\":{\"plane\":{\"m"
"aximum\":1,\"description\":\"If the smallest eigenvalue is smaller than "
"the median eigenvalue * plane_threshold, the voxel is considered a pla"
"ne.\",\"exclusiveMaximum\":true,\"exclusiveMinimum\":true,\"minimum\":0,\"type"
"\":\"number\"},\"line\":{\"minimum\":1,\"description\":\"If the biggest "
"eigenvalue is bigger than the median eigenvalue * line_threshold, the "
"voxel is considered a line.\",\"exclusiveMinimum\":true,\"type\":\"number\"}}"
",\"type\":\"object\"},\"voxel_size_cubic\":{\"type\":\"number\",\"$ref\":\"#/defini"
"tions/edge_length\"},\"voxel_type\":{\"description\":\"Whether a point in a "
"voxel represents its center or its centroid. If type is <tt>index</tt>"
" there is no point but only an integer voxel index.\",\"default\":\"centro"
"id\",\"enum\":[\"center\",\"centroid\",\"index\"]},\"voxel_size\":{\"description\":"
"\"Size of voxels.\",\"minItems\":3,\"maxItems\":3,\"type\":\"array\",\"items\":{\"$"
"ref\":\"#/definitions/edge_length\"}},\"edge_length\":{\"minimum\":0,\"descrip"
"tion\":\"Length of voxel edge "
"[m].\",\"exclusiveMinimum\":true,\"type\":\"number\"}},\"description\":\"Details"
" about the voxels contained in the file\",\"oneOf\":[{\"required\":[\"size\","
"\"voxel_origin\",\"voxel_type\"],\"properties\":{\"size\":{\"description\":\"Size"
" of voxels in file coordinate system.\",\"oneOf\":[{\"$ref\":\"#/definitions"
"/voxel_size\"},{\"$ref\":\"#/definitions/voxel_size_cubic\"}]},\"voxel_type\""
":{\"$ref\":\"#/definitions/voxel_type\"},\"voxel_origin\":{\"$ref\":\"#/definit"
"ions/voxel_origin_enum\"},\"shape_thresholds\":{\"$ref\":\"#/definitions/sha"
"pe_thresholds\"}},\"additionalProperties\":false},{\"required\":[\"reference"
"_point\",\"size_llcs\",\"size\",\"voxel_origin\",\"voxel_type\"],\"properties\":{"
"\"size\":{\"description\":\"Size of voxels in file coordinate system.\",\"$re"
"f\":\"#/definitions/voxel_size\"},\"reference_point\":{\"description\":\"Point"
" in WGS84 geodetic decimal degree (EPSG:4326) that was used to compute"
" the projection distortion parameters. The coefficient order is "
"latitude, longitude. Only voxels with corresponding geo_tag, "
"voxel_size and reference_point can be reliably processed together. "
"This entry is available for voxel files in projected CRS only.\",\"minIt"
"ems\":2,\"maxItems\":2,\"type\":\"array\",\"items\":{\"minimum\":-180,\"maximum\":1"
"80,\"type\":\"number\"}},\"voxel_origin\":{\"oneOf\":[{\"$ref\":\"#/definitions/v"
"oxel_origin_enum\"},{\"description\":\"The base point of the voxel grid. "
"Used together with <tt>voxel_size</tt> and <tt>voxel_index</tt> to "
"compute actual point coordinates.\",\"$ref\":\"#/definitions/voxel_origin_"
"point\"}]},\"size_llcs\":{\"description\":\"Size of voxels in a locally "
"levelled cartesian coordinate system (xyz). This is only used for "
"voxels based on a map projection.\",\"$ref\":\"#/definitions/voxel_size\"},"
"\"voxel_type\":{\"$ref\":\"#/definitions/voxel_type\"},\"shape_thresholds\":{\""
"$ref\":\"#/definitions/shape_thresholds\"}},\"additionalProperties\":false}"
"],\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Voxel "
"Information\",\"type\":\"object\"}"
)
RDB_RIEGL_VOXEL_INFO_EXAMPLE = (
"{\"size\":[0.5971642834779395,0.5971642834779395,0.5143705304787237],\"re"
"ference_point\":[48,16],\"voxel_origin\":\"corner\",\"shape_thresholds\":{\"pl"
"ane\":0.16,\"line\":6},\"voxel_type\":\"centroid\",\"size_llcs\":[0.51565752528"
"91171,0.5130835356683303,0.5143705304787237]}"
)

# Settings for waveform averaging
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS             = "riegl.waveform_averaging_settings"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_TITLE       = "Waveform Averaging Settings"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_DESCRIPTION = "Settings for waveform averaging"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_SCHEMA = (
"{\"description\":\"Settings for waveform averaging\",\"required\":[\"num_shot"
"s\",\"mta_zone\"],\"properties\":{\"trim\":{\"minimum\":0,\"description\":\"Percen"
"tage for robust averaging.\",\"default\":0,\"type\":\"number\",\"maximum\":0.5}"
",\"mta_zone\":{\"minimum\":1,\"description\":\"Fixed MTA zone for averaging.\""
",\"type\":\"integer\"},\"num_shots\":{\"minimum\":1,\"description\":\"Number of "
"consecutive shots to be used for averaging.\",\"type\":\"integer\"}},\"$sche"
"ma\":\"http://json-schema.org/draft-04/schema#\",\"title\":\"Waveform "
"Averaging Settings\",\"type\":\"object\"}"
)
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_EXAMPLE = (
"{\"trim\":0.05,\"mta_zone\":1,\"num_shots\":7}"
)

# Details about waveform files
RDB_RIEGL_WAVEFORM_INFO             = "riegl.waveform_info"
RDB_RIEGL_WAVEFORM_INFO_TITLE       = "Waveform Information"
RDB_RIEGL_WAVEFORM_INFO_DESCRIPTION = "Details about waveform files"
RDB_RIEGL_WAVEFORM_INFO_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_INFO_SCHEMA = (
"{\"description\":\"Details about waveform files\",\"required\":[\"sample_bloc"
"k_file\",\"sample_data_files\"],\"properties\":{\"sample_data_files\":{\"type\""
":\"array\",\"items\":{\"required\":[\"channel\",\"channel_name\",\"sample_interva"
"l\",\"sample_bits\",\"laser_wavelength\",\"delta_st\",\"file_extension\"],\"prop"
"erties\":{\"laser_wavelength\":{\"minimum\":0,\"description\":\"Laser "
"wavelength in meters (0 = unknown)\",\"exclusiveMinimum\":false,\"type\":\"n"
"umber\"},\"sample_interval\":{\"minimum\":0,\"description\":\"Sampling "
"interval in seconds\",\"exclusiveMinimum\":false,\"type\":\"number\"},\"sample"
"_bits\":{\"maximum\":32,\"description\":\"Bitwidth of samples (e.g. 10 bit, "
"12 bit)\",\"exclusiveMaximum\":false,\"exclusiveMinimum\":false,\"minimum\":0"
",\"type\":\"integer\"},\"file_extension\":{\"description\":\"Sample data file "
"extension, without the leading "
"dot\",\"type\":\"string\"},\"channel_name\":{\"description\":\"Sample block "
"channel name\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's "
"Universally Unique Identifier (RFC "
"4122)\",\"type\":\"string\"},\"channel\":{\"maximum\":255,\"description\":\"Sample"
" block channel number (255 = invalid)\",\"exclusiveMaximum\":false,\"exclu"
"siveMinimum\":false,\"minimum\":0,\"type\":\"integer\"},\"delta_st\":{\"descript"
"ion\":\"reserved\",\"type\":\"number\"}},\"type\":\"object\"}},\"range_offset_m\":{"
"\"description\":\"Calibrated device specific range offset for waveform "
"analysis by system response fitting in meters.\",\"type\":\"number\"},\"samp"
"le_block_file\":{\"required\":[\"file_extension\"],\"properties\":{\"file_exte"
"nsion\":{\"description\":\"Sample block file extension, without the "
"leading dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's "
"Universally Unique Identifier (RFC 4122)\",\"type\":\"string\"}},\"type\":\"ob"
"ject\"},\"range_offset_waveform_samples_m\":{\"description\":\"Calibrated "
"device specific range offset for waveform samples in meters.\",\"type\":\""
"number\"}},\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"title\":"
"\"Waveform Information\",\"type\":\"object\"}"
)
RDB_RIEGL_WAVEFORM_INFO_EXAMPLE = (
"{\"sample_block_file\":{\"file_extension\":\"sbx\",\"file_uuid\":\"93a03615-66c"
"0-4bea-8ff8-c577378fe660\"},\"range_offset_m\":3.1415,\"sample_data_files\""
":[{\"laser_wavelength\":0,\"sample_interval\":1.00503e-09,\"sample_bits\":12"
",\"file_extension\":\"sp0\",\"channel_name\":\"high_power\",\"file_uuid\":\"da084"
"413-e3e8-4655-a122-071de8490d8e\",\"channel\":0,\"delta_st\":0},{\"laser_wav"
"elength\":0,\"sample_interval\":1.00503e-09,\"sample_bits\":12,\"file_extens"
"ion\":\"sp1\",\"channel_name\":\"low_power\",\"file_uuid\":\"93585b5e-5ea9-43a1-"
"947b-e7ba3be642d2\",\"channel\":1,\"delta_st\":0},{\"laser_wavelength\":0,\"sa"
"mple_interval\":1.00503e-09,\"sample_bits\":12,\"file_extension\":\"sp5\",\"ch"
"annel_name\":\"wwf\",\"file_uuid\":\"9d2298c4-1036-464f-b5cb-1cf8e517f3a0\",\""
"channel\":5,\"delta_st\":0}],\"range_offset_waveform_samples_m \":7.283}"
)

# Scanner settings for waveform output
RDB_RIEGL_WAVEFORM_SETTINGS             = "riegl.waveform_settings"
RDB_RIEGL_WAVEFORM_SETTINGS_TITLE       = "Waveform Settings"
RDB_RIEGL_WAVEFORM_SETTINGS_DESCRIPTION = "Scanner settings for waveform output"
RDB_RIEGL_WAVEFORM_SETTINGS_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_SETTINGS_SCHEMA = (
"{\"description\":\"Scanner settings for waveform "
"output\",\"title\":\"Waveform Settings\",\"type\":\"array\",\"$schema\":\"http://j"
"son-schema.org/draft-04/schema#\",\"items\":{\"required\":[\"sbl_name\",\"enab"
"led\",\"channel_idx_mask\"],\"properties\":{\"smart_enabled\":{\"description\":"
"\"Smart waveform output "
"enabled\",\"type\":\"boolean\"},\"sbl_name\":{\"description\":\"Name of sample "
"block, e.g.: wfm, "
"wwf\",\"type\":\"string\"},\"pass_rng_less\":{\"description\":\"Threshold for "
"range less than "
"[m]\",\"type\":\"number\"},\"logic_expression\":{\"description\":\"Logic "
"expression of smart waveforms "
"filter\",\"type\":\"string\"},\"enabled\":{\"description\":\"Waveform output ena"
"bled\",\"type\":\"boolean\"},\"pass_dev_greater\":{\"description\":\"Threshold "
"for deviation greater than "
"[1]\",\"type\":\"integer\"},\"pass_ampl_less\":{\"description\":\"Threshold for "
"amplitude less than "
"[dB]\",\"type\":\"number\"},\"pass_rng_greater\":{\"description\":\"Threshold "
"for range greater than "
"[m]\",\"type\":\"number\"},\"pass_ampl_greater\":{\"description\":\"Threshold "
"for amplitude greater than "
"[dB]\",\"type\":\"number\"},\"pass_dev_less\":{\"description\":\"Threshold for "
"deviation less than "
"[1]\",\"type\":\"integer\"},\"channel_idx_mask\":{\"description\":\"Bit mask for"
" channels which belong to sbl_name: Channel 0 = Bit0, Channel 1 = "
"Bit1, ...\",\"type\":\"integer\"}},\"type\":\"object\"}}"
)
RDB_RIEGL_WAVEFORM_SETTINGS_EXAMPLE = (
"[{\"smart_enabled\":true,\"sbl_name\":\"wfm\",\"pass_rng_less\":13.11,\"enabled"
"\":true,\"pass_ampl_less\":5.0,\"pass_rng_greater\":9.27,\"pass_ampl_greater"
"\":1.0,\"channel_idx_mask\":11},{\"sbl_name\":\"wwf\",\"enabled\":false,\"channe"
"l_idx_mask\":32}]"
)

# Window analysis data estimated from scandata and resulting filter parameters
RDB_RIEGL_WINDOW_ANALYSIS             = "riegl.window_analysis"
RDB_RIEGL_WINDOW_ANALYSIS_TITLE       = "Window Analysis"
RDB_RIEGL_WINDOW_ANALYSIS_DESCRIPTION = "Window analysis data estimated from scandata and resulting filter parameters"
RDB_RIEGL_WINDOW_ANALYSIS_STATUS      = "optional"
RDB_RIEGL_WINDOW_ANALYSIS_SCHEMA = (
"{\"description\":\"Window analysis data estimated from scandata and "
"resulting filter parameters\",\"required\":[\"result\",\"filter\",\"settings\"]"
",\"properties\":{\"settings\":{\"required\":[\"range\",\"amplitude\"],\"propertie"
"s\":{\"range\":{\"required\":[\"sigma_factor\",\"additive_value\"],\"properties\""
":{\"sigma_factor\":{\"type\":\"number\"},\"additive_value\":{\"type\":\"number\"}}"
",\"type\":\"object\"},\"amplitude\":{\"required\":[\"sigma_factor\",\"additive_va"
"lue\"],\"properties\":{\"sigma_factor\":{\"type\":\"number\"},\"additive_value\":"
"{\"type\":\"number\"}},\"type\":\"object\"}},\"type\":\"object\"},\"result\":{\"requi"
"red\":[\"angle\",\"range_mean\",\"range_sigma\",\"amplitude_mean\",\"amplitude_s"
"igma\",\"amplitude_offset\"],\"properties\":{\"range_mean\":{\"description\":\"["
"m]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"range_sigma\":{\"descript"
"ion\":\"[m]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplitude_sigma\""
":{\"description\":\"[dB]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"angl"
"e\":{\"description\":\"[deg]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"a"
"mplitude_mean\":{\"description\":\"[dB]\",\"type\":\"array\",\"items\":{\"type\":\"n"
"umber\"}},\"amplitude_offset\":{\"description\":\"[dB]\",\"type\":\"array\",\"item"
"s\":{\"type\":\"number\"}},\"timestamp\":{\"description\":\"[s]\",\"type\":\"array\","
"\"items\":{\"type\":\"number\"}}},\"type\":\"object\"},\"filter\":{\"required\":[\"an"
"gle\",\"range_min\",\"range_max\",\"amplitude_max\"],\"properties\":{\"angle\":{\""
"description\":\"[deg]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"range_"
"max\":{\"description\":\"[m]\",\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"a"
"mplitude_max\":{\"description\":\"[dB]\",\"type\":\"array\",\"items\":{\"type\":\"nu"
"mber\"}},\"range_min\":{\"description\":\"[m]\",\"type\":\"array\",\"items\":{\"type"
"\":\"number\"}}},\"type\":\"object\"}},\"$schema\":\"http://json-schema.org/draf"
"t-04/schema#\",\"title\":\"Window Analysis\",\"type\":\"object\"}"
)
RDB_RIEGL_WINDOW_ANALYSIS_EXAMPLE = (
"{\"settings\":{\"range\":{\"sigma_factor\":8,\"additive_value\":0.1},\"amplitud"
"e\":{\"sigma_factor\":4,\"additive_value\":1.0}},\"result\":{\"range_mean\":[0."
"1105621,0.1079564,0.1087088,0.1067261,0.1054582,0.1090412,0.102871,0.1"
"019044,0.1051523,0.1058445,0.1031261],\"range_sigma\":[0.01869652,0.0215"
"1435,0.01747969,0.01918765,0.01945776,0.01934862,0.01955329,0.02225589"
",0.02229977,0.01899122,0.02009433],\"amplitude_sigma\":[0.4272844,0.4298"
"479,0.4236816,0.4283583,0.4362353,0.4315141,0.4373984,0.4472798,0.4346"
"001,0.4345487,0.4540681],\"angle\":[14.9,15.0,15.1,15.2,15.3,15.4,15.5,1"
"5.6,15.7,15.8,15.9],\"amplitude_mean\":[5.347396,5.263155,5.224655,5.179"
"926,5.097782,5.116479,5.051756,4.983473,5.007885,5.002441,4.982],\"ampl"
"itude_offset\":[1.9,1.9],\"timestamp\":[408.4441,411.4443]},\"filter\":{\"an"
"gle\":[14.9,15.0,15.1,15.2,15.3,15.4,15.5,15.6,15.7,15.8,15.9],\"range_m"
"ax\":[0.424,0.425,0.426,0.427,0.428,0.428,0.429,0.43,0.431,0.431,0.432]"
",\"amplitude_max\":[8.04,8.01,7.99,7.96,7.93,7.9,7.88,7.85,7.83,7.8,7.78"
"],\"range_min\":[-0.208,-0.21,-0.212,-0.214,-0.216,-0.218,-0.219,-0.221,"
"-0.223,-0.225,-0.227]}}"
)

# Correction parameters for window glass echoes
RDB_RIEGL_WINDOW_ECHO_CORRECTION             = "riegl.window_echo_correction"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_TITLE       = "Window Echo Correction"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_DESCRIPTION = "Correction parameters for window glass echoes"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_STATUS      = "optional"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_SCHEMA = (
"{\"description\":\"Correction parameters for window glass echoes\",\"requir"
"ed\":[\"amplitude\",\"range\",\"slices\"],\"properties\":{\"range\":{\"description"
"\":\"Range axis of correction table\",\"required\":[\"minimum\",\"maximum\",\"en"
"tries\"],\"properties\":{\"minimum\":{\"minimum\":-2.0,\"description\":\"Minimum"
" range in m\",\"type\":\"number\",\"maximum\":2.0},\"maximum\":{\"minimum\":-2.0,"
"\"description\":\"Maximum range in m\",\"type\":\"number\",\"maximum\":2.0},\"ent"
"ries\":{\"minimum\":1,\"description\":\"Number of range entries\",\"type\":\"int"
"eger\"}},\"type\":\"object\"},\"slices\":{\"type\":\"array\",\"items\":{\"descriptio"
"n\":\"Window echo correction parameter slice\",\"required\":[\"amplitude\",\"t"
"able\"],\"properties\":{\"table\":{\"description\":\"Correction table "
"(dimension defined by the 'amplitude' and 'range' "
"objects)\",\"minItems\":1,\"type\":\"array\",\"items\":{\"description\":\"Table "
"row (= amplitude "
"axis)\",\"minItems\":1,\"type\":\"array\",\"items\":{\"description\":\"Table "
"column (= range axis)\",\"minItems\":3,\"maxItems\":3,\"type\":\"array\",\"items"
"\":{\"description\":\"Table cell (item 0: amplitude in dB, 1: range in m, "
"2: flags)\",\"type\":\"number\"}}}},\"amplitude\":{\"description\":\"Window echo"
" amplitude of slice in dB\",\"type\":\"number\"}},\"type\":\"object\"}},\"amplit"
"ude\":{\"description\":\"Amplitude axis of correction table\",\"required\":[\""
"minimum\",\"maximum\",\"entries\"],\"properties\":{\"minimum\":{\"minimum\":0.0,\""
"description\":\"Minimum amplitude in "
"dB\",\"type\":\"number\"},\"maximum\":{\"minimum\":0.0,\"description\":\"Maximum "
"amplitude in "
"dB\",\"type\":\"number\"},\"entries\":{\"minimum\":1,\"description\":\"Number of "
"amplitude entries\",\"type\":\"integer\"}},\"type\":\"object\"}},\"$schema\":\"htt"
"p://json-schema.org/draft-04/schema#\",\"title\":\"Window Echo "
"Correction\",\"type\":\"object\"}"
)
RDB_RIEGL_WINDOW_ECHO_CORRECTION_EXAMPLE = (
"{\"range\":{\"minimum\":-1.5060822940732335,\"maximum\":1.5060822940732335,\""
"entries\":128},\"slices\":[{\"table\":[[[6.23,0.3535,1]],[[5.54,0.72375,1]]"
"],\"amplitude\":1.5},{\"table\":[[[6.23,0.3535,1]],[[5.54,0.72375,1]]],\"am"
"plitude\":2.0}],\"amplitude\":{\"minimum\":2,\"maximum\":20,\"entries\":128}}"
)
