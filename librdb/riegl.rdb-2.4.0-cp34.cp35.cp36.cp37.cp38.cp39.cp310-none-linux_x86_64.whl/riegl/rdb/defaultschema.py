#
#*******************************************************************************
#
#  Copyright 2022 RIEGL Laser Measurement Systems
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
#  SPDX-License-Identifier: Apache-2.0
#
#*******************************************************************************
#
"""
*******************************************************************************
*
* \author RIEGL LMS GmbH, Austria
* \brief  Description of RIEGL RDB 2 database file contents
*
*  NOTE: All information in this file is preliminary, since the
*        definition of the database schemas is not yet complete.
*
*******************************************************************************
"""

# File schema version
RDB_SCHEMA_VERSION = "ab4e0cc0"
RDB_SCHEMA_DATE = "2021-05-03"

# Schema for ".avg.fwa" files
RDB_SCHEMA_RIEGL_AVG_FWA = (
"{\"identifier\":\"avg.fwa\",\"metadata\":[],\"attributes\":[\"riegl.id*\",\"riegl"
".amplitude\",\"riegl.gain\",\"riegl.raw_range\",\"riegl.wfm_echo_time_offset"
"\",\"riegl.wfm_sbl_id\",\"riegl.deviation?\",\"riegl.pulse_width?\"],\"extensi"
"on\":\"avg.fwa\"}"
)

# Schema for ".avg.sbx" files
RDB_SCHEMA_RIEGL_AVG_SBX = (
"{\"identifier\":\"avg.sbx\",\"metadata\":[],\"attributes\":[\"riegl.id*\",\"riegl"
".wfm_sbl_channel\",\"riegl.wfm_sbl_mean\",\"riegl.wfm_sbl_std_dev\",\"riegl."
"wfm_sbl_time_offset\",\"riegl.wfm_sda_first\",\"riegl.wfm_sda_count\"],\"ext"
"ension\":\"avg.sbx\"}"
)

# Schema for ".avg.sidx" files
RDB_SCHEMA_RIEGL_AVG_SIDX = (
"{\"identifier\":\"avg.sidx\",\"metadata\":[\"riegl.shot_info\",\"riegl.waveform"
"_info\",\"riegl.echo_info?\",\"riegl.waveform_averaging_settings\"],\"attrib"
"utes\":[\"riegl.id\",\"riegl.shot_timestamp_hr*\",\"riegl.wfm_sbl_first\",\"ri"
"egl.wfm_sbl_count\",\"riegl.echo_first?\",\"riegl.echo_count?\"],\"extension"
"\":\"avg.sidx\"}"
)

# Schema for ".avg.sp{C}" files
RDB_SCHEMA_RIEGL_AVG_SPC = (
"{\"identifier\":\"avg.sp{C}\",\"metadata\":[],\"attributes\":[\"riegl.id*\",\"rie"
"gl.wfm_sample_value\"],\"extension\":\"avg.sp{C}\"}"
)

# Schema for ".cpx" files
RDB_SCHEMA_RIEGL_CPX = (
"{\"identifier\":\"cpx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.control_object_"
"catalog\",\"riegl.record_names\",\"riegl.imported_files\"],\"attributes\":[\"r"
"iegl.id\",\"riegl.xyz*\",\"riegl.xyz_accuracies\",\"riegl.control_object_typ"
"e\",\"riegl.zenith_vector\",\"riegl.used_for_adjustment\",\"riegl.acquisitio"
"n_date?\",\"riegl.cp_surface_inclination_angle\",\"riegl.cp_surface_inclin"
"ation_tolerance_angle\",\"riegl.import_line_number\"],\"extension\":\"cpx\"}"
)

# Schema for ".fwa" files
RDB_SCHEMA_RIEGL_FWA = (
"{\"identifier\":\"fwa\",\"metadata\":[],\"attributes\":[\"riegl.id*\",\"riegl.amp"
"litude\",\"riegl.gain\",\"riegl.raw_range\",\"riegl.wfm_echo_time_offset\",\"r"
"iegl.wfm_sbl_id\",\"riegl.deviation?\",\"riegl.pulse_width?\"],\"extension\":"
"\"fwa\"}"
)

# Schema for ".mpx" files
RDB_SCHEMA_RIEGL_MPX = (
"{\"identifier\":\"mpx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.pixel_info\",\"ri"
"egl.time_base?\"],\"attributes\":[\"riegl.id\",\"riegl.xy_map*\",\"riegl.ampli"
"tude\",\"riegl.reflectance\",\"riegl.deviation\",\"riegl.timestamp_min?\",\"ri"
"egl.timestamp_max?\",\"riegl.point_count\",\"riegl.point_count_grid_cell\","
"\"riegl.pixel_linear_sums?\",\"riegl.pixel_square_sums?\",\"riegl.height_mi"
"n\",\"riegl.height_max\",\"riegl.height_mean\",\"riegl.height_center\",\"riegl"
".surface_normal\",\"riegl.pca_thickness\",\"riegl.std_dev\",\"riegl.voxel_co"
"unt\"],\"extension\":\"mpx\"}"
)

# Schema for ".mtch" files
RDB_SCHEMA_RIEGL_MTCH = (
"{\"identifier\":\"mtch\",\"metadata\":[\"riegl.plane_patch_matching\"],\"attrib"
"utes\":[\"riegl.xyz*\",\"riegl.plane_references\",\"riegl.plane_patch_distan"
"ce\",\"riegl.plane_patch_lateral_distance\",\"riegl.plane_patch_link_vecto"
"r\",\"riegl.id\"],\"extension\":\"mtch\"}"
)

# Schema for ".mvx" files
RDB_SCHEMA_RIEGL_MVX = (
"{\"identifier\":\"mvx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.time_base?\",\"ri"
"egl.voxel_info\"],\"attributes\":[\"riegl.id\",\"riegl.xyz_map*\",\"riegl.ampl"
"itude\",\"riegl.reflectance\",\"riegl.deviation\",\"riegl.timestamp_min?\",\"r"
"iegl.timestamp_max?\",\"riegl.point_count\",\"riegl.shape_id\",\"riegl.covar"
"iances?\",\"riegl.pca_axis_min\",\"riegl.pca_axis_max\",\"riegl.pca_extents\""
",\"riegl.std_dev\",\"riegl.voxel_collapsed\"],\"extension\":\"mvx\"}"
)

# Schema for ".obsx" files
RDB_SCHEMA_RIEGL_OBSX = (
"{\"identifier\":\"obsx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.plane_slope_cl"
"ass_info?\",\"riegl.pointcloud_info\",\"riegl.sda1_source_files\"],\"attribu"
"tes\":[\"riegl.xyz\",\"riegl.surface_normal\",\"riegl.plane_slope_class?\",\"r"
"iegl.id*\",\"riegl.sda1_plane_patch_one\",\"riegl.sda1_plane_patch_two\",\"r"
"iegl.sda1_source_file_one\",\"riegl.sda1_source_file_two\"],\"extension\":\""
"obsx\"}"
)

# Schema for ".opefx" files
RDB_SCHEMA_RIEGL_OPEFX = (
"{\"identifier\":\"opefx\",\"metadata\":[\"riegl.device\",\"riegl.device_geometr"
"y\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"riegl.scan_patte"
"rn?\",\"riegl.time_base\",\"riegl.record_names\",\"riegl.control_object_refe"
"rence_file\"],\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_accuraci"
"es?\",\"riegl.surface_normal\",\"riegl.plane_up\",\"riegl.point_count\",\"rieg"
"l.std_dev\",\"riegl.plane_width\",\"riegl.plane_height\",\"riegl.plane_confi"
"dence_normal\",\"riegl.model_fit_quality?\",\"riegl.used_for_adjustment\",\""
"riegl.xyz_socs\",\"riegl.timestamp\",\"riegl.mirror_facet\",\"riegl.platform"
"_rpy_ROCS_NED\",\"riegl.platform_drpy_ROCS_NED\",\"riegl.platform_xyz_ROCS"
"_ENU\",\"riegl.platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_vector\",\"riegl.r"
"aw_range\",\"riegl.raw_frame_angle\",\"riegl.raw_line_angle\",\"riegl.refere"
"nce_object_id\"],\"extension\":\"opefx\"}"
)

# Schema for ".opp" files
RDB_SCHEMA_RIEGL_OPP = (
"{\"identifier\":\"opp\",\"metadata\":[\"riegl.device\",\"riegl.device_geometry\""
",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"riegl.scan_pattern"
"?\",\"riegl.time_base\",\"riegl.record_names\",\"riegl.control_object_refere"
"nce_file\"],\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_accuracies"
"?\",\"riegl.surface_normal\",\"riegl.plane_up\",\"riegl.point_count\",\"riegl."
"std_dev\",\"riegl.plane_width\",\"riegl.plane_height\",\"riegl.plane_confide"
"nce_normal\",\"riegl.model_fit_quality?\",\"riegl.used_for_adjustment\",\"ri"
"egl.xyz_socs\",\"riegl.timestamp\",\"riegl.mirror_facet\",\"riegl.platform_r"
"py_ROCS_NED\",\"riegl.platform_drpy_ROCS_NED\",\"riegl.platform_xyz_ROCS_E"
"NU\",\"riegl.platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_vector\",\"riegl.raw"
"_range\",\"riegl.raw_frame_angle\",\"riegl.raw_line_angle\",\"riegl.referenc"
"e_object_id\"],\"extension\":\"opp\"}"
)

# Schema for ".opx" files
RDB_SCHEMA_RIEGL_OPX = (
"{\"identifier\":\"opx\",\"metadata\":[\"riegl.device\",\"riegl.device_geometry\""
",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"riegl.scan_pattern"
"?\",\"riegl.time_base\",\"riegl.control_object_catalog\",\"riegl.record_name"
"s\",\"riegl.control_object_reference_file\"],\"attributes\":[\"riegl.id\",\"ri"
"egl.xyz*\",\"riegl.control_object_type\",\"riegl.model_cs_axis_x?\",\"riegl."
"model_cs_axis_y?\",\"riegl.model_cs_axis_z?\",\"riegl.model_fit_quality?\","
"\"riegl.obs_confidence_xy?\",\"riegl.obs_confidence_z?\",\"riegl.obs_signal"
"_confidence_rot?\",\"riegl.used_for_adjustment\",\"riegl.xyz_socs\",\"riegl."
"timestamp\",\"riegl.mirror_facet\",\"riegl.platform_rpy_ROCS_NED\",\"riegl.p"
"latform_drpy_ROCS_NED\",\"riegl.platform_xyz_ROCS_ENU\",\"riegl.platform_d"
"xyz_ROCS_ENU\",\"riegl.sda.shift_vector\",\"riegl.raw_range\",\"riegl.raw_fr"
"ame_angle\",\"riegl.raw_line_angle\",\"riegl.reference_object_id\"],\"extens"
"ion\":\"opx\"}"
)

# Schema for ".owp" files
RDB_SCHEMA_RIEGL_OWP = (
"{\"identifier\":\"owp\",\"metadata\":[],\"attributes\":[\"riegl.id*\",\"riegl.raw"
"_range\",\"riegl.amplitude\",\"riegl.deviation\",\"riegl.gain\"],\"extension\":"
"\"owp\"}"
)

# Schema for ".pefx" files
RDB_SCHEMA_RIEGL_PEFX = (
"{\"identifier\":\"pefx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.vertex_info\",\""
"riegl.record_names\",\"riegl.imported_files\"],\"attributes\":[\"riegl.id\",\""
"riegl.xyz*\",\"riegl.xyz_accuracies?\",\"riegl.surface_normal\",\"riegl.plan"
"e_up\",\"riegl.std_dev\",\"riegl.plane_confidence_normal\",\"riegl.plane_wid"
"th\",\"riegl.plane_height\",\"riegl.vertex_first\",\"riegl.vertex_count\",\"ri"
"egl.used_for_adjustment\",\"riegl.acquisition_date?\",\"riegl.import_line_"
"number\",\"riegl.import_line_count\"],\"extension\":\"pefx\"}"
)

# Schema for ".pofx" files
RDB_SCHEMA_RIEGL_PROJECT_POFX = (
"{\"identifier\":\"project.pofx\",\"metadata\":[\"riegl.time_base\",\"riegl.traj"
"ectory_info\"],\"attributes\":[\"riegl.id\",\"riegl.pof_timestamp*\",\"riegl.p"
"of_latitude\",\"riegl.pof_longitude\",\"riegl.pof_height\",\"riegl.pof_roll\""
",\"riegl.pof_pitch\",\"riegl.pof_yaw\",\"riegl.pof_path_length\"],\"extension"
"\":\"pofx\"}"
)

# Schema for ".pofx" files
RDB_SCHEMA_RIEGL_SCAN_POFX = (
"{\"identifier\":\"scan.pofx\",\"metadata\":[\"riegl.time_base\",\"riegl.geo_tag"
"\",\"riegl.trajectory_info\"],\"attributes\":[\"riegl.id\",\"riegl.pof_timesta"
"mp*\",\"riegl.pof_latitude\",\"riegl.pof_longitude\",\"riegl.pof_height\",\"ri"
"egl.pof_roll\",\"riegl.pof_pitch\",\"riegl.pof_yaw\",\"riegl.pof_path_length"
"\",\"riegl.pof_xyz\",\"riegl.pof_roll_ned\",\"riegl.pof_pitch_ned\",\"riegl.po"
"f_yaw_ned\"],\"extension\":\"pofx\"}"
)

# Schema for ".poqx" files
RDB_SCHEMA_RIEGL_PROJECT_POQX = (
"{\"identifier\":\"project.poqx\",\"metadata\":[\"riegl.time_base\",\"riegl.traj"
"ectory_info\"],\"attributes\":[\"riegl.id\",\"riegl.pof_timestamp*\",\"riegl.p"
"of_accuracy_north\",\"riegl.pof_accuracy_east\",\"riegl.pof_accuracy_down\""
",\"riegl.pof_accuracy_roll\",\"riegl.pof_accuracy_pitch\",\"riegl.pof_accur"
"acy_yaw\",\"riegl.pof_path_length\",\"riegl.pof_pdop\",\"riegl.pof_satellite"
"s_gnss?\",\"riegl.pof_satellites_gps?\",\"riegl.pof_satellites_glonass?\",\""
"riegl.pof_satellites_beidou?\",\"riegl.pof_satellites_galileo?\",\"riegl.p"
"of_satellites_qzss?\"],\"extension\":\"poqx\"}"
)

# Schema for ".poqx" files
RDB_SCHEMA_RIEGL_SCAN_POQX = (
"{\"identifier\":\"scan.poqx\",\"metadata\":[\"riegl.time_base\",\"riegl.traject"
"ory_info\"],\"attributes\":[\"riegl.id\",\"riegl.pof_timestamp*\",\"riegl.pof_"
"accuracy_north\",\"riegl.pof_accuracy_east\",\"riegl.pof_accuracy_down\",\"r"
"iegl.pof_accuracy_roll\",\"riegl.pof_accuracy_pitch\",\"riegl.pof_accuracy"
"_yaw\",\"riegl.pof_path_length\",\"riegl.pof_pdop\",\"riegl.pof_satellites_g"
"nss?\",\"riegl.pof_satellites_gps?\",\"riegl.pof_satellites_glonass?\",\"rie"
"gl.pof_satellites_beidou?\",\"riegl.pof_satellites_galileo?\",\"riegl.pof_"
"satellites_qzss?\"],\"extension\":\"poqx\"}"
)

# Schema for ".ppx" files
RDB_SCHEMA_RIEGL_PPX = (
"{\"identifier\":\"ppx\",\"metadata\":[\"riegl.device\",\"riegl.time_base\"],\"att"
"ributes\":[\"riegl.id\",\"riegl.pps_timestamp_intern*\",\"riegl.pps_timestam"
"p_extern\"],\"extension\":\"ppx\"}"
)

# Schema for ".ptch" files
RDB_SCHEMA_RIEGL_PROJECT_PTCH = (
"{\"identifier\":\"project.ptch\",\"metadata\":[\"riegl.device\",\"riegl.geo_tag"
"?\",\"riegl.scan_pattern?\",\"riegl.time_base?\",\"riegl.plane_patch_statist"
"ics?\"],\"attributes\":[\"riegl.xyz*\",\"riegl.surface_normal\",\"riegl.plane_"
"up\",\"riegl.reflectance?\",\"riegl.point_count\",\"riegl.std_dev\",\"riegl.pl"
"ane_width\",\"riegl.plane_height\",\"riegl.plane_count\",\"riegl.covariances"
"\",\"riegl.id\"],\"extension\":\"ptch\"}"
)

# Schema for ".ptch" files
RDB_SCHEMA_RIEGL_SCAN_PTCH = (
"{\"identifier\":\"scan.ptch\",\"metadata\":[\"riegl.device\",\"riegl.device_geo"
"metry\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"riegl.scan_p"
"attern?\",\"riegl.time_base\",\"riegl.plane_patch_statistics?\",\"riegl.plan"
"e_slope_class_info?\"],\"attributes\":[\"riegl.xyz*\",\"riegl.xyz_socs\",\"rie"
"gl.direction?\",\"riegl.direction_medium?\",\"riegl.direction_coarse?\",\"ri"
"egl.surface_normal\",\"riegl.plane_up\",\"riegl.timestamp\",\"riegl.reflecta"
"nce?\",\"riegl.point_count\",\"riegl.std_dev\",\"riegl.plane_width\",\"riegl.p"
"lane_height\",\"riegl.plane_count\",\"riegl.mirror_facet\",\"riegl.covarianc"
"es\",\"riegl.id\",\"riegl.plane_slope_class?\",\"riegl.plane_occupancy\",\"rie"
"gl.plane_confidence_normal\",\"riegl.plane_cog_link\",\"riegl.match_count\""
",\"riegl.platform_rpy_ROCS_NED\",\"riegl.platform_xyz_ROCS_ENU\",\"riegl.pl"
"atform_drpy_ROCS_NED\",\"riegl.platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_"
"vector\",\"riegl.raw_range\",\"riegl.raw_frame_angle\",\"riegl.raw_line_angl"
"e\"],\"extension\":\"ptch\"}"
)

# Schema for ".ptch" files
RDB_SCHEMA_RIEGL_SCANPOS_PTCH = (
"{\"identifier\":\"scanpos.ptch\",\"metadata\":[\"riegl.device\",\"riegl.geo_tag"
"?\",\"riegl.scan_pattern?\",\"riegl.time_base?\",\"riegl.plane_patch_statist"
"ics?\"],\"attributes\":[\"riegl.xyz*\",\"riegl.surface_normal\",\"riegl.plane_"
"up\",\"riegl.reflectance?\",\"riegl.point_count\",\"riegl.std_dev\",\"riegl.pl"
"ane_width\",\"riegl.plane_height\",\"riegl.plane_count\",\"riegl.covariances"
"\",\"riegl.id\"],\"extension\":\"ptch\"}"
)

# Schema for ".rdbx" files
RDB_SCHEMA_RIEGL_RDBX = (
"{\"identifier\":\"rdbx\",\"metadata\":[\"riegl.atmosphere\",\"riegl.beam_geomet"
"ry\",\"riegl.device_geometry\",\"riegl.device\",\"riegl.gaussian_decompositi"
"on?\",\"riegl.exponential_decomposition?\",\"riegl.geo_tag\",\"riegl.georefe"
"rencing_parameters\",\"riegl.mta_settings?\",\"riegl.near_range_correction"
"?\",\"riegl.noise_estimates?\",\"riegl.angular_notch_filter?\",\"riegl.notch"
"_filter?\",\"riegl.pointcloud_info?\",\"riegl.pulse_position_modulation?\","
"\"riegl.range_statistics?\",\"riegl.receiver_internals?\",\"riegl.reflectan"
"ce_calculation?\",\"riegl.reflectance_correction?\",\"riegl.scan_pattern\","
"\"riegl.time_base\",\"riegl.waveform_settings?\",\"riegl.window_analysis?\","
"\"riegl.window_echo_correction?\"],\"attributes\":[\"riegl.id\",\"riegl.times"
"tamp\",\"riegl.xyz*\",\"riegl.xyz_socs\",\"riegl.direction_medium\",\"riegl.am"
"plitude\",\"riegl.reflectance?\",\"riegl.deviation?\",\"riegl.pulse_width?\","
"\"riegl.target_index\",\"riegl.target_count\",\"riegl.mirror_facet?\",\"riegl"
".scan_segment?\",\"riegl.mta_unresolved?\",\"riegl.mta_zone?\",\"riegl.windo"
"w_echo_impact_corrected?\",\"riegl.rgba?\",\"riegl.class?\",\"riegl.start_of"
"_scan_line?\",\"riegl.end_of_scan_line?\",\"riegl.source_indicator?\",\"rieg"
"l.fwa?\",\"riegl.waveform_available?\",\"riegl.wfm_sbl_id?\",\"riegl.wfm_ech"
"o_time_offset?\",\"riegl.scan_angle\",\"riegl.scan_direction\",\"riegl.sourc"
"e_index?\",\"riegl.hydro_intersection_point?\",\"riegl.hydro_intersection_"
"normal?\"],\"extension\":\"rdbx\"}"
)

# Schema for ".rmvx" files
RDB_SCHEMA_RIEGL_RMVX = (
"{\"identifier\":\"rmvx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.voxel_info\",\"r"
"iegl.time_base?\"],\"attributes\":[\"riegl.id\",\"riegl.voxel_index*\",\"riegl"
".amplitude\",\"riegl.reflectance\",\"riegl.deviation\",\"riegl.direction_med"
"ium\",\"riegl.point_count\",\"riegl.voxel_linear_sums\",\"riegl.voxel_square"
"_sums\",\"riegl.timestamp_min?\",\"riegl.timestamp_max?\"],\"extension\":\"rmv"
"x\"}"
)

# Schema for ".s10x" files
RDB_SCHEMA_RIEGL_S10X = (
"{\"identifier\":\"s10x\",\"metadata\":[\"riegl.time_base\",\"riegl.pose_sensors"
"\"],\"attributes\":[\"riegl.id\",\"riegl.timestamp*\",\"riegl.frame_angle_coar"
"se\",\"riegl.gyroscope_raw\",\"riegl.accelerometer_raw\",\"riegl.magnetic_fi"
"eld_sensor_raw\",\"riegl.gyroscope\",\"riegl.accelerometer\",\"riegl.magneti"
"c_field_sensor\",\"riegl.barometric_height_amsl\",\"riegl.temperature\",\"ri"
"egl.line_scan_active\",\"riegl.frame_scan_active\",\"riegl.data_acquisitio"
"n_active\"],\"extension\":\"s10x\"}"
)

# Schema for ".sbx" files
RDB_SCHEMA_RIEGL_SBX = (
"{\"identifier\":\"sbx\",\"metadata\":[],\"attributes\":[\"riegl.id*\",\"riegl.wfm"
"_sbl_channel\",\"riegl.wfm_sbl_mean\",\"riegl.wfm_sbl_std_dev\",\"riegl.wfm_"
"sbl_time_offset\",\"riegl.wfm_sda_first\",\"riegl.wfm_sda_count\"],\"extensi"
"on\":\"sbx\"}"
)

# Schema for ".sdcx" files
RDB_SCHEMA_RIEGL_SDCX = (
"{\"identifier\":\"sdcx\",\"metadata\":[\"riegl.atmosphere\",\"riegl.beam_geomet"
"ry\",\"riegl.device_geometry\",\"riegl.device\",\"riegl.gaussian_decompositi"
"on?\",\"riegl.exponential_decomposition?\",\"riegl.mta_settings?\",\"riegl.n"
"ear_range_correction?\",\"riegl.noise_estimates?\",\"riegl.angular_notch_f"
"ilter?\",\"riegl.notch_filter?\",\"riegl.pointcloud_info?\",\"riegl.pulse_po"
"sition_modulation?\",\"riegl.range_statistics?\",\"riegl.receiver_internal"
"s?\",\"riegl.reflectance_calculation?\",\"riegl.reflectance_correction?\",\""
"riegl.scan_pattern\",\"riegl.time_base\",\"riegl.window_analysis?\",\"riegl."
"window_echo_correction?\"],\"attributes\":[\"riegl.id\",\"riegl.timestamp*\","
"\"riegl.xyz\",\"riegl.amplitude\",\"riegl.reflectance?\",\"riegl.deviation?\","
"\"riegl.pulse_width?\",\"riegl.target_index\",\"riegl.target_count\",\"riegl."
"mirror_facet?\",\"riegl.scan_segment?\",\"riegl.mta_unresolved?\",\"riegl.mt"
"a_zone?\",\"riegl.window_echo_impact_corrected?\",\"riegl.class?\",\"riegl.s"
"tart_of_scan_line?\",\"riegl.end_of_scan_line?\",\"riegl.source_indicator?"
"\",\"riegl.fwa?\",\"riegl.waveform_available?\",\"riegl.wfm_sbl_id?\",\"riegl."
"wfm_echo_time_offset?\"],\"extension\":\"sdcx\"}"
)

# Schema for ".sidx" files
RDB_SCHEMA_RIEGL_SIDX = (
"{\"identifier\":\"sidx\",\"metadata\":[\"riegl.shot_info\",\"riegl.echo_info\"],"
"\"attributes\":[\"riegl.id\",\"riegl.shot_timestamp_hr*\",\"riegl.echo_first\""
",\"riegl.echo_count\"],\"extension\":\"sidx\"}"
)

# Schema for ".sodx" files
RDB_SCHEMA_RIEGL_SODX = (
"{\"identifier\":\"sodx\",\"metadata\":[\"riegl.atmosphere\",\"riegl.device\",\"ri"
"egl.device_geometry\",\"riegl.device_output_limits\",\"riegl.beam_geometry"
"\",\"riegl.near_range_correction?\",\"riegl.window_echo_correction?\",\"rieg"
"l.receiver_internals?\",\"riegl.gaussian_decomposition?\",\"riegl.exponent"
"ial_decomposition?\",\"riegl.mta_settings?\",\"riegl.pulse_position_modula"
"tion?\",\"riegl.notch_filter?\",\"riegl.reflectance_calculation?\",\"riegl.s"
"can_pattern\",\"riegl.time_base\",\"riegl.waveform_info?\",\"riegl.echo_info"
"?\"],\"attributes\":[\"riegl.id\",\"riegl.shot_timestamp_hr*\",\"riegl.mirror_"
"facet\",\"riegl.scan_segment\",\"riegl.start_of_scan_line\",\"riegl.line_ang"
"le_coarse\",\"riegl.shot_origin\",\"riegl.shot_direction\",\"riegl.shot_dire"
"ction_levelled?\",\"riegl.wfm_sbl_first?\",\"riegl.wfm_sbl_count?\",\"riegl."
"echo_first?\",\"riegl.echo_count?\"],\"extension\":\"sodx\"}"
)

# Schema for ".sp{C}" files
RDB_SCHEMA_RIEGL_SPC = (
"{\"identifier\":\"sp{C}\",\"metadata\":[],\"attributes\":[\"riegl.id*\",\"riegl.w"
"fm_sample_value\"],\"extension\":\"sp{C}\"}"
)

# Schema for ".vtx" files
RDB_SCHEMA_RIEGL_VTX = (
"{\"identifier\":\"vtx\",\"metadata\":[\"riegl.geo_tag\"],\"attributes\":[\"riegl."
"id*\",\"riegl.xyz\",\"riegl.xyz_accuracies?\"],\"extension\":\"vtx\"}"
)

# Schema for ".vxls" files
RDB_SCHEMA_RIEGL_VXLS = (
"{\"identifier\":\"vxls\",\"metadata\":[\"riegl.voxel_info\",\"riegl.geo_tag?\"],"
"\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.covariances\",\"riegl.pca_a"
"xis_max\",\"riegl.pca_axis_min\",\"riegl.pca_extents\",\"riegl.point_count\","
"\"riegl.reflectance\",\"riegl.shape_id\",\"riegl.voxel_collapsed\",\"riegl.st"
"d_dev?\"],\"extension\":\"vxls\"}"
)

# Schema for ".wdcx" files
RDB_SCHEMA_RIEGL_WDCX = (
"{\"identifier\":\"wdcx\",\"metadata\":[\"riegl.atmosphere\",\"riegl.beam_geomet"
"ry\",\"riegl.device_geometry\",\"riegl.device\",\"riegl.gaussian_decompositi"
"on?\",\"riegl.exponential_decomposition?\",\"riegl.geo_tag\",\"riegl.georefe"
"rencing_parameters\",\"riegl.mta_settings?\",\"riegl.near_range_correction"
"?\",\"riegl.noise_estimates?\",\"riegl.angular_notch_filter?\",\"riegl.notch"
"_filter?\",\"riegl.pointcloud_info?\",\"riegl.pulse_position_modulation?\","
"\"riegl.range_statistics?\",\"riegl.receiver_internals?\",\"riegl.reflectan"
"ce_calculation?\",\"riegl.reflectance_correction?\",\"riegl.scan_pattern\","
"\"riegl.time_base\",\"riegl.waveform_settings?\",\"riegl.window_analysis?\","
"\"riegl.window_echo_correction?\"],\"attributes\":[\"riegl.id\",\"riegl.times"
"tamp\",\"riegl.xyz*\",\"riegl.xyz_socs\",\"riegl.direction_medium\",\"riegl.am"
"plitude\",\"riegl.reflectance?\",\"riegl.deviation?\",\"riegl.pulse_width?\","
"\"riegl.target_index\",\"riegl.target_count\",\"riegl.mirror_facet?\",\"riegl"
".scan_segment?\",\"riegl.mta_unresolved?\",\"riegl.mta_zone?\",\"riegl.windo"
"w_echo_impact_corrected?\",\"riegl.rgba?\",\"riegl.class?\",\"riegl.start_of"
"_scan_line?\",\"riegl.end_of_scan_line?\",\"riegl.source_indicator?\",\"rieg"
"l.fwa?\",\"riegl.waveform_available?\",\"riegl.wfm_sbl_id?\",\"riegl.wfm_ech"
"o_time_offset?\",\"riegl.scan_angle\",\"riegl.scan_direction\",\"riegl.sourc"
"e_index?\",\"riegl.hydro_intersection_point?\",\"riegl.hydro_intersection_"
"normal?\"],\"extension\":\"wdcx\"}"
)

# Schema for ".wex" files
RDB_SCHEMA_RIEGL_WEX = (
"{\"identifier\":\"wex\",\"metadata\":[\"riegl.device\",\"riegl.notch_filter\",\"r"
"iegl.window_analysis\"],\"attributes\":[\"riegl.id\",\"riegl.timestamp*\",\"ri"
"egl.wex_filter_valid\",\"riegl.wex_point_count\",\"riegl.wex_amplitude\",\"r"
"iegl.wex_amplitude_std_dev\",\"riegl.wex_amplitude_min\",\"riegl.wex_ampli"
"tude_max\",\"riegl.wex_amplitude_offset\",\"riegl.wex_deviation\",\"riegl.we"
"x_deviation_std_dev\",\"riegl.wex_deviation_min\",\"riegl.wex_deviation_ma"
"x\",\"riegl.wex_range\",\"riegl.wex_range_std_dev\",\"riegl.wex_range_min\",\""
"riegl.wex_range_max\",\"riegl.wex_filter_range_min\",\"riegl.wex_filter_ra"
"nge_max\",\"riegl.wex_filter_amplitude_max\"],\"extension\":\"wex\"}"
)

# Table of all RDB file schema strings
RDB_SCHEMA_ARRAY = [
    RDB_SCHEMA_RIEGL_AVG_FWA,
    RDB_SCHEMA_RIEGL_AVG_SBX,
    RDB_SCHEMA_RIEGL_AVG_SIDX,
    RDB_SCHEMA_RIEGL_AVG_SPC,
    RDB_SCHEMA_RIEGL_CPX,
    RDB_SCHEMA_RIEGL_FWA,
    RDB_SCHEMA_RIEGL_MPX,
    RDB_SCHEMA_RIEGL_MTCH,
    RDB_SCHEMA_RIEGL_MVX,
    RDB_SCHEMA_RIEGL_OBSX,
    RDB_SCHEMA_RIEGL_OPEFX,
    RDB_SCHEMA_RIEGL_OPP,
    RDB_SCHEMA_RIEGL_OPX,
    RDB_SCHEMA_RIEGL_OWP,
    RDB_SCHEMA_RIEGL_PEFX,
    RDB_SCHEMA_RIEGL_PROJECT_POFX,
    RDB_SCHEMA_RIEGL_SCAN_POFX,
    RDB_SCHEMA_RIEGL_PROJECT_POQX,
    RDB_SCHEMA_RIEGL_SCAN_POQX,
    RDB_SCHEMA_RIEGL_PPX,
    RDB_SCHEMA_RIEGL_PROJECT_PTCH,
    RDB_SCHEMA_RIEGL_SCAN_PTCH,
    RDB_SCHEMA_RIEGL_SCANPOS_PTCH,
    RDB_SCHEMA_RIEGL_RDBX,
    RDB_SCHEMA_RIEGL_RMVX,
    RDB_SCHEMA_RIEGL_S10X,
    RDB_SCHEMA_RIEGL_SBX,
    RDB_SCHEMA_RIEGL_SDCX,
    RDB_SCHEMA_RIEGL_SIDX,
    RDB_SCHEMA_RIEGL_SODX,
    RDB_SCHEMA_RIEGL_SPC,
    RDB_SCHEMA_RIEGL_VTX,
    RDB_SCHEMA_RIEGL_VXLS,
    RDB_SCHEMA_RIEGL_WDCX,
    RDB_SCHEMA_RIEGL_WEX
]
