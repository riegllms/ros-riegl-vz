#
#*******************************************************************************
#
#  Copyright 2022 RIEGL Laser Measurement Systems
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
#  SPDX-License-Identifier: Apache-2.0
#
#*******************************************************************************
#
"""
*******************************************************************************
*
* \author  RIEGL LMS GmbH, Austria
* \brief   Description of RIEGL RDB 2 database meta data items.
* \version 2015-10-27/AW: Initial version
* \version 2015-11-25/AW: Item "Geo Tag" added
* \version 2016-10-27/AW: Item "Voxel Information" added
* \version 2016-11-17/AW: Item "Voxel Information" updated
* \version 2016-12-12/AW: Item "Range Statistics" added
* \version 2017-03-08/AW: Item "Plane Patch Statistics" added
* \version 2017-04-05/AW: Items "Atmosphere" and "Geometric Scale Factor" added
* \version 2017-08-22/AW: Items for waveform sample block and value files added
* \version 2017-10-24/AW: Item "Gaussian Decomposition" added
* \version 2017-11-13/AW: Item "riegl.scan_pattern" updated
* \version 2017-11-21/AW: Item "riegl.trajectory_info" added
* \version 2018-01-11/AW: Item "riegl.beam_geometry" added
* \version 2018-01-15/AW: Item "riegl.reflectance_calculation" added
* \version 2018-01-15/AW: Item "riegl.near_range_correction" added
* \version 2018-01-15/AW: Item "riegl.device_geometry" added
* \version 2018-02-13/AW: Item "riegl.notch_filter" added
* \version 2018-03-08/AW: Item "riegl.window_echo_correction" added
* \version 2018-03-15/AW: Item "riegl.pulse_position_modulation" added
* \version 2018-05-24/AW: Item "riegl.pixel_info" added
* \version 2018-06-08/AW: Item "riegl.shot_info" added
* \version 2018-06-08/AW: Item "riegl.echo_info" added
* \version 2018-06-14/AW: Item "riegl.mta_settings" added
* \version 2018-06-14/AW: Item "riegl.receiver_internals" added
* \version 2018-06-14/AW: Item "riegl.device_output_limits" added
* \version 2018-06-26/AW: Schema: replace "number" with "integer" if applicable
* \version 2018-07-09/AW: Item "riegl.pose_estimation" added
* \version 2018-07-09/AW: Item "riegl.pose_sensors" added
* \version 2018-09-20/AW: Item "riegl.pointcloud_info" added
* \version 2018-11-08/AW: Item "riegl.scan_pattern" updated
* \version 2018-11-13/AW: Item "riegl.receiver_internals" updated
* \version 2019-03-06/AW: Item "riegl.receiver_internals" updated
* \version 2019-03-21/AW: Item "riegl.device_geometry" updated
* \version 2019-04-15/AW: Item "riegl.point_attribute_groups" added
* \version 2019-04-30/AW: Item "riegl.waveform_settings" added
* \version 2019-10-03/AW: Item "riegl.angular_notch_filter" added
* \version 2019-10-03/AW: Item "riegl.noise_estimates" added
* \version 2019-10-25/AW: Item "riegl.window_analysis" added
* \version 2019-11-06/AW: Item "riegl.georeferencing_parameters" added
* \version 2019-11-27/AW: Item "riegl.plane_patch_matching" added
* \version 2019-12-13/AW: Items for tie-/control objects added
* \version 2019-12-19/AW: Items for tie-/control objects added
* \version 2020-02-04/AW: Item "riegl.detection_probability" added
* \version 2020-02-04/AW: Item "riegl.licenses" added
* \version 2020-04-27/AW: Item "riegl.waveform_info" updated (schema+example)
* \version 2020-09-03/AW: Item "riegl.reflectance_correction" added
* \version 2020-09-10/AW: Item "riegl.device_geometry_passive_channel" added
* \version 2020-09-25/AW: Item "riegl.georeferencing_parameters" updated
* \version 2020-09-25/AW: Item "riegl.trajectory_info" updated
* \version 2020-09-29/AW: Item "riegl.temperature_calculation" added
* \version 2020-10-23/AW: Item "riegl.exponential_decomposition" added (#3709)
* \version 2020-11-30/AW: Item "riegl.notch_filter" updated (schema)
* \version 2020-12-02/AW: Item "riegl.georeferencing_parameters" updated (schema)
* \version 2021-02-02/AW: Item "riegl.plane_slope_class_info" added (rdbplanes/#7)
* \version 2021-02-16/AW: Item "riegl.device_output_limits" updated (schema, #3811)
* \version 2021-03-03/AW: Item "riegl.exponential_decomposition" updated (schema, #3822)
* \version 2021-03-03/AW: Item "riegl.waveform_averaging_settings" added (#3821)
* \version 2021-04-01/AW: Item "riegl.voxel_info" updated (schema, #3854)
* \version 2021-04-16/AW: Item "riegl.voxel_info" updated (schema, #3866)
* \version 2021-09-30/AW: Item "riegl.waveform_info" updated (schema+example, #4016)
* \version 2021-10-04/AW: Improved spelling of the descriptions of some items
* \version 2021-11-04/AW: Rename "riegl.record_names" to "riegl.item_names" (#4034)
* \version 2022-03-11/AW: Item "riegl.devices" added (#4162)
* \version 2022-03-14/AW: Item "riegl.stored_filters" added (#4164)
*
*******************************************************************************
"""

# Angular notch filter parameters for window glass echoes
RDB_RIEGL_ANGULAR_NOTCH_FILTER             = "riegl.angular_notch_filter"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_TITLE       = "Angular Notch Filter"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_DESCRIPTION = "Angular notch filter parameters for window glass echoes"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_STATUS      = "optional"
RDB_RIEGL_ANGULAR_NOTCH_FILTER_SCHEMA = (
"{\"description\":\"Angular notch filter parameters for window glass "
"echoes\",\"title\":\"Angular Notch Filter\",\"type\":\"object\",\"$schema\":\"http"
"://json-schema.org/draft-04/schema#\",\"properties\":{\"range_mean\":{\"desc"
"ription\":\"Mean range [m]\",\"items\":{\"type\":\"number\"},\"type\":\"array\"},\"a"
"mplitude_mean\":{\"description\":\"Mean amplitude [dB]\",\"items\":{\"type\":\"n"
"umber\"},\"type\":\"array\"},\"angle\":{\"description\":\"Angle [deg]\",\"items\":{"
"\"type\":\"number\"},\"type\":\"array\"}},\"required\":[\"angle\",\"range_mean\",\"am"
"plitude_mean\"]}"
)
RDB_RIEGL_ANGULAR_NOTCH_FILTER_EXAMPLE = (
"{\"range_mean\":[0.094,0.094,0.09075,0.08675,0.0815,0.0775,0.074,0.071,0"
".068,0.0675,0.06475],\"amplitude_mean\":[3.780913,3.780913,3.480913,3.12"
"0913,2.850913,2.720913,2.680913,2.610913,2.530913,2.570913,2.570913],\""
"angle\":[14.0,15.0,16.0,17.0,18.0,19.0,20.0,21.0,22.0,23.0,24.0]}"
)

# Atmospheric parameters
RDB_RIEGL_ATMOSPHERE             = "riegl.atmosphere"
RDB_RIEGL_ATMOSPHERE_TITLE       = "Atmosphere"
RDB_RIEGL_ATMOSPHERE_DESCRIPTION = "Atmospheric parameters"
RDB_RIEGL_ATMOSPHERE_STATUS      = "optional"
RDB_RIEGL_ATMOSPHERE_SCHEMA = (
"{\"description\":\"Atmospheric parameters\",\"title\":\"Atmospheric Parameter"
"s\",\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\""
",\"properties\":{\"wavelength\":{\"description\":\"Laser wavelength "
"[nm]\",\"type\":\"number\"},\"pressure_sl\":{\"description\":\"Atmospheric "
"pressure at sea level "
"[mbar]\",\"type\":\"number\"},\"group_velocity\":{\"description\":\"Group "
"velocity of laser beam "
"[m/s]\",\"type\":\"number\"},\"attenuation\":{\"description\":\"Atmospheric "
"attenuation "
"[1/km]\",\"type\":\"number\"},\"rel_humidity\":{\"description\":\"Relative "
"humidity along measurement path "
"[%]\",\"type\":\"number\"},\"amsl\":{\"description\":\"Height above mean sea "
"level (AMSL) "
"[m]\",\"type\":\"number\"},\"temperature\":{\"description\":\"Temperature along "
"measurement path "
"[\\u00b0C]\",\"type\":\"number\"},\"pressure\":{\"description\":\"Pressure along "
"measurment path [mbar]\",\"type\":\"number\"}},\"required\":[\"temperature\",\"p"
"ressure\",\"rel_humidity\",\"pressure_sl\",\"amsl\",\"group_velocity\",\"attenua"
"tion\",\"wavelength\"]}"
)
RDB_RIEGL_ATMOSPHERE_EXAMPLE = (
"{\"wavelength\":1550,\"pressure_sl\":970,\"group_velocity\":299711000.0,\"att"
"enuation\":0.028125,\"rel_humidity\":63,\"amsl\":0,\"temperature\":7,\"pressur"
"e\":970}"
)

# Laser beam geometry details
RDB_RIEGL_BEAM_GEOMETRY             = "riegl.beam_geometry"
RDB_RIEGL_BEAM_GEOMETRY_TITLE       = "Beam Geometry"
RDB_RIEGL_BEAM_GEOMETRY_DESCRIPTION = "Laser beam geometry details"
RDB_RIEGL_BEAM_GEOMETRY_STATUS      = "optional"
RDB_RIEGL_BEAM_GEOMETRY_SCHEMA = (
"{\"description\":\"Laser beam geometry details\",\"title\":\"Beam Geometry\",\""
"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"pr"
"operties\":{\"beam_divergence\":{\"description\":\"Beam divergence in far "
"field [rad]\",\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\":false},\"be"
"am_exit_diameter\":{\"description\":\"Beam width at exit aperture [m]\",\"mi"
"nimum\":0,\"type\":\"number\",\"exclusiveMinimum\":false}},\"required\":[\"beam_"
"exit_diameter\",\"beam_divergence\"]}"
)
RDB_RIEGL_BEAM_GEOMETRY_EXAMPLE = (
"{\"beam_divergence\":0.0003,\"beam_exit_diameter\":0.0072}"
)

# List of control object type definitions
RDB_RIEGL_CONTROL_OBJECT_CATALOG             = "riegl.control_object_catalog"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_TITLE       = "Control Object Catalog"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_DESCRIPTION = "List of control object type definitions"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_STATUS      = "optional"
RDB_RIEGL_CONTROL_OBJECT_CATALOG_SCHEMA = (
"{\"description\":\"List of control object type "
"definitions\",\"title\":\"Control Object Catalog\",\"type\":\"object\",\"$schema"
"\":\"http://json-schema.org/draft-04/schema#\",\"properties\":{\"types\":{\"it"
"ems\":{\"type\":\"object\",\"oneOf\":[{\"$ref\":\"#/definitions/rectangle\"},{\"$r"
"ef\":\"#/definitions/checkerboard2x2\"},{\"$ref\":\"#/definitions/chevron\"},"
"{\"$ref\":\"#/definitions/circular_disk\"},{\"$ref\":\"#/definitions/cylinder"
"\"},{\"$ref\":\"#/definitions/sphere\"},{\"$ref\":\"#/definitions/round_corner"
"_cube_prism\"}]},\"type\":\"array\",\"uniqueItems\":true}},\"definitions\":{\"sp"
"here\":{\"description\":\"sphere\",\"allOf\":[{\"$ref\":\"#/definitions/common\"}"
",{\"description\":\"sphere specific "
"properties\",\"properties\":{\"diameter\":{\"description\":\"diameter in meter"
"s\",\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\":true},\"shape\":{\"desc"
"ription\":\"shape identifier\",\"type\":\"string\",\"enum\":[\"sphere\"]}},\"type\""
":\"object\",\"required\":[\"shape\",\"diameter\"]}],\"type\":\"object\"},\"cylinder"
"\":{\"description\":\"cylinder\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{"
"\"description\":\"cylinder specific "
"properties\",\"properties\":{\"diameter\":{\"description\":\"diameter in meter"
"s\",\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\":true},\"shape\":{\"desc"
"ription\":\"shape identifier\",\"type\":\"string\",\"enum\":[\"cylinder\"]},\"heig"
"ht\":{\"description\":\"height in meters\",\"minimum\":0,\"type\":\"number\",\"exc"
"lusiveMinimum\":true}},\"type\":\"object\",\"required\":[\"shape\",\"diameter\",\""
"height\"]}],\"type\":\"object\"},\"round_corner_cube_prism\":{\"description\":\""
"round corner cube "
"prism\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"description\":\"round "
"corner cube prism specific "
"properties\",\"properties\":{\"diameter\":{\"description\":\"diameter in meter"
"s\",\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\":true},\"shape\":{\"desc"
"ription\":\"shape identifier\",\"type\":\"string\",\"enum\":[\"round_corner_cube"
"_prism\"]},\"offset\":{\"description\":\"offset in meters, e.g. reflector "
"constant (optional)\",\"type\":\"number\"}},\"type\":\"object\",\"required\":[\"sh"
"ape\",\"diameter\"]}],\"type\":\"object\"},\"chevron\":{\"description\":\"chevron\""
",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"description\":\"chevron "
"specific "
"properties\",\"properties\":{\"thickness\":{\"description\":\"thickness in met"
"ers\",\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\":true},\"shape\":{\"de"
"scription\":\"shape identifier\",\"type\":\"string\",\"enum\":[\"chevron\"]},\"out"
"side_edge_length\":{\"description\":\"length of the two outer edges in met"
"ers\",\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\":true}},\"type\":\"obj"
"ect\",\"required\":[\"shape\",\"outside_edge_length\",\"thickness\"]}],\"type\":\""
"object\"},\"common\":{\"description\":\"common object "
"properties\",\"properties\":{\"description\":{\"description\":\"string "
"describing the object\",\"type\":\"string\"},\"shape\":{\"description\":\"shape "
"identifier\",\"type\":\"string\",\"enum\":[\"rectangle\",\"checkerboard2x2\",\"che"
"vron\",\"circular_disk\",\"cylinder\",\"sphere\",\"round_corner_cube_prism\"]},"
"\"name\":{\"description\":\"unique type identifier\",\"type\":\"string\",\"minLen"
"gth\":3},\"surface_type\":{\"description\":\"surface material type\",\"type\":\""
"string\",\"enum\":[\"retro_reflective_foil\",\"diffuse\"]}},\"type\":\"object\",\""
"required\":[\"name\",\"shape\"]},\"checkerboard2x2\":{\"description\":\"checkerb"
"oard 2 by 2\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"description\":\""
"checkerboard specific "
"properties\",\"properties\":{\"square_length\":{\"description\":\"length of a "
"square of the checkerboard in meters\",\"minimum\":0,\"type\":\"number\",\"exc"
"lusiveMinimum\":true},\"shape\":{\"description\":\"shape identifier\",\"type\":"
"\"string\",\"enum\":[\"checkerboard2x2\"]}},\"type\":\"object\",\"required\":[\"sha"
"pe\",\"square_length\"]}],\"type\":\"object\"},\"rectangle\":{\"description\":\"re"
"ctangle\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"description\":\"rect"
"angle specific properties\",\"properties\":{\"width\":{\"description\":\"width"
" in meters\",\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\":true},\"shap"
"e\":{\"type\":\"string\",\"enum\":[\"rectangle\"]},\"length\":{\"description\":\"len"
"gth in meters\",\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\":true}},\""
"type\":\"object\",\"required\":[\"shape\",\"length\",\"width\"]}],\"type\":\"object\""
"},\"circular_disk\":{\"description\":\"circular disk\",\"allOf\":[{\"$ref\":\"#/d"
"efinitions/common\"},{\"description\":\"circular disk specific "
"properties\",\"properties\":{\"diameter\":{\"description\":\"diameter in meter"
"s\",\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\":true},\"shape\":{\"desc"
"ription\":\"shape identifier\",\"type\":\"string\",\"enum\":[\"circular_disk\"]},"
"\"offset\":{\"description\":\"offset in meters, e.g. reflector constant (op"
"tional)\",\"type\":\"number\"}},\"type\":\"object\",\"required\":[\"shape\",\"diamet"
"er\"]}],\"type\":\"object\"}},\"required\":[\"types\"]}"
)
RDB_RIEGL_CONTROL_OBJECT_CATALOG_EXAMPLE = (
"{\"comments\":[\"This file contains a list of control object types (aka. "
"'catalog').\",\"Each type is described by an object,\",\"which must "
"contain at least the following parameters:\",\"  - name: unique "
"identifier of the type\",\"  - shape: one of the following supported "
"shapes:\",\"      - rectangle\",\"      - checkerboard2x2\",\"      - "
"chevron\",\"      - circular_disk\",\"      - cylinder\",\"      - sphere\",\""
"      - round_corner_cube_prism\",\"Depending on 'shape', the following "
"parameters must/may be specified:\",\"  - rectangle:\",\"      - length: "
"length in meters\",\"      - width: width in meters\",\"  - "
"checkerboard2x2:\",\"      - square_length: length of a square of the "
"checkerboard in meters\",\"  - circular_disk:\",\"      - diameter: "
"diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
"constant (optional)\",\"  - chevron:\",\"      - outside_edge_length: "
"length of the two outer edges in meters\",\"      - thickness: thickness"
" in meters\",\"  - cylinder:\",\"      - diameter: diameter in meters\",\""
"      - height:  height in meters\",\"  - sphere:\",\"      - diameter: "
"diameter in meters\",\"  - round_corner_cube_prism:\",\"      - diameter: "
"diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
"constant (optional)\",\"Optional parameters:\",\"    - description: string"
" describing the object\",\"    - surface_type: surface material type "
"(either 'retro_reflective_foil' or "
"'diffuse')\"],\"types\":[{\"description\":\"Rectangle (60cm x "
"30cm)\",\"shape\":\"rectangle\",\"width\":0.3,\"name\":\"Rectangle "
"60x30\",\"length\":0.6},{\"description\":\"Rectangle (80cm x "
"40cm)\",\"shape\":\"rectangle\",\"width\":0.4,\"name\":\"Rectangle "
"80x40\",\"length\":0.8},{\"description\":\"Checkerboard (square length: "
"30cm)\",\"shape\":\"checkerboard2x2\",\"name\":\"Checkerboard2x2 "
"30\",\"square_length\":0.3},{\"description\":\"Checkerboard (square length: "
"50cm)\",\"shape\":\"checkerboard2x2\",\"name\":\"Checkerboard2x2 "
"50\",\"square_length\":0.5},{\"description\":\"Chevron (a=24''; "
"b=4'')\",\"shape\":\"chevron\",\"thickness\":0.1016,\"name\":\"Chevron "
"24''/4''\",\"outside_edge_length\":0.6096},{\"description\":\" Circular Disk"
" (diameter: 50cm)\",\"shape\":\"circular_disk\",\"name\":\"Circular Disk "
"50\",\"surface_type\":\"diffuse\",\"diameter\":0.5},{\"description\":\"flat "
"circular reflector from retro-reflective foil\",\"name\":\"RIEGL flat "
"reflector 50 mm\",\"offset\":0.0,\"surface_type\":\"retro_reflective_foil\",\""
"diameter\":0.05,\"shape\":\"circular_disk\"},{\"description\":\"flat circular "
"reflector from retro-reflective foil\",\"name\":\"RIEGL flat reflector 100"
" mm\",\"offset\":0.0,\"surface_type\":\"retro_reflective_foil\",\"diameter\":0."
"1,\"shape\":\"circular_disk\"},{\"description\":\"flat circular reflector "
"from retro-reflective foil\",\"name\":\"RIEGL flat reflector 150 mm\",\"offs"
"et\":0.0,\"surface_type\":\"retro_reflective_foil\",\"diameter\":0.15,\"shape\""
":\"circular_disk\"},{\"description\":\"cylindrical reflector from "
"retro-reflective foil\",\"height\":0.05,\"surface_type\":\"retro_reflective_"
"foil\",\"diameter\":0.05,\"name\":\"RIEGL cylindrical reflector 50 "
"mm\",\"shape\":\"cylinder\"},{\"description\":\"cylindrical reflector from "
"retro-reflective foil\",\"height\":0.1,\"surface_type\":\"retro_reflective_f"
"oil\",\"diameter\":0.1,\"name\":\"RIEGL cylindrical reflector 100 "
"mm\",\"shape\":\"cylinder\"},{\"description\":\"Sphere (diameter: 200 "
"mm)\",\"shape\":\"sphere\",\"name\":\"Sphere 200 "
"mm\",\"diameter\":0.2},{\"description\":\"round corner cube "
"prism\",\"shape\":\"round_corner_cube_prism\",\"name\":\"Corner Cube Prism 50 "
"mm\",\"offset\":0.0,\"diameter\":0.05}]}"
)

# Details about the control object reference file
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE             = "riegl.control_object_reference_file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_TITLE       = "Control Object Reference file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_DESCRIPTION = "Details about the control object reference file"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_STATUS      = "optional"
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_SCHEMA = (
"{\"description\":\"Details about the control object reference "
"file\",\"title\":\"Control Object Reference "
"file\",\"properties\":{\"reference_file\":{\"description\":\"Reference to a "
"control object file\",\"properties\":{\"file_path\":{\"description\":\"Path of"
" the control object file relative to referring "
"file\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"Control object "
"file's Universally Unique Identifier (RFC 4122)\",\"type\":\"string\"}},\"ty"
"pe\":\"object\",\"required\":[\"file_uuid\",\"file_path\"]}},\"type\":\"object\",\"$"
"schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE_EXAMPLE = (
"{\"reference_file\":{\"file_path\":\"../../../10_CONTROL_OBJECTS/ControlPoi"
"nts.cpx\",\"file_uuid\":\"810f5d57-eccf-49ed-b07a-0cdd109b4213\"}}"
)

# Detection probability as a function of amplitude
RDB_RIEGL_DETECTION_PROBABILITY             = "riegl.detection_probability"
RDB_RIEGL_DETECTION_PROBABILITY_TITLE       = "Detection Probability"
RDB_RIEGL_DETECTION_PROBABILITY_DESCRIPTION = "Detection probability as a function of amplitude"
RDB_RIEGL_DETECTION_PROBABILITY_STATUS      = "optional"
RDB_RIEGL_DETECTION_PROBABILITY_SCHEMA = (
"{\"description\":\"Detection probability as a function of "
"amplitude\",\"title\":\"Detection Probability\",\"type\":\"object\",\"$schema\":\""
"http://json-schema.org/draft-04/schema#\",\"properties\":{\"amplitude\":{\"d"
"escription\":\"Amplitude [dB]\",\"items\":{\"type\":\"number\"},\"type\":\"array\"}"
",\"detection_probability\":{\"description\":\"Detection probability [0..1]\""
",\"items\":{\"type\":\"number\"},\"type\":\"array\"}},\"required\":[\"amplitude\",\"d"
"etection_probability\"]}"
)
RDB_RIEGL_DETECTION_PROBABILITY_EXAMPLE = (
"{\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0],\"detection"
"_probability\":[0.0,0.5,0.8,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0]}"
)

# Details about the device used to acquire the point cloud
RDB_RIEGL_DEVICE             = "riegl.device"
RDB_RIEGL_DEVICE_TITLE       = "Device Information"
RDB_RIEGL_DEVICE_DESCRIPTION = "Details about the device used to acquire the point cloud"
RDB_RIEGL_DEVICE_STATUS      = "optional"
RDB_RIEGL_DEVICE_SCHEMA = (
"{\"description\":\"Details about the device used to acquire the point "
"cloud\",\"title\":\"Device Information\",\"type\":\"object\",\"$schema\":\"http://"
"json-schema.org/draft-04/schema#\",\"properties\":{\"channel_text\":{\"descr"
"iption\":\"Optional channel description (e.g. 'Green Channel' for "
"multi-channel "
"devices)\",\"type\":\"string\"},\"device_build\":{\"description\":\"Device build"
" variant\",\"type\":\"string\"},\"device_name\":{\"description\":\"Optional "
"device name (e.g. 'Scanner 1' for multi-scanner "
"systems)\",\"type\":\"string\"},\"channel_number\":{\"description\":\"Laser "
"channel number (not defined or 0: single channel device)\",\"minimum\":0,"
"\"type\":\"integer\",\"exclusiveMinimum\":false},\"serial_number\":{\"descripti"
"on\":\"Device serial number (e.g. "
"S2221234)\",\"type\":\"string\"},\"device_type\":{\"description\":\"Device type "
"identifier (e.g. VZ-400i)\",\"type\":\"string\"}},\"required\":[\"device_type\""
",\"serial_number\"]}"
)
RDB_RIEGL_DEVICE_EXAMPLE = (
"{\"channel_text\":\"\",\"device_build\":\"\",\"device_name\":\"Scanner 1\",\"channe"
"l_number\":0,\"serial_number\":\"S2221234\",\"device_type\":\"VZ-400i\"}"
)

# Scanner device geometry details
RDB_RIEGL_DEVICE_GEOMETRY             = "riegl.device_geometry"
RDB_RIEGL_DEVICE_GEOMETRY_TITLE       = "Device Geometry"
RDB_RIEGL_DEVICE_GEOMETRY_DESCRIPTION = "Scanner device geometry details"
RDB_RIEGL_DEVICE_GEOMETRY_STATUS      = "optional"
RDB_RIEGL_DEVICE_GEOMETRY_SCHEMA = (
"{\"description\":\"Scanner device geometry details\",\"title\":\"Device Geome"
"try\",\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema"
"#\",\"properties\":{\"secondary\":{\"description\":\"Additional device "
"geometry structure "
"(optional)\",\"properties\":{\"ID\":{\"description\":\"Structure identifier\",\""
"items\":{\"type\":\"integer\"},\"maxItems\":2,\"type\":\"array\",\"minItems\":2},\"c"
"ontent\":{\"description\":\"Internal calibration values\",\"items\":{\"type\":\""
"number\"},\"type\":\"array\"}},\"type\":\"object\",\"required\":[\"ID\",\"content\"]}"
",\"primary\":{\"description\":\"Primary device geometry structure "
"(mandatory)\",\"properties\":{\"ID\":{\"description\":\"Structure identifier\","
"\"items\":{\"type\":\"integer\"},\"maxItems\":2,\"type\":\"array\",\"minItems\":2},\""
"content\":{\"description\":\"Internal calibration values\",\"items\":{\"type\":"
"\"number\"},\"type\":\"array\"}},\"type\":\"object\",\"required\":[\"ID\",\"content\"]"
"},\"amu\":{\"description\":\"Angle Measurement "
"Unit\",\"properties\":{\"lineCC\":{\"description\":\"Line Circle Count (number"
" of LSBs per full rotation about line axis)\",\"minimum\":0,\"type\":\"numbe"
"r\",\"exclusiveMinimum\":false},\"frameCC\":{\"description\":\"Frame Circle "
"Count (number of LSBs per full rotation about frame axis)\",\"minimum\":0"
",\"type\":\"number\",\"exclusiveMinimum\":false}},\"type\":\"object\"}},\"require"
"d\":[\"primary\"]}"
)
RDB_RIEGL_DEVICE_GEOMETRY_EXAMPLE = (
"{\"secondary\":{\"ID\":[91,0],\"content\":[0]},\"primary\":{\"ID\":[4,0],\"conten"
"t\":[0]},\"amu\":{\"lineCC\":124000,\"frameCC\":124000}}"
)

# Scanner passive channel device geometry details
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL             = "riegl.device_geometry_passive_channel"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_TITLE       = "Device Geometry Passive Channel"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_DESCRIPTION = "Scanner passive channel device geometry details"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_STATUS      = "optional"
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_SCHEMA = (
"{\"description\":\"Scanner passive channel device geometry "
"details\",\"title\":\"Device Geometry Passive Channel\",\"type\":\"object\",\"$s"
"chema\":\"http://json-schema.org/draft-04/schema#\",\"properties\":{\"primar"
"y\":{\"description\":\"Primary device geometry structure "
"(mandatory)\",\"properties\":{\"ID\":{\"description\":\"Structure identifier\","
"\"items\":{\"type\":\"integer\"},\"maxItems\":2,\"type\":\"array\",\"minItems\":2},\""
"content\":{\"description\":\"Internal calibration values\",\"items\":{\"type\":"
"\"number\"},\"type\":\"array\"}},\"type\":\"object\",\"required\":[\"ID\",\"content\"]"
"}},\"required\":[\"primary\"]}"
)
RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL_EXAMPLE = (
"{\"primary\":{\"ID\":[143,0],\"content\":[0]}}"
)

# Limits of the measured values output by the device
RDB_RIEGL_DEVICE_OUTPUT_LIMITS             = "riegl.device_output_limits"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_TITLE       = "Device Output Limits"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_DESCRIPTION = "Limits of the measured values output by the device"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_STATUS      = "optional"
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_SCHEMA = (
"{\"description\":\"Limits of the measured values output by the device. "
"The limits depend on the device type, measurement program and/or scan "
"pattern.\",\"title\":\"Device Output "
"Limits\",\"properties\":{\"amplitude_maximum\":{\"description\":\"Maximum "
"possible amplitude in "
"dB.\",\"type\":\"number\"},\"reflectance_minimum\":{\"description\":\"Minimum "
"possible reflectance in "
"dB.\",\"type\":\"number\"},\"range_maximum\":{\"description\":\"Maximum possible"
" range in "
"meters.\",\"type\":\"number\"},\"deviation_minimum\":{\"description\":\"Minimum "
"possible pulse shape deviation.\",\"type\":\"number\"},\"reflectance_maximum"
"\":{\"description\":\"Maximum possible reflectance in dB.\",\"type\":\"number\""
"},\"background_radiation_minimum\":{\"description\":\"Minimum possible "
"background radiation.\",\"type\":\"number\"},\"background_radiation_maximum\""
":{\"description\":\"Maximum possible background radiation.\",\"type\":\"numbe"
"r\"},\"deviation_maximum\":{\"description\":\"Maximum possible pulse shape "
"deviation.\",\"type\":\"number\"},\"range_minimum\":{\"description\":\"Minimum "
"possible range in meters.\",\"type\":\"number\"},\"mta_zone_count_maximum\":{"
"\"description\":\"Maximum number of MTA "
"zones.\",\"type\":\"number\"},\"echo_count_maximum\":{\"description\":\"Maximum "
"number of echoes a laser shot can "
"have.\",\"type\":\"number\"},\"amplitude_minimum\":{\"description\":\"Minimum "
"possible amplitude in dB.\",\"type\":\"number\"}},\"type\":\"object\",\"$schema\""
":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_DEVICE_OUTPUT_LIMITS_EXAMPLE = (
"{\"amplitude_maximum\":100.0,\"reflectance_minimum\":-100.0,\"background_ra"
"diation_maximum\":0,\"reflectance_maximum\":100.0,\"range_maximum\":10000.0"
",\"background_radiation_minimum\":0,\"deviation_minimum\":-1,\"range_minimu"
"m\":2.9,\"mta_zone_count_maximum\":7,\"deviation_maximum\":32767,\"amplitude"
"_minimum\":0.0}"
)

# Details about the devices used to acquire the point cloud
RDB_RIEGL_DEVICES             = "riegl.devices"
RDB_RIEGL_DEVICES_TITLE       = "Devices Information"
RDB_RIEGL_DEVICES_DESCRIPTION = "Details about the devices used to acquire the point cloud"
RDB_RIEGL_DEVICES_STATUS      = "optional"
RDB_RIEGL_DEVICES_SCHEMA = (
"{\"description\":\"Details about the devices used to acquire the point "
"cloud (e.g. when merging point clouds of different "
"devices)\",\"title\":\"Devices Information\",\"type\":\"array\",\"$schema\":\"http"
"://json-schema.org/draft-04/schema#\",\"items\":{\"properties\":{\"channel_t"
"ext\":{\"description\":\"Optional channel description (e.g. 'Green "
"Channel' for multi-channel "
"devices)\",\"type\":\"string\"},\"device_build\":{\"description\":\"Device build"
" variant\",\"type\":\"string\"},\"device_name\":{\"description\":\"Optional "
"device name (e.g. 'Scanner 1' for multi-scanner "
"systems)\",\"type\":\"string\"},\"signed\":{\"description\":\"Flag that is set "
"when the original 'riegl.device' entry in the source file was "
"correctly "
"signed.\",\"type\":\"boolean\"},\"channel_number\":{\"description\":\"Laser "
"channel number (not defined or 0: single channel device)\",\"minimum\":0,"
"\"type\":\"integer\",\"exclusiveMinimum\":false},\"serial_number\":{\"descripti"
"on\":\"Device serial number (e.g. "
"S2221234)\",\"type\":\"string\"},\"device_type\":{\"description\":\"Device type "
"identifier (e.g. VZ-400i)\",\"type\":\"string\"}},\"type\":\"object\",\"required"
"\":[\"device_type\",\"serial_number\"]}}"
)
RDB_RIEGL_DEVICES_EXAMPLE = (
"[{\"channel_text\":\"\",\"device_build\":\"\",\"device_name\":\"Scanner 1\",\"signe"
"d\":false,\"channel_number\":0,\"serial_number\":\"S2221234\",\"device_type\":\""
"VZ-400i\"},{\"channel_text\":\"\",\"device_build\":\"\",\"device_name\":\"Scanner "
"2\",\"signed\":true,\"channel_number\":1,\"serial_number\":\"S2222680\",\"device"
"_type\":\"VQ-1560i-DW\"},{\"channel_text\":\"\",\"device_build\":\"\",\"device_nam"
"e\":\"Scanner 3\",\"signed\":true,\"channel_number\":2,\"serial_number\":\"S2222"
"680\",\"device_type\":\"VQ-1560i-DW\"}]"
)

# Details about echo files
RDB_RIEGL_ECHO_INFO             = "riegl.echo_info"
RDB_RIEGL_ECHO_INFO_TITLE       = "Echo Information"
RDB_RIEGL_ECHO_INFO_DESCRIPTION = "Details about echo files"
RDB_RIEGL_ECHO_INFO_STATUS      = "optional"
RDB_RIEGL_ECHO_INFO_SCHEMA = (
"{\"description\":\"Details about echo files\",\"title\":\"Echo Information\",\""
"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"pr"
"operties\":{\"echo_file\":{\"properties\":{\"file_extension\":{\"description\":"
"\"Echo file extension, without the leading "
"dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's Universally "
"Unique Identifier (RFC 4122)\",\"type\":\"string\"}},\"type\":\"object\",\"requi"
"red\":[\"file_extension\"]}},\"required\":[\"echo_file\"]}"
)
RDB_RIEGL_ECHO_INFO_EXAMPLE = (
"{\"echo_file\":{\"file_extension\":\"owp\",\"file_uuid\":\"26a03615-67c0-4bea-8"
"fe8-c577378fe661\"}}"
)

# Details for exponential decomposition of full waveform data
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION             = "riegl.exponential_decomposition"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_TITLE       = "Exponential Decomposition"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_DESCRIPTION = "Details for exponential decomposition of full waveform data"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_STATUS      = "optional"
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_SCHEMA = (
"{\"description\":\"Details for exponential decomposition of full waveform"
" data\",\"title\":\"Exponential Decomposition\",\"type\":\"object\",\"$schema\":\""
"http://json-schema.org/draft-04/schema#\",\"additionalProperties\":false,"
"\"definitions\":{\"channel\":{\"properties\":{\"delay\":{\"description\":\"delay "
"calibration in "
"seconds\",\"type\":\"number\"},\"parameter\":{\"description\":\"parameters of "
"the syswave exponential "
"sum\",\"properties\":{\"gamma\":{\"description\":\"decay in 1/second\",\"items\":"
"{\"type\":\"number\"},\"type\":\"array\"},\"B\":{\"description\":\"imaginary part "
"of amplitude factor in units of full-scale\",\"items\":{\"type\":\"number\"},"
"\"type\":\"array\"},\"A\":{\"description\":\"real part of amplitude factor in "
"units of full-scale\",\"items\":{\"type\":\"number\"},\"type\":\"array\"},\"omega\""
":{\"description\":\"angular frequency in Hz\",\"items\":{\"type\":\"number\"},\"t"
"ype\":\"array\"}},\"type\":\"object\",\"required\":[\"A\",\"B\",\"gamma\",\"omega\"]},\""
"a_lin\":{\"description\":\"relative linear amplitude range [0..1]\",\"minimu"
"m\":0,\"type\":\"number\",\"exclusiveMinimum\":false,\"exclusiveMaximum\":false"
",\"maximum\":1},\"scale\":{\"description\":\"amplitude calibration\",\"type\":\"n"
"umber\"}},\"type\":\"object\",\"required\":[\"delay\",\"scale\",\"parameter\"]}},\"p"
"atternProperties\":{\"^[0-9]+$\":{\"description\":\"one field per channel, "
"field name is channel index\",\"$ref\":\"#/definitions/channel\"}}}"
)
RDB_RIEGL_EXPONENTIAL_DECOMPOSITION_EXAMPLE = (
"{\"0\":{\"delay\":3.783458418887631e-09,\"parameter\":{\"gamma\":[-1094726528."
"0,-769562752.0,-848000064.0],\"B\":[-3.9813032150268555,0.08622030913829"
"803,-0.3152860999107361],\"A\":[0.9772450923919678,0.3354335129261017,-1"
".312678575515747],\"omega\":[352020896.0,3647927552.0,-1977987072.0]},\"a"
"_lin\":0.27,\"scale\":1.0},\"1\":{\"delay\":3.5e-09,\"parameter\":{\"gamma\":[-10"
"94726528.0,-769562752.0,-848000064.0],\"B\":[-3.9,0.0,-0.3],\"A\":[0.9,0.3"
",-1.3],\"omega\":[352020896.0,3647927552.0,-1977987072.0]},\"a_lin\":0.9,\""
"scale\":1.0}}"
)

# Details for Gaussian decomposition of full waveform data
RDB_RIEGL_GAUSSIAN_DECOMPOSITION             = "riegl.gaussian_decomposition"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_TITLE       = "Gaussian Decomposition"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_DESCRIPTION = "Details for Gaussian decomposition of full waveform data"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_STATUS      = "optional"
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_SCHEMA = (
"{\"description\":\"riegl.gaussian_decomposition contains information "
"relevant for extracting calibrated amplitudes and calibrated ranges "
"from a Gaussian decomposition of full waveform data. This information "
"is contained in a table with five columns. Two columns are to be used "
"as input: amplitude_lsb_low_power and amplitude_lsb_high_power. The "
"other three columns provide the outputs. Amplitude_db gives the "
"calibrated amplitude in the optical regime in decibels. The range "
"offset columns provide additive range offsets, given in units of "
"seconds, for each channel.\",\"title\":\"Gaussian Decomposition\",\"type\":\"o"
"bject\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"properties"
"\":{\"range_offset_sec_high_power\":{\"items\":{\"type\":\"number\"},\"type\":\"ar"
"ray\"},\"amplitude_lsb_high_power\":{\"items\":{\"type\":\"number\"},\"type\":\"ar"
"ray\"},\"amplitude_db\":{\"items\":{\"type\":\"number\"},\"type\":\"array\"},\"range"
"_offset_sec_low_power\":{\"items\":{\"type\":\"number\"},\"type\":\"array\"},\"amp"
"litude_lsb_low_power\":{\"items\":{\"type\":\"number\"},\"type\":\"array\"}},\"req"
"uired\":[\"amplitude_lsb_low_power\",\"amplitude_lsb_high_power\",\"amplitud"
"e_db\",\"range_offset_sec_low_power\",\"range_offset_sec_high_power\"]}"
)
RDB_RIEGL_GAUSSIAN_DECOMPOSITION_EXAMPLE = (
"{\"range_offset_sec_high_power\":[],\"amplitude_lsb_high_power\":[],\"ampli"
"tude_db\":[],\"range_offset_sec_low_power\":[],\"amplitude_lsb_low_power\":"
"[]}"
)

# Point cloud georeferencing information
RDB_RIEGL_GEO_TAG             = "riegl.geo_tag"
RDB_RIEGL_GEO_TAG_TITLE       = "Geo Tag"
RDB_RIEGL_GEO_TAG_DESCRIPTION = "Point cloud georeferencing information"
RDB_RIEGL_GEO_TAG_STATUS      = "optional"
RDB_RIEGL_GEO_TAG_SCHEMA = (
"{\"description\":\"Point cloud georeferencing information\",\"title\":\"Geo "
"Tag\",\"properties\":{\"crs\":{\"description\":\"Global Coordinate Reference "
"System. Please note that only 3D Cartesian Coordinate Systems are "
"allowed.\",\"properties\":{\"epsg\":{\"description\":\"EPSG "
"code\",\"minimum\":0,\"type\":\"integer\"},\"name\":{\"description\":\"Coordinate "
"reference system "
"name\",\"type\":\"string\"},\"wkt\":{\"description\":\"\\\"Well-Known Text\\\" "
"string, OGC WKT dialect (see http://www.opengeospatial.org/standards/w"
"kt-crs)\",\"type\":\"string\"}},\"type\":\"object\"},\"pose\":{\"description\":\"Coo"
"rdinate Transformation Matrix to transform from File Coordinate System"
" to Global Coordinate Reference System. 4x4 matrix stored as two "
"dimensional array, row major order.\",\"items\":{\"description\":\"rows\",\"it"
"ems\":{\"description\":\"columns\",\"type\":\"number\"},\"type\":\"array\",\"maxItem"
"s\":4,\"minItems\":4},\"type\":\"array\",\"maxItems\":4,\"minItems\":4}},\"type\":\""
"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_GEO_TAG_EXAMPLE = (
"{\"crs\":{\"epsg\":4978,\"name\":\"WGS84 Geocentric\",\"wkt\":\"GEOCCS[\\\"WGS84 Ge"
"ocentric\\\",DATUM[\\\"WGS84\\\",SPHEROID[\\\"WGS84\\\",6378137.000,298.25722356"
"3,AUTHORITY[\\\"EPSG\\\",\\\"7030\\\"]],AUTHORITY[\\\"EPSG\\\",\\\"6326\\\"]],PRIMEM[\\"
"\"Greenwich\\\",0.0000000000000000,AUTHORITY[\\\"EPSG\\\",\\\"8901\\\"]],UNIT[\\\"M"
"eter\\\",1.00000000000000000000,AUTHORITY[\\\"EPSG\\\",\\\"9001\\\"]],AXIS[\\\"X\\\""
",OTHER],AXIS[\\\"Y\\\",EAST],AXIS[\\\"Z\\\",NORTH],AUTHORITY[\\\"EPSG\\\",\\\"4978\\\""
"]]\"},\"pose\":[[-0.269827776749716,-0.723017716139738,0.635954678449952,"
"4063882.500831],[0.962908599449764,-0.20260517250352,0.178208229833847"
",1138787.607461],[0.0,0.660451759194338,0.7508684796801,4766084.550196"
"],[0.0,0.0,0.0,1.0]]}"
)

# Geometric scale factor applied to point coordinates
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR             = "riegl.geometric_scale_factor"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_TITLE       = "Geometric Scale Factor"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_DESCRIPTION = "Geometric scale factor applied to point coordinates"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_STATUS      = "optional"
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_SCHEMA = (
"{\"description\":\"Geometric scale factor applied to point coordinates\",\""
"minimum\":0,\"type\":\"number\",\"$schema\":\"http://json-schema.org/draft-04/"
"schema#\",\"exclusiveMinimum\":true}"
)
RDB_RIEGL_GEOMETRIC_SCALE_FACTOR_EXAMPLE = (
"1.0"
)

# Parameters used for georeferencing of the point cloud
RDB_RIEGL_GEOREFERENCING_PARAMETERS             = "riegl.georeferencing_parameters"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_TITLE       = "Georeferencing Parameters"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_DESCRIPTION = "Parameters used for georeferencing of the point cloud"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_STATUS      = "optional"
RDB_RIEGL_GEOREFERENCING_PARAMETERS_SCHEMA = (
"{\"description\":\"Parameters used for georeferencing of the point "
"cloud\",\"title\":\"Georeferencing Parameters\",\"properties\":{\"socs_to_body"
"_matrix\":{\"description\":\"Coordinate Transformation Matrix to transform"
" from Scanner's Own Coordinate System to Body Coordinate System. 4x4 "
"matrix stored as two dimensional array, row major order.\",\"items\":{\"de"
"scription\":\"rows\",\"items\":{\"description\":\"columns\",\"type\":\"number\"},\"t"
"ype\":\"array\",\"maxItems\":4,\"minItems\":4},\"type\":\"array\",\"maxItems\":4,\"m"
"inItems\":4},\"socs_to_rocs_matrix\":{\"description\":\"Coordinate "
"Transformation Matrix to transform from Scanner's Own Coordinate "
"System to Record Coordinate System. 4x4 matrix stored as two "
"dimensional array, row major order.\",\"items\":{\"description\":\"rows\",\"it"
"ems\":{\"description\":\"columns\",\"type\":\"number\"},\"type\":\"array\",\"maxItem"
"s\":4,\"minItems\":4},\"type\":\"array\",\"maxItems\":4,\"minItems\":4},\"trajecto"
"ry_offsets\":{\"description\":\"Correction offsets applied to the "
"trajectory data\",\"properties\":{\"offset_pitch\":{\"description\":\"[deg]\",\""
"type\":\"number\"},\"offset_height\":{\"description\":\"[m]\",\"type\":\"number\"},"
"\"offset_yaw\":{\"description\":\"[deg]\",\"type\":\"number\"},\"version\":{\"descr"
"iption\":\"Meaning of offset values and how to apply them; version 0: "
"Rz(yaw+offset_yaw)*Ry(pitch+offset_pitch)*Rx(roll+offset_roll), "
"version 1: Rz(yaw)*Ry(pitch)*Rx(roll) * Rz(yaw_offset)*Ry(pitch_offset"
")*Rx(roll_offset)\",\"type\":\"integer\"},\"offset_east\":{\"description\":\"[m]"
"\",\"type\":\"number\"},\"offset_north\":{\"description\":\"[m]\",\"type\":\"number\""
"},\"offset_roll\":{\"description\":\"[deg]\",\"type\":\"number\"},\"offset_time\":"
"{\"description\":\"[s]\",\"type\":\"number\"}},\"type\":\"object\"},\"body_coordina"
"te_system_type\":{\"description\":\"BODY coordinate frame (NED: "
"North-East-Down, ENU: East-North-Up), default: NED\",\"type\":\"string\",\"e"
"num\":[\"NED\",\"ENU\"]},\"trajectory_file\":{\"description\":\"Trajectory data "
"used for georeferencing of the point "
"cloud\",\"properties\":{\"file_extension\":{\"description\":\"Trajectory file "
"extension, without the leading "
"dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's Universally "
"Unique Identifier (RFC 4122)\",\"type\":\"string\"}},\"type\":\"object\",\"requi"
"red\":[\"file_extension\"]}},\"type\":\"object\",\"$schema\":\"http://json-schem"
"a.org/draft-04/schema#\"}"
)
RDB_RIEGL_GEOREFERENCING_PARAMETERS_EXAMPLE = (
"{\"socs_to_body_matrix\":[[-0.269827776749716,-0.723017716139738,0.63595"
"4678449952,0.0],[0.962908599449764,-0.20260517250352,0.178208229833847"
",0.0],[0.0,0.660451759194338,0.7508684796801,0.0],[0.0,0.0,0.0,1.0]],\""
"trajectory_offsets\":{\"offset_pitch\":0.01,\"offset_height\":-0.2,\"offset_"
"yaw\":-0.45,\"version\":0,\"offset_east\":0.15,\"offset_north\":0.07,\"offset_"
"roll\":0.03,\"offset_time\":18.007},\"body_coordinate_system_type\":\"NED\",\""
"trajectory_file\":{\"file_extension\":\"pofx\",\"file_uuid\":\"93a03615-66c0-4"
"bea-8ff8-c577378fe660\"}}"
)

# Map of item names
RDB_RIEGL_ITEM_NAMES             = "riegl.item_names"
RDB_RIEGL_ITEM_NAMES_TITLE       = "Item Names"
RDB_RIEGL_ITEM_NAMES_DESCRIPTION = "Map of item names"
RDB_RIEGL_ITEM_NAMES_STATUS      = "optional"
RDB_RIEGL_ITEM_NAMES_SCHEMA = (
"{\"description\":\"Map of item names\",\"title\":\"Item Names\",\"type\":\"object"
"\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"additionalPrope"
"rties\":false,\"patternProperties\":{\"^-?[0-9]+$\":{\"description\":\"One "
"field per item, field name is item id, field value is item "
"name\",\"type\":\"string\"}}}"
)
RDB_RIEGL_ITEM_NAMES_EXAMPLE = (
"{\"47\":\"Name of item with id 47\",\"1\":\"Name of item with id "
"1\",\"-1\":\"Name of item with id -1\",\"2\":\"Name of item with id 2\"}"
)

# License keys for software features
RDB_RIEGL_LICENSES             = "riegl.licenses"
RDB_RIEGL_LICENSES_TITLE       = "Software License Keys"
RDB_RIEGL_LICENSES_DESCRIPTION = "License keys for software features"
RDB_RIEGL_LICENSES_STATUS      = "optional"
RDB_RIEGL_LICENSES_SCHEMA = (
"{\"description\":\"License keys for software features\",\"title\":\"Software "
"License Keys\",\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-"
"04/schema#\",\"additionalProperties\":false,\"patternProperties\":{\"^.*$\":{"
"\"description\":\"Each field of the object represents a feature and holds"
" a list of license keys, where the field name is the feature "
"name.\",\"items\":{\"description\":\"License key (example: '46AE032A - "
"39882AC4 - 9EC0A184 - "
"6F163D73')\",\"type\":\"string\"},\"type\":\"array\",\"minItems\":1}}}"
)
RDB_RIEGL_LICENSES_EXAMPLE = (
"{\"Full Waveform Analysis Topography\":[\"0FD5FF07 - 011A1255 - 9F76CACA "
"- 8D2ED557\"],\"Full Waveform Analysis Topography with GPU "
"support\":[\"8AB44126 - 23B92250 - 16E2689F - 34EF7E7B\"],\"MTA "
"resolution\":[\"468E020A - 39A922E4 - B681A184 - "
"673E3D72\"],\"Georeferencing\":[\"46AE032A - 39882AC4 - 9EC0A184 - "
"6F163D73\"]}"
)

# Parameters for MTA processing
RDB_RIEGL_MTA_SETTINGS             = "riegl.mta_settings"
RDB_RIEGL_MTA_SETTINGS_TITLE       = "MTA Settings"
RDB_RIEGL_MTA_SETTINGS_DESCRIPTION = "Parameters for MTA processing"
RDB_RIEGL_MTA_SETTINGS_STATUS      = "optional"
RDB_RIEGL_MTA_SETTINGS_SCHEMA = (
"{\"description\":\"Parameters for MTA processing\",\"title\":\"MTA "
"Settings\",\"properties\":{\"modulation_depth\":{\"description\":\"Depth of "
"pulse position modulation in meter.\",\"minimum\":0,\"type\":\"number\"},\"zon"
"e_width\":{\"description\":\"Width of a MTA zone in meter.\",\"minimum\":0,\"t"
"ype\":\"number\"},\"zone_count\":{\"description\":\"Maximum number of MTA zone"
"s.\",\"minimum\":0,\"type\":\"integer\",\"maximum\":255}},\"type\":\"object\",\"$sch"
"ema\":\"http://json-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_MTA_SETTINGS_EXAMPLE = (
"{\"modulation_depth\":9.368514,\"zone_width\":149.896225,\"zone_count\":23}"
)

# Lookup table for range correction based on raw range
RDB_RIEGL_NEAR_RANGE_CORRECTION             = "riegl.near_range_correction"
RDB_RIEGL_NEAR_RANGE_CORRECTION_TITLE       = "Near Range Correction Table"
RDB_RIEGL_NEAR_RANGE_CORRECTION_DESCRIPTION = "Lookup table for range correction based on raw range"
RDB_RIEGL_NEAR_RANGE_CORRECTION_STATUS      = "optional"
RDB_RIEGL_NEAR_RANGE_CORRECTION_SCHEMA = (
"{\"description\":\"Lookup table for range correction based on raw "
"range\",\"title\":\"Near Range Correction Table\",\"type\":\"object\",\"$schema\""
":\"http://json-schema.org/draft-04/schema#\",\"properties\":{\"content\":{\"d"
"escription\":\"Correction value [m] to be added to the raw range\",\"items"
"\":{\"type\":\"number\"},\"maxItems\":2000,\"type\":\"array\",\"minItems\":1},\"delt"
"a\":{\"description\":\"Delta between table entries [m], first entry is at "
"range = 0 m\",\"type\":\"number\"}},\"required\":[\"delta\",\"content\"]}"
)
RDB_RIEGL_NEAR_RANGE_CORRECTION_EXAMPLE = (
"{\"content\":[0.0],\"delta\":0.512}"
)

# Standard deviation for range and amplitude as a function of amplitude
RDB_RIEGL_NOISE_ESTIMATES             = "riegl.noise_estimates"
RDB_RIEGL_NOISE_ESTIMATES_TITLE       = "Noise Estimates"
RDB_RIEGL_NOISE_ESTIMATES_DESCRIPTION = "Standard deviation for range and amplitude as a function of amplitude"
RDB_RIEGL_NOISE_ESTIMATES_STATUS      = "optional"
RDB_RIEGL_NOISE_ESTIMATES_SCHEMA = (
"{\"description\":\"Standard deviation for range and amplitude as a "
"function of amplitude\",\"title\":\"Noise Estimates\",\"type\":\"object\",\"$sch"
"ema\":\"http://json-schema.org/draft-04/schema#\",\"properties\":{\"amplitud"
"e\":{\"description\":\"Amplitude [dB]\",\"items\":{\"type\":\"number\"},\"type\":\"a"
"rray\"},\"amplitude_sigma\":{\"description\":\"Sigma amplitude [dB]\",\"items\""
":{\"type\":\"number\"},\"type\":\"array\"},\"range_sigma\":{\"description\":\"Sigma"
" range [m]\",\"items\":{\"type\":\"number\"},\"type\":\"array\"}},\"required\":[\"am"
"plitude\",\"range_sigma\",\"amplitude_sigma\"]}"
)
RDB_RIEGL_NOISE_ESTIMATES_EXAMPLE = (
"{\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0],\"amplitude"
"_sigma\":[0.988,0.988,0.875,0.774,0.686,0.608,0.54,0.482,0.432,0.39,0.3"
"54],\"range_sigma\":[0.065,0.056,0.046,0.038,0.032,0.027,0.024,0.021,0.0"
"18,0.016,0.014]}"
)

# Notch filter parameters for window glass echoes
RDB_RIEGL_NOTCH_FILTER             = "riegl.notch_filter"
RDB_RIEGL_NOTCH_FILTER_TITLE       = "Notch Filter"
RDB_RIEGL_NOTCH_FILTER_DESCRIPTION = "Notch filter parameters for window glass echoes"
RDB_RIEGL_NOTCH_FILTER_STATUS      = "optional"
RDB_RIEGL_NOTCH_FILTER_SCHEMA = (
"{\"description\":\"Notch filter parameters for window glass "
"echoes\",\"title\":\"Notch Filter\",\"type\":\"object\",\"$schema\":\"http://json-"
"schema.org/draft-04/schema#\",\"properties\":{\"amplitude_maximum\":{\"minim"
"um\":0,\"description\":\"Maximum amplitude "
"[dB]\",\"type\":\"number\"},\"range_maximum\":{\"description\":\"Maximum range "
"[m]\",\"type\":\"number\"},\"range_minimum\":{\"description\":\"Minimum range [m"
"]\",\"type\":\"number\"}},\"required\":[\"range_minimum\",\"range_maximum\",\"ampl"
"itude_maximum\"]}"
)
RDB_RIEGL_NOTCH_FILTER_EXAMPLE = (
"{\"amplitude_maximum\":18.0,\"range_maximum\":0.2,\"range_minimum\":-0.5}"
)

# Details about the pixels contained in the file
RDB_RIEGL_PIXEL_INFO             = "riegl.pixel_info"
RDB_RIEGL_PIXEL_INFO_TITLE       = "Pixel Information"
RDB_RIEGL_PIXEL_INFO_DESCRIPTION = "Details about the pixels contained in the file"
RDB_RIEGL_PIXEL_INFO_STATUS      = "optional"
RDB_RIEGL_PIXEL_INFO_SCHEMA = (
"{\"description\":\"Details about the pixels contained in the "
"file\",\"title\":\"Pixel Information\",\"type\":\"object\",\"$schema\":\"http://js"
"on-schema.org/draft-04/schema#\",\"properties\":{\"size_llcs\":{\"descriptio"
"n\":\"Size of pixels in a locally levelled cartesian coordinate system "
"(xy). This is only used for pixels based on a map projection.\",\"$ref\":"
"\"#/definitions/pixel_size\"},\"size\":{\"description\":\"Size of pixels in "
"file coordinate system.\",\"$ref\":\"#/definitions/pixel_size\"}},\"definiti"
"ons\":{\"pixel_size\":{\"description\":\"Size of "
"pixels.\",\"items\":{\"description\":\"Length of pixel edge [m].\",\"minimum\":"
"0,\"type\":\"number\"},\"type\":\"array\",\"maxItems\":2,\"minItems\":2}},\"require"
"d\":[\"size\"]}"
)
RDB_RIEGL_PIXEL_INFO_EXAMPLE = (
"{\"size_llcs\":[0.5156575252891171,0.5130835356683303],\"size\":[0.5971642"
"834779395,0.5971642834779395]}"
)

# Details about the plane patch matching process
RDB_RIEGL_PLANE_PATCH_MATCHING             = "riegl.plane_patch_matching"
RDB_RIEGL_PLANE_PATCH_MATCHING_TITLE       = "Plane Patch Matching"
RDB_RIEGL_PLANE_PATCH_MATCHING_DESCRIPTION = "Details about the plane patch matching process"
RDB_RIEGL_PLANE_PATCH_MATCHING_STATUS      = "optional"
RDB_RIEGL_PLANE_PATCH_MATCHING_SCHEMA = (
"{\"description\":\"Details about the plane patch matching "
"process\",\"title\":\"Plane Patch Matching\",\"type\":\"object\",\"$schema\":\"htt"
"p://json-schema.org/draft-04/schema#\",\"properties\":{\"plane_patch_file_"
"one\":{\"description\":\"Reference to the plane patch file one\",\"$ref\":\"#/"
"definitions/file_reference\"},\"plane_patch_file_two\":{\"description\":\"Re"
"ference to the plane patch file two\",\"$ref\":\"#/definitions/file_refere"
"nce\"}},\"definitions\":{\"file_reference\":{\"description\":\"Reference to a "
"plane patch file\",\"properties\":{\"file_path\":{\"description\":\"Path of "
"the plane patch file relative to the match "
"file\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"Plane patch file's "
"Universally Unique Identifier (RFC 4122)\",\"type\":\"string\"}},\"type\":\"ob"
"ject\",\"required\":[\"file_uuid\",\"file_path\"]}},\"required\":[\"plane_patch_"
"file_one\",\"plane_patch_file_two\"]}"
)
RDB_RIEGL_PLANE_PATCH_MATCHING_EXAMPLE = (
"{\"plane_patch_file_one\":{\"file_path\":\"Record009_Line001/191025_121410_"
"Scanner_1.ptch\",\"file_uuid\":\"810f5d57-eccf-49ed-b07a-0cdd109b4213\"},\"p"
"lane_patch_file_two\":{\"file_path\":\"project.ptch\",\"file_uuid\":\"fa47d509"
"-a64e-49ce-8b14-ff3130fbefa9\"}}"
)

# Statistics about plane patches found by plane patch extractor
RDB_RIEGL_PLANE_PATCH_STATISTICS             = "riegl.plane_patch_statistics"
RDB_RIEGL_PLANE_PATCH_STATISTICS_TITLE       = "Plane Patch Statistics"
RDB_RIEGL_PLANE_PATCH_STATISTICS_DESCRIPTION = "Statistics about plane patches found by plane patch extractor"
RDB_RIEGL_PLANE_PATCH_STATISTICS_STATUS      = "optional"
RDB_RIEGL_PLANE_PATCH_STATISTICS_SCHEMA = (
"{\"description\":\"Statistics about plane patches found by plane patch "
"extractor\",\"title\":\"Plane Patch "
"Statistics\",\"properties\":{\"total_area\":{\"description\":\"sum of all "
"plane patch areas [m\\u00b2]\",\"type\":\"number\"},\"total_horizontal_area\":"
"{\"description\":\"sum of all plane patch areas projected to horizontal "
"plane [m\\u00b2]\",\"type\":\"number\"}},\"type\":\"object\",\"$schema\":\"http://j"
"son-schema.org/draft-04/schema#\"}"
)
RDB_RIEGL_PLANE_PATCH_STATISTICS_EXAMPLE = (
"{\"total_area\":14007.965,\"total_horizontal_area\":13954.601}"
)

# Settings and classes for plane slope classification
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO             = "riegl.plane_slope_class_info"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_TITLE       = "Plane Slope Class Info"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_DESCRIPTION = "Settings and classes for plane slope classification"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_STATUS      = "optional"
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_SCHEMA = (
"{\"description\":\"Settings and classes for plane slope "
"classification\",\"title\":\"Plane Slope Class Info\",\"type\":\"object\",\"$sch"
"ema\":\"http://json-schema.org/draft-04/schema#\",\"properties\":{\"classes\""
":{\"description\":\"Class definition table\",\"additionalProperties\":false,"
"\"type\":\"object\",\"patternProperties\":{\"^[0-9]+$\":{\"description\":\"one "
"field per class, field name is class number, field value is class "
"name\",\"type\":\"string\"}}},\"settings\":{\"description\":\"Classification "
"settings, details see documentation of rdbplanes\",\"type\":\"object\",\"one"
"Of\":[{\"$ref\":\"#/definitions/method-1\"},{\"$ref\":\"#/definitions/method-2"
"\"}]}},\"definitions\":{\"method-2\":{\"description\":\"Classification method "
"2\",\"properties\":{\"sloping_plane_classes_maximum_angle\":{\"description\":"
"\"maximum inclination angle of sloping plane patches [deg]\",\"minimum\":-"
"360.0,\"type\":\"number\",\"maximum\":360.0},\"plane_classification_method\":{"
"\"description\":\"method ID (=2)\",\"minimum\":2,\"type\":\"integer\",\"maximum\":"
"2},\"sloping_plane_classes_minimum_angle\":{\"description\":\"minimum "
"inclination angle of sloping plane patches [deg]\",\"minimum\":-360.0,\"ty"
"pe\":\"number\",\"maximum\":360.0}},\"type\":\"object\",\"required\":[\"plane_clas"
"sification_method\",\"sloping_plane_classes_minimum_angle\",\"sloping_plan"
"e_classes_maximum_angle\"]},\"method-1\":{\"description\":\"Classification "
"method 1\",\"properties\":{\"maximum_inclination_angle_horizontal\":{\"descr"
"iption\":\"maximum inclination angle of horizontal plane patches [deg]\","
"\"minimum\":-360.0,\"type\":\"number\",\"maximum\":360.0},\"plane_classificatio"
"n_method\":{\"description\":\"method ID (=1)\",\"minimum\":1,\"type\":\"integer\""
",\"maximum\":1}},\"type\":\"object\",\"required\":[\"plane_classification_metho"
"d\",\"maximum_inclination_angle_horizontal\"]}},\"required\":[\"settings\",\"c"
"lasses\"]}"
)
RDB_RIEGL_PLANE_SLOPE_CLASS_INFO_EXAMPLE = (
"{\"classes\":{\"3\":\"sloping, pointing up and south\",\"6\":\"vertical, "
"pointing east\",\"14\":\"horizontal, pointing down\",\"8\":\"vertical, "
"pointing north\",\"2\":\"sloping, pointing up and east\",\"11\":\"sloping, "
"pointing down and south\",\"13\":\"sloping, pointing down and "
"west\",\"1\":\"horizontal, pointing up\",\"7\":\"vertical, pointing "
"south\",\"9\":\"vertical, pointing west\",\"5\":\"sloping, pointing up and "
"west\",\"4\":\"sloping, pointing up and north\",\"10\":\"sloping, pointing "
"down and east\",\"12\":\"sloping, pointing down and north\"},\"settings\":{\"s"
"loping_plane_classes_maximum_angle\":70.0,\"plane_classification_method\""
":2,\"sloping_plane_classes_minimum_angle\":10.0}}"
)

# Grouping and sorting of point attributes for visualization purposes
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS             = "riegl.point_attribute_groups"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_TITLE       = "Point Attribute Groups"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_DESCRIPTION = "Grouping and sorting of point attributes for visualization purposes"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_STATUS      = "optional"
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_SCHEMA = (
"{\"description\":\"Grouping and sorting of point attributes for "
"visualization purposes\",\"title\":\"Point Attribute Groups\",\"type\":\"objec"
"t\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"additionalProp"
"erties\":false,\"patternProperties\":{\"^.*$\":{\"description\":\"Each field "
"of the object represents a point attribute group and holds a list of "
"point attributes, where the field name is the group "
"name.\",\"items\":{\"description\":\"Point attribute full name or name "
"pattern (perl regular expression "
"syntax)\",\"type\":\"string\"},\"type\":\"array\",\"minItems\":1}}}"
)
RDB_RIEGL_POINT_ATTRIBUTE_GROUPS_EXAMPLE = (
"{\"Primary Attributes\":[\"riegl.reflectance\",\"riegl.amplitude\",\"riegl.de"
"viation\"],\"Other Attributes\":[\"riegl.selected\",\"riegl.visible\"],\"Time\""
":[\"riegl.timestamp\"],\"Coordinates/Vectors\":[\"riegl.xyz\",\"riegl.range\","
"\"riegl.theta\",\"riegl.phi\"],\"Secondary "
"Attributes\":[\"riegl.mirror_facet\",\"riegl.waveform_available\"]}"
)

# Details about point cloud files
RDB_RIEGL_POINTCLOUD_INFO             = "riegl.pointcloud_info"
RDB_RIEGL_POINTCLOUD_INFO_TITLE       = "Point Cloud Information"
RDB_RIEGL_POINTCLOUD_INFO_DESCRIPTION = "Details about point cloud files"
RDB_RIEGL_POINTCLOUD_INFO_STATUS      = "optional"
RDB_RIEGL_POINTCLOUD_INFO_SCHEMA = (
"{\"description\":\"Details about point cloud files\",\"title\":\"Point Cloud "
"Information\",\"properties\":{\"comments\":{\"description\":\"Comments\",\"type\""
":\"string\"},\"field_of_application\":{\"description\":\"Field of application"
"\",\"type\":\"string\",\"enum\":[\"unknown\",\"SLS\",\"TLS\",\"KLS\",\"MLS\",\"ULS\",\"ALS"
"\",\"BLS\",\"ILS\"]},\"project\":{\"description\":\"Project name\",\"type\":\"string"
"\"}},\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#"
"\"}"
)
RDB_RIEGL_POINTCLOUD_INFO_EXAMPLE = (
"{\"comments\":\"Line 3\",\"field_of_application\":\"ALS\",\"project\":\"Campaign "
"4\"}"
)

# Estimated position and orientation information
RDB_RIEGL_POSE_ESTIMATION             = "riegl.pose_estimation"
RDB_RIEGL_POSE_ESTIMATION_TITLE       = "Pose Estimation"
RDB_RIEGL_POSE_ESTIMATION_DESCRIPTION = "Estimated position and orientation information"
RDB_RIEGL_POSE_ESTIMATION_STATUS      = "optional"
RDB_RIEGL_POSE_ESTIMATION_SCHEMA = (
"{\"description\":\"Estimated position and orientation information as "
"measured by GNSS, IMU or inclination sensors\",\"title\":\"Pose Estimation"
"\",\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\","
"\"properties\":{\"position\":{\"description\":\"Position coordinates and "
"position accuracy values as measured by GNSS in the specified "
"Coordinate Reference System "
"(CRS)\",\"properties\":{\"coordinate_2\":{\"description\":\"Coordinate 2 as "
"defined by axis 2 of the specified CRS (e.g., Y, Longitude)\",\"type\":\"n"
"umber\"},\"vertical_accuracy\":{\"description\":\"Vertical accuracy [m]\",\"mi"
"nimum\":0,\"type\":\"number\",\"exclusiveMinimum\":true},\"crs\":{\"description\""
":\"Global Coordinate Reference "
"System\",\"properties\":{\"epsg\":{\"description\":\"EPSG "
"code\",\"minimum\":0,\"type\":\"integer\"},\"wkt\":{\"description\":\"\\\"Well-Known"
" Text\\\" string, OGC WKT dialect (see http://www.opengeospatial.org/sta"
"ndards/wkt-crs)\",\"type\":\"string\"}},\"type\":\"object\",\"required\":[\"epsg\"]"
"},\"coordinate_1\":{\"description\":\"Coordinate 1 as defined by axis 1 of "
"the specified CRS (e.g., X, Latitude)\",\"type\":\"number\"},\"horizontal_ac"
"curacy\":{\"description\":\"Horizontal accuracy [m]\",\"minimum\":0,\"type\":\"n"
"umber\",\"exclusiveMinimum\":true},\"coordinate_3\":{\"description\":\"Coordin"
"ate 3 as defined by axis 3 of the specified CRS (e.g., Z, Altitude)\",\""
"type\":\"number\"}},\"type\":\"object\",\"required\":[\"coordinate_1\",\"coordinat"
"e_2\",\"coordinate_3\",\"horizontal_accuracy\",\"vertical_accuracy\",\"crs\"]},"
"\"orientation\":{\"description\":\"Orientation values and orientation "
"accuracies, measured with IMU or inclination "
"sensors.\",\"properties\":{\"roll_accuracy\":{\"description\":\"Roll angle "
"accuracy [deg]\",\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\":true},\""
"roll\":{\"description\":\"Roll angle about scanner X-axis [deg]\",\"minimum\""
":-360,\"type\":\"number\",\"maximum\":360},\"yaw_accuracy\":{\"description\":\"Ya"
"w angle accuracy [deg]\",\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\""
":true},\"pitch\":{\"description\":\"Pitch angle about scanner Y-axis [deg]\""
",\"minimum\":-360,\"type\":\"number\",\"maximum\":360},\"yaw\":{\"description\":\"Y"
"aw angle about scanner Z-axis [deg]\",\"minimum\":-360,\"type\":\"number\",\"m"
"aximum\":360},\"pitch_accuracy\":{\"description\":\"Pitch angle accuracy [de"
"g]\",\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\":true}},\"type\":\"obje"
"ct\",\"required\":[\"roll\",\"pitch\",\"yaw\",\"roll_accuracy\",\"pitch_accuracy\","
"\"yaw_accuracy\"]},\"barometric_height_amsl\":{\"description\":\"Altitude "
"determined based on the atmospheric pressure according to the standard"
" atmosphere laws [m].\",\"type\":\"number\"}},\"required\":[\"orientation\"]}"
)
RDB_RIEGL_POSE_ESTIMATION_EXAMPLE = (
"{\"position\":{\"coordinate_2\":15.645033406,\"vertical_accuracy\":1.3314999"
"341964722,\"crs\":{\"epsg\":4979,\"wkt\":\"GEOGCS[\\\"WGS84 / Geographic\\\",DATU"
"M[\\\"WGS84\\\",SPHEROID[\\\"WGS84\\\",6378137.000,298.257223563,AUTHORITY[\\\"E"
"PSG\\\",\\\"7030\\\"]],AUTHORITY[\\\"EPSG\\\",\\\"6326\\\"]],PRIMEM[\\\"Greenwich\\\",0."
"0000000000000000,AUTHORITY[\\\"EPSG\\\",\\\"8901\\\"]],UNIT[\\\"Degree\\\",0.01745"
"329251994329547,AUTHORITY[\\\"EPSG\\\",\\\"9102\\\"]],AXIS[\\\"Latitude\\\",NORTH]"
",AXIS[\\\"Longitude\\\",EAST],AUTHORITY[\\\"EPSG\\\",\\\"4979\\\"]]\"},\"coordinate_"
"1\":48.655799473,\"horizontal_accuracy\":0.810699999332428,\"coordinate_3\""
":362.7124938964844},\"orientation\":{\"roll_accuracy\":0.00943378393687574"
"5,\"roll\":3.14743073066123,\"yaw_accuracy\":1.0094337839368757,\"pitch\":1."
"509153024827064,\"yaw\":101.87293630292045,\"pitch_accuracy\":0.0094337839"
"36875745},\"barometric_height_amsl\":386.7457796227932}"
)

# Details on position and orientation sensors
RDB_RIEGL_POSE_SENSORS             = "riegl.pose_sensors"
RDB_RIEGL_POSE_SENSORS_TITLE       = "Pose Sensors"
RDB_RIEGL_POSE_SENSORS_DESCRIPTION = "Details on position and orientation sensors"
RDB_RIEGL_POSE_SENSORS_STATUS      = "optional"
RDB_RIEGL_POSE_SENSORS_SCHEMA = (
"{\"description\":\"Details on position and orientation "
"sensors\",\"title\":\"Pose Sensors\",\"type\":\"object\",\"$schema\":\"http://json"
"-schema.org/draft-04/schema#\",\"properties\":{\"magnetic_field_sensor\":{\""
"description\":\"Magnetic Field Sensor "
"details\",\"properties\":{\"offset\":{\"description\":\"Value to be subtracted"
" from raw measurement values\",\"$ref\":\"#/definitions/vector\"},\"fixed\":{"
"\"description\":\"Distortion of magnetic field caused by non-rotating "
"scanner part\",\"$ref\":\"#/definitions/vector\"},\"z_axis\":{\"description\":\""
"Sensitive Z axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":{\"description\":\"Sensitive Y"
" axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"unit\":{\"description\":\"Unit of raw "
"data and calibration values, 1 LSB in nT\",\"minimum\":0,\"type\":\"number\","
"\"exclusiveMinimum\":true},\"x_axis\":{\"description\":\"Sensitive X axis of "
"sensor at frame angle = 0\",\"$ref\":\"#/definitions/vector\"},\"relative_no"
"nlinearity\":{\"description\":\"Relative nonlinearity, dimensionless\",\"$re"
"f\":\"#/definitions/vector\"}},\"type\":\"object\",\"required\":[\"unit\",\"x_axis"
"\",\"y_axis\",\"z_axis\",\"offset\",\"fixed\",\"relative_nonlinearity\"]},\"gyrosc"
"ope\":{\"description\":\"Gyroscope "
"details\",\"properties\":{\"origin\":{\"description\":\"Sensor origin in SOCS "
"[m] at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"offset\":{\"description\":\"Value to be"
" subtracted from raw measurement values\",\"$ref\":\"#/definitions/vector\""
"},\"z_axis\":{\"description\":\"Sensitive Z axis of sensor at frame angle ="
" 0\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":{\"description\":\"Sensitive "
"Y axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"unit\":{\"description\":\"Unit of raw "
"data and calibration values, 1 LSB in rad/s\",\"minimum\":0,\"type\":\"numbe"
"r\",\"exclusiveMinimum\":true},\"x_axis\":{\"description\":\"Sensitive X axis "
"of sensor at frame angle = 0\",\"$ref\":\"#/definitions/vector\"},\"relative"
"_nonlinearity\":{\"description\":\"Relative nonlinearity, dimensionless\",\""
"$ref\":\"#/definitions/vector\"}},\"type\":\"object\",\"required\":[\"unit\",\"x_a"
"xis\",\"y_axis\",\"z_axis\",\"offset\",\"origin\",\"relative_nonlinearity\"]},\"ac"
"celerometer\":{\"description\":\"Accelerometer "
"details\",\"properties\":{\"origin\":{\"description\":\"Sensor origin in SOCS "
"[m] at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"offset\":{\"description\":\"Value to be"
" subtracted from raw measurement values\",\"$ref\":\"#/definitions/vector\""
"},\"z_axis\":{\"description\":\"Sensitive Z axis of sensor at frame angle ="
" 0\",\"$ref\":\"#/definitions/vector\"},\"y_axis\":{\"description\":\"Sensitive "
"Y axis of sensor at frame angle = "
"0\",\"$ref\":\"#/definitions/vector\"},\"unit\":{\"description\":\"Unit of raw "
"data and calibration values, 1 LSB in 9.81 m/s\\u00b2\",\"minimum\":0,\"typ"
"e\":\"number\",\"exclusiveMinimum\":true},\"x_axis\":{\"description\":\"Sensitiv"
"e X axis of sensor at frame angle = 0\",\"$ref\":\"#/definitions/vector\"},"
"\"relative_nonlinearity\":{\"description\":\"Relative nonlinearity, dimensi"
"onless\",\"$ref\":\"#/definitions/vector\"}},\"type\":\"object\",\"required\":[\"u"
"nit\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\",\"origin\",\"relative_nonlineari"
"ty\"]}},\"definitions\":{\"vector\":{\"items\":{\"description\":\"Index 0=X, "
"1=Y, 2=Z component\",\"type\":\"number\"},\"maxItems\":3,\"type\":\"array\",\"minI"
"tems\":3}},\"required\":[\"gyroscope\",\"accelerometer\",\"magnetic_field_sens"
"or\"]}"
)
RDB_RIEGL_POSE_SENSORS_EXAMPLE = (
"{\"magnetic_field_sensor\":{\"offset\":[-23812.052734375,5606.57666015625,"
"2493.28125],\"fixed\":[-1576.010498046875,1596.081787109375,0.0],\"z_axis"
"\":[0.00041987866279669106,7.876977906562388e-05,0.011407104320824146],"
"\"y_axis\":[0.00027888521435670555,-0.011427424848079681,-5.204829722060"
"822e-05],\"unit\":91.74311828613281,\"x_axis\":[-0.011162743903696537,-2.3"
"15962774446234e-05,0.00016818844596855342],\"relative_nonlinearity\":[0."
"0,0.0,0.0]},\"gyroscope\":{\"origin\":[0.026900000870227814,-0.03999999910"
"593033,-0.08950000256299973],\"offset\":[-50.92609786987305,146.15643310"
"546875,62.4327278137207],\"z_axis\":[0.555869996547699,119.2213516235351"
"6,0.467585027217865],\"y_axis\":[-0.440765917301178,-0.7897399663925171,"
"119.5894775390625],\"unit\":0.00014544410805683583,\"x_axis\":[-121.195556"
"640625,0.8219714164733887,0.2313031703233719],\"relative_nonlinearity\":"
"[2.888176311444113e-07,1.06274164579645e-07,-1.7186295080634935e-39]},"
"\"accelerometer\":{\"origin\":[0.026900000870227814,-0.03999999910593033,-"
"0.08950000256299973],\"offset\":[-733.3636474609375,58.969032287597656,1"
"060.2550048828125],\"z_axis\":[1.639882206916809,15166.744140625,-116.99"
"742889404297],\"y_axis\":[-7.027288913726807,-44.12333679199219,14952.37"
"01171875],\"unit\":6.666666740784422e-05,\"x_axis\":[-15008.123046875,56.9"
"56390380859375,-60.5175666809082],\"relative_nonlinearity\":[0.0,0.0,0.0"
"]}}"
)

# Laser pulse position modulation used for MTA resolution
RDB_RIEGL_PULSE_POSITION_MODULATION             = "riegl.pulse_position_modulation"
RDB_RIEGL_PULSE_POSITION_MODULATION_TITLE       = "Pulse Position Modulation"
RDB_RIEGL_PULSE_POSITION_MODULATION_DESCRIPTION = "Laser pulse position modulation used for MTA resolution"
RDB_RIEGL_PULSE_POSITION_MODULATION_STATUS      = "optional"
RDB_RIEGL_PULSE_POSITION_MODULATION_SCHEMA = (
"{\"description\":\"Laser pulse position modulation used for MTA "
"resolution\",\"title\":\"Pulse Position Modulation\",\"type\":\"object\",\"$sche"
"ma\":\"http://json-schema.org/draft-04/schema#\",\"properties\":{\"code_phas"
"e_mode\":{\"description\":\"0: no synchronization, 1: toggle between 2 "
"phases, 2: increment with phase_increment\",\"minimum\":0,\"type\":\"integer"
"\",\"maximum\":255},\"pulse_interval\":{\"description\":\"Explicit table of "
"the pulse position modulation used for MTA resolution. Table gives "
"times between successive laser pulses in seconds.\",\"items\":{\"minimum\":"
"0,\"type\":\"number\"},\"type\":\"array\"},\"num_mod_ampl\":{\"description\":\"Numb"
"er of different modulation amplitudes (2: binary modulation)\",\"minimum"
"\":0,\"type\":\"integer\",\"maximum\":255},\"phase_step\":{\"description\":\"Step "
"width in phase of modulation code from line to line\",\"minimum\":0,\"type"
"\":\"integer\",\"maximum\":255},\"length\":{\"description\":\"Length of code\",\"m"
"inimum\":0,\"type\":\"integer\",\"maximum\":255}},\"required\":[\"length\",\"num_m"
"od_ampl\",\"pulse_interval\"]}"
)
RDB_RIEGL_PULSE_POSITION_MODULATION_EXAMPLE = (
"{\"code_phase_mode\":2,\"pulse_interval\":[2.759375e-06,2.759375e-06,2.759"
"375e-06,2.759375e-06,2.821875e-06,2.759375e-06,2.759375e-06,2.821875e-"
"06,2.759375e-06,2.821875e-06,2.821875e-06,2.759375e-06,2.759375e-06,2."
"821875e-06,2.821875e-06,2.821875e-06,2.821875e-06,2.821875e-06,2.75937"
"5e-06,2.759375e-06,2.759375e-06,2.821875e-06,2.821875e-06,2.759375e-06"
",2.821875e-06,2.821875e-06,2.821875e-06,2.759375e-06,2.821875e-06,2.75"
"9375e-06,2.821875e-06],\"num_mod_ampl\":2,\"phase_step\":5,\"length\":31}"
)

# Statistics about target distance wrt. SOCS origin
RDB_RIEGL_RANGE_STATISTICS             = "riegl.range_statistics"
RDB_RIEGL_RANGE_STATISTICS_TITLE       = "Range Statistics"
RDB_RIEGL_RANGE_STATISTICS_DESCRIPTION = "Statistics about target distance wrt. SOCS origin"
RDB_RIEGL_RANGE_STATISTICS_STATUS      = "optional"
RDB_RIEGL_RANGE_STATISTICS_SCHEMA = (
"{\"description\":\"Statistics about target distance wrt. SOCS "
"origin\",\"title\":\"Range Statistics\",\"type\":\"object\",\"$schema\":\"http://j"
"son-schema.org/draft-04/schema#\",\"properties\":{\"minimum\":{\"description"
"\":\"Minimum value\",\"type\":\"number\"},\"average\":{\"description\":\"Average "
"value\",\"type\":\"number\"},\"maximum\":{\"description\":\"Maximum "
"value\",\"type\":\"number\"},\"std_dev\":{\"description\":\"Standard deviation\","
"\"type\":\"number\"}},\"required\":[\"minimum\",\"average\",\"maximum\",\"std_dev\"]"
"}"
)
RDB_RIEGL_RANGE_STATISTICS_EXAMPLE = (
"{\"minimum\":0.919,\"average\":15.49738,\"maximum\":574.35,\"std_dev\":24.349}"
)

# Receiver Internals
RDB_RIEGL_RECEIVER_INTERNALS             = "riegl.receiver_internals"
RDB_RIEGL_RECEIVER_INTERNALS_TITLE       = "Receiver Internals"
RDB_RIEGL_RECEIVER_INTERNALS_DESCRIPTION = "Receiver Internals"
RDB_RIEGL_RECEIVER_INTERNALS_STATUS      = "optional"
RDB_RIEGL_RECEIVER_INTERNALS_SCHEMA = (
"{\"description\":\"Receiver Internals\",\"title\":\"Receiver Internals\",\"type"
"\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"proper"
"ties\":{\"sr\":{\"minimum\":0,\"exclusiveMinimum\":true,\"description\":\"Sample"
" rate [Hz]\",\"type\":\"number\"},\"tbl\":{\"description\":\"various internal da"
"ta\",\"items\":{\"$ref\":\"#/definitions/fp_table\"},\"type\":\"array\",\"minItems"
"\":1},\"ex\":{\"description\":\"DEPRECATED, use "
"'riegl.exponential_decomposition' "
"instead\",\"type\":\"object\"},\"a\":{\"description\":\"Amplitude [dB]\",\"items\":"
"{\"type\":\"number\"},\"maxItems\":256,\"type\":\"array\",\"minItems\":1},\"t\":{\"ad"
"ditionalProperties\":false,\"type\":\"object\",\"patternProperties\":{\"^[0-9]"
"+$\":{\"description\":\"one field per channel, field name is channel index"
"\",\"$ref\":\"#/definitions/fp\"}}},\"mw\":{\"minimum\":0,\"exclusiveMinimum\":tr"
"ue,\"description\":\"Maximum weight\",\"type\":\"number\",\"maximum\":4095},\"si\""
":{\"minimum\":0,\"description\":\"Start index (hw_start)\",\"type\":\"number\",\""
"maximum\":255},\"nt\":{\"minimum\":0,\"description\":\"Number of traces\",\"type"
"\":\"integer\",\"maximum\":255},\"ns\":{\"minimum\":0,\"description\":\"Number of "
"samples\",\"type\":\"integer\",\"maximum\":4095}},\"definitions\":{\"fp_table_ro"
"w\":{\"minItems\":1,\"type\":\"array\",\"maxItems\":2048,\"items\":{\"type\":\"numbe"
"r\"}},\"fp\":{\"description\":\"Fingerprint values\",\"properties\":{\"w\":{\"item"
"s\":{\"items\":{\"type\":\"number\"},\"maxItems\":5,\"type\":\"array\",\"minItems\":5"
"},\"maxItems\":256,\"type\":\"array\",\"minItems\":1},\"s\":{\"items\":{\"items\":{\""
"type\":\"number\"},\"maxItems\":4096,\"type\":\"array\",\"minItems\":1},\"maxItems"
"\":256,\"type\":\"array\",\"minItems\":1}},\"type\":\"object\",\"required\":[\"s\",\"w"
"\"]},\"fp_table\":{\"properties\":{\"tv\":{\"minItems\":1,\"type\":\"array\",\"maxIt"
"ems\":2048,\"items\":{\"oneOf\":[{\"$ref\":\"#/definitions/fp_table_row\"},{\"ty"
"pe\":\"number\"}]}},\"tc\":{\"description\":\"table data type "
"code\",\"max\":255,\"type\":\"integer\",\"min\":0},\"ny\":{\"description\":\"number "
"of y entries\",\"max\":2048,\"type\":\"integer\",\"min\":1},\"nx\":{\"description\""
":\"number of x entries\",\"max\":2048,\"type\":\"integer\",\"min\":1},\"ch\":{\"des"
"cription\":\"channel number\",\"max\":255,\"type\":\"integer\",\"min\":0}},\"type\""
":\"object\",\"required\":[\"ch\",\"tc\",\"nx\",\"ny\",\"tv\"],\"desription\":\"scanner "
"internal data\"}}}"
)
RDB_RIEGL_RECEIVER_INTERNALS_EXAMPLE = (
"{\"sr\":7959997000.0,\"tbl\":[{\"tv\":[[1,2,3,4,5],[1.1,2.2,3.3,4.4,5.5]],\"t"
"c\":1,\"ny\":2,\"nx\":5,\"ch\":0}],\"a\":[-1.55],\"t\":{\"0\":{\"w\":[[78,86,126,134,"
"31],[78,86,126,134,31]],\"s\":[[1.23,4.56],[7.89,0.12]]},\"1\":{\"w\":[[78,8"
"6,126,134,31],[78,86,126,134,31]],\"s\":[[1.23,4.56],[7.89,0.12]]}},\"mw\""
":31,\"si\":48,\"nt\":128,\"ns\":400}"
)

# Lookup table for reflectance calculation based on amplitude and range
RDB_RIEGL_REFLECTANCE_CALCULATION             = "riegl.reflectance_calculation"
RDB_RIEGL_REFLECTANCE_CALCULATION_TITLE       = "Reflectance Calculation Table"
RDB_RIEGL_REFLECTANCE_CALCULATION_DESCRIPTION = "Lookup table for reflectance calculation based on amplitude and range"
RDB_RIEGL_REFLECTANCE_CALCULATION_STATUS      = "optional"
RDB_RIEGL_REFLECTANCE_CALCULATION_SCHEMA = (
"{\"description\":\"Lookup table for reflectance calculation based on "
"amplitude and range\",\"title\":\"Reflectance Calculation Table\",\"type\":\"o"
"bject\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"properties"
"\":{\"content\":{\"description\":\"Correction value [dB] to be added to the "
"amplitude\",\"items\":{\"type\":\"number\"},\"maxItems\":2000,\"type\":\"array\",\"m"
"inItems\":1},\"delta\":{\"description\":\"Delta between table entries [m], "
"first entry is at range = 0 "
"m\",\"type\":\"number\"}},\"required\":[\"delta\",\"content\"]}"
)
RDB_RIEGL_REFLECTANCE_CALCULATION_EXAMPLE = (
"{\"content\":[-33.01],\"delta\":0.150918}"
)

# Range-dependent and scan-angle-dependent correction of reflectance reading
RDB_RIEGL_REFLECTANCE_CORRECTION             = "riegl.reflectance_correction"
RDB_RIEGL_REFLECTANCE_CORRECTION_TITLE       = "Near-range reflectance correction"
RDB_RIEGL_REFLECTANCE_CORRECTION_DESCRIPTION = "Range-dependent and scan-angle-dependent correction of reflectance reading"
RDB_RIEGL_REFLECTANCE_CORRECTION_STATUS      = "optional"
RDB_RIEGL_REFLECTANCE_CORRECTION_SCHEMA = (
"{\"description\":\"Range-dependent and scan-angle-dependent correction of"
" reflectance reading\",\"title\":\"Near-range reflectance correction\",\"typ"
"e\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"prope"
"rties\":{\"ranges_m\":{\"description\":\"Range [m]\",\"items\":{\"type\":\"number\""
"},\"type\":\"array\"},\"reflectance_correction_db\":{\"description\":\"Near "
"range reflectance correction in dB as a function of range over "
"angle\",\"items\":{\"description\":\"rows (each array corresponds to a "
"range)\",\"items\":{\"description\":\"columns (each value corresponds to an "
"angle)\",\"type\":\"number\"},\"type\":\"array\"},\"type\":\"array\"},\"line_angles_"
"deg\":{\"description\":\"Angle [deg]\",\"items\":{\"type\":\"number\"},\"type\":\"ar"
"ray\"}},\"required\":[\"ranges_m\",\"line_angles_deg\",\"reflectance_correctio"
"n_db\"]}"
)
RDB_RIEGL_REFLECTANCE_CORRECTION_EXAMPLE = (
"{\"ranges_m\":[0.0,1.0,2.0,3.0],\"reflectance_correction_db\":[[0.8,0.7,0."
"6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05"
",0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0."
"4,0.3,0.2,0.1,0.05,0.01]],\"line_angles_deg\":[0.0,0.5,1.0,1.5,1.0,2.0,2"
".5,3.0,3.5,4.0]}"
)

# Scan pattern description
RDB_RIEGL_SCAN_PATTERN             = "riegl.scan_pattern"
RDB_RIEGL_SCAN_PATTERN_TITLE       = "Scan Pattern"
RDB_RIEGL_SCAN_PATTERN_DESCRIPTION = "Scan pattern description"
RDB_RIEGL_SCAN_PATTERN_STATUS      = "optional"
RDB_RIEGL_SCAN_PATTERN_SCHEMA = (
"{\"description\":\"Scan pattern description\",\"title\":\"Scan "
"Pattern\",\"properties\":{\"line\":{\"description\":\"Line Scan "
"Pattern\",\"properties\":{\"increment\":{\"description\":\"Increment of angle "
"in SOCS [deg]\",\"minimum\":0.0,\"type\":\"number\",\"maximum\":90.0},\"stop\":{\""
"description\":\"Stop angle in SOCS [deg]\",\"minimum\":0.0,\"type\":\"number\","
"\"maximum\":720.0},\"program\":{\"$ref\":\"#/definitions/program\"},\"start\":{\""
"description\":\"Start angle in SOCS [deg]\",\"minimum\":0.0,\"type\":\"number\""
",\"maximum\":360.0}},\"type\":\"object\",\"required\":[\"start\",\"stop\",\"increme"
"nt\"]},\"rectangular\":{\"description\":\"Rectangular Field Of View Scan "
"Pattern\",\"properties\":{\"phi_increment\":{\"description\":\"Increment of "
"phi angle in SOCS [deg]\",\"minimum\":0.0,\"type\":\"number\",\"maximum\":90.0}"
",\"phi_stop\":{\"description\":\"Stop phi angle in SOCS [deg]\",\"minimum\":0."
"0,\"type\":\"number\",\"maximum\":720.0},\"theta_increment\":{\"description\":\"I"
"ncrement of theta angle in SOCS [deg]\",\"minimum\":0.0,\"type\":\"number\",\""
"maximum\":90.0},\"theta_stop\":{\"description\":\"Stop theta angle in SOCS ["
"deg]\",\"minimum\":0.0,\"type\":\"number\",\"maximum\":180.0},\"theta_start\":{\"d"
"escription\":\"Start theta angle in SOCS [deg]\",\"minimum\":0.0,\"type\":\"nu"
"mber\",\"maximum\":180.0},\"program\":{\"$ref\":\"#/definitions/program\"},\"phi"
"_start\":{\"description\":\"Start phi angle in SOCS [deg]\",\"minimum\":0.0,\""
"type\":\"number\",\"maximum\":360.0}},\"type\":\"object\",\"required\":[\"phi_star"
"t\",\"phi_stop\",\"phi_increment\",\"theta_start\",\"theta_stop\",\"theta_increm"
"ent\"]},\"segments\":{\"description\":\"Segmented Line Scan Pattern\",\"proper"
"ties\":{\"program\":{\"$ref\":\"#/definitions/program\"},\"list\":{\"items\":{\"de"
"scription\":\"Line Scan "
"Segment\",\"properties\":{\"increment\":{\"description\":\"Increment of angle "
"in SOCS [deg]\",\"minimum\":0.0,\"type\":\"number\",\"maximum\":90.0},\"stop\":{\""
"description\":\"Stop angle in SOCS [deg]\",\"minimum\":0.0,\"type\":\"number\","
"\"maximum\":720.0},\"start\":{\"description\":\"Start angle in SOCS [deg]\",\"m"
"inimum\":0.0,\"type\":\"number\",\"maximum\":360.0}},\"type\":\"object\",\"require"
"d\":[\"start\",\"stop\",\"increment\"]},\"type\":\"array\"}},\"type\":\"object\",\"req"
"uired\":[\"list\"]}},\"definitions\":{\"program\":{\"description\":\"Measurement"
" program\",\"properties\":{\"laser_prr\":{\"description\":\"Laser Pulse "
"Repetition Rate [Hz]\",\"minimum\":0,\"type\":\"number\",\"exclusiveMinimum\":f"
"alse},\"name\":{\"description\":\"Name of measurement program\",\"type\":\"stri"
"ng\"}},\"type\":\"object\",\"required\":[\"name\"]}},\"$schema\":\"http://json-sch"
"ema.org/draft-04/schema#\"}"
)
RDB_RIEGL_SCAN_PATTERN_EXAMPLE = (
"{\"rectangular\":{\"phi_increment\":0.04,\"phi_stop\":270.0,\"theta_increment"
"\":0.04,\"theta_stop\":130.0,\"theta_start\":30.0,\"program\":{\"laser_prr\":10"
"0000.0,\"name\":\"High Speed\"},\"phi_start\":45.0}}"
)

# Details about laser shot files
RDB_RIEGL_SHOT_INFO             = "riegl.shot_info"
RDB_RIEGL_SHOT_INFO_TITLE       = "Shot Information"
RDB_RIEGL_SHOT_INFO_DESCRIPTION = "Details about laser shot files"
RDB_RIEGL_SHOT_INFO_STATUS      = "optional"
RDB_RIEGL_SHOT_INFO_SCHEMA = (
"{\"description\":\"Details about laser shot files\",\"title\":\"Shot Informat"
"ion\",\"properties\":{\"shot_file\":{\"properties\":{\"file_extension\":{\"descr"
"iption\":\"Shot file extension, without the leading "
"dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's Universally "
"Unique Identifier (RFC 4122)\",\"type\":\"string\"}},\"type\":\"object\",\"requi"
"red\":[\"file_extension\"]}},\"type\":\"object\",\"$schema\":\"http://json-schem"
"a.org/draft-04/schema#\"}"
)
RDB_RIEGL_SHOT_INFO_EXAMPLE = (
"{\"shot_file\":{\"file_extension\":\"sodx\",\"file_uuid\":\"26a00815-67c0-4bff-"
"8fe8-c577378fe663\"}}"
)

# Point filters applied in addition to the application-defined filters
RDB_RIEGL_STORED_FILTERS             = "riegl.stored_filters"
RDB_RIEGL_STORED_FILTERS_TITLE       = "Stored filters"
RDB_RIEGL_STORED_FILTERS_DESCRIPTION = "Point filters applied in addition to the application-defined filters"
RDB_RIEGL_STORED_FILTERS_STATUS      = "optional"
RDB_RIEGL_STORED_FILTERS_SCHEMA = (
"{\"description\":\"Point filters applied in addition to the "
"application-defined filters\",\"title\":\"Stored filters\",\"type\":\"object\","
"\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"properties\":{\"act"
"ivated\":{\"description\":\"Apply ('true') or ignore ('false') all "
"filters\",\"type\":\"boolean\"},\"filters\":{\"description\":\"List of point "
"filters\",\"items\":{\"description\":\"Point filter "
"definition\",\"properties\":{\"activated\":{\"description\":\"Apply ('true') "
"or ignore ('false') this "
"filter\",\"type\":\"boolean\"},\"title\":{\"description\":\"A short filter title"
" (e.g. for display in a selection "
"list)\",\"type\":\"string\"},\"description\":{\"description\":\"A brief "
"description of the filter (e.g. for display in a "
"tooltip)\",\"type\":\"string\"},\"filter\":{\"description\":\"The RDB filter "
"string to apply (e.g. when reading points or index), details see "
"documentation of function select()\",\"type\":\"string\"}},\"type\":\"object\","
"\"required\":[\"activated\",\"title\",\"description\",\"filter\"]},\"type\":\"array"
"\"}},\"required\":[\"activated\",\"filters\"]}"
)
RDB_RIEGL_STORED_FILTERS_EXAMPLE = (
"{\"activated\":true,\"filters\":[{\"activated\":true,\"title\":\"MTA Zone "
"Resolved/Unresolved\",\"description\":\"Ignore points with uncertain MTA "
"zone assignment\",\"filter\":\"riegl.mta_unresolved == "
"0\"},{\"activated\":true,\"title\":\"Deviation\",\"description\":\"Ignore points"
" with invalid pulse shape deviation\",\"filter\":\"riegl.deviation != "
"-1\"}]}"
)

# Conversion of background radiation raw values to temperatures in °C
RDB_RIEGL_TEMPERATURE_CALCULATION             = "riegl.temperature_calculation"
RDB_RIEGL_TEMPERATURE_CALCULATION_TITLE       = "Temperature Calculation Table"
RDB_RIEGL_TEMPERATURE_CALCULATION_DESCRIPTION = "Conversion of background radiation raw values to temperatures in °C"
RDB_RIEGL_TEMPERATURE_CALCULATION_STATUS      = "optional"
RDB_RIEGL_TEMPERATURE_CALCULATION_SCHEMA = (
"{\"description\":\"Conversion of background radiation raw values to "
"temperatures in \\u00b0C\",\"title\":\"Temperature Calculation Table\",\"type"
"\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"proper"
"ties\":{\"InGaAs_Si_Difference\":{\"description\":\"Conversion table for "
"InGaAs - Si difference\",\"$ref\":\"#/definitions/conversion_table\"},\"InGa"
"As\":{\"description\":\"Conversion table for InGaAs channel\",\"$ref\":\"#/def"
"initions/conversion_table\"},\"Si\":{\"description\":\"Conversion table for "
"Si channel\",\"$ref\":\"#/definitions/conversion_table\"}},\"definitions\":{\""
"conversion_table\":{\"properties\":{\"temperature\":{\"description\":\"Tempera"
"ture [\\u00b0C]\",\"items\":{\"type\":\"number\"},\"type\":\"array\"},\"value\":{\"de"
"scription\":\"LSB [1]\",\"items\":{\"type\":\"number\"},\"type\":\"array\"}},\"type\""
":\"object\",\"required\":[\"value\",\"temperature\"]}}}"
)
RDB_RIEGL_TEMPERATURE_CALCULATION_EXAMPLE = (
"{\"InGaAs_Si_Difference\":{\"temperature\":[1749.977111117893,1749.9771111"
"17893,1749.977111117893,1749.977111117893,1749.977111117893,1749.97711"
"1117893,1744.7813348796044,1681.9971312601092,1622.3944822534868],\"val"
"ue\":[1000.0,1100.090029602954,1200.04425183874,1300.1342814416948,1400"
".0885036774805,1500.0427259132668,1600.1327555162209,1700.086977752006"
"5,1800.0411999877924]},\"InGaAs\":{\"temperature\":[307.22196722535614,309"
".1153478247277,311.1188086915047,313.10025350480055,315.2137946389828,"
"317.2172555057597,319.2207163725366,321.2021611858325,323.315702320014"
"8],\"value\":[0.0,64.00097659230323,128.0019531846065,192.0029297769097,"
"256.0039063692129,320.00488296151616,384.0058595538194,448.00683614612"
"26,512.0078127384259]},\"Si\":{\"temperature\":[546.300048828125,548.81640"
"51212026,551.3143938500972,554.0144257850053,556.604252334815,559.2124"
"464488079,561.8022729986177,564.4104671126105,567.0002936624203],\"valu"
"e\":[0.0,64.00097659230323,128.0019531846065,192.0029297769097,256.0039"
"063692129,320.00488296151616,384.0058595538194,448.0068361461226,512.0"
"078127384259]}}"
)

# Base of timestamps (epoch)
RDB_RIEGL_TIME_BASE             = "riegl.time_base"
RDB_RIEGL_TIME_BASE_TITLE       = "Time Base"
RDB_RIEGL_TIME_BASE_DESCRIPTION = "Base of timestamps (epoch)"
RDB_RIEGL_TIME_BASE_STATUS      = "optional"
RDB_RIEGL_TIME_BASE_SCHEMA = (
"{\"description\":\"Base of timestamps (epoch)\",\"title\":\"Time Base\",\"type\""
":\"object\",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"propert"
"ies\":{\"epoch\":{\"description\":\"Date and time of timestamp '0' as "
"proposed by RFC 3339 (e.g. 2015-10-27T00:00:00+01:00).\",\"type\":\"string"
"\"},\"system\":{\"description\":\"Time system (time standard)\",\"type\":\"strin"
"g\",\"enum\":[\"unknown\",\"UTC\",\"GPS\"]},\"source\":{\"description\":\"Timestamp "
"source\",\"type\":\"string\",\"enum\":[\"unknown\",\"RTC\",\"GNSS\"]}},\"required\":["
"\"epoch\",\"source\"]}"
)
RDB_RIEGL_TIME_BASE_EXAMPLE = (
"{\"epoch\":\"2015-10-27T00:00:00+00:00\",\"system\":\"UTC\",\"source\":\"GNSS\"}"
)

# Details about position+orientation files
RDB_RIEGL_TRAJECTORY_INFO             = "riegl.trajectory_info"
RDB_RIEGL_TRAJECTORY_INFO_TITLE       = "Trajectory Information"
RDB_RIEGL_TRAJECTORY_INFO_DESCRIPTION = "Details about position+orientation files"
RDB_RIEGL_TRAJECTORY_INFO_STATUS      = "optional"
RDB_RIEGL_TRAJECTORY_INFO_SCHEMA = (
"{\"description\":\"Details about position+orientation "
"files\",\"title\":\"Trajectory Information\",\"type\":\"object\",\"$schema\":\"htt"
"p://json-schema.org/draft-04/schema#\",\"properties\":{\"field_of_applicat"
"ion\":{\"description\":\"Field of application\",\"type\":\"string\",\"enum\":[\"un"
"known\",\"SLS\",\"TLS\",\"KLS\",\"MLS\",\"ULS\",\"ALS\",\"BLS\",\"ILS\"]},\"navigation_f"
"rame\":{\"description\":\"Navigation frame (NED: North-East-Down, ENU: Eas"
"t-North-Up)\",\"type\":\"string\",\"enum\":[\"unknown\",\"NED\",\"ENU\"]},\"settings"
"\":{\"description\":\"Settings used to calculate the trajectory "
"(descriptive "
"text)\",\"type\":\"string\"},\"time_interval\":{\"description\":\"Time interval "
"statistics\",\"properties\":{\"minimum\":{\"description\":\"Minimum time "
"interval [s]\",\"type\":\"number\"},\"average\":{\"description\":\"Average time "
"interval [s]\",\"type\":\"number\"},\"maximum\":{\"description\":\"Maximum time "
"interval [s]\",\"type\":\"number\"},\"std_dev\":{\"description\":\"Standard "
"deviation of intervals [s]\",\"type\":\"number\"}},\"type\":\"object\",\"require"
"d\":[\"minimum\",\"average\",\"maximum\",\"std_dev\"]},\"location\":{\"description"
"\":\"Project location, e.g. city/state/country\",\"type\":\"string\"},\"device"
"\":{\"description\":\"Navigation device, e.g. "
"name/type/serial\",\"type\":\"string\"},\"company\":{\"description\":\"Company "
"name\",\"type\":\"string\"},\"project\":{\"description\":\"Project "
"name\",\"type\":\"string\"},\"software\":{\"description\":\"Software that "
"calculated the trajectory (this may be the same or different software "
"than the one that created the file)\",\"type\":\"string\"}},\"required\":[\"ti"
"me_interval\",\"navigation_frame\"]}"
)
RDB_RIEGL_TRAJECTORY_INFO_EXAMPLE = (
"{\"field_of_application\":\"MLS\",\"navigation_frame\":\"NED\",\"settings\":\"def"
"ault\",\"time_interval\":{\"minimum\":0.00500032,\"average\":0.00500053,\"maxi"
"mum\":0.005004883,\"std_dev\":5.51e-07},\"location\":\"Horn\",\"device\":\"IMU "
"Model 12/1, Serial# 12345\",\"company\":\"RIEGL LMS\",\"project\":\"Campaign "
"3\",\"software\":\"Navigation Software XYZ\"}"
)

# Details about vertex file
RDB_RIEGL_VERTEX_INFO             = "riegl.vertex_info"
RDB_RIEGL_VERTEX_INFO_TITLE       = "Vertex Information"
RDB_RIEGL_VERTEX_INFO_DESCRIPTION = "Details about vertex file"
RDB_RIEGL_VERTEX_INFO_STATUS      = "optional"
RDB_RIEGL_VERTEX_INFO_SCHEMA = (
"{\"description\":\"Details about vertex file\",\"title\":\"Vertex Information"
"\",\"properties\":{\"vertex_file\":{\"properties\":{\"file_extension\":{\"descri"
"ption\":\"Vertex file extension, without the leading "
"dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's Universally "
"Unique Identifier (RFC 4122)\",\"type\":\"string\"}},\"type\":\"object\",\"requi"
"red\":[\"file_extension\"]}},\"type\":\"object\",\"$schema\":\"http://json-schem"
"a.org/draft-04/schema#\"}"
)
RDB_RIEGL_VERTEX_INFO_EXAMPLE = (
"{\"vertex_file\":{\"file_extension\":\"vtx\",\"file_uuid\":\"51534d95-d71f-4f36"
"-ae1a-3e63a21fd1c7\"}}"
)

# Details about the voxels contained in the file
RDB_RIEGL_VOXEL_INFO             = "riegl.voxel_info"
RDB_RIEGL_VOXEL_INFO_TITLE       = "Voxel Information"
RDB_RIEGL_VOXEL_INFO_DESCRIPTION = "Details about the voxels contained in the file"
RDB_RIEGL_VOXEL_INFO_STATUS      = "optional"
RDB_RIEGL_VOXEL_INFO_SCHEMA = (
"{\"description\":\"Details about the voxels contained in the "
"file\",\"title\":\"Voxel Information\",\"type\":\"object\",\"$schema\":\"http://js"
"on-schema.org/draft-04/schema#\",\"oneOf\":[{\"additionalProperties\":false"
",\"properties\":{\"voxel_origin\":{\"$ref\":\"#/definitions/voxel_origin_enum"
"\"},\"shape_thresholds\":{\"$ref\":\"#/definitions/shape_thresholds\"},\"voxel"
"_type\":{\"$ref\":\"#/definitions/voxel_type\"},\"size\":{\"description\":\"Size"
" of voxels in file coordinate system.\",\"oneOf\":[{\"$ref\":\"#/definitions"
"/voxel_size\"},{\"$ref\":\"#/definitions/voxel_size_cubic\"}]}},\"required\":"
"[\"size\",\"voxel_origin\",\"voxel_type\"]},{\"additionalProperties\":false,\"p"
"roperties\":{\"reference_point\":{\"description\":\"Point in WGS84 geodetic "
"decimal degree (EPSG:4326) that was used to compute the projection "
"distortion parameters. The coefficient order is latitude, longitude. "
"Only voxels with corresponding geo_tag, voxel_size and reference_point"
" can be reliably processed together. This entry is available for voxel"
" files in projected CRS only.\",\"items\":{\"minimum\":-180,\"type\":\"number\""
",\"maximum\":180},\"maxItems\":2,\"type\":\"array\",\"minItems\":2},\"shape_thres"
"holds\":{\"$ref\":\"#/definitions/shape_thresholds\"},\"size_llcs\":{\"descrip"
"tion\":\"Size of voxels in a locally levelled cartesian coordinate "
"system (xyz). This is only used for voxels based on a map projection.\""
",\"$ref\":\"#/definitions/voxel_size\"},\"size\":{\"description\":\"Size of "
"voxels in file coordinate system.\",\"$ref\":\"#/definitions/voxel_size\"},"
"\"voxel_origin\":{\"oneOf\":[{\"$ref\":\"#/definitions/voxel_origin_enum\"},{\""
"description\":\"The base point of the voxel grid. Used together with "
"<tt>voxel_size</tt> and <tt>voxel_index</tt> to compute actual point c"
"oordinates.\",\"$ref\":\"#/definitions/voxel_origin_point\"}]},\"voxel_type\""
":{\"$ref\":\"#/definitions/voxel_type\"}},\"required\":[\"reference_point\",\"s"
"ize_llcs\",\"size\",\"voxel_origin\",\"voxel_type\"]}],\"definitions\":{\"edge_l"
"ength\":{\"description\":\"Length of voxel edge [m].\",\"exclusiveMinimum\":t"
"rue,\"type\":\"number\",\"minimum\":0},\"voxel_type\":{\"description\":\"Whether "
"a point in a voxel represents its center or its centroid. If type is "
"<tt>index</tt> there is no point but only an integer voxel index.\",\"de"
"fault\":\"centroid\",\"enum\":[\"center\",\"centroid\",\"index\"]},\"shape_thresho"
"lds\":{\"description\":\"Thresholds used to compute the voxel's shape_id "
"value.\",\"properties\":{\"line\":{\"description\":\"If the biggest eigenvalue"
" is bigger than the median eigenvalue * line_threshold, the voxel is "
"considered a line.\",\"exclusiveMinimum\":true,\"type\":\"number\",\"minimum\":"
"1},\"plane\":{\"description\":\"If the smallest eigenvalue is smaller than "
"the median eigenvalue * plane_threshold, the voxel is considered a pla"
"ne.\",\"minimum\":0,\"maximum\":1,\"exclusiveMinimum\":true,\"type\":\"number\",\""
"exclusiveMaximum\":true}},\"type\":\"object\",\"required\":[\"plane\",\"line\"]},"
"\"voxel_size_cubic\":{\"type\":\"number\",\"$ref\":\"#/definitions/edge_length\""
"},\"voxel_origin_enum\":{\"description\":\"Defines whether the voxel's "
"center or a corner is placed on CRS origin <tt>(0/0/0)</tt>.\",\"default"
"\":\"corner\",\"enum\":[\"center\",\"corner\"]},\"voxel_size\":{\"description\":\"Si"
"ze of voxels.\",\"items\":{\"$ref\":\"#/definitions/edge_length\"},\"maxItems\""
":3,\"type\":\"array\",\"minItems\":3},\"voxel_origin_point\":{\"description\":\"O"
"rigin point for all voxel indices in voxel CRS.\",\"items\":{\"type\":\"numb"
"er\"},\"maxItems\":3,\"type\":\"array\",\"minItems\":3}}}"
)
RDB_RIEGL_VOXEL_INFO_EXAMPLE = (
"{\"reference_point\":[48,16],\"shape_thresholds\":{\"plane\":0.16,\"line\":6},"
"\"size_llcs\":[0.5156575252891171,0.5130835356683303,0.5143705304787237]"
",\"size\":[0.5971642834779395,0.5971642834779395,0.5143705304787237],\"vo"
"xel_origin\":\"corner\",\"voxel_type\":\"centroid\"}"
)

# Settings for waveform averaging
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS             = "riegl.waveform_averaging_settings"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_TITLE       = "Waveform Averaging Settings"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_DESCRIPTION = "Settings for waveform averaging"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_SCHEMA = (
"{\"description\":\"Settings for waveform averaging\",\"title\":\"Waveform "
"Averaging Settings\",\"type\":\"object\",\"$schema\":\"http://json-schema.org/"
"draft-04/schema#\",\"properties\":{\"trim\":{\"description\":\"Percentage for "
"robust averaging.\",\"minimum\":0,\"type\":\"number\",\"maximum\":0.5,\"default\""
":0},\"mta_zone\":{\"description\":\"Fixed MTA zone for averaging.\",\"minimum"
"\":1,\"type\":\"integer\"},\"num_shots\":{\"description\":\"Number of "
"consecutive shots to be used for averaging.\",\"minimum\":1,\"type\":\"integ"
"er\"}},\"required\":[\"num_shots\",\"mta_zone\"]}"
)
RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS_EXAMPLE = (
"{\"trim\":0.05,\"mta_zone\":1,\"num_shots\":7}"
)

# Details about waveform files
RDB_RIEGL_WAVEFORM_INFO             = "riegl.waveform_info"
RDB_RIEGL_WAVEFORM_INFO_TITLE       = "Waveform Information"
RDB_RIEGL_WAVEFORM_INFO_DESCRIPTION = "Details about waveform files"
RDB_RIEGL_WAVEFORM_INFO_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_INFO_SCHEMA = (
"{\"description\":\"Details about waveform files\",\"title\":\"Waveform Inform"
"ation\",\"type\":\"object\",\"$schema\":\"http://json-schema.org/draft-04/sche"
"ma#\",\"properties\":{\"range_offset_m\":{\"description\":\"Calibrated device "
"specific range offset for waveform analysis by system response fitting"
" in meters.\",\"type\":\"number\"},\"sample_block_file\":{\"properties\":{\"file"
"_extension\":{\"description\":\"Sample block file extension, without the "
"leading dot\",\"type\":\"string\"},\"file_uuid\":{\"description\":\"File's "
"Universally Unique Identifier (RFC 4122)\",\"type\":\"string\"}},\"type\":\"ob"
"ject\",\"required\":[\"file_extension\"]},\"sample_data_files\":{\"items\":{\"pr"
"operties\":{\"delta_st\":{\"description\":\"reserved\",\"type\":\"number\"},\"lase"
"r_wavelength\":{\"description\":\"Laser wavelength in meters (0 = unknown)"
"\",\"exclusiveMinimum\":false,\"type\":\"number\",\"minimum\":0},\"channel\":{\"mi"
"nimum\":0,\"exclusiveMinimum\":false,\"type\":\"integer\",\"description\":\"Samp"
"le block channel number (255 = invalid)\",\"exclusiveMaximum\":false,\"max"
"imum\":255},\"sample_interval\":{\"description\":\"Sampling interval in seco"
"nds\",\"exclusiveMinimum\":false,\"type\":\"number\",\"minimum\":0},\"file_exten"
"sion\":{\"description\":\"Sample data file extension, without the leading "
"dot\",\"type\":\"string\"},\"channel_name\":{\"description\":\"Sample block "
"channel name\",\"type\":\"string\"},\"sample_bits\":{\"minimum\":0,\"exclusiveMi"
"nimum\":false,\"type\":\"integer\",\"description\":\"Bitwidth of samples (e.g."
" 10 bit, 12 bit)\",\"exclusiveMaximum\":false,\"maximum\":32},\"file_uuid\":{"
"\"description\":\"File's Universally Unique Identifier (RFC 4122)\",\"type\""
":\"string\"}},\"type\":\"object\",\"required\":[\"channel\",\"channel_name\",\"samp"
"le_interval\",\"sample_bits\",\"laser_wavelength\",\"delta_st\",\"file_extensi"
"on\"]},\"type\":\"array\"},\"range_offset_waveform_samples_m\":{\"description\""
":\"Calibrated device specific range offset for waveform samples in mete"
"rs.\",\"type\":\"number\"}},\"required\":[\"sample_block_file\",\"sample_data_fi"
"les\"]}"
)
RDB_RIEGL_WAVEFORM_INFO_EXAMPLE = (
"{\"range_offset_m\":3.1415,\"sample_block_file\":{\"file_extension\":\"sbx\",\""
"file_uuid\":\"93a03615-66c0-4bea-8ff8-c577378fe660\"},\"sample_data_files\""
":[{\"delta_st\":0,\"laser_wavelength\":0,\"channel\":0,\"sample_interval\":1.0"
"0503e-09,\"file_extension\":\"sp0\",\"channel_name\":\"high_power\",\"sample_bi"
"ts\":12,\"file_uuid\":\"da084413-e3e8-4655-a122-071de8490d8e\"},{\"delta_st\""
":0,\"laser_wavelength\":0,\"channel\":1,\"sample_interval\":1.00503e-09,\"fil"
"e_extension\":\"sp1\",\"channel_name\":\"low_power\",\"sample_bits\":12,\"file_u"
"uid\":\"93585b5e-5ea9-43a1-947b-e7ba3be642d2\"},{\"delta_st\":0,\"laser_wave"
"length\":0,\"channel\":5,\"sample_interval\":1.00503e-09,\"file_extension\":\""
"sp5\",\"channel_name\":\"wwf\",\"sample_bits\":12,\"file_uuid\":\"9d2298c4-1036-"
"464f-b5cb-1cf8e517f3a0\"}],\"range_offset_waveform_samples_m \":7.283}"
)

# Scanner settings for waveform output
RDB_RIEGL_WAVEFORM_SETTINGS             = "riegl.waveform_settings"
RDB_RIEGL_WAVEFORM_SETTINGS_TITLE       = "Waveform Settings"
RDB_RIEGL_WAVEFORM_SETTINGS_DESCRIPTION = "Scanner settings for waveform output"
RDB_RIEGL_WAVEFORM_SETTINGS_STATUS      = "optional"
RDB_RIEGL_WAVEFORM_SETTINGS_SCHEMA = (
"{\"description\":\"Scanner settings for waveform "
"output\",\"title\":\"Waveform Settings\",\"type\":\"array\",\"$schema\":\"http://j"
"son-schema.org/draft-04/schema#\",\"items\":{\"properties\":{\"pass_rng_grea"
"ter\":{\"description\":\"Threshold for range greater than "
"[m]\",\"type\":\"number\"},\"channel_idx_mask\":{\"description\":\"Bit mask for "
"channels which belong to sbl_name: Channel 0 = Bit0, Channel 1 = Bit1,"
" ...\",\"type\":\"integer\"},\"pass_dev_greater\":{\"description\":\"Threshold "
"for deviation greater than "
"[1]\",\"type\":\"integer\"},\"sbl_name\":{\"description\":\"Name of sample "
"block, e.g.: wfm, "
"wwf\",\"type\":\"string\"},\"enabled\":{\"description\":\"Waveform output "
"enabled\",\"type\":\"boolean\"},\"smart_enabled\":{\"description\":\"Smart "
"waveform output "
"enabled\",\"type\":\"boolean\"},\"pass_rng_less\":{\"description\":\"Threshold "
"for range less than "
"[m]\",\"type\":\"number\"},\"pass_ampl_greater\":{\"description\":\"Threshold "
"for amplitude greater than "
"[dB]\",\"type\":\"number\"},\"logic_expression\":{\"description\":\"Logic "
"expression of smart waveforms "
"filter\",\"type\":\"string\"},\"pass_dev_less\":{\"description\":\"Threshold for"
" deviation less than "
"[1]\",\"type\":\"integer\"},\"pass_ampl_less\":{\"description\":\"Threshold for "
"amplitude less than [dB]\",\"type\":\"number\"}},\"type\":\"object\",\"required\""
":[\"sbl_name\",\"enabled\",\"channel_idx_mask\"]}}"
)
RDB_RIEGL_WAVEFORM_SETTINGS_EXAMPLE = (
"[{\"pass_rng_greater\":9.27,\"channel_idx_mask\":11,\"sbl_name\":\"wfm\",\"enab"
"led\":true,\"smart_enabled\":true,\"pass_rng_less\":13.11,\"pass_ampl_greate"
"r\":1.0,\"pass_ampl_less\":5.0},{\"channel_idx_mask\":32,\"sbl_name\":\"wwf\",\""
"enabled\":false}]"
)

# Window analysis data estimated from scandata and resulting filter parameters
RDB_RIEGL_WINDOW_ANALYSIS             = "riegl.window_analysis"
RDB_RIEGL_WINDOW_ANALYSIS_TITLE       = "Window Analysis"
RDB_RIEGL_WINDOW_ANALYSIS_DESCRIPTION = "Window analysis data estimated from scandata and resulting filter parameters"
RDB_RIEGL_WINDOW_ANALYSIS_STATUS      = "optional"
RDB_RIEGL_WINDOW_ANALYSIS_SCHEMA = (
"{\"description\":\"Window analysis data estimated from scandata and "
"resulting filter parameters\",\"title\":\"Window Analysis\",\"type\":\"object\""
",\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"properties\":{\"re"
"sult\":{\"properties\":{\"amplitude_sigma\":{\"description\":\"[dB]\",\"items\":{"
"\"type\":\"number\"},\"type\":\"array\"},\"amplitude_mean\":{\"description\":\"[dB]"
"\",\"items\":{\"type\":\"number\"},\"type\":\"array\"},\"angle\":{\"description\":\"[d"
"eg]\",\"items\":{\"type\":\"number\"},\"type\":\"array\"},\"timestamp\":{\"descripti"
"on\":\"[s]\",\"items\":{\"type\":\"number\"},\"type\":\"array\"},\"range_sigma\":{\"de"
"scription\":\"[m]\",\"items\":{\"type\":\"number\"},\"type\":\"array\"},\"range_mean"
"\":{\"description\":\"[m]\",\"items\":{\"type\":\"number\"},\"type\":\"array\"},\"ampl"
"itude_offset\":{\"description\":\"[dB]\",\"items\":{\"type\":\"number\"},\"type\":\""
"array\"}},\"type\":\"object\",\"required\":[\"angle\",\"range_mean\",\"range_sigma"
"\",\"amplitude_mean\",\"amplitude_sigma\",\"amplitude_offset\"]},\"filter\":{\"p"
"roperties\":{\"range_max\":{\"description\":\"[m]\",\"items\":{\"type\":\"number\"}"
",\"type\":\"array\"},\"angle\":{\"description\":\"[deg]\",\"items\":{\"type\":\"numbe"
"r\"},\"type\":\"array\"},\"amplitude_max\":{\"description\":\"[dB]\",\"items\":{\"ty"
"pe\":\"number\"},\"type\":\"array\"},\"range_min\":{\"description\":\"[m]\",\"items\""
":{\"type\":\"number\"},\"type\":\"array\"}},\"type\":\"object\",\"required\":[\"angle"
"\",\"range_min\",\"range_max\",\"amplitude_max\"]},\"settings\":{\"properties\":{"
"\"amplitude\":{\"properties\":{\"sigma_factor\":{\"type\":\"number\"},\"additive_"
"value\":{\"type\":\"number\"}},\"type\":\"object\",\"required\":[\"sigma_factor\",\""
"additive_value\"]},\"range\":{\"properties\":{\"sigma_factor\":{\"type\":\"numbe"
"r\"},\"additive_value\":{\"type\":\"number\"}},\"type\":\"object\",\"required\":[\"s"
"igma_factor\",\"additive_value\"]}},\"type\":\"object\",\"required\":[\"range\",\""
"amplitude\"]}},\"required\":[\"result\",\"filter\",\"settings\"]}"
)
RDB_RIEGL_WINDOW_ANALYSIS_EXAMPLE = (
"{\"result\":{\"amplitude_sigma\":[0.4272844,0.4298479,0.4236816,0.4283583,"
"0.4362353,0.4315141,0.4373984,0.4472798,0.4346001,0.4345487,0.4540681]"
",\"amplitude_mean\":[5.347396,5.263155,5.224655,5.179926,5.097782,5.1164"
"79,5.051756,4.983473,5.007885,5.002441,4.982],\"angle\":[14.9,15.0,15.1,"
"15.2,15.3,15.4,15.5,15.6,15.7,15.8,15.9],\"timestamp\":[408.4441,411.444"
"3],\"range_sigma\":[0.01869652,0.02151435,0.01747969,0.01918765,0.019457"
"76,0.01934862,0.01955329,0.02225589,0.02229977,0.01899122,0.02009433],"
"\"range_mean\":[0.1105621,0.1079564,0.1087088,0.1067261,0.1054582,0.1090"
"412,0.102871,0.1019044,0.1051523,0.1058445,0.1031261],\"amplitude_offse"
"t\":[1.9,1.9]},\"filter\":{\"range_max\":[0.424,0.425,0.426,0.427,0.428,0.4"
"28,0.429,0.43,0.431,0.431,0.432],\"angle\":[14.9,15.0,15.1,15.2,15.3,15."
"4,15.5,15.6,15.7,15.8,15.9],\"amplitude_max\":[8.04,8.01,7.99,7.96,7.93,"
"7.9,7.88,7.85,7.83,7.8,7.78],\"range_min\":[-0.208,-0.21,-0.212,-0.214,-"
"0.216,-0.218,-0.219,-0.221,-0.223,-0.225,-0.227]},\"settings\":{\"amplitu"
"de\":{\"sigma_factor\":4,\"additive_value\":1.0},\"range\":{\"sigma_factor\":8,"
"\"additive_value\":0.1}}}"
)

# Correction parameters for window glass echoes
RDB_RIEGL_WINDOW_ECHO_CORRECTION             = "riegl.window_echo_correction"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_TITLE       = "Window Echo Correction"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_DESCRIPTION = "Correction parameters for window glass echoes"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_STATUS      = "optional"
RDB_RIEGL_WINDOW_ECHO_CORRECTION_SCHEMA = (
"{\"description\":\"Correction parameters for window glass "
"echoes\",\"title\":\"Window Echo Correction\",\"type\":\"object\",\"$schema\":\"ht"
"tp://json-schema.org/draft-04/schema#\",\"properties\":{\"amplitude\":{\"des"
"cription\":\"Amplitude axis of correction "
"table\",\"properties\":{\"minimum\":{\"description\":\"Minimum amplitude in "
"dB\",\"minimum\":0.0,\"type\":\"number\"},\"maximum\":{\"description\":\"Maximum "
"amplitude in "
"dB\",\"minimum\":0.0,\"type\":\"number\"},\"entries\":{\"description\":\"Number of"
" amplitude entries\",\"minimum\":1,\"type\":\"integer\"}},\"type\":\"object\",\"re"
"quired\":[\"minimum\",\"maximum\",\"entries\"]},\"slices\":{\"items\":{\"descripti"
"on\":\"Window echo correction parameter "
"slice\",\"properties\":{\"amplitude\":{\"description\":\"Window echo amplitude"
" of slice in dB\",\"type\":\"number\"},\"table\":{\"description\":\"Correction "
"table (dimension defined by the 'amplitude' and 'range' "
"objects)\",\"items\":{\"description\":\"Table row (= amplitude "
"axis)\",\"items\":{\"description\":\"Table column (= range "
"axis)\",\"items\":{\"description\":\"Table cell (item 0: amplitude in dB, 1:"
" range in m, 2: flags)\",\"type\":\"number\"},\"maxItems\":3,\"type\":\"array\",\""
"minItems\":3},\"type\":\"array\",\"minItems\":1},\"type\":\"array\",\"minItems\":1}"
"},\"type\":\"object\",\"required\":[\"amplitude\",\"table\"]},\"type\":\"array\"},\"r"
"ange\":{\"description\":\"Range axis of correction "
"table\",\"properties\":{\"minimum\":{\"description\":\"Minimum range in m\",\"mi"
"nimum\":-2.0,\"type\":\"number\",\"maximum\":2.0},\"maximum\":{\"description\":\"M"
"aximum range in m\",\"minimum\":-2.0,\"type\":\"number\",\"maximum\":2.0},\"entr"
"ies\":{\"description\":\"Number of range entries\",\"minimum\":1,\"type\":\"inte"
"ger\"}},\"type\":\"object\",\"required\":[\"minimum\",\"maximum\",\"entries\"]}},\"r"
"equired\":[\"amplitude\",\"range\",\"slices\"]}"
)
RDB_RIEGL_WINDOW_ECHO_CORRECTION_EXAMPLE = (
"{\"amplitude\":{\"minimum\":2,\"maximum\":20,\"entries\":128},\"slices\":[{\"ampl"
"itude\":1.5,\"table\":[[[6.23,0.3535,1]],[[5.54,0.72375,1]]]},{\"amplitude"
"\":2.0,\"table\":[[[6.23,0.3535,1]],[[5.54,0.72375,1]]]}],\"range\":{\"minim"
"um\":-1.5060822940732335,\"maximum\":1.5060822940732335,\"entries\":128}}"
)
