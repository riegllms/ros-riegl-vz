# -*- coding: utf-8 -*-
"""
RDB library factory interface

===============================================================================
=                                                                             =
= WARNING: This file MUST NEVER be provided to non-RIEGL software developers! =
=                                                                             =
===============================================================================
"""

from ctypes import CFUNCTYPE, POINTER, c_void_p, c_uint8

import riegl.rdb.library


# noinspection PyPep8
def riegl_authentication_function(packet):
    """
    RIEGL authentication function for RDB library
    """
    k = packet[0]
    for j in range(256):
        i = k % 100  # don't use a constant array here...
        k += 1
        if i == +0: packet[j] ^= 0x7F
        if i == 50: packet[j] ^= 0x30
        if i == +1: packet[j] ^= 0xDB
        if i == 51: packet[j] ^= 0xCD
        if i == +2: packet[j] ^= 0xEC
        if i == 52: packet[j] ^= 0x73
        if i == +3: packet[j] ^= 0x45
        if i == 53: packet[j] ^= 0x1A
        if i == +4: packet[j] ^= 0xB8
        if i == 54: packet[j] ^= 0x23
        if i == +5: packet[j] ^= 0xBD
        if i == 55: packet[j] ^= 0x09
        if i == +6: packet[j] ^= 0x6A
        if i == 56: packet[j] ^= 0xB3
        if i == +7: packet[j] ^= 0xF8
        if i == 57: packet[j] ^= 0x13
        if i == +8: packet[j] ^= 0xE0
        if i == 58: packet[j] ^= 0x50
        if i == +9: packet[j] ^= 0x0A
        if i == 59: packet[j] ^= 0xA6
        if i == 10: packet[j] ^= 0x05
        if i == 60: packet[j] ^= 0xE2
        if i == 11: packet[j] ^= 0x4A
        if i == 61: packet[j] ^= 0xE8
        if i == 12: packet[j] ^= 0x8B
        if i == 62: packet[j] ^= 0x5C
        if i == 13: packet[j] ^= 0x8C
        if i == 63: packet[j] ^= 0xDF
        if i == 14: packet[j] ^= 0x22
        if i == 64: packet[j] ^= 0x27
        if i == 15: packet[j] ^= 0x62
        if i == 65: packet[j] ^= 0xFF
        if i == 16: packet[j] ^= 0x77
        if i == 66: packet[j] ^= 0xE8
        if i == 17: packet[j] ^= 0x4B
        if i == 67: packet[j] ^= 0xBA
        if i == 18: packet[j] ^= 0x14
        if i == 68: packet[j] ^= 0x2B
        if i == 19: packet[j] ^= 0x43
        if i == 69: packet[j] ^= 0xBF
        if i == 20: packet[j] ^= 0x9D
        if i == 70: packet[j] ^= 0xB1
        if i == 21: packet[j] ^= 0x23
        if i == 71: packet[j] ^= 0x31
        if i == 22: packet[j] ^= 0x7C
        if i == 72: packet[j] ^= 0x88
        if i == 23: packet[j] ^= 0x02
        if i == 73: packet[j] ^= 0x16
        if i == 24: packet[j] ^= 0xE8
        if i == 74: packet[j] ^= 0xC1
        if i == 25: packet[j] ^= 0x17
        if i == 75: packet[j] ^= 0x97
        if i == 26: packet[j] ^= 0x40
        if i == 76: packet[j] ^= 0x4D
        if i == 27: packet[j] ^= 0x4B
        if i == 77: packet[j] ^= 0x6C
        if i == 28: packet[j] ^= 0xA8
        if i == 78: packet[j] ^= 0xCF
        if i == 29: packet[j] ^= 0xC7
        if i == 79: packet[j] ^= 0x30
        if i == 30: packet[j] ^= 0x57
        if i == 80: packet[j] ^= 0x04
        if i == 31: packet[j] ^= 0xFA
        if i == 81: packet[j] ^= 0x3D
        if i == 32: packet[j] ^= 0xAC
        if i == 82: packet[j] ^= 0x64
        if i == 33: packet[j] ^= 0xE0
        if i == 83: packet[j] ^= 0x3B
        if i == 34: packet[j] ^= 0xE4
        if i == 84: packet[j] ^= 0x4E
        if i == 35: packet[j] ^= 0x4D
        if i == 85: packet[j] ^= 0x77
        if i == 36: packet[j] ^= 0x83
        if i == 86: packet[j] ^= 0x70
        if i == 37: packet[j] ^= 0x42
        if i == 87: packet[j] ^= 0x43
        if i == 38: packet[j] ^= 0x27
        if i == 88: packet[j] ^= 0xFF
        if i == 39: packet[j] ^= 0x13
        if i == 89: packet[j] ^= 0x89
        if i == 40: packet[j] ^= 0x2E
        if i == 90: packet[j] ^= 0x4B
        if i == 41: packet[j] ^= 0x0D
        if i == 91: packet[j] ^= 0x66
        if i == 42: packet[j] ^= 0x52
        if i == 92: packet[j] ^= 0x9C
        if i == 43: packet[j] ^= 0x43
        if i == 93: packet[j] ^= 0x7B
        if i == 44: packet[j] ^= 0x90
        if i == 94: packet[j] ^= 0xF5
        if i == 45: packet[j] ^= 0x65
        if i == 95: packet[j] ^= 0x85
        if i == 46: packet[j] ^= 0x8F
        if i == 96: packet[j] ^= 0xE1
        if i == 47: packet[j] ^= 0xE2
        if i == 97: packet[j] ^= 0x32
        if i == 48: packet[j] ^= 0x1F
        if i == 98: packet[j] ^= 0x2E
        if i == 49: packet[j] ^= 0xE9
        if i == 99: packet[j] ^= 0x12


riegl_authentication_function = CFUNCTYPE(None, POINTER(c_uint8))(
    riegl_authentication_function
)


def factory_mode_on():
    """
    Enable RDB library factory mode

    Call this function once on startup (or when appropriate) to enable factory
    mode. The factory mode allows to call RDB library API functions which would
    otherwise require a valid software license key.

    Note: By default, the factory mode is activated when this module is
          imported in your application.
    """
    riegl.rdb.library.handle.rdb_factory_set_authentication_function(
        riegl_authentication_function
    )


def factory_mode_off():
    """
    Disable RDB library factory mode

    Call this function right before shutdown (or when appropriate) to disable
    factory mode.
    """
    riegl.rdb.library.handle.rdb_factory_set_authentication_function(
        c_void_p(None)
    )


# by default, we turn the factory mode on...
factory_mode_on()
